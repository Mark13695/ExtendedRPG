package com.modMark.Combat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.modMark.Crafting.MarkInventory;
import com.modMark.Gui.GuiHUDBars;
import com.modMark.Gui.GuiInventory2;
import com.modMark.Main.MainRegistry;
import com.modMark.Packets.CombatLvlPacket;
import com.modMark.Packets.InventoryPacketA;
import com.modMark.Skill.MarkData;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.NameFormat;

public class EventHandlerHUD {
	
	
	public GuiHUDBars HUD;
	private Minecraft mc;

	public EventHandlerHUD(GuiHUDBars hud, Minecraft mcIn){
		
		this.mc = mcIn;
		this.HUD = hud;
	}
	
	@SubscribeEvent
	public void ChatNameChanger(ClientChatReceivedEvent event){
		
			String Chat = event.getMessage().getFormattedText();
			String Chat2 = event.getMessage().getUnformattedText();
			String Finished = null;
			
			String[] splittedChat = new String[2];
			String[] splittedChat2 = new String[2];
			if(Chat.contains(">")){
			splittedChat = Chat.split(">", 2);
			}
			if(Chat2.contains(">")){
			splittedChat2 = Chat2.split(">", 2);
				}
			
			EntityPlayer clientPlayer = this.mc.thePlayer;
			EntityPlayer NamePlayer = null;
			List<NetworkPlayerInfo> players = new ArrayList<>();
			players.addAll(Minecraft.getMinecraft().getConnection().getPlayerInfoMap());
			String name = null;
			for(int i = 0; i < players.size(); i++){
				
					name = "<" + players.get(i).getGameProfile().getName();
				System.out.println(name + " : " + splittedChat2[0] + " : " + name.equals(splittedChat2[0]));
				if(name.equals(splittedChat2[0])){
					System.out.println("check1");
					NamePlayer = this.mc.theWorld.getPlayerEntityByName(players.get(i).getGameProfile().getName());	
					
					System.out.println(players.get(i).getGameProfile().getName() + " : " + (this.mc.theWorld.getPlayerEntityByName("Mark136dev") != null ? this.mc.theWorld.getPlayerEntityByName("Mark136dev").getName() : null));
					break;
				}
			}
			
			if(NamePlayer != null){
				MainRegistry.network.sendToServer(new CombatLvlPacket(clientPlayer, NamePlayer));
				MarkData p = clientPlayer.getCapability(MainRegistry.ModMark136Data, null);
				Finished = name +  TextFormatting.fromColorIndex(this.GetCombatColour(p.Combat2 - p.Combat)) + "[" + p.Combat2 + "]" + TextFormatting.WHITE + ">";
				
			}
			else{
				Finished = name + ">";
				System.err.println("no Player here");
			}
			if(splittedChat[1] != null){
			TextComponentString component = new TextComponentString(Finished + splittedChat[1]);
			event.setMessage(component);
	}}
	
	
	
	@SubscribeEvent(receiveCanceled=true)
	  public void HUDEvent1(RenderGameOverlayEvent.Pre event) {
	    EntityPlayerSP entityPlayerSP = Minecraft.getMinecraft().thePlayer;
	    if (entityPlayerSP == null) return;
	    
	    switch (event.getType()) {
	      case HEALTH:
	        HUD.Draw(event.getResolution().getScaledWidth(), event.getResolution().getScaledHeight());        
	      
	        event.setCanceled(true);
	        break;

	      case ARMOR:
	        event.setCanceled(true);
	        break;
	        
	      case FOOD:
	        event.setCanceled(true);
	        break;
	        
	      case EXPERIENCE:
		    event.setCanceled(true);
		    break;
	        
	      default: 
	        break;
	    }
	    
	    
		}
	
	public void HUDEvent2(RenderGameOverlayEvent.Post event) {
		
		
		 switch (event.getType()) {
	      case TEXT:
	    	  break;
	      default:
	    	  break;
		 }
		
	}
	/** gives the colour of what the combat level should be in.
	 * #difLvls Constains the levels 
	 *  */
	public int GetCombatColour(int difLvls){ //TODO: Find a way to let the chat accepts hex colours
		if(difLvls > 49)return 5; //0xFF00FF;
		else if(difLvls > 14) return 4; //0xFF0000;
		else if(difLvls > 9) return 12; //Remove this line if you can work with HexColours;
		else if(difLvls > 2) return 6; //Remove this line if you can work with HexColours;
		else if(difLvls < -49)return 9; //0x00FF00;
		else if(difLvls < -14)return 3; //0x00FF00;
		else if(difLvls < -9)return 2;//0x0055FF;
		else if(difLvls < -2)return 10; //0x00FF00;
		else return 14;

		
		
	//	Map<Integer, Integer> Colour = new HashMap<Integer, Integer>();
	//	Colour.put(0, 0xFFFF00);
	//	Colour.put(1, 0xFFEE00);
	//	Colour.put(2, 0xFFDD00);
	//	Colour.put(3, 0xFFCC00);
	//	Colour.put(4, 0xFFBB00);
	//	Colour.put(5, 0xFFAA00);
	//	Colour.put(6, 0xFF9900);
	//	Colour.put(7, 0xFF8800);
	//	Colour.put(8, 0xFF7700);
	//	Colour.put(9, 0xFF6600);
	//	Colour.put(10, 0xFF5500);
	//	Colour.put(11, 0xFF4400);
	//	Colour.put(12, 0xFF3300);
	//	Colour.put(13, 0xFF2200);
	//	Colour.put(14, 0xFF1100);
	//	Colour.put(-1, 0xEEFF00);
	//	Colour.put(-2, 0xDDFF00);
	//	Colour.put(-3, 0xCCFF00);
	//	Colour.put(-4, 0xBBFF00);
	//	Colour.put(-5, 0xAAFF00);
	//	Colour.put(-6, 0x99FF00);
	//	Colour.put(-7, 0x88FF00);
	//	Colour.put(-8, 0x77FF00);
	//	Colour.put(-9, 0x66FF00);
	//	Colour.put(-10, 0x55FF00);
	//	Colour.put(-11, 0x44FF00);
	//	Colour.put(-12, 0x33FF00);
	//	Colour.put(-13, 0x22FF00);
	//	Colour.put(-14, 0x11FF00);
		
	//	return Colour.get(difLvls) == null ? 0xFFFFFF : Colour.get(difLvls);
	}
	
	@SubscribeEvent
	public void PlayerContainerEvent(GuiOpenEvent event){
		
		if(event.getGui() instanceof net.minecraft.client.gui.inventory.GuiInventory){	
			
			EntityPlayer player = Minecraft.getMinecraft().thePlayer;
			if(!player.isCreative()){
			event.setGui(new GuiInventory2(player.inventory, new MarkInventory()));
			MainRegistry.network.sendToServer(new InventoryPacketA(player));
			}
			}
		}
}
