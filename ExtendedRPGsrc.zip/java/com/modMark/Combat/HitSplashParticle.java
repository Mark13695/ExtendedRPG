package com.modMark.Combat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

public class HitSplashParticle extends Particle {
	private int AD = 0;

	public HitSplashParticle(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn,
			double ySpeedIn, double zSpeedIn, int AttackDamage, boolean Hurt) {
		super(worldIn, xCoordIn, yCoordIn, zCoordIn, xSpeedIn, ySpeedIn, zSpeedIn);
		motionX = xSpeedIn;
		motionY = ySpeedIn;
		motionZ = zSpeedIn;
		this.AD = AttackDamage;
		if(Hurt){
		TextComponentString AdComp = new TextComponentString(TextFormatting.RED + "" +this.AD);
		}
		this.particleMaxAge = 80;
		this.particleAlpha = 0.99F;
		//TextureAtlasSprite sprite = Minecraft.getMinecraft().getTextureMapBlocks().;
		//setParticleTexture(sprite); TODO: Zorg ervoor dat je die TCS in de TAS kan krijgen
	}
	
	@Override
	  public int getFXLayer()
	  {
	    return 1;
	  }
	
	 @Override
	  public int getBrightnessForRender(float partialTick)
	  {
		 return 0xf000f0;
	  }
	 
	 @Override
	  public boolean isTransparent()
	  {
	    return false;
	  }
	 
	 @Override
	  public void onUpdate()
	  {
	    prevPosX = posX;
	    prevPosY = posY;
	    prevPosZ = posZ;

	    moveEntity(motionX, motionY, motionZ);  
	       motionY += 0.05;

	    
	    if (isCollided) {  
	      this.setExpired();
	    }

	    if (prevPosY == posY && motionY > 0) {  // detect a collision while moving upwards (can't move up at all)
	      this.setExpired();
	    }

	    if (this.particleMaxAge-- <= 0) {
	      this.setExpired();
	    }
	  }
}


