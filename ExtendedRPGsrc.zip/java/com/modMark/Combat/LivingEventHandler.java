package com.modMark.Combat;

import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class LivingEventHandler {

	@SubscribeEvent
	public void AttackEntity(LivingHurtEvent event){
		Entity Damager = event.getSource().getSourceOfDamage();
		Entity Damaged = event.getEntity();
		Boolean isDying = false;
		
		
		if(Damager instanceof EntityPlayer){
			EntityPlayer player = (EntityPlayer)Damager;
			ItemStack WeaponItem = player.getHeldItemMainhand();
			ItemStack WeaponItem2 = player.getHeldItemOffhand();
			String W1 = WeaponItem != null ? player.getHeldItemMainhand().getDisplayName() : null;
			String W2 = WeaponItem2 != null ? player.getHeldItemOffhand().getDisplayName() : null;
			if(event.getSource() != DamageSource.inFire){
		System.out.println("Damager: " + Damager + " , Damaged: " + Damaged);
			}
		}
		else{
			if(event.getSource() != DamageSource.inFire){
			System.out.println("Source: " + event.getSource().damageType + " Damager: " + Damager + " , Damaged: " + Damaged);
			}
		}
		if(Damaged instanceof EntityLiving){
			EntityLiving Li = (EntityLiving)Damaged;
			Li.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0D);
			if(!(Damaged instanceof EntityPlayer)){
			MobData p1 = Li.getCapability(MainRegistry.ModMark136MobData, null);
			int CurHP = p1.getHP();
			p1.setHP(Math.max(CurHP - (int)event.getAmount(), 0));
			if(p1.getHP() == 0){
				event.setAmount(Li.getMaxHealth());
				isDying = true;
			}
			}
		}
		if(Damaged instanceof EntityPlayer){
			EntityPlayer pl = (EntityPlayer)Damaged;
			pl.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0D);
			MarkData p2 = pl.getCapability(MainRegistry.ModMark136Data, null);
			int CurHP2 = p2.getHP();
			p2.setHP(Math.max(CurHP2 - (int)event.getAmount(), 0));
			if(p2.getHP() == 0){
				event.setAmount(20.0F);
				isDying = true;
			}
		}
		
		
		if(!isDying){
		event.setAmount(0.0F);
		}
	}
	@SubscribeEvent
	public void HealEntity(LivingHealEvent event){		
		event.setAmount(0);
	}
	@SubscribeEvent
	public void AttackEntity(AttackEntityEvent event){	
		EntityPlayer player = event.getEntityPlayer();
		boolean canSwing = player.getCooledAttackStrength(0.0F) != 1;
		event.setCanceled(canSwing);
	}
	
}
