package com.modMark.Combat;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class MarkArrow extends EntityTippedArrow {

	private ItemStack stack;
	

	public MarkArrow(World worldIn, EntityLivingBase shooter, ItemStack Stack) {
		super(worldIn, shooter);
		this.stack = Stack;
		this.pickupStatus = EntityArrow.PickupStatus.DISALLOWED;
	}
	
	public ItemStack getArrowType(){
		return this.stack;
	}

}
