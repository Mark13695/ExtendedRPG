package com.modMark.Combat;

import javax.annotation.Nullable;

import net.minecraft.entity.Entity;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSourceIndirect;

public class MarkDamageSrc {
	
	public static DamageSource CapturedByTrap = new DamageSource("CapturedByTrap").setDamageBypassesArmor();
	public static DamageSource RangedAttack = new DamageSource("RangedCB").setDamageBypassesArmor();
	public static DamageSource MagicAttack = new DamageSource("MagicCB").setDamageBypassesArmor();
	
	
	
	public static DamageSource CauseRangedDamage(Entity source, @Nullable Entity indirect){
		 return (new EntityDamageSourceIndirect("RangedCB", source, indirect)).setProjectile();
	}
	public static DamageSource CauseMagicDamage(Entity source, @Nullable Entity indirect){
		 return (new EntityDamageSourceIndirect("MagicCB", source, indirect)).setProjectile();
	}
}
