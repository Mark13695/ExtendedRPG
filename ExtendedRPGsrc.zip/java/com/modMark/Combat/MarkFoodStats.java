package com.modMark.Combat;

import com.modMark.Main.MainRegistry;
import com.modMark.Packets.HiscorePacketC;
import com.modMark.Packets.PacketHUD;
import com.modMark.Skill.MarkData;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.util.FoodStats;
import net.minecraft.world.EnumDifficulty;

public class MarkFoodStats extends FoodStats {

	
	private int MarkFoodLevel = 0;
	private float HealVal = 0.0F;
	private int FoodTimer = 0;
	private int RegenTimer = 0;
	
	public MarkFoodStats(){
		this.setFoodLevel(10);
		
	}
	
	/**
     * Add food stats.
     */
    public void addStats(int foodLevelIn, float foodSaturationModifier)
    {
    	if(this.MarkFoodLevel < 100)
        this.MarkFoodLevel += foodLevelIn * 5;
        this.HealVal = 4.0F;
    }

    public void addStats(ItemFood foodItem, ItemStack stack)
    {
        this.addStats(foodItem.getHealAmount(stack), foodItem.getSaturationModifier(stack));
    }
	
	@Override
	public void onUpdate(EntityPlayer player)
    {
		if(this.MarkFoodLevel > 0){
			if(this.FoodTimer < 60){
			this.FoodTimer++;
			}
			else{
				this.MarkFoodLevel--;
				if(player instanceof EntityPlayerMP){
				MainRegistry.network.sendTo(new PacketHUD(this.MarkFoodLevel, player), (EntityPlayerMP) player);
				}
				this.FoodTimer = 0;
			}
		}
		MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
		EnumDifficulty d = player.worldObj.getDifficulty();
		if(this.HealVal > 0.0F){
		 int hp1 = p.getHP();
			p.setHP(hp1 + (int)this.HealVal);
			this.HealVal = 0.0F;
		}
		if(p.getHP() < p.getMaxHP() && d != EnumDifficulty.HARD){
			int k = d == EnumDifficulty.NORMAL ? 2 : 1;
			if(this.RegenTimer < (200 - ((p.Level[0] != 0 ? p.Level[0] : 1) / 255)* 190) * k){
			this.RegenTimer++;
			}	
		else{
			int hp2 = p.getHP();
			p.setHP(hp2 + 1);
			this.HealVal = 0.0F;
			this.RegenTimer = 0;
		}
		}
    }
	@Override
	public boolean needFood()
    {
        return this.MarkFoodLevel < 100;
    }
	
	public int getFoodLevel2(){
		return this.MarkFoodLevel;
	}
	public void setFoodLevel2(int lvl){
		this.MarkFoodLevel = lvl;
	}
}
