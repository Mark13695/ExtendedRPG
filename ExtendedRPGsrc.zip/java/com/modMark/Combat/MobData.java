package com.modMark.Combat;

import java.util.List;
import java.util.concurrent.Callable;

import com.modMark.Main.MainRegistry;
import com.modMark.Packets.CombatLvlPacket4;
import com.modMark.Packets.CombatLvlPacketHP;
import com.modMark.Packets.SkillPacket;
import com.modMark.Skill.MarkData;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class MobData implements ICapabilityProvider, INBTSerializable<NBTTagCompound> {

	public EntityLiving entity;
	public int Cb;
	public float Accuracy;
	public float defence;
	private int HP = 0;
	private int MaxHp = 0;
	
	public MobData(EntityLiving ent){
		this.entity = ent;
		
	}
	
	public void SyncCb(EntityPlayer player){
		MainRegistry.network.sendTo(new CombatLvlPacket4(this.Cb , this.entity, (EntityPlayerMP) player), (EntityPlayerMP) player);
		MainRegistry.network.sendTo(new CombatLvlPacketHP((EntityPlayerMP) player,this.HP, this.entity, this.MaxHp, false, false), (EntityPlayerMP) player);
	}
	
	public void setCombat(int CB){
		this.Cb = CB;
		if (entity instanceof EntityIronGolem){
			this.setMaxHP(2500);
			this.HP = 2500;
		}
		else if (entity instanceof EntityVillager){
			this.setMaxHP(500);
			this.HP = 500;
		}
		else if (entity instanceof EntityZombie || entity instanceof EntitySkeleton || entity instanceof EntitySpider || entity instanceof EntityWolf){
		this.setMaxHP(80 + (15 * this.Cb));
		this.HP = 80 + (15 * this.Cb);
		}
		else{
			this.setMaxHP(80);
			this.HP = 80;
		}
		
	}
	public int getCombat(){
		return this.Cb;
	}
	public int getHP(){
		return this.HP;
	}
	public int getMaxHP(){
		return this.MaxHp;
	}
	public void setHP(int hp){
		this.HP = hp;
		if(!this.entity.worldObj.isRemote){
		List <EntityPlayerMP> players =  FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().getPlayerList();
		for (int i = 0; i < players.size();i++){
			MainRegistry.network.sendTo(new CombatLvlPacketHP(players.get(i),this.HP, this.entity, this.MaxHp, false, false), players.get(i));
			}
		}
	}
	public void setMaxHP(int mhp){
		if(mhp <= 0){
			throw new IllegalArgumentException("you cant set hp to zero");
		}
		this.MaxHp = mhp;
	}
	
	public static void register()
	{
		CapabilityManager.INSTANCE.register(MobData.class, new MobData.Storage(), new MobData.Factory());
	
	}
	
	public float getMaxHealth(){
		if (entity instanceof EntityZombie || entity instanceof EntitySkeleton || entity instanceof EntitySpider){
			return 80 + (15 * this.Cb);
		}
		else{
			return entity.getMaxHealth();
		}
	}
	
	
	@Override
	public NBTTagCompound serializeNBT() {
		NBTTagCompound combat = new NBTTagCompound();
		combat.setInteger("MobCB136", this.getCombat());
		return combat;
	}

	@Override
	public void deserializeNBT(NBTTagCompound nbt) {
		int readCb = 0;
		if(nbt.hasKey("MobCB136", 3)){
		readCb = nbt.getInteger("MobCB136");
		}
		this.setCombat(readCb); 
	}


	
	
	@Override
	public boolean hasCapability(Capability<?> capability, EnumFacing facing) {

		return MainRegistry.ModMark136MobData != null && capability == MainRegistry.ModMark136MobData;
	}

	@Override
	public <T> T getCapability(Capability<T> capability, EnumFacing facing) {

		return MainRegistry.ModMark136MobData != null && capability == MainRegistry.ModMark136MobData ? (T)this : null;

	}
	
	public static class Storage implements Capability.IStorage<MobData>
    {

        @Override
        public NBTBase writeNBT(Capability<MobData> capability, MobData instance, EnumFacing side)
        {
            return null;
        }

        @Override
        public void readNBT(Capability<MobData> capability, MobData instance, EnumFacing side, NBTBase nbt)
        {

        }

    }
 
	
 public static class Factory implements Callable<MobData>
    {
        @Override
        public MobData call() throws Exception
        {
            return null;
        }
    }


}
