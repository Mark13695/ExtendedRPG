package com.modMark.Crafting;

import java.util.ArrayList;
import java.util.List;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Item_Block.TileEntity.TECraftingTable;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class MarkContainer extends Container{
	
	private TECraftingTable TE;
	public List<ItemStack> Stacks = new ArrayList<>();
	

	public MarkContainer(InventoryPlayer invPlayer, TECraftingTable te){
		this.TE = te;
		
		
		for (int x = 0; x < 9; x++){	
			addSlotToContainer(new Slot(invPlayer, x, 49 + (18 * x), 198));
		}for (int x = 0; x < 9; x++){
			addSlotToContainer(new Slot(invPlayer, x + 9, 49 + (18 * x), 140));
		}for (int x = 0; x < 9; x++){
			addSlotToContainer(new Slot(invPlayer, x + 18, 49 + (18 * x), 158));
		}for (int x = 0; x < 9; x++){
			addSlotToContainer(new Slot(invPlayer, x + 27, 49 + (18 * x), 176));
		}
			
			
		
		
		
		
		
		for (int x = 0; x < 4; x++){
			
			addSlotToContainer(new Slot(TE, 3 * x, 5, 5 +(18 * x)));
			addSlotToContainer(new Slot(TE, 1 + (3 * x), 23, 5 +(18 * x)));
			addSlotToContainer(new Slot(TE, 2 + (3 * x), 41, 5 +(18 * x)));
			
			addSlotToContainer(new MarkFinishedSlot(TE, 12 + (3 * x), 83, 5 +(18 * x)));
			addSlotToContainer(new MarkFinishedSlot(TE, 13 + (3 * x), 101, 5 +(18 * x)));
			addSlotToContainer(new MarkFinishedSlot(TE, 14 + (3 * x), 119, 5 +(18 * x)));
		}
			
		
		Block block = TE.getBlockType();
		boolean b = block != MarkBlocks.BasicTable && block != MarkBlocks.TailoryBench_I && block != MarkBlocks.Anvil_I && block != MarkBlocks.TanningBench_I && block != MarkBlocks.JewelryTable_I && block != MarkBlocks.FletchingTable_I && block != MarkBlocks.Cauldron_I && block != MarkBlocks.WorkBench_I;
		if(b){
		addSlotToContainer(new Slot(TE, 24, 60, 59));
		}
		addSlotToContainer(new MarkShowcaseSlot(TE, 25, 156, 9));// slot 25 crafting
	this.GetShowcaseItems("");
	
		
		
		
		
}
	
	
	
	public List<ItemStack> GetShowcaseItems(String s){
		
		this.Stacks.clear();
		
		
		
		Block block = TE.getBlockType();
		
		
		if(block == MarkBlocks.BasicTable){
			
			this.Stacks.add(new ItemStack(MarkBlocks.BasicTable));
			this.Stacks.add(new ItemStack(MarkBlocks.TailoryBench_I));
			this.Stacks.add(new ItemStack(MarkBlocks.Anvil_I));
			this.Stacks.add(new ItemStack(MarkBlocks.Furnace_I));
			this.Stacks.add(new ItemStack(MarkBlocks.TanningBench_I));
			this.Stacks.add(new ItemStack(MarkBlocks.JewelryTable_I));
			this.Stacks.add(new ItemStack(MarkBlocks.GlassOven_I));
			this.Stacks.add(new ItemStack(MarkBlocks.FletchingTable_I));
			this.Stacks.add(new ItemStack(MarkBlocks.Range_I));
			this.Stacks.add(new ItemStack(MarkBlocks.Cauldron_I));
			this.Stacks.add(new ItemStack(MarkBlocks.WorkBench_I));
			this.Stacks.add(new ItemStack(MarkBlocks.MarkTrapE));
			this.Stacks.add(new ItemStack(Blocks.PLANKS));
			this.Stacks.add(new ItemStack(Items.STICK));
			this.Stacks.add(new ItemStack(Blocks.TORCH));
			this.Stacks.add(new ItemStack(Blocks.CHEST));
			this.Stacks.add(new ItemStack(MarkItems.FishRod));
			this.Stacks.add(new ItemStack(Items.WOODEN_AXE));
			this.Stacks.add(new ItemStack(Items.WOODEN_SHOVEL));
			this.Stacks.add(new ItemStack(Items.WOODEN_PICKAXE));
			this.Stacks.add(new ItemStack(Items.WOODEN_HOE));
			this.Stacks.add(new ItemStack(Items.WOODEN_SWORD));
			this.Stacks.add(new ItemStack(Items.BOW));
			this.Stacks.add(new ItemStack(Blocks.WOOL));
			this.Stacks.add(new ItemStack(Items.PAPER));
			this.Stacks.add(new ItemStack(Items.SUGAR));
			
			
			
		}
		else if(block == MarkBlocks.TailoryBench_I || block ==  MarkBlocks.TailoryBench_II){
			this.Stacks.add(new ItemStack(Blocks.WOOL));
			this.Stacks.add(new ItemStack(Items.PAPER));
			this.Stacks.add(new ItemStack(Items.BOOK));
			
			this.Stacks.add(new ItemStack(MarkItems.Book20));
			this.Stacks.add(new ItemStack(MarkItems.Silk20));
			this.Stacks.add(new ItemStack(MarkItems.Book40));
			this.Stacks.add(new ItemStack(MarkItems.Silk40));
			
			if (block == MarkBlocks.TailoryBench_II){
				this.Stacks.add(new ItemStack(MarkItems.Book60));
				this.Stacks.add(new ItemStack(MarkItems.Silk60));
				this.Stacks.add(new ItemStack(MarkItems.Book80));
				this.Stacks.add(new ItemStack(MarkItems.Silk80));		
			}
		}
		else if(block == MarkBlocks.Anvil_I || block ==  MarkBlocks.Anvil_II){
			
			this.Stacks.add(new ItemStack(Items.WOODEN_AXE));
			this.Stacks.add(new ItemStack(Items.WOODEN_SHOVEL));
			this.Stacks.add(new ItemStack(Items.WOODEN_PICKAXE));
			this.Stacks.add(new ItemStack(Items.WOODEN_HOE));
			this.Stacks.add(new ItemStack(Items.WOODEN_SWORD));
			this.Stacks.add(new ItemStack(Items.STONE_PICKAXE));
			this.Stacks.add(new ItemStack(Items.STONE_AXE));
			this.Stacks.add(new ItemStack(Items.STONE_SHOVEL));
			this.Stacks.add(new ItemStack(Items.STONE_HOE));
			this.Stacks.add(new ItemStack(Items.STONE_SWORD));
			this.Stacks.add(new ItemStack(Items.SHEARS));
			this.Stacks.add(new ItemStack(Items.IRON_PICKAXE));
			this.Stacks.add(new ItemStack(Items.IRON_AXE));
			this.Stacks.add(new ItemStack(Items.IRON_SHOVEL));
			this.Stacks.add(new ItemStack(Items.IRON_HOE));
			this.Stacks.add(new ItemStack(Items.IRON_SWORD));
			this.Stacks.add(new ItemStack(Items.IRON_BOOTS));
			this.Stacks.add(new ItemStack(Items.IRON_HELMET));
			this.Stacks.add(new ItemStack(Items.BUCKET));
			this.Stacks.add(new ItemStack(Items.IRON_LEGGINGS));
			this.Stacks.add(new ItemStack(Items.IRON_CHESTPLATE));
			this.Stacks.add(new ItemStack(Items.GOLDEN_PICKAXE));
			this.Stacks.add(new ItemStack(Items.GOLDEN_AXE));
			this.Stacks.add(new ItemStack(Items.GOLDEN_SHOVEL));
			this.Stacks.add(new ItemStack(Items.GOLDEN_HOE));
			this.Stacks.add(new ItemStack(Items.GOLDEN_SWORD));
			this.Stacks.add(new ItemStack(Items.GOLDEN_BOOTS));
			this.Stacks.add(new ItemStack(Items.GOLDEN_HELMET));
			this.Stacks.add(new ItemStack(Items.GOLDEN_LEGGINGS));
			this.Stacks.add(new ItemStack(Items.GOLDEN_CHESTPLATE));
			this.Stacks.add(new ItemStack(Items.DIAMOND_PICKAXE));
			this.Stacks.add(new ItemStack(Items.DIAMOND_AXE));
			this.Stacks.add(new ItemStack(Items.DIAMOND_SHOVEL));
			this.Stacks.add(new ItemStack(Items.DIAMOND_HOE));
			this.Stacks.add(new ItemStack(Items.DIAMOND_SWORD));
			this.Stacks.add(new ItemStack(Items.DIAMOND_BOOTS));
			this.Stacks.add(new ItemStack(Items.DIAMOND_HELMET));
			this.Stacks.add(new ItemStack(Items.DIAMOND_LEGGINGS));
			this.Stacks.add(new ItemStack(Items.DIAMOND_CHESTPLATE));
			
			
			
			
		}
		else if(block == MarkBlocks.Furnace_I || block ==  MarkBlocks.Furnace_II){
			
			this.Stacks.add(new ItemStack(Blocks.STONE));
			this.Stacks.add(new ItemStack(Items.COAL, 1, 1));
			this.Stacks.add(new ItemStack(Items.DYE, 1, 2));
			this.Stacks.add(new ItemStack(Items.BRICK));
			this.Stacks.add(new ItemStack(Items.IRON_INGOT));
			this.Stacks.add(new ItemStack(Items.DYE, 1, 4));
			this.Stacks.add(new ItemStack(Blocks.STONEBRICK, 1, 2));
			this.Stacks.add(new ItemStack(Items.GOLD_INGOT));
			
			if(block ==  MarkBlocks.Furnace_II){
				this.Stacks.add(new ItemStack(Items.NETHERBRICK));
				this.Stacks.add(new ItemStack(MarkItems.NetheriteBar));
				this.Stacks.add(new ItemStack(MarkBlocks.CrystBricks));
				this.Stacks.add(new ItemStack(MarkItems.CrystliumBar));
			}
			
		}
			
		else if(block == MarkBlocks.TanningBench_I || block ==  MarkBlocks.TanningBench_II){
			
			this.Stacks.add(new ItemStack(Items.LEATHER));
			this.Stacks.add(new ItemStack(Items.BOOK));
			this.Stacks.add(new ItemStack(Items.LEATHER_BOOTS));
			this.Stacks.add(new ItemStack(Items.LEATHER_HELMET));
			this.Stacks.add(new ItemStack(Items.LEATHER_LEGGINGS));
			this.Stacks.add(new ItemStack(Items.LEATHER_CHESTPLATE));
			this.Stacks.add(new ItemStack(MarkItems.Book20));
			this.Stacks.add(new ItemStack(MarkItems.Leather20));
			this.Stacks.add(new ItemStack(MarkItems.Book40));
			this.Stacks.add(new ItemStack(MarkItems.Leather40));
			
			if (block == MarkBlocks.TanningBench_II){
				this.Stacks.add(new ItemStack(MarkItems.Book60));
				this.Stacks.add(new ItemStack(MarkItems.Leather60));
				this.Stacks.add(new ItemStack(MarkItems.Book80));
				this.Stacks.add(new ItemStack(MarkItems.Leather80));	
			
			}
		}
		else if(block == MarkBlocks.JewelryTable_I || block ==  MarkBlocks.JewelryTable_II){
			
		
			
			
			
		}
		else if(block == MarkBlocks.GlassOven_I || block ==  MarkBlocks.GlassOven_II){
			
			this.Stacks.add(new ItemStack(MarkBlocks.DirtGlass));
			this.Stacks.add(new ItemStack(MarkItems.GemOpal));
			this.Stacks.add(new ItemStack(MarkItems.GemSapphire));
			this.Stacks.add(new ItemStack(MarkBlocks.GravelGlass));
			this.Stacks.add(new ItemStack(MarkItems.GemOlivine));
			this.Stacks.add(new ItemStack(MarkItems.GemHyacinth));
			this.Stacks.add(new ItemStack(Blocks.GLASS));
			this.Stacks.add(new ItemStack(MarkItems.GemTopaz));
			this.Stacks.add(new ItemStack(MarkItems.GemAmethyst));
			if(block ==  MarkBlocks.GlassOven_II){
			
			this.Stacks.add(new ItemStack(MarkBlocks.NetherGlass));
			this.Stacks.add(new ItemStack(MarkItems.GemSiam));
			this.Stacks.add(new ItemStack(MarkBlocks.SoulGlass));
			this.Stacks.add(new ItemStack(MarkBlocks.CrystGlass));
			this.Stacks.add(new ItemStack(MarkItems.GemAquamarine));
			this.Stacks.add(new ItemStack(MarkBlocks.CyantinianGlass));
			}
			
		}
		else if(block == MarkBlocks.FletchingTable_I || block ==  MarkBlocks.FletchingTable_II){
			
			this.Stacks.add(new ItemStack(Items.STICK));
			this.Stacks.add(new ItemStack(Items.BOW));
			this.Stacks.add(new ItemStack(MarkItems.Stick10));
			this.Stacks.add(new ItemStack(MarkItems.TrapKey));
			this.Stacks.add(new ItemStack(MarkItems.Stick20));
			this.Stacks.add(new ItemStack(MarkItems.Stick40));
			if(block ==  MarkBlocks.FletchingTable_II){
			this.Stacks.add(new ItemStack(MarkItems.Stick60));
			this.Stacks.add(new ItemStack(MarkItems.Stick80));
			}
		}
		
		else if(block == MarkBlocks.Range_I || block ==  MarkBlocks.Range_II){
			this.Stacks.add(new ItemStack(MarkItems.Cod_Cooked));
			this.Stacks.add(new ItemStack(Items.COOKED_BEEF));
			this.Stacks.add(new ItemStack(Items.COOKED_CHICKEN));
			this.Stacks.add(new ItemStack(Items.COOKED_MUTTON));
			this.Stacks.add(new ItemStack(Items.COOKED_PORKCHOP));
			this.Stacks.add(new ItemStack(Items.COOKED_RABBIT));
			this.Stacks.add(new ItemStack(Items.SUGAR));
			this.Stacks.add(new ItemStack(Items.BREAD));
			this.Stacks.add(new ItemStack(MarkItems.Trout_Cooked));
			this.Stacks.add(new ItemStack(MarkItems.Sardine_Cooked));
			this.Stacks.add(new ItemStack(Items.COOKED_FISH, 1, 1));
			this.Stacks.add(new ItemStack(MarkItems.Tuna_Cooked));
			this.Stacks.add(new ItemStack(MarkItems.CakeUnf));
			this.Stacks.add(new ItemStack(Items.CAKE));
			
		
			if(block ==  MarkBlocks.Range_II){
				this.Stacks.add(new ItemStack(MarkItems.Herring_Cooked));
				this.Stacks.add(new ItemStack(MarkItems.Bass_Cooked));
				this.Stacks.add(new ItemStack(MarkItems.Eel_Cooked));
				this.Stacks.add(new ItemStack(MarkItems.Batiod_Cooked));
				this.Stacks.add(new ItemStack(MarkItems.Shark_Cooked));
			}
		}
			else if(block == MarkBlocks.Cauldron_I || block ==  MarkBlocks.Cauldron_II){
				this.Stacks.add(new ItemStack(Items.DYE, 1, 1));
				
				
			}
			else if(block == MarkBlocks.WorkBench_I || block ==  MarkBlocks.WorkBench_II){
				this.Stacks.add(new ItemStack(Blocks.PLANKS));
				this.Stacks.add(new ItemStack(Blocks.CHEST));
				this.Stacks.add(new ItemStack(Blocks.TORCH));
				this.Stacks.add(new ItemStack(MarkBlocks.MarkTrapE));
				this.Stacks.add(new ItemStack(Blocks.WOODEN_SLAB, 1, 0));
				this.Stacks.add(new ItemStack(Items.BOAT));
				this.Stacks.add(new ItemStack(Blocks.OAK_STAIRS));
				this.Stacks.add(new ItemStack(Blocks.LADDER));
				this.Stacks.add(new ItemStack(Items.BOWL));
				this.Stacks.add(new ItemStack(Blocks.OAK_FENCE));
				this.Stacks.add(new ItemStack(Blocks.SANDSTONE));
				this.Stacks.add(new ItemStack(Blocks.GLASS_PANE));
				this.Stacks.add(new ItemStack(Blocks.RED_SANDSTONE));
				this.Stacks.add(new ItemStack(Blocks.STONE_SLAB, 1, 1));
				this.Stacks.add(new ItemStack(Blocks.STONE_SLAB2));
				this.Stacks.add(new ItemStack(Blocks.RED_SANDSTONE_STAIRS));
				this.Stacks.add(new ItemStack(Blocks.SANDSTONE_STAIRS));
				this.Stacks.add(new ItemStack(Blocks.RED_SANDSTONE_STAIRS));
				this.Stacks.add(new ItemStack(Items.OAK_DOOR));
				this.Stacks.add(new ItemStack(Blocks.OAK_FENCE_GATE));
				this.Stacks.add(new ItemStack(Blocks.TRAPDOOR));
				this.Stacks.add(new ItemStack(Items.BED));
				this.Stacks.add(new ItemStack(Blocks.STONE_SLAB, 1, 0));
				this.Stacks.add(new ItemStack(Blocks.STONE_SLAB, 1, 3));
				this.Stacks.add(new ItemStack(Blocks.STONE_STAIRS));
				this.Stacks.add(new ItemStack(Blocks.BRICK_BLOCK));
				this.Stacks.add(new ItemStack(Blocks.STONE_SLAB, 1, 4));
				this.Stacks.add(new ItemStack(Blocks.BRICK_STAIRS));
				this.Stacks.add(new ItemStack(Items.FLOWER_POT));
				
				this.Stacks.add(new ItemStack(Blocks.PLANKS, 1 , 4));
				this.Stacks.add(new ItemStack(Items.ACACIA_BOAT));
				this.Stacks.add(new ItemStack(Blocks.WOODEN_SLAB, 1, 4));
				this.Stacks.add(new ItemStack(Blocks.ACACIA_STAIRS));
				this.Stacks.add(new ItemStack(Blocks.ACACIA_FENCE));
				this.Stacks.add(new ItemStack(Items.ACACIA_DOOR));
				this.Stacks.add(new ItemStack(Blocks.ACACIA_FENCE_GATE));
				this.Stacks.add(new ItemStack(Blocks.STONEBRICK));
				this.Stacks.add(new ItemStack(Blocks.STONE_SLAB, 1, 5));
				this.Stacks.add(new ItemStack(Blocks.STONE_BRICK_STAIRS));
				this.Stacks.add(new ItemStack(MarkBlocks.LogYew_Planks));
				this.Stacks.add(new ItemStack(MarkBlocks.LogYew_stairs));
				this.Stacks.add(new ItemStack(MarkItems.LogYew_Door));
				if(block ==  MarkBlocks.WorkBench_II){
				this.Stacks.add(new ItemStack(MarkBlocks.LogNetherBranch_Planks));
				this.Stacks.add(new ItemStack(MarkItems.LogNetherBranch_Door));
				this.Stacks.add(new ItemStack(Blocks.NETHER_BRICK));
				this.Stacks.add(new ItemStack(Blocks.STONE_SLAB, 1, 6));
				this.Stacks.add(new ItemStack(Blocks.NETHER_BRICK_STAIRS));
				this.Stacks.add(new ItemStack(Blocks.NETHER_BRICK_FENCE));
				
				this.Stacks.add(new ItemStack(MarkBlocks.LogCrystWood_Planks));
				this.Stacks.add(new ItemStack(MarkItems.LogCrystWood_Door));
				}
				
				
			}
		
		
		
		
		int i23 = this.Stacks.size() - 1;
		if (!s.isEmpty()){
			for (i23 = (this.Stacks.size() - 1); i23 >= 0; i23--){
				for (int i = 0; i < 1; i++){
			if (!this.Stacks.get(i23).getDisplayName().toLowerCase().contains(s.toLowerCase())){
				this.Stacks.remove(i23);
			}
			

			}
		}
		}
		
		if(TE.getSizeInventory() > 26){
			int ShowcaseSlots = TE.getSizeInventory() - 26;
			if(this.Stacks.size() < ShowcaseSlots){
			for (int i = this.Stacks.size(); i < ShowcaseSlots; i++){
				TE.removeStackFromSlot(i + 26);
				
				
			}
		}
		}
		
		this.addShowcaseSlots();
		this.scrollTo(0.0F);
		return this.Stacks;
		
	}
	
	
	
	
	public void addShowcaseSlots(){
		
			//addSlotToContainer(new MarkShowcaseSlot(TE, 26, 139, 48));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 27, 157, 48));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 28, 175, 48));
			//addSlotToContainer(new MarkShowcaseSlot(TE, 29, 193, 48));
			//addSlotToContainer(new MarkShowcaseSlot(TE, 30, 139, 66));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 31, 157, 66));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 32, 175, 66));
			//addSlotToContainer(new MarkShowcaseSlot(TE, 33, 193, 66));
			//addSlotToContainer(new MarkShowcaseSlot(TE, 34, 139, 84));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 35, 157, 84));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 36, 175, 84));
			//addSlotToContainer(new MarkShowcaseSlot(TE, 37, 193, 84));
			//addSlotToContainer(new MarkShowcaseSlot(TE, 38, 139, 102));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 39, 157, 102));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 40, 175, 102));
			//addSlotToContainer(new MarkShowcaseSlot(TE, 41, 193, 102));
			//addSlotToContainer(new MarkShowcaseSlot(TE, 42, 139, 120));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 43, 157, 120));	
			//addSlotToContainer(new MarkShowcaseSlot(TE, 44, 175, 120));
			//addSlotToContainer(new MarkShowcaseSlot(TE, 45, 193, 120));
						
		
	}
	
	@Override
	public boolean canInteractWith(EntityPlayer playerIn) {
		
		return TE.isUseableByPlayer(playerIn);
	}
	
	
	
	@Override
	public ItemStack transferStackInSlot(EntityPlayer playerIn, int index)
	{
		Slot sourceSlot = (Slot)inventorySlots.get(index);
		if (sourceSlot == null || !sourceSlot.getHasStack()) return null;
		ItemStack sourceStack = sourceSlot.getStack();
		ItemStack copyOfSourceStack = sourceStack.copy();

		// Check if the slot clicked is one of the vanilla container slots
		if (index >= 0 && index < 36) {
			// This is a vanilla container slot so merge the stack into the tile inventory
			if (!mergeItemStack(sourceStack, 36, 48, false)){
				return null;
			}
		} else if (index >= 36 && index < 60) {
			// This is a TE slot so merge the stack into the players inventory
			if (!mergeItemStack(sourceStack, 0, 36, false)) {
				return null;
			}
		} else {
			System.err.print("Invalid slotIndex:" + index);
			return null;
		}

		// If stack size == 0 (the entire stack was moved) set slot contents to null
		if (sourceStack.stackSize == 0) {
			sourceSlot.putStack(null);
		} else {
			sourceSlot.onSlotChanged();
		}

		sourceSlot.onPickupFromSlot(playerIn, sourceStack);
		return copyOfSourceStack;
	}
	
	@Override
	public void onContainerClosed(EntityPlayer playerIn)
	{
		super.onContainerClosed(playerIn);
		this.TE.closeInventory(playerIn);
	}
	
	 public void scrollTo(float posValue)
     {
         int ExtraRows = (this.Stacks.size() + 4 - 1) / 4 - 5;
         int j = (int)((double)(posValue * (float)ExtraRows) + 0.5D);  //vermenigvuldigd de posValue met de Extra rijen en zorgd voor een normale afronding.

         if (j < 0)
         {
             j = 0;
         }

         for (int RowNo = 0; RowNo < 5; ++RowNo)
         {
             for (int SlotinRow = 0; SlotinRow < 4; ++SlotinRow)
             {
                 int i1 = SlotinRow + (RowNo + j) * 4;

                 if (i1 >= 0 && i1 < this.Stacks.size())
                 {
                	 this.TE.setInventorySlotContents(SlotinRow + RowNo * 4 + 26, (ItemStack)this.Stacks.get(i1));
                 }
                 else
                 {
                	 this.TE.setInventorySlotContents(SlotinRow + RowNo * 4 + 26, (ItemStack)null);
                 }
             }
         }
     }

	 
}
