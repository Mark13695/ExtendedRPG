package com.modMark.Crafting;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.annotation.Nullable;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Main.MainRegistry;
import com.modMark.Packets.CraftingPacketB;
import com.modMark.Packets.CraftingPacketC;
import com.modMark.Packets.InventoryPacketB;
import com.modMark.Skill.MarkData;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ITickable;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class MarkContainerInv extends Container {
	public MarkInventory Showcase;
	public InventoryPlayer invP;
	private int CurrentCraftProgness;
	private int MaxCraftProgness;
	private int CraftVal;
	public int GainedXP;
	private ItemStack[] IngrList = new ItemStack[3];
	private boolean addremIngr;
	
	
	public MarkContainerInv(InventoryPlayer invPlayer, MarkInventory inv){
		this.Showcase = inv;
		this.invP = invPlayer;
	
		
		for (int x = 0; x < 9; x++){	
			addSlotToContainer(new Slot(invPlayer, x, 38 + (18 * x), 198));
		}for (int x = 0; x < 9; x++){
			addSlotToContainer(new Slot(invPlayer, x + 9, 38 + (18 * x), 139));
		}for (int x = 0; x < 9; x++){
			addSlotToContainer(new Slot(invPlayer, x + 18, 38 + (18 * x), 157));
		}for (int x = 0; x < 9; x++){
			addSlotToContainer(new Slot(invPlayer, x + 27, 38 + (18 * x), 175));	
		}
		
		
		for (int x = 0; x < 4; x++){
			addSlotToContainer(new SlotArmour(invPlayer, x, 39 - x, 5, 7 + (18 * x)));
		}
			addSlotToContainer(new Slot(invPlayer, 40, 77, 61));
			
			
			addSlotToContainer(new MarkShowcaseSlot(inv, 0, 140, 43));
			addSlotToContainer(new MarkShowcaseSlot(inv, 1, 158, 43));
			addSlotToContainer(new MarkShowcaseSlot(inv, 2, 176, 43));
			addSlotToContainer(new MarkShowcaseSlot(inv, 3, 194, 43));
			addSlotToContainer(new MarkShowcaseSlot(inv, 4, 212, 43));
			
			addSlotToContainer(new MarkShowcaseSlot(inv, 5, 140, 61));
			addSlotToContainer(new MarkShowcaseSlot(inv, 6, 158, 61));
			addSlotToContainer(new MarkShowcaseSlot(inv, 7, 176, 61));
			addSlotToContainer(new MarkShowcaseSlot(inv, 8, 194, 61));
			addSlotToContainer(new MarkShowcaseSlot(inv, 9, 212, 61));
			
			addSlotToContainer(new MarkShowcaseSlot(inv, 10, 140, 79));
			addSlotToContainer(new MarkShowcaseSlot(inv, 11, 158, 79));
			addSlotToContainer(new MarkShowcaseSlot(inv, 12, 176, 79));
			addSlotToContainer(new MarkShowcaseSlot(inv, 13, 194, 79));
			addSlotToContainer(new MarkShowcaseSlot(inv, 14, 212, 79));
			
			addSlotToContainer(new MarkShowcaseSlot(inv, 15, 158, 97));
			addSlotToContainer(new MarkShowcaseSlot(inv, 16, 176, 97));
			addSlotToContainer(new MarkShowcaseSlot(inv, 17, 194, 97));
			
			addSlotToContainer(new MarkShowcaseSlot(inv, 18, 157, 12));
			
			this.Showcase.fillStacks();
	}
	
	public ItemStack[] getInventory2(){
		ItemStack[] stack2 = new ItemStack[35];
		int[] stackSize = new int[35];
		for (int i = 0; i < 35; i++){
			stack2[i] = this.invP.getStackInSlot(i);
			stackSize[i] = this.invP.getStackInSlot(i) != null ? stackSize[i] = this.invP.getStackInSlot(i).stackSize : 0;
		
		}
		
		for(int i1 = 0; i1 < 35; i1++){
			for(int i2 = 0; i2 < 35; i2++){
			if (i1 != i2){
				if(stack2[i1] != null && stack2[i2] != null){
				if(stack2[i1].getItem() == stack2[i2].getItem()){
					if(stack2[i1].getMetadata() == stack2[i2].getMetadata()){
					stackSize[i1] += stackSize[i2];
					stack2[i1] = new ItemStack(stack2[i2].getItem(), stackSize[i1], stack2[i2].getMetadata());
					stack2[i2] = null; stackSize[i2] = 0;
					
				}}
				}
			}
			}
		}
		return stack2;
		
	}
	

	@Override
	public boolean canInteractWith(EntityPlayer playerIn) {
		
		return this.Showcase.isUseableByPlayer(playerIn);
	}
	
	
	
	
	public void setCraftStackValue(int i){
		this.CraftVal = i;
	}
	public void addRemCraftStackValue(int i){
		 this.CraftVal += i;
		
	}
	public int getCraftStackValue(){
		return this.CraftVal;
	}
	
	
	public void remIngrInv(){
		if(this.Showcase.getStackInSlot(18) != null){
			if(this.ContainItems(this.Showcase.getStackInSlot(18).getItem())){
				for (int i = 0; i < 3; i++){
					int g = 0;
					for (int j = 0; j < 35; j++){ //TODO
						if(this.invP.getStackInSlot(j) != null && this.IngrList[i] != null){
							if(this.invP.getStackInSlot(j).getItem() == this.IngrList[i].getItem()){
						
								if(this.invP.getStackInSlot(j).getMetadata() == this.IngrList[i].getMetadata()){
									int a =	this.invP.getStackInSlot(j).stackSize;
									int b =	g == 0 ? this.IngrList[i].stackSize: g;
									if(a > b){
										
										int c = a - b;
										System.out.println("Values:" + a + " + " + b + " = " + c);
							
										this.invP.setInventorySlotContents(j, new ItemStack(this.IngrList[i].getItem(),c , this.IngrList[i].getMetadata()));
										return;
									}	
									else if (a == b){
										this.invP.removeStackFromSlot(j);
										System.out.println("Values:" + a + " + " + b);
										return;
									}
									else{
										g = b - a;
										System.out.println("Values:" + b + " - " + a + " = " + g);
										this.invP.removeStackFromSlot(j);
							
									}
								}
							}
						}
					}
				}
			}
		}
	}
	public void addIngrInv(){
		for (int i = 0; i < 3; i++){
			int g = 0;
			for (int j = 0; j < 35; j++){
				if(this.invP.getStackInSlot(j) != null && this.IngrList[i] != null)
				if(this.invP.getStackInSlot(j).getItem() == this.IngrList[i].getItem()){
					if(this.invP.getStackInSlot(j).getMetadata() == this.IngrList[i].getMetadata()){
				int a =	this.invP.getStackInSlot(j).stackSize;
				int b =	g == 0 ? this.IngrList[i].stackSize : g;
					if((a + b) <= 64){
						int c = a + b;
						
						this.invP.setInventorySlotContents(j, new ItemStack(this.IngrList[i].getItem(), c, this.IngrList[i].getMetadata()));
						break;
					}	
					else{
						g = (b + a) - 64;
						this.invP.setInventorySlotContents(j, new ItemStack(this.IngrList[i].getItem(), 64, this.IngrList[i].getMetadata()));
						
					}
					}
				}
			}
		}
	}
	public void PutCrItemInv(Item item){
		
		if(!this.invP.player.worldObj.isRemote){
		this.invP.addItemStackToInventory(new ItemStack(item, (this.getCorStackSize(item) * this.getCraftStackValue()), this.getCorMetaData(item)));
		}
		}

/**1 if Bucket, 2 if glass bottle, 0 if nothing  */
public int bucketItem(){
	 Map<Item, Integer> bucket = new HashMap<Item, Integer>();
	 
	 bucket.put(Items.LAVA_BUCKET, 1);
	 bucket.put(Items.WATER_BUCKET, 1);
	 bucket.put(Items.MILK_BUCKET, 1);
	 
	 return bucket.get(this.Showcase.getStackInSlot(18).getItem()) != null ? bucket.get(this.Showcase.getStackInSlot(18).getItem()) : 0;
}

public int getCorStackSize(Item item){
	Map<Item, Integer> size = new HashMap<Item, Integer>();
	size.put(Items.STICK, 4);
	size.put(Item.getItemFromBlock(Blocks.PLANKS), 4);
	size.put(Item.getItemFromBlock(Blocks.TORCH), 4);
	return size.get(item) != null ? size.get(item) : 1;
}

public int getCorMetaData(Item item){
	Map<Item, Integer> meta = new HashMap<Item, Integer>();
	
	if(item == Item.getItemFromBlock(Blocks.WOOL)){
		if(this.IngrList[1] != null){
		if (this.IngrList[1].getItem() == Items.DYE){
			return (15 - this.IngrList[1].getMetadata());
		}
		else{
			return 0;
		}
		}
	}
	if(item == Item.getItemFromBlock(Blocks.PLANKS)){
		if(this.IngrList[0] != null){
		return this.IngrList[0].getMetadata();
		}
	}
	
	return meta.get(item) != null ? meta.get(item) : 0;
	
}

public Boolean ContainItems(Item item){
	 
	 if(this.IngrList != null){
	 boolean[] b = new boolean[this.IngrList.length];
	 for(int i = 0; i < this.IngrList.length; i++){
		 b[i] = false;
	 }
	
	 for (int j = 0; j < this.getInventory2().length; j++){
		
			
			
			 
	 for(int i = 0; i < 3; i++){
		if(!b[i]){
			if(this.IngrList[i] != null){
			if(this.getInventory2()[j] != null){
				if(this.getInventory2()[j].getItem() == this.IngrList[i].getItem()){
				
				
				if(this.getInventory2()[j].stackSize >= this.IngrList[i].stackSize){
					 Item it = this.IngrList[i].getItem();
					 if(it == Item.getItemFromBlock(Blocks.PLANKS) || it == Item.getItemFromBlock(Blocks.LOG) || it == Items.DYE || it == Item.getItemFromBlock(Blocks.WOOL) || it == Items.FISH){
					if(this.getInventory2()[j].getMetadata() == this.IngrList[i].getMetadata()){
							b[i] = true; 
							
						}}
						else{
							b[i] = true;
							
						
				}
			}
			}
			
		}
	 }
			else{
				if (i != 0){
				b[i] = true;
				}
			}
	 }
	 }
	 
	 } 
		
	 
	 for(int i = 0; i < b.length; i++){
		 if (b[i] == false)return false; 
	 }
	 return true;
	 
	 }
	 return false;
}

public void setIngredientList(ItemStack s1, ItemStack s2, ItemStack s3){
	
	ItemStack[] s = {s1, s2, s3};
	this.IngrList = s;
	}
public int getCurrentCrProg(){
	return this.CurrentCraftProgness;
}
public int getMaxCrProg(){
	return this.MaxCraftProgness;
}
public void setMaxCrProg(int i){
	this.MaxCraftProgness = i;
}
public void setCurrentCrProg(int i){
	this.CurrentCraftProgness = i;
}
public void adremCurrentCrProg(int i){
	this.CurrentCraftProgness += i;
}

public int BasicTableSkill(Item item){
	int ARCHEOLOGY = 13;
	int TAILORY = 14;
	int SMITHING = 15;
	int TANNING = 16;
	int JEWELRY = 17;
	int FLETCHING = 18;
	int COOKING = 19;
	int HERBLORE = 20;
	int HONOUR = 21;
	int TECHNOLOGY = 28;
		
	Map<Item, Integer> BTSkill = new HashMap<Item, Integer>();
	
	BTSkill.put(Items.STICK, FLETCHING);
	BTSkill.put(Items.FLINT_AND_STEEL, SMITHING);
	BTSkill.put(Item.getItemFromBlock(Blocks.WOOL), TAILORY);
	BTSkill.put(Items.PAPER, TANNING);
	BTSkill.put(Items.SUGAR, COOKING);
	return BTSkill.get(item) != null ? BTSkill.get(item) : 22; // returns CONSTRUCTION skill if hashmap results null
	}

public int GetCraftXP(Item item){
	Map<Item, Integer> ItemXP = new HashMap<Item, Integer>();
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.BasicTable), 1);
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.TailoryBench_I), 2);
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.Anvil_I), 2);
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.Furnace_I), 2);
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.TanningBench_I), 2);
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.JewelryTable_I), 2);
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.GlassOven_I), 2);
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.FletchingTable_I), 2);
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.Range_I), 2);
	ItemXP.put(Item.getItemFromBlock(MarkBlocks.Cauldron_I), 2);
	ItemXP.put(Item.getItemFromBlock(Blocks.PLANKS), 1);
	ItemXP.put(Item.getItemFromBlock(Blocks.WOOL), 1);
	ItemXP.put(Items.FLINT_AND_STEEL, 2);
	ItemXP.put(Items.STICK, 1);
	ItemXP.put(Items.PAPER, 1);
	ItemXP.put(Items.SUGAR, 1);
	
	
	
	return ItemXP.get(item) != null ? ItemXP.get(item) : 0;
}

public boolean CraftSlotContainsStack(){
	
	return this.Showcase.getStackInSlot(18) != null;// slot 25 Crafting
}

//update TE, Crafting Mechanism!! -------------------------------------------------------------------------------------------------------
public void Craft() {
	System.out.println("StackVal: " + this.getCraftStackValue() + " : " + (this.invP.player.worldObj.isRemote ? "Client" : "Server"));
	this.remIngrInv(); //TODO
	this.PutCrItemInv(this.Showcase.getStackInSlot(18).getItem()); 
			
			if(this.invP.player.worldObj != null){	
				if(!this.invP.player.worldObj.isRemote){
					if(this.invP.player != null){
						EntityPlayer pla = this.invP.player;
					MarkData p = pla.getCapability(MainRegistry.ModMark136Data, null);
					
					p.addXp(this.BasicTableSkill(this.Showcase.getStackInSlot(18).getItem()), (this.GetCraftXP(this.Showcase.getStackInSlot(18).getItem())* this.getCraftStackValue()));
					p.syncSkill();
				}}
			}
			
	this.setCraftStackValue(0);
	this.Showcase.removeStackFromSlot(18);

	

}
@Override
public ItemStack transferStackInSlot(EntityPlayer playerIn, int index)
{
	Slot sourceSlot = (Slot)inventorySlots.get(index);
	if (sourceSlot == null || !sourceSlot.getHasStack()) return null;
	ItemStack sourceStack = sourceSlot.getStack();
	ItemStack copyOfSourceStack = sourceStack.copy();

	
	if (index >= 0 && index < 9 || index >= 36 && index < 40) {
			if (!mergeItemStack(sourceStack, 9, 36, false)){
			return null;
		}
	} else if (index >= 9 && index < 36) {
		
		if (!mergeItemStack(sourceStack, 0, 9, false)) {
			return null;
		}
	} else {
		System.err.print("Invalid slotIndex:" + index);
		return null;
	}

	if (sourceStack.stackSize == 0) {
		sourceSlot.putStack(null);
	} else {
		sourceSlot.onSlotChanged();
	}

	sourceSlot.onPickupFromSlot(playerIn, sourceStack);
	return copyOfSourceStack;
}
}
