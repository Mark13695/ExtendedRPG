package com.modMark.Crafting;

import javax.annotation.Nullable;

import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class MarkFinishedSlot extends Slot {

	public MarkFinishedSlot(IInventory inventoryIn, int index, int xPosition, int yPosition) {
		super(inventoryIn, index, xPosition, yPosition);
		
	}

	
	@Override
	 public boolean isItemValid(@Nullable ItemStack stack)
	    {
	        return false;
	    }
}
