package com.modMark.Crafting;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;

public class MarkInventory implements IInventory {
	
	

	private ItemStack[] stack = new ItemStack[19];
	
	
	
	public void fillStacks(){
		this.stack[0] = new ItemStack(Items.STICK, 1);
		this.stack[1] = new ItemStack(Blocks.PLANKS, 1);
		this.stack[2] = new ItemStack(Blocks.WOOL, 1);
		this.stack[3] = new ItemStack(Items.SUGAR, 1);
		this.stack[4] = new ItemStack(Items.FLINT_AND_STEEL, 1);
		this.stack[5] = new ItemStack(Blocks.TORCH, 1);
		this.stack[6] = new ItemStack(MarkBlocks.BasicTable, 1);
		this.stack[7] = new ItemStack(MarkBlocks.TailoryBench_I, 1);
		this.stack[8] = new ItemStack(MarkBlocks.Furnace_I, 1);
		this.stack[9] = new ItemStack(MarkBlocks.Anvil_I, 1);
		this.stack[10] = new ItemStack(MarkBlocks.TanningBench_I, 1);
		this.stack[11] = new ItemStack(MarkBlocks.GlassOven_I, 1);
		this.stack[12] = new ItemStack(MarkBlocks.JewelryTable_I, 1);
		this.stack[13] = new ItemStack(MarkBlocks.FletchingTable_I, 1);
		this.stack[14] = new ItemStack(MarkBlocks.Range_I, 1);
		this.stack[15] = new ItemStack(MarkBlocks.Cauldron_I, 1);
		this.stack[16] = new ItemStack(MarkBlocks.WorkBench_I, 1);
		
		//this.stack[17] = new ItemStack(MarkBlocks.TechBench_I, 1);
	}
	
	
	
	@Override
	public String getName() {
		return "container.markcraftinv.name";
	}

	@Override
	public boolean hasCustomName() {
		
		return false;
	}

	@Override
	public ITextComponent getDisplayName() {
		return null;
	}

	@Override
	public int getSizeInventory() {
		return this.stack.length;
	}

	@Override
	public ItemStack getStackInSlot(int index) {
		return stack[index];
	}
	

	@Override
	public ItemStack decrStackSize(int index, int count) {  // not really needed I think
		ItemStack slotStack = getStackInSlot(index);
		if (slotStack == null) {
			return null;
		}
		
		ItemStack RemovedStack;
		
		if (slotStack.stackSize <= count) {
			RemovedStack = slotStack;
			setInventorySlotContents(index, null);	
		}
		else{
			RemovedStack = slotStack.splitStack(count);
			if (slotStack.stackSize == 0) {
				setInventorySlotContents(index, null);
			}
		}
		return RemovedStack;
	}

	@Override
	public ItemStack removeStackFromSlot(int index) {
		ItemStack itemStack = getStackInSlot(index);
		
		if (itemStack != null) setInventorySlotContents(index, null);
		return itemStack;
	}

	@Override
	public void setInventorySlotContents(int index, ItemStack stackIn) {
		this.stack[index] = stackIn;
		if(stackIn != null && stackIn.stackSize > getInventoryStackLimit()){
			stackIn.stackSize = getInventoryStackLimit();
		}
	
		
	}

	@Override
	public int getInventoryStackLimit() {
		
		return 64;
	}

	@Override
	public void markDirty() {
		// not needed because Items Are always the same in this inv
		
	}

	@Override
	public boolean isUseableByPlayer(EntityPlayer player) {
		return true;
	}

	@Override
	public void openInventory(EntityPlayer player) {
		
		
	}

	@Override
	public void closeInventory(EntityPlayer player) {
		
		
	}

	@Override
	public boolean isItemValidForSlot(int index, ItemStack stack) {
		
		return true;
	}

	@Override
	public int getField(int id) {
		
		return 0;
	}

	@Override
	public void setField(int id, int value) {
		
		
	}

	@Override
	public int getFieldCount() {
	
		return 0;
	}

	@Override
	public void clear() {
		Arrays.fill(this.stack, null);
		
	}
	
	

}
