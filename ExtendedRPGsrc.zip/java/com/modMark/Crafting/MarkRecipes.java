package com.modMark.Crafting;

import java.util.Iterator;
import java.util.List;

import net.minecraft.init.Items;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CraftingManager;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.world.World;

public class MarkRecipes /**implements IRecipe*/ {
	
	//private IRecipe Recipe;
	
	//public MarkRecipes(IRecipe r){
		
		//this.Recipe = r;
	//}

	//@Override
	//public boolean matches(InventoryCrafting inv, World worldIn) {
		
	//	return false;
	//}

	//@Override
	//public ItemStack getCraftingResult(InventoryCrafting inv) {
		
	//	return null;
	//}

	//@Override
	//public int getRecipeSize() {
		
	//	return 0;
	//}

	//@Override
	//public ItemStack getRecipeOutput() {
		
	//	return null;
	//}

	//@Override
	//public ItemStack[] getRemainingItems(InventoryCrafting inv) {
		
	//	return null;
	//}

	
	
	
	
	
	
	
}
