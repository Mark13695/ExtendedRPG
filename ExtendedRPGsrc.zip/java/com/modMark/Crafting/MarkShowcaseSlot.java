package com.modMark.Crafting;

import javax.annotation.Nullable;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkShowcaseSlot extends Slot {

	public MarkShowcaseSlot(IInventory inventoryIn, int index, int xPosition, int yPosition) {
		super(inventoryIn, index, xPosition, yPosition);
		
	}
	
	@Override
	 public boolean isItemValid(@Nullable ItemStack stack)
	    {
	        return false;
	    }

	@Override
	public boolean canTakeStack(EntityPlayer playerIn)
    {
        return false;
    }
	
	
	
	
}
