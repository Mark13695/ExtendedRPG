package com.modMark.Crafting;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nullable;

import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class SlotArmour extends Slot {
	private int ArmourType;

	public SlotArmour(IInventory inventoryIn, int armourType , int index, int xPosition, int yPosition) {
		super(inventoryIn, index, xPosition, yPosition);
		this.ArmourType = armourType;
	}

	
	@Override
	 public boolean isItemValid(@Nullable ItemStack stack)
	    {
		Map<Item, Integer> Type = new HashMap<Item, Integer>();
		
		Type.put(Items.LEATHER_HELMET, 0);
		Type.put(Items.IRON_HELMET, 0);
		Type.put(Items.GOLDEN_HELMET, 0);
		Type.put(Items.DIAMOND_HELMET, 0);
		Type.put(Items.CHAINMAIL_HELMET, 0);
		
		Type.put(Items.LEATHER_CHESTPLATE, 1);
		Type.put(Items.IRON_CHESTPLATE, 1);
		Type.put(Items.GOLDEN_CHESTPLATE, 1);
		Type.put(Items.DIAMOND_CHESTPLATE, 1);
		Type.put(Items.CHAINMAIL_CHESTPLATE, 1);
		Type.put(Items.ELYTRA, 1);
		
		Type.put(Items.LEATHER_LEGGINGS, 2);
		Type.put(Items.IRON_LEGGINGS, 2);
		Type.put(Items.GOLDEN_LEGGINGS, 2);
		Type.put(Items.DIAMOND_LEGGINGS, 2);
		Type.put(Items.CHAINMAIL_LEGGINGS, 2);
		
		Type.put(Items.LEATHER_BOOTS, 3);
		Type.put(Items.IRON_BOOTS, 3);
		Type.put(Items.GOLDEN_BOOTS, 3);
		Type.put(Items.DIAMOND_BOOTS, 3);
		Type.put(Items.CHAINMAIL_BOOTS, 3);
		
		int k = Type.get(stack.getItem()) == null ? -1 : Type.get(stack.getItem());
		
		if(k == this.ArmourType){
			return true;
		}
		else{
	        return false;
		}
	        
	        
	    }
}
