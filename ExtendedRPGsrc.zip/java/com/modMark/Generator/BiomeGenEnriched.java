package com.modMark.Generator;

import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.Block.MarkLog;

import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenTallGrass;
import net.minecraft.world.gen.feature.WorldGenTrees;
import net.minecraft.world.gen.feature.WorldGenerator;

public class BiomeGenEnriched extends Biome 
{

	protected static final WorldGenMarkTrees EnrichedTrees = new WorldGenMarkTrees(false, false, MarkBlocks.LogYew.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogYew_Leaf.getDefaultState(), false);
	protected static final WorldGenMarkTrees EnrichedTrees_BIG = new WorldGenMarkTrees(false, true, MarkBlocks.LogYew.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogYew_Leaf.getDefaultState(), false);
	
	public BiomeGenEnriched(BiomeProperties id) {
		super(id);
		this.theBiomeDecorator.grassPerChunk = 1;
		this.theBiomeDecorator.deadBushPerChunk = 1;
		this.fillerBlock = Blocks.DIRT.getDefaultState();
		this.topBlock = MarkBlocks.EnrichedGrass.getDefaultState();
		
	}
	
	 public WorldGenAbstractTree genBigTreeChance(Random rand)
	    {
		 if(this == MarkBiome.Biome_1_EnrichedM){
			 return rand.nextInt(5) > 0 ? EnrichedTrees : EnrichedTrees_BIG;
		 }
		 else{
	        return rand.nextInt(7) > 0 ? EnrichedTrees : EnrichedTrees_BIG;
		 }
	    }
	
	 public WorldGenerator getRandomWorldGenForGrass(Random rand)
	    {
	        return new WorldGenMarkGrass(MarkBlocks.TallGrass40);
	    }
	 
	 
}
