package com.modMark.Generator;

import java.util.Set;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Sets;
import com.modMark.Generator.Nether.BiomeCryst;
import com.modMark.Generator.Nether.BiomeCrystD;
import com.modMark.Generator.Nether.BiomeNether;
import com.modMark.Generator.Nether.BiomeNetherD;
import com.modMark.Generator.Nether.NetherWorldProvider;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.DimensionType;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeDecorator;
import net.minecraft.world.biome.BiomeHell;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.common.BiomeDictionary.Type;
import net.minecraftforge.common.BiomeManager;
import net.minecraftforge.common.BiomeManager.BiomeEntry;
import net.minecraftforge.common.BiomeManager.BiomeType;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class MarkBiome extends Biome {

	public MarkBiome(BiomeProperties properties) {
		super(properties);
		this.theBiomeDecorator = new MarkDecorator(this);
	}
	public static void init(){
		initBiome();
		regBiome();
		
	}
	private static Set<BiomeManager.BiomeEntry> NetherEntries = Sets.newHashSet();
	public static Biome Biome_1_Enriched;
	public static Biome Biome_1_EnrichedM;
	public static Biome Biome_2_Nether;
	public static Biome Biome_2_NetherDesert;
	public static Biome Biome_2_Cryst;
	public static Biome Biome_2_CrystDesert;
	
;
	
	
	
	public static void initBiome(){
		
		DimensionManager.unregisterDimension(-1);
		DimensionType nether = DimensionType.register("Nether", "_nether", -1, NetherWorldProvider.class, false);
	    DimensionManager.registerDimension(-1, nether);
		
		Biome_1_Enriched = new BiomeGenEnriched((new Biome.BiomeProperties("Enriched")).setBaseBiome("Enriched").setTemperature(1.2F).setRainfall(0.9F).setWaterColor(2653061));
		Biome_1_EnrichedM = new BiomeGenEnriched((new Biome.BiomeProperties("Enriched M")).setBaseBiome("Enriched").setHeightVariation(0.3F).setTemperature(1.2F).setRainfall(0.9F).setWaterColor(2653061));
		Biome_2_Nether = new BiomeNether((new Biome.BiomeProperties("Nether")).setRainDisabled());
		Biome_2_NetherDesert = new BiomeNetherD((new Biome.BiomeProperties("NetherDesert")).setRainDisabled());
		Biome_2_Cryst = new BiomeCryst((new Biome.BiomeProperties("Cryst")).setRainDisabled());
		Biome_2_CrystDesert = new BiomeCrystD((new Biome.BiomeProperties("CrystDesert")).setRainDisabled());
		
		
		
	}
	public static void regBiome(){
		AddSurfaceBiome(Biome_1_Enriched, "Enriched", 178 , BiomeType.WARM, 10);
		AddSurfaceBiome(Biome_1_EnrichedM, "Enriched M", 179 , BiomeType.WARM, 10);
		
		AddNetherBiome(Biome_2_Nether, 45, 180, "Nether");
		AddNetherBiome(Biome_2_NetherDesert, 25, 181, "NetherDesert");
		AddNetherBiome(Biome_2_Cryst, 17, 182, "Cryst");
		AddNetherBiome(Biome_2_CrystDesert, 13, 183, "CrystDesert");
		
		if(BiomeDictionary.isBiomeRegistered(Biome_1_Enriched)){
			System.out.println("1 is Registered");
		}
		if(BiomeDictionary.isBiomeRegistered(Biome_1_EnrichedM)){
			System.out.println("2 is Registered");
		}
		
		
		
		
	}
	
	public static void AddSurfaceBiome(Biome biome, String name, int ID, BiomeType biometype, int weight){
		Biome.registerBiome(ID, name, biome);
		BiomeManager.addBiome(biometype, new BiomeEntry(biome, weight));
		BiomeManager.addSpawnBiome(biome);
		
		
	}
	
		public static void AddNetherBiome(Biome biome, int Weight, int ID, String Name)
		{
			Biome.registerBiome(ID, Name, biome);
			NetherEntries.add(new BiomeEntry(biome, Weight));
		}
		
		public static ImmutableList<BiomeManager.BiomeEntry> getBiomeEntries()
	    {
	        return ImmutableList.copyOf(NetherEntries);
	    }
		
}	
