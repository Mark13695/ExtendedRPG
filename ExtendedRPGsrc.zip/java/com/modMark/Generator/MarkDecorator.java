package com.modMark.Generator;

import java.util.Random;

import com.modMark.Generator.Nether.BiomeCrystD;
import com.modMark.Generator.Nether.BiomeNetherD;
import com.modMark.Item_Block.MarkBlocks;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeDecorator;
import net.minecraft.world.gen.ChunkProviderSettings;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenDeadBush;
import net.minecraft.world.gen.feature.WorldGenerator;

public class MarkDecorator extends BiomeDecorator {
	
    public MarkDecorator(Biome biome) {
	 
    }
	
  public void decorate(World world, Random random, Biome base, BlockPos pos)
    {
	    if (this.decorating)
	    {
		    throw new RuntimeException("Already decorating!!");
	    }
	    else
	    {
	    	this.chunkProviderSettings = ChunkProviderSettings.Factory.jsonToFactory(world.getWorldInfo().getGeneratorOptions()).build();
		    this.chunkPos = pos;
		    this.genDecorations(base, world, random);
		    this.decorating = false;   
	    }
    }
	
    protected void genDecorations(Biome base, World world, Random random)
    {
    	
    	
    	net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new net.minecraftforge.event.terraingen.DecorateBiomeEvent.Pre(world, random, chunkPos));
    if(base == MarkBiome.Biome_1_Enriched || base == MarkBiome.Biome_1_EnrichedM)
    { 
        if(net.minecraftforge.event.terraingen.TerrainGen.decorate(world, random, chunkPos, net.minecraftforge.event.terraingen.DecorateBiomeEvent.Decorate.EventType.GRASS))
            for (int i3 = 0; i3 < this.grassPerChunk; ++i3)
            {
            	int j7 = random.nextInt(16) + 8;
                int i11 = random.nextInt(16) + 8;
                int k14 = world.getHeight(this.chunkPos.add(j7, 0, i11)).getY() * 2;

                if (k14 > 0)
                {
                	int l17 = random.nextInt(k14);
                	
                    ((BiomeGenEnriched)base).getRandomWorldGenForGrass(random).generate(world, random, chunkPos.add(j7, l17, i11));
                	
                }
            }
        

      }
    
    if(base == MarkBiome.Biome_1_Enriched || base == MarkBiome.Biome_1_EnrichedM)
    {
 if(net.minecraftforge.event.terraingen.TerrainGen.decorate(world, random, chunkPos, net.minecraftforge.event.terraingen.DecorateBiomeEvent.Decorate.EventType.DEAD_BUSH)){
        	
            for (int j3 = 0; j3 < 1; ++j3)
            {
                int k7 = random.nextInt(16) + 8;
                int j11 = random.nextInt(16) + 8;
                int l14 = world.getHeight(chunkPos.add(k7, 0, j11)).getY() * 2;

                if (l14 > 0)
                {
                	
                    int i18 = random.nextInt(l14);
                    (new WorldGenMarkCrystalBush()).generate(world, random, chunkPos.add(k7, i18, j11));
                }
  }}}}}
    
        
    
    

