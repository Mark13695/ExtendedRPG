package com.modMark.Generator;

import java.util.Random;

import com.google.common.base.Predicate;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.Block.BlockGemOres;
import com.modMark.Item_Block.Block.MarkLog;
import com.modMark.Item_Block.Block.MarkOre;

import net.minecraft.block.BlockLog;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockStateMatcher;
import net.minecraft.client.renderer.block.statemap.BlockStateMapper;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkGenerator;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraft.world.gen.feature.WorldGenTrees;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.fml.common.IWorldGenerator;

public class MarkGen implements IWorldGenerator {
	private WorldGenerator gen_opal_ore; //Generates Opal GemOre (used in Overworld)
	private WorldGenerator gen_sapphire_ore; //Generates Sapphire GemOre (used in Overworld)
	private WorldGenerator gen_olivine_ore; //Generates Olivine GemOre (used in Overworld)
	private WorldGenerator gen_hyacinth_ore; //Generates Hyacinth GemOre (used in Overworld)
	private WorldGenerator gen_topaz_ore; //Generates Topaz GemOre (used in Overworld)
	private WorldGenerator gen_amethyst_ore; //Generates Amethyst GemOre (used in Overworld)
	private WorldGenerator gen_siam_ore; //Generates Siam GemOre (used in Nether)
	private WorldGenerator gen_aquamarine_ore; //Generates Aquamarin GemOre (used in Nether)
	
	private WorldGenerator gen_netherite_ore;
	private WorldGenerator gen_crystlium_ore;
	
	private WorldGenerator gen_Script01;
	private WorldGenerator gen_Script05;
	private WorldGenerator gen_Script10;
	private WorldGenerator gen_Script15;
	private WorldGenerator gen_Script20;
	private WorldGenerator gen_Script30;
	private WorldGenerator gen_Script40;
	private WorldGenerator gen_Script50a;
	private WorldGenerator gen_Script50b;
	private WorldGenerator gen_Script60a;
	private WorldGenerator gen_Script60b;
	private WorldGenerator gen_Script65a;
	private WorldGenerator gen_Script65b;
	private WorldGenerator gen_Script75a;
	private WorldGenerator gen_Script75b;
	private WorldGenerator gen_Script80a;
	private WorldGenerator gen_Script80b;
	private WorldGenerator gen_Script85a;
	private WorldGenerator gen_Script85b;
	private WorldGenerator gen_YewTree;
	private WorldGenerator gen_CrystalBush;
	private WorldGenerator gen_NetherTreeA;
	private WorldGenerator gen_NetherTreeB;
	private WorldGenerator gen_NetherGrassA;
	private WorldGenerator gen_NetherGrassB;
	

	public MarkGen() {
		Random random = new Random();
	    this.gen_opal_ore = new WorldGenMinable(MarkBlocks.GemOpalOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 8);
	    this.gen_sapphire_ore = new WorldGenMinable(MarkBlocks.GemSapphireOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 8);
	    this.gen_olivine_ore = new WorldGenMinable(MarkBlocks.GemOlivineOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 8);
	    this.gen_hyacinth_ore = new WorldGenMinable(MarkBlocks.GemHyacinthOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 8);
	    this.gen_topaz_ore = new WorldGenMinable(MarkBlocks.GemTopazOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 8);
	    this.gen_amethyst_ore = new WorldGenMinable(MarkBlocks.GemAmethystOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 8);
	    this.gen_siam_ore = new WorldGenMinable(MarkBlocks.GemSiamOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 8, BlockStateMatcher.forBlock(MarkBlocks.NetherSand));
	    this.gen_aquamarine_ore = new WorldGenMinable(MarkBlocks.GemAquamarineOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 8, BlockStateMatcher.forBlock(MarkBlocks.CrystSand));
	    
	    this.gen_netherite_ore = new WorldGenMinable(MarkBlocks.OreNetherite.getDefaultState().withProperty(MarkOre.Natural, true), 8, BlockStateMatcher.forBlock(Blocks.NETHERRACK));
	    this.gen_crystlium_ore = new WorldGenMinable(MarkBlocks.OreCrystlium.getDefaultState().withProperty(MarkOre.Natural, true), 8, BlockStateMatcher.forBlock(MarkBlocks.CrystRack));

	    
	    
	    this.gen_Script01 = new WorldGenMinable(MarkBlocks.Script01.getDefaultState(), 8);
	    this.gen_Script05 = new WorldGenMinable(MarkBlocks.Script05.getDefaultState(), 8);
	    this.gen_Script10 = new WorldGenMinable(MarkBlocks.Script10.getDefaultState(), 8);
	    this.gen_Script15 = new WorldGenMinable(MarkBlocks.Script15.getDefaultState(), 8);
	    this.gen_Script20 = new WorldGenMinable(MarkBlocks.Script20.getDefaultState(), 8);
	    this.gen_Script30 = new WorldGenMinable(MarkBlocks.Script30.getDefaultState(), 8);
	    this.gen_Script40 = new WorldGenMinable(MarkBlocks.Script40.getDefaultState(), 8);
	    this.gen_Script50a = new WorldGenMinable(MarkBlocks.Script50.getDefaultState(), 8, BlockStateMatcher.forBlock(Blocks.NETHERRACK));
	    this.gen_Script50b = new WorldGenMinable(MarkBlocks.Script50.getDefaultState(), 8, BlockStateMatcher.forBlock(MarkBlocks.NetherSand));
	    this.gen_Script60a = new WorldGenMinable(MarkBlocks.Script60.getDefaultState(), 8, BlockStateMatcher.forBlock(Blocks.NETHERRACK));
	    this.gen_Script60b = new WorldGenMinable(MarkBlocks.Script60.getDefaultState(), 8, BlockStateMatcher.forBlock(MarkBlocks.NetherSand));
	    this.gen_Script65a = new WorldGenMinable(MarkBlocks.Script65.getDefaultState(), 8, BlockStateMatcher.forBlock(Blocks.NETHERRACK));
	    this.gen_Script65b = new WorldGenMinable(MarkBlocks.Script65.getDefaultState(), 8, BlockStateMatcher.forBlock(MarkBlocks.NetherSand));
	    this.gen_Script75a = new WorldGenMinable(MarkBlocks.Script75.getDefaultState(), 8, BlockStateMatcher.forBlock(MarkBlocks.CrystRack));
	    this.gen_Script75b = new WorldGenMinable(MarkBlocks.Script75.getDefaultState(), 8, BlockStateMatcher.forBlock(MarkBlocks.CrystSand));
	    this.gen_Script80a = new WorldGenMinable(MarkBlocks.Script80.getDefaultState(), 8, BlockStateMatcher.forBlock(MarkBlocks.CrystRack));
	    this.gen_Script80b = new WorldGenMinable(MarkBlocks.Script80.getDefaultState(), 8, BlockStateMatcher.forBlock(MarkBlocks.CrystSand));
	    this.gen_Script85a = new WorldGenMinable(MarkBlocks.Script85.getDefaultState(), 8, BlockStateMatcher.forBlock(MarkBlocks.CrystRack));
	    this.gen_Script85b = new WorldGenMinable(MarkBlocks.Script85.getDefaultState(), 8, BlockStateMatcher.forBlock(MarkBlocks.CrystSand));
	    this.gen_CrystalBush = new WorldGenMarkCrystalBush();
	    this.gen_YewTree = new WorldGenMarkTrees(false, random.nextInt(6) == 0, MarkBlocks.LogYew.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogYew_Leaf.getDefaultState(), false);
	    this.gen_NetherTreeA = new WorldGenMarkTrees(false, random.nextInt(6) == 0, MarkBlocks.LogNetherBranch.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogNetherBranch_Leaf.getDefaultState(), false);
	    this.gen_NetherTreeB = new WorldGenMarkTrees(false, random.nextInt(6) == 0, MarkBlocks.LogCrystWood.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogCrystWood_Leaf.getDefaultState(), false);
	    this.gen_NetherGrassA = new WorldGenMarkGrass(MarkBlocks.TallGrass60);
	    this.gen_NetherGrassB = new WorldGenMarkGrass(MarkBlocks.TallGrass80);
	    
	    
	}

	@Override
	public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator,
			IChunkProvider chunkProvider) {
		switch (world.provider.getDimension()) {
	    case 0: //Overworld
	    	this.runGenerator(this.gen_opal_ore, world, random, chunkX, chunkZ, 12, 30, 200);
	    	this.runGenerator(this.gen_sapphire_ore, world, random, chunkX, chunkZ, 10, 25, 120);
	    	this.runGenerator(this.gen_olivine_ore, world, random, chunkX, chunkZ, 9, 25, 120);
	    	this.runGenerator(this.gen_hyacinth_ore, world, random, chunkX, chunkZ, 9, 25, 120);
	    	this.runGenerator(this.gen_topaz_ore, world, random, chunkX, chunkZ, 5, 15, 80);
	    	this.runGenerator(this.gen_amethyst_ore, world, random, chunkX, chunkZ, 2, 3, 30);
	    	
	    	this.runGenerator(this.gen_Script01, world, random, chunkX, chunkZ, 16, 30, 200);
	    	this.runGenerator(this.gen_Script05, world, random, chunkX, chunkZ, 8, 25, 120);
	    	this.runGenerator(this.gen_Script10, world, random, chunkX, chunkZ, 7, 25, 120);
	    	this.runGenerator(this.gen_Script15, world, random, chunkX, chunkZ, 7, 25, 120);
	    	this.runGenerator(this.gen_Script20, world, random, chunkX, chunkZ, 6, 20, 100);
	    	this.runGenerator(this.gen_Script30, world, random, chunkX, chunkZ, 4, 10, 60);
	    	this.runGenerator(this.gen_Script40, world, random, chunkX, chunkZ, 2, 3, 30);
	    	if(world.getBiomeForCoordsBody(new BlockPos(chunkX * 16, 0, chunkZ * 16)) == MarkBiome.Biome_1_Enriched || world.getBiomeForCoordsBody(new BlockPos(chunkX * 16, 0, chunkZ * 16)) == MarkBiome.Biome_1_EnrichedM){	
		    	this.runGenerator(this.gen_YewTree, world, random, chunkX, chunkZ, 14, 3, 120);
		    	this.runGenerator(this.gen_CrystalBush, world, random, chunkX, chunkZ, 1, 60, 120);

		    	}
	    	
	    	
	    	
	    	
	        break;
	    case -1: //Nether
	    	
	    	this.runGenerator(this.gen_siam_ore, world, random, chunkX, chunkZ, 4, 3, 120);
	    	this.runGenerator(this.gen_amethyst_ore, world, random, chunkX, chunkZ, 4, 3, 120);
	    	this.runGenerator(this.gen_netherite_ore, world, random, chunkX, chunkZ, 4, 3, 120);
	    	this.runGenerator(this.gen_crystlium_ore, world, random, chunkX, chunkZ, 4, 3, 120);
	    	this.runGenerator(this.gen_Script50a, world, random, chunkX, chunkZ, 9, 3, 120);
	    	this.runGenerator(this.gen_Script50b, world, random, chunkX, chunkZ, 9, 3, 120);
	    	this.runGenerator(this.gen_Script60a, world, random, chunkX, chunkZ, 7, 3, 120);
	    	this.runGenerator(this.gen_Script60b, world, random, chunkX, chunkZ, 7, 3, 120);
	    	this.runGenerator(this.gen_Script65a, world, random, chunkX, chunkZ, 4, 3, 120);
	    	this.runGenerator(this.gen_Script65b, world, random, chunkX, chunkZ, 4, 3, 120);
	    	this.runGenerator(this.gen_Script75a, world, random, chunkX, chunkZ, 9, 3, 120);
	    	this.runGenerator(this.gen_Script75b, world, random, chunkX, chunkZ, 9, 3, 120);
	    	this.runGenerator(this.gen_Script80a, world, random, chunkX, chunkZ, 7, 3, 120);
	    	this.runGenerator(this.gen_Script80b, world, random, chunkX, chunkZ, 7, 3, 120);
	    	this.runGenerator(this.gen_Script85a, world, random, chunkX, chunkZ, 4, 3, 120);
	    	this.runGenerator(this.gen_Script85b, world, random, chunkX, chunkZ, 4, 3, 120);
	    	if(world.getBiomeForCoordsBody(new BlockPos(chunkX * 16, 0, chunkZ * 16)) == MarkBiome.Biome_2_NetherDesert){	
	    	this.runGenerator(this.gen_NetherTreeA, world, random, chunkX, chunkZ, 7, 3, 120);
	    	this.runGenerator(this.gen_NetherGrassA, world, random, chunkX, chunkZ, 16, 3, 120);
	    	}
	    	if(world.getBiomeForCoordsBody(new BlockPos(chunkX * 16, 0, chunkZ * 16)) == MarkBiome.Biome_2_CrystDesert){
	    	this.runGenerator(this.gen_NetherTreeB, world, random, chunkX, chunkZ, 7, 3, 120);
	    	this.runGenerator(this.gen_NetherGrassB, world, random, chunkX, chunkZ, 16, 3, 120);
	    	}
	        break;
	    case 1: //End

	        break;
	    }
	}
		private void runGenerator(WorldGenerator generator, World world, Random rand, int chunk_X, int chunk_Z, int chancesToSpawn, int minHeight, int maxHeight) {
		    if (minHeight < 0 || maxHeight > 256 || minHeight > maxHeight)
		        throw new IllegalArgumentException("Illegal Height Arguments for WorldGenerator");

		    int heightDiff = maxHeight - minHeight + 1;
		    for (int i = 0; i < chancesToSpawn; i ++) {
		        int x = chunk_X * 16 + rand.nextInt(16);
		        int y = minHeight + rand.nextInt(heightDiff);
		        int z = chunk_Z * 16 + rand.nextInt(16);
		        generator.generate(world, rand, new BlockPos(x, y, z));
		    
		}
		    
		    
		    
	}
		
		

		
	
	
}
