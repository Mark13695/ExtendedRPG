package com.modMark.Generator.Nether;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Mob.EntitySalaBlue;
import com.modMark.Mob.EntitySalaRed;

import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeHell;
import net.minecraft.world.biome.Biome.BiomeProperties;
import net.minecraft.world.biome.Biome.SpawnListEntry;

public class BiomeCryst extends BiomeNetherBase {

	public BiomeCryst(BiomeProperties Biome_ID) {
		super(Biome_ID);
		
		this.fillerBlock = MarkBlocks.CrystRack.getDefaultState();
		this.topBlock = MarkBlocks.CrystRack.getDefaultState();

				spawnableMonsterList.clear();
		        spawnableMonsterList.add(new SpawnListEntry(EntityGhast.class, 50, 4, 4));
		        spawnableMonsterList.add(new SpawnListEntry(EntityPigZombie.class, 100, 4, 4));
		        spawnableMonsterList.add(new SpawnListEntry(EntityMagmaCube.class, 2, 4, 4));
		        spawnableMonsterList.add(new Biome.SpawnListEntry(EntityEnderman.class, 1, 4, 4));
		        spawnableMonsterList.add(new SpawnListEntry(EntitySalaBlue.class, 15, 3, 5));

		        
		    }
}
