package com.modMark.Generator.Nether;

import java.util.Random;

import com.modMark.Generator.MarkBiome;
import com.modMark.Generator.WorldGenMarkGrass;
import com.modMark.Generator.WorldGenMarkTrees;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.Block.MarkLog;
import com.modMark.Mob.EntitySalaBlue;
import com.modMark.Mob.EntitySalaRed;

import net.minecraft.block.BlockLog;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeHell;
import net.minecraft.world.biome.Biome.BiomeProperties;
import net.minecraft.world.biome.Biome.SpawnListEntry;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenerator;

public class BiomeCrystD extends BiomeNetherBase {

	protected static final WorldGenMarkTrees CrystTrees = new WorldGenMarkTrees(false, false, MarkBlocks.LogCrystWood.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogCrystWood_Leaf.getDefaultState(), false);
	protected static final WorldGenMarkTrees CrystTrees_BIG = new WorldGenMarkTrees(false, true, MarkBlocks.LogCrystWood.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogCrystWood_Leaf.getDefaultState(), false);
	
	
	
	public BiomeCrystD(BiomeProperties Biome_ID) {
		super(Biome_ID);
		
		this.fillerBlock = MarkBlocks.CrystSand.getDefaultState();
		this.topBlock = MarkBlocks.CrystSand.getDefaultState();
		this.theBiomeDecorator.treesPerChunk = 1;
		this.theBiomeDecorator.grassPerChunk = 1;
				spawnableMonsterList.clear();
		        spawnableMonsterList.add(new SpawnListEntry(EntityGhast.class, 50, 4, 4));
		        spawnableMonsterList.add(new SpawnListEntry(EntityPigZombie.class, 100, 4, 4));
		        spawnableMonsterList.add(new SpawnListEntry(EntityMagmaCube.class, 2, 4, 4));
		        spawnableMonsterList.add(new Biome.SpawnListEntry(EntityEnderman.class, 1, 4, 4));
		        spawnableMonsterList.add(new SpawnListEntry(EntitySalaBlue.class, 15, 4, 6));
		        
		    }
	
	public WorldGenAbstractTree genBigTreeChance(Random rand)
    {
        return rand.nextInt(7) > 0 ? CrystTrees : CrystTrees_BIG;
    }

 public WorldGenerator getRandomWorldGenForGrass(Random rand)
    {
        return new WorldGenMarkGrass(MarkBlocks.TallGrass80);
    }
}
