package com.modMark.Generator.Nether;

import com.modMark.Generator.MarkBiome;
import com.modMark.Generator.MarkDecorator;

import net.minecraft.block.state.pattern.BlockMatcher;
import net.minecraft.init.Blocks;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.feature.WorldGenBush;
import net.minecraft.world.gen.feature.WorldGenFire;
import net.minecraft.world.gen.feature.WorldGenGlowStone1;
import net.minecraft.world.gen.feature.WorldGenGlowStone2;
import net.minecraft.world.gen.feature.WorldGenHellLava;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.common.BiomeManager;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class BiomeNetherBase extends MarkBiome {

	 public final WorldGenFire fire = new WorldGenFire();
	    public final WorldGenGlowStone1 glowStone1 = new WorldGenGlowStone1();
	    public final WorldGenGlowStone2 glowStone2 = new WorldGenGlowStone2();
	    public final WorldGenerator quartz = new WorldGenMinable(Blocks.QUARTZ_ORE.getDefaultState(), 14, BlockMatcher.forBlock(Blocks.NETHERRACK));
	    public final WorldGenerator magma = new WorldGenMinable(Blocks.field_189877_df.getDefaultState(), 33, BlockMatcher.forBlock(Blocks.NETHERRACK));
	    public final WorldGenHellLava lavaTrap = new WorldGenHellLava(Blocks.FLOWING_LAVA, true);
	    public final WorldGenHellLava lavaSpring = new WorldGenHellLava(Blocks.FLOWING_LAVA, false);
	    public final WorldGenBush brownMushroom = new WorldGenBush(Blocks.BROWN_MUSHROOM);
	    public final WorldGenBush redMushroom = new WorldGenBush(Blocks.RED_MUSHROOM);
	
	    public BiomeNetherBase(BiomeProperties id){
	    	
	    super(id);
	    
	    this.topBlock = Blocks.NETHERRACK.getDefaultState();
	    this.fillerBlock = Blocks.NETHERRACK.getDefaultState();
	    
	    spawnableMonsterList.clear();
        spawnableCreatureList.clear();
        spawnableWaterCreatureList.clear();
        spawnableCaveCreatureList.clear();

        theBiomeDecorator = new MarkDecorator(this);
        
        
  
	
	    }
	
	
	
	
	
	
	
	
	
}
