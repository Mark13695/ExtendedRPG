package com.modMark.Generator.Nether;

import java.util.Random;

import com.modMark.Generator.MarkBiome;
import com.modMark.Generator.WorldGenMarkGrass;
import com.modMark.Generator.WorldGenMarkTrees;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.Block.MarkLog;
import com.modMark.Mob.EntitySalaRed;

import net.minecraft.block.BlockLog;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeHell;
import net.minecraft.world.biome.Biome.BiomeProperties;
import net.minecraft.world.biome.Biome.SpawnListEntry;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenerator;

public class BiomeNetherD extends BiomeNetherBase {

	protected static final WorldGenMarkTrees NetherTrees = new WorldGenMarkTrees(false, false, MarkBlocks.LogNetherBranch.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogNetherBranch_Leaf.getDefaultState(), false);
	protected static final WorldGenMarkTrees NetherTrees_BIG = new WorldGenMarkTrees(false, true, MarkBlocks.LogNetherBranch.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogNetherBranch_Leaf.getDefaultState(), false);
	
	
	public BiomeNetherD(BiomeProperties Biome_ID) {
		super(Biome_ID);
		
		this.fillerBlock = MarkBlocks.NetherSand.getDefaultState();
		this.topBlock = MarkBlocks.NetherSand.getDefaultState();
		this.theBiomeDecorator.treesPerChunk = 1;
		this.theBiomeDecorator.grassPerChunk = 1;
				spawnableMonsterList.clear();
		        spawnableMonsterList.add(new SpawnListEntry(EntityGhast.class, 50, 4, 4));
		        spawnableMonsterList.add(new SpawnListEntry(EntityPigZombie.class, 100, 4, 4));
		        spawnableMonsterList.add(new SpawnListEntry(EntityMagmaCube.class, 2, 4, 4));
		        spawnableMonsterList.add(new Biome.SpawnListEntry(EntityEnderman.class, 1, 4, 4));
		        spawnableMonsterList.add(new SpawnListEntry(EntitySalaRed.class, 15, 4, 6));
		        
		    }
		
	 @Override
	    public void decorate(World world, Random rand, BlockPos pos)
	    {
	        for(int i = 0; i < 8; i++)
	        {
	            lavaSpring.generate(world, rand, pos.add(rand.nextInt(16) + 8, rand.nextInt(120) + 4, rand.nextInt(16) + 8));
	        }

	        for(int i = 0; i < rand.nextInt(rand.nextInt(10) + 1) + 1; i++)
	        {
	            fire.generate(world, rand, pos.add(rand.nextInt(16) + 8, rand.nextInt(120) + 4, rand.nextInt(16) + 8));
	        }

	        for(int i = 0; i < rand.nextInt(rand.nextInt(10) + 1); i++)
	        {
	            glowStone1.generate(world, rand, pos.add(rand.nextInt(16) + 8, rand.nextInt(120) + 4, rand.nextInt(16) + 8));
	        }

	        for(int i = 0; i < 10; i++)
	        {
	            glowStone2.generate(world, rand, pos.add(rand.nextInt(16) + 8, rand.nextInt(128), rand.nextInt(16) + 8));
	        }

	        if(rand.nextBoolean())
	        {
	            brownMushroom.generate(world, rand, pos.add(rand.nextInt(16) + 8, rand.nextInt(128), rand.nextInt(16) + 8));
	        }

	        if(rand.nextBoolean())
	        {
	            redMushroom.generate(world, rand, pos.add(rand.nextInt(16) + 8, rand.nextInt(128), rand.nextInt(16) + 8));
	        }

	        for(int i = 0; i < 16; i++)
	        {
	            quartz.generate(world, rand, pos.add(rand.nextInt(16), rand.nextInt(108) + 10, rand.nextInt(16)));
	        }

	        for(int i = 0; i < 4; i++)
	        {
	            magma.generate(world, rand, pos.add(rand.nextInt(16), rand.nextInt(9) + 28, rand.nextInt(16)));
	        }

	        for(int i = 0; i < 16; i++)
	        {
	            lavaTrap.generate(world, rand, pos.add(rand.nextInt(16), rand.nextInt(108) + 10, rand.nextInt(16)));
	        }
	        
	       
	    }
	 public WorldGenAbstractTree genBigTreeChance(Random rand)
	    {
	        return rand.nextInt(7) > 0 ? NetherTrees : NetherTrees_BIG;
	    }
	
	 public WorldGenerator getRandomWorldGenForGrass(Random rand)
	    {
	        return new WorldGenMarkGrass(MarkBlocks.TallGrass60);
	    }
		
	}


