package com.modMark.Generator.Nether;

import java.util.List;
import java.util.Random;

import com.modMark.Generator.MarkBiome;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.Fluid.MarkFluids;

import net.minecraft.block.BlockFalling;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockMatcher;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldEntitySpawner;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.ChunkProviderHell;
import net.minecraft.world.gen.MapGenBase;
import net.minecraft.world.gen.MapGenCavesHell;
import net.minecraft.world.gen.NoiseGeneratorOctaves;
import net.minecraft.world.gen.feature.WorldGenBush;
import net.minecraft.world.gen.feature.WorldGenFire;
import net.minecraft.world.gen.feature.WorldGenGlowStone1;
import net.minecraft.world.gen.feature.WorldGenGlowStone2;
import net.minecraft.world.gen.feature.WorldGenHellLava;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraft.world.gen.structure.MapGenNetherBridge;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.terraingen.ChunkGeneratorEvent;
import net.minecraftforge.event.terraingen.ChunkGeneratorEvent.InitNoiseField;
import net.minecraftforge.event.terraingen.InitNoiseGensEvent;
import net.minecraftforge.event.terraingen.TerrainGen;
import net.minecraftforge.fml.common.eventhandler.Event.Result;

public class NetherChunkProvider extends ChunkProviderHell {
	
	private final World world;
	private final boolean generateStructures;
    private final Random rand;
    /** Holds the noise used to determine whether slowsand can be generated at a location */
    private double[] slowsandNoise = new double[256];
    private double[] gravelNoise = new double[256];
    private double[] depthBuffer = new double[256];
    private double[] buffer;
    private NoiseGeneratorOctaves lperlinNoise1;
    private NoiseGeneratorOctaves lperlinNoise2;
    private NoiseGeneratorOctaves perlinNoise1;
    /** Determines whether slowsand or gravel can be generated at a location */
    private NoiseGeneratorOctaves slowsandGravelNoiseGen;
    /** Determines whether something other than nettherack can be generated at a location */
    private NoiseGeneratorOctaves netherrackExculsivityNoiseGen;
    public NoiseGeneratorOctaves scaleNoise;
    public NoiseGeneratorOctaves depthNoise;
    private final WorldGenFire fireFeature = new WorldGenFire();
    private final WorldGenGlowStone1 lightGemGen = new WorldGenGlowStone1();
    private final WorldGenGlowStone2 hellPortalGen = new WorldGenGlowStone2();
    private final WorldGenerator quartzGen = new WorldGenMinable(Blocks.QUARTZ_ORE.getDefaultState(), 14, BlockMatcher.forBlock(Blocks.NETHERRACK));
    private final WorldGenerator field_189888_D = new WorldGenMinable(Blocks.field_189877_df.getDefaultState(), 33, BlockMatcher.forBlock(Blocks.NETHERRACK));
    private final WorldGenHellLava lavaTrapGen = new WorldGenHellLava(Blocks.FLOWING_LAVA, true);
    private final WorldGenHellLava hellSpringGen = new WorldGenHellLava(Blocks.FLOWING_LAVA, false);
    private final WorldGenBush brownMushroomFeature = new WorldGenBush(Blocks.BROWN_MUSHROOM);
    private final WorldGenBush redMushroomFeature = new WorldGenBush(Blocks.RED_MUSHROOM);
    private MapGenNetherBridge genNetherBridge = new MapGenNetherBridge();
    private MapGenBase genNetherCaves = new MapGenCavesHell();
    double[] pnr;
    double[] ar;
    double[] br;
    double[] noiseData4;
    double[] dr;
	    
    private Biome[] BiomesForGeneration;

	   
	    
	    public NetherChunkProvider(World world, Boolean genStructures){
	    	super(world, genStructures, world.getSeed());
	    	
	    	 this.world = world;
	    	 this.generateStructures = genStructures;
	         this.rand = new Random(world.getSeed());
	         this.lperlinNoise1 = new NoiseGeneratorOctaves(this.rand, 16);
	         this.lperlinNoise2 = new NoiseGeneratorOctaves(this.rand, 16);
	         this.perlinNoise1 = new NoiseGeneratorOctaves(this.rand, 8);
	         this.slowsandGravelNoiseGen = new NoiseGeneratorOctaves(this.rand, 4);
	         this.netherrackExculsivityNoiseGen = new NoiseGeneratorOctaves(this.rand, 4);
	         this.scaleNoise = new NoiseGeneratorOctaves(this.rand, 10);
	         this.depthNoise = new NoiseGeneratorOctaves(this.rand, 16);

	         InitNoiseGensEvent.ContextHell ctx = new net.minecraftforge.event.terraingen.InitNoiseGensEvent.ContextHell(lperlinNoise1, lperlinNoise2, perlinNoise1, slowsandGravelNoiseGen, netherrackExculsivityNoiseGen, scaleNoise, depthNoise);
	         
	         this.lperlinNoise1 = ctx.getLPerlin1();
	         this.lperlinNoise2 = ctx.getLPerlin2();
	         this.perlinNoise1 = ctx.getPerlin();
	         this.slowsandGravelNoiseGen = ctx.getPerlin2();
	         this.netherrackExculsivityNoiseGen = ctx.getPerlin3();
	         this.scaleNoise = ctx.getScale();
	         this.depthNoise = ctx.getDepth();
	         this.genNetherBridge = (MapGenNetherBridge)TerrainGen.getModdedMapGen(genNetherBridge, net.minecraftforge.event.terraingen.InitMapGenEvent.EventType.NETHER_BRIDGE);
	         this.genNetherCaves = (MapGenCavesHell)TerrainGen.getModdedMapGen(genNetherCaves, net.minecraftforge.event.terraingen.InitMapGenEvent.EventType.NETHER_CAVE);
	     }
	    
	    /** This one sets the blocks in the chunk*/
	    public void prepareHeights(int x, int z, ChunkPrimer primer, Biome[] biomes)
	    {
	    	
	    	
	       // int i = 4; Int was meant for Decoration. I don't like this kind of Decoration in Java  
	        int j = this.world.getSeaLevel() / 2 + 1;
	        // int k = 5; Int was meant for Decoration. I don't like this kind of Decoration in Java  
	        //int l = 17; Int was meant for Decoration. I don't like this kind of Decoration in Java  
	        // int i1 = 5; Int was meant for Decoration. I don't like this kind of Decoration in Java  
	         this.buffer = this.getHeights(this.buffer, x * 4, 0, z * 4, 5, 17, 5);

	        for (int j1 = 0; j1 < 4; ++j1)
	        {
	            for (int k1 = 0; k1 < 4; ++k1)
	            {
	                for (int l1 = 0; l1 < 16; ++l1)
	                {
	                   // double d0 = 0.125D; double was meant for Decoration. I don't like this kind of Decoration in Java 
	                	double d1 = this.buffer[((j1 + 0) * 5 + k1 + 0) * 17 + l1 + 0];
	                    double d2 = this.buffer[((j1 + 0) * 5 + k1 + 1) * 17 + l1 + 0];
	                    double d3 = this.buffer[((j1 + 1) * 5 + k1 + 0) * 17 + l1 + 0];
	                    double d4 = this.buffer[((j1 + 1) * 5 + k1 + 1) * 17 + l1 + 0];
	                    double d5 = (this.buffer[((j1 + 0) * 5 + k1 + 0) * 17 + l1 + 1] - d1) * 0.125D;
	                    double d6 = (this.buffer[((j1 + 0) * 5 + k1 + 1) * 17 + l1 + 1] - d2) * 0.125D;
	                    double d7 = (this.buffer[((j1 + 1) * 5 + k1 + 0) * 17 + l1 + 1] - d3) * 0.125D;
	                    double d8 = (this.buffer[((j1 + 1) * 5 + k1 + 1) * 17 + l1 + 1] - d4) * 0.125D;
	                    
	                    for (int i2 = 0; i2 < 8; ++i2)
	                    {
	                       // double d9 = 0.25D;
	                        double d10 = d1;
	                        double d11 = d2;
	                        double d12 = (d3 - d1) * 0.25D;
	                        double d13 = (d4 - d2) * 0.25D;

	                        for (int j2 = 0; j2 < 4; ++j2)
	                        {
	                          //double d14 = 0.25D;
	                            double d15 = d10;
	                            double d16 = (d11 - d10) * 0.25D;
	                            

	                            for (int k2 = 0; k2 < 4; ++k2)
	                            {
	                                IBlockState iblockstate = null;
	                                
	                                int posX = j2 + j1 * 4;
	                                int posY = i2 + l1 * 8;
	                                int posZ = k2 + k1 * 4;
	                                
	                                
	                                
	                                Biome biome = biomes[posX + posZ * 16];
	                                
	                                if (l1 * 8 + i2 < j)
	                                {
	                                	
	                                	
	                                	if(biome == MarkBiome.Biome_2_Cryst || biome == MarkBiome.Biome_2_CrystDesert)
                                    	{
                                    		iblockstate = MarkFluids.BlueLava.getBlock().getDefaultState();
                                    	}
                                    	else
                                    	{
                                    		iblockstate = LAVA;
                                    	}
	                                }

	                                if (d15 > 0.0D)
	                                {
	                                    iblockstate = biome.fillerBlock;
	                                }

	                                primer.setBlockState(posX, posY, posZ, iblockstate);
	                                d15 += d16;
	                            }

	                            d10 += d12;
	                            d11 += d13;
	                        }

	                        d1 += d5;
	                        d2 += d6;
	                        d3 += d7;
	                        d4 += d8;
	                    }
	                }
	            }
	        }
	    }
	    
	    public void buildSurfaces(int x, int y, ChunkPrimer primer, Biome[] biomes)
	    {
	        if (!ForgeEventFactory.onReplaceBiomeBlocks(this, x, y, primer, this.world)) return;
	        
	        int SeaLevel = 64;
	        
	        
	        this.slowsandNoise = this.slowsandGravelNoiseGen.generateNoiseOctaves(this.slowsandNoise, x * 16, y * 16, 0, 16, 16, 1, 0.03125D, 0.03125D, 1.0D);
	        this.gravelNoise = this.slowsandGravelNoiseGen.generateNoiseOctaves(this.gravelNoise, x * 16, 109, y * 16, 16, 1, 16, 0.03125D, 1.0D, 0.03125D);
	        this.depthBuffer = this.netherrackExculsivityNoiseGen.generateNoiseOctaves(this.depthBuffer, x * 16, y * 16, 0, 16, 16, 1, 0.0625D, 0.0625D, 0.0625D);

	        for (int posZ = 0; posZ < 16; ++posZ)
	        {
	            for (int posX = 0; posX < 16; ++posX)
	            {
	                boolean flag = this.slowsandNoise[posZ + posX * 16] + this.rand.nextDouble() * 0.2D > 0.0D;
	                boolean flag1 = this.gravelNoise[posZ + posX * 16] + this.rand.nextDouble() * 0.2D > 0.0D;
	                int l = (int)(this.depthBuffer[posZ + posX * 16] / 3.0D + 3.0D + this.rand.nextDouble() * 0.25D);
	                int i1 = -1;
	                
	                Biome biome = biomes[posZ + posX * 16];
	                IBlockState iblockstate = biome.topBlock;
	                IBlockState iblockstate1 = biome.fillerBlock;
	                

	                for (int posY = 127; posY >= 0; --posY)
	                {
	                    if (posY < 127 - this.rand.nextInt(5) && posY > this.rand.nextInt(5))
	                    {
	                        IBlockState iblockstate2 = primer.getBlockState(posX, posY, posZ);

	                        if (iblockstate2.getBlock() != null && iblockstate2.getMaterial() != Material.AIR)
	                        {
	                            if (iblockstate2.getBlock() == biome.fillerBlock)
	                            {
	                                if (i1 == -1)
	                                {
	                                    if (l <= 0)
	                                    {
	                                        iblockstate = AIR;
	                                        iblockstate1 = biome.fillerBlock;
	                                    }
	                                    else if (posY >= SeaLevel - 4 && posY <= SeaLevel + 1)
	                                    {
	                                        iblockstate = biome.topBlock;
	                                        iblockstate1 = biome.fillerBlock;

	                                        if (flag1)
	                                        {
	                                            iblockstate = GRAVEL;
	                                            iblockstate1 = biome.fillerBlock;
	                                        }

	                                        if (flag)
	                                        {
	                                            iblockstate = SOUL_SAND;
	                                            iblockstate1 = SOUL_SAND;
	                                        }
	                                    }

	                                    if (posY < SeaLevel && (iblockstate == null || iblockstate.getMaterial() == Material.AIR))
	                                    {
	                                    	if(biome == MarkBiome.Biome_2_Cryst || biome == MarkBiome.Biome_2_CrystDesert)
	                                    	{
	                                    		iblockstate = MarkFluids.BlueLava.getBlock().getDefaultState();
	                                    	}
	                                    	else
	                                    	{
	                                    		iblockstate = LAVA;
	                                    	}
	                                    }

	                                    i1 = l;

	                                    if (posY >= SeaLevel - 1)
	                                    {
	                                        primer.setBlockState(posX, posY, posZ, iblockstate);
	                                    }
	                                    else
	                                    {
	                                        primer.setBlockState(posX, posY, posZ, iblockstate1);
	                                    }
	                                }
	                                else if (i1 > 0)
	                                {
	                                    --i1;
	                                    primer.setBlockState(posX, posY, posZ, iblockstate1);
	                                }
	                            }
	                        }
	                        else
	                        {
	                            i1 = -1;
	                        }
	                    }
	                    else
	                    {
	                        primer.setBlockState(posX, posY, posZ, BEDROCK);
	                    }
	                }
	            }
	        }
	    
	        
	    }
	    
	    @Override
	    public Chunk provideChunk(int x, int z)
	    {
	    	this.rand.setSeed((long) x * 341873128712L + (long) z * 132897987541L);
	        ChunkPrimer chunkprimer = new ChunkPrimer();
	        this.BiomesForGeneration = world.getBiomeProvider().loadBlockGeneratorData(this.BiomesForGeneration, x * 16, z * 16, 16, 16);
	        prepareHeights(x, z, chunkprimer, this.BiomesForGeneration);
	        buildSurfaces(x, z, chunkprimer, this.BiomesForGeneration);
	        genNetherCaves.generate(world, x, z, chunkprimer);
	        if (this.generateStructures)
	        {
	        genNetherBridge.generate(world, x, z, chunkprimer);
	        }

	        Chunk chunk = new Chunk(world, chunkprimer, x, z);
	        Biome[] abiome = world.getBiomeProvider().loadBlockGeneratorData((Biome[])null, x * 16, z * 16, 16, 16);
	        byte[] abyte = chunk.getBiomeArray();

	        for(int i = 0; i < abyte.length; ++i)
	        {
	        	abyte[i] = (byte) Biome.getIdForBiome(abiome[i]);
	        }

	        chunk.resetRelightChecks();
	        return chunk;
	    }
	    
	    private double[] getHeights(double[] MapHeigth, int x, int y, int z, int xZise, int yZise, int zZise)
	    {
	        if (MapHeigth == null)
	        {
	        	MapHeigth = new double[xZise * yZise * zZise];
	        }

	        InitNoiseField event = new ChunkGeneratorEvent.InitNoiseField(this, MapHeigth, x, y, z, xZise, yZise, zZise);
	        MinecraftForge.EVENT_BUS.post(event);
	        if (event.getResult() == Result.DENY) return event.getNoisefield();

	        // double d0 = 684.412D;  double was meant for Decoration. I don't like this kind of Decoration in Java
	        // double d1 = 2053.236D;  double was meant for Decoration. I don't like this kind of Decoration in Java
	        this.noiseData4 = this.scaleNoise.generateNoiseOctaves(this.noiseData4, x, y, z, xZise, 1, zZise, 1.0D, 0.0D, 1.0D);
	        this.dr = this.depthNoise.generateNoiseOctaves(this.dr, x, y, z, xZise, 1, zZise, 100.0D, 0.0D, 100.0D);
	        this.pnr = this.perlinNoise1.generateNoiseOctaves(this.pnr, x, y, z, xZise, yZise, zZise, 8.555150000000001D, 34.2206D, 8.555150000000001D);
	        this.ar = this.lperlinNoise1.generateNoiseOctaves(this.ar, x, y, z, xZise, yZise, zZise, 684.412D, 2053.236D, 684.412D);
	        this.br = this.lperlinNoise2.generateNoiseOctaves(this.br, x, y, z, xZise, yZise, zZise, 684.412D, 2053.236D, 684.412D);
	        int i = 0;
	        double[] adouble = new double[yZise];

	        for (int j = 0; j < yZise; ++j)
	        {
	            adouble[j] = Math.cos((double)j * Math.PI * 6.0D / (double)yZise) * 2.0D;
	            double d2 = (double)j;

	            if (j > yZise / 2)
	            {
	                d2 = (double)(yZise - 1 - j);
	            }

	            if (d2 < 4.0D)
	            {
	                d2 = 4.0D - d2;
	                adouble[j] -= d2 * d2 * d2 * 10.0D;
	            }
	        }

	         for (int l = 0; l < xZise; ++l) 
	         {
	            for (int i1 = 0; i1 < zZise; ++i1)
	          {               
	                double d3 = 0.0D; 

	                for (int k = 0; k < yZise; ++k)
	                {
	                    double d4 = adouble[k];
	                    double d5 = this.ar[i] / 512.0D;
	                    double d6 = this.br[i] / 512.0D;
	                    double d7 = (this.pnr[i] / 10.0D + 1.0D) / 2.0D;
	                    double d8;

	                    if (d7 < 0.0D)
	                    {
	                        d8 = d5;
	                    }
	                    else if (d7 > 1.0D)
	                    {
	                        d8 = d6;
	                    }
	                    else
	                    {
	                        d8 = d5 + (d6 - d5) * d7;
	                    }

	                    d8 = d8 - d4;

	                    if (k > yZise - 4)
	                    {
	                        double d9 = (double)((float)(k - (yZise - 4)) / 3.0F);
	                        d8 = d8 * (1.0D - d9) + -10.0D * d9;
	                    }

	                    if ((double)k < 0.0D)
	                    {
	                        double d10 = (0.0D - (double)k) / 4.0D;
	                        d10 = MathHelper.clamp_double(d10, 0.0D, 1.0D);
	                        d8 = d8 * (1.0D - d10) + -10.0D * d10;
	                    }

	                    MapHeigth[i] = d8;
	                    ++i;
	                }
	                }}
	        

	        return MapHeigth;
	    }
	    
	    @Override
	    public void populate(int chunkX, int chunkZ)
	    {
	        ChunkPos chunkPos = new ChunkPos(chunkX, chunkZ);
	        BlockPos blockPos = new BlockPos(chunkX * 16, 0, chunkZ * 16);
	        Biome biome = world.getBiomeForCoordsBody(blockPos.add(16, 0, 16));

	        BlockFalling.fallInstantly = true;

	        genNetherBridge.generateStructure(world, rand, chunkPos);
	        biome.decorate(world, rand, blockPos);
	        WorldEntitySpawner.performWorldGenSpawning(world, biome, blockPos.getX() + 8, blockPos.getZ() + 8, 16, 16, rand);

	        BlockFalling.fallInstantly = false;
	    }

	    @Override
	    public boolean generateStructures(Chunk chunk, int chunkX, int chunkZ)
	    {
	        return false;
	    }

	    @Override
	    public List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType creatureType, BlockPos pos)
	    {
	        if(creatureType == EnumCreatureType.MONSTER)
	        {
	            if(genNetherBridge.isInsideStructure(pos))
	            {
	                return genNetherBridge.getSpawnList();
	            }

	            if(genNetherBridge.isPositionInStructure(world, pos) && world.getBlockState(pos.down()).getBlock() == Blocks.NETHER_BRICK)
	            {
	                return genNetherBridge.getSpawnList();
	            }
	        }

	        return world.getBiomeForCoordsBody(pos).getSpawnableList(creatureType);
	    }
	    
	    @Override
	    public BlockPos getStrongholdGen(World world, String structureName, BlockPos pos)
	    {
	        return null;
	    }

	    @Override
	    public void recreateStructures(Chunk chunk, int chunkX, int chunkZ)
	    {
	        genNetherBridge.generate(world, chunkX, chunkZ, null);
	    }
	    
}
