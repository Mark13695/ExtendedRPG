package com.modMark.Generator.Nether;

import java.util.List;

import com.modMark.Generator.MarkBiome;

import net.minecraft.util.WeightedRandom;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.layer.IntCache;
import net.minecraftforge.common.BiomeManager;
import net.minecraftforge.common.BiomeManager.BiomeEntry;

public class NetherGenLayerBiome extends NetherGenLayer{

	public NetherGenLayerBiome(long seed) {
		super(seed);
		
	}
	
	 private BiomeEntry getBiomeEntries(List<BiomeManager.BiomeEntry> biomeEntries)
	    {
	        return WeightedRandom.getRandomItem(biomeEntries, nextInt(WeightedRandom.getTotalWeight(biomeEntries)));
	    }
	
	 @Override
	    public int[] getInts(int areaX, int areaY, int width, int Length)
	    {
	        int[] aint = IntCache.getIntCache(width * Length);

	        for(int i = 0; i < Length; ++i)
	        {
	            for(int j = 0; j < width; ++j)
	            {
	                initChunkSeed((long) (j + areaX), (long) (i + areaY));
	                aint[j + i * width] = Biome.getIdForBiome(getBiomeEntries(MarkBiome.getBiomeEntries()).biome);
	                
	                
	            }
	        }

	        return aint;
	    }

	
}
