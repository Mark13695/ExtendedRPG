package com.modMark.Generator.Nether;

import net.minecraft.world.DimensionType;
import net.minecraft.world.World;
import net.minecraft.world.WorldProviderHell;
import net.minecraft.world.chunk.IChunkGenerator;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class NetherWorldProvider extends WorldProviderHell
{
    @Override
    public void createBiomeProvider()
    {
        biomeProvider = new NetherBiomeProvider(worldObj.getSeed());
        isHellWorld = true;
        hasNoSky = true;
        setDimension(-1);
    }
    
    public boolean isSurfaceWorld()
    {
        return false;
    }

    @Override
    public IChunkGenerator createChunkGenerator()
    {
        return new NetherChunkProvider(this.worldObj, this.worldObj.getWorldInfo().isMapFeaturesEnabled());
    }

    @Override
    @SideOnly(Side.CLIENT)
    public boolean doesXZShowFog(int x, int z)
    {
        return true;
    }
    
}
