package com.modMark.Generator;

import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.Block.MarkTallGrass;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;

public class WorldGenMarkGrass extends WorldGenerator{

	private final Block MarkGrass;

    public WorldGenMarkGrass(Block block)
    {
        this.MarkGrass = block;
    }
    @Override
    public boolean generate(World worldIn, Random rand, BlockPos p)
    {
    	IBlockState state;
        Block block;

        do
        {
        	state = worldIn.getBlockState(p);
            block = state.getBlock();
            if (!block.isAir(state, worldIn, p) && !block.isLeaves(state, worldIn, p)) break;
            p = p.down();
        } while (p.getY() > 0);

       int x = p.getX();
       int y = p.getY();
       int z = p.getZ();
        for (int i = 0; i < 128; ++i)
        {
            BlockPos blockpos = p.add(rand.nextInt(8) - rand.nextInt(8), rand.nextInt(4) - rand.nextInt(4), rand.nextInt(8) - rand.nextInt(8));
            if(worldIn.isAirBlock(blockpos) && worldIn.getBiomeForCoordsBody(p)== MarkBiome.Biome_2_CrystDesert || worldIn.isAirBlock(blockpos) && worldIn.getBiomeForCoordsBody(p)== MarkBiome.Biome_2_NetherDesert){
            	}
            
            if (worldIn.isAirBlock(blockpos) && ((MarkTallGrass) this.MarkGrass).canBlockStay(worldIn, blockpos, this.MarkGrass.getDefaultState()))
            {
                worldIn.setBlockState(blockpos, this.MarkGrass.getDefaultState(), 2);
            }
        }

        return true;
    }
}
	

