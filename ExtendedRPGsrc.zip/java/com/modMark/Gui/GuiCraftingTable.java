package com.modMark.Gui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import com.modMark.Crafting.MarkContainer;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Item_Block.TileEntity.TECraftingTable;
import com.modMark.Main.MainRegistry;
import com.modMark.Packets.CraftingPacketS;
import com.modMark.Packets.HiscorePacketA;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.client.config.GuiSlider;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GuiCraftingTable extends GuiContainer {
	
	public static int SkillID;
	private String[] SkillName = new String[35];
	private int MainLock = 1;
	private double Level1;
	private int Level;
	private double NextLevel0;
	private double NextLevel1;
	private int NextLevel; 
	private int XpNeed; 
	private double Degrees1;
	private double Degrees; //head
	public static int XP;
	public static boolean NeedsEnergy;
	private float PoX;
	private float PoY;
	private int xsize = 235;
	private int ysize = 220;
	private int w = this.width;
	private int h = this.height;
	private int x = ((w - xsize)  / 2);
	private int y = ((h - ysize) / 2);
	private int z = 1;
	private GuiTextField searchField;
	private boolean clearSearch;
	private boolean prevSearchClick;
	private boolean onSearchClick;
	private TECraftingTable TE;
	private ItemStack SlotItem;
	private int addLevel = 0;
	private int hasItemVariants = 0;
	private int ItemVariant = 0;
	private int ItemVariant1 = 0;
	private int ItemVariant2 = 0;
	private int ItemVariant3 = 0;
	private int ItemVarZise = 0;
	private int ItemVarZise1 = 0;
	private int ItemVarZise2 = 0;
	private int ItemVarZise3 = 0;
	
	private float ScrollVal = 0.0F;
	private boolean isScrolling;
	private boolean HideInventory;
	private boolean wasClicking;
	private int ExtraRows;
	public static EntityPlayer player;
	private boolean Craftclick = false;
	private boolean remCraftstack = false;
	private boolean addremIngr = false;
	
	
	
	
	
	

	
	
	public GuiCraftingTable(InventoryPlayer invPlayer, TECraftingTable tile) {
		super(new MarkContainer(invPlayer, tile));
		this.TE = tile;
		xSize = 235;
		ySize = 220;
		ExtraRows = ((((MarkContainer) this.inventorySlots).Stacks.size() + 4 - 1) / 4 - 5) > 0 ? (((MarkContainer) this.inventorySlots).Stacks.size() + 4 - 1) / 4 - 5 : 0;
		if (this.TE.getStackInSlot(25) != null){
			this.SlotItem = this.TE.getStackInSlot(25);
		this.setCorrectList(this.SlotItem);
		}
		
	}



	
	 @Override
     public void drawGuiContainerBackgroundLayer(float pticks , int mouseX, int mouseY){
		 this.drawDefaultBackground();
		 ResourceLocation location = new ResourceLocation("mark13695", "textures/gui/MarkCraftingContainer.png");
		 this.mc.getTextureManager().bindTexture(location);
		 
		 
		 this.CalcLvl();
		 
		 // positions
		 	this.PoX = mouseX;
		 	this.PoY = mouseY;
		 	this.xsize = 235;
		 	this.ysize = 220;
		 	this.w = this.width;
		 	this.h = this.height;
		 	this.x = ((w - xSize)  / 2);
		 	this.y = ((h - ySize) / 2);
		 	this.z = 1;
			
			//draws the head picture
			drawModalRectWithCustomSizedTexture(this.x, this.y, 0, 0, this.xsize, this.ysize, 235, 220);
		 
		 ResourceLocation[] SkillIcon = new ResourceLocation[35];
		 
		 SkillIcon[0] = new ResourceLocation("mark13695", "textures/gui/No_Icon.png");
		 SkillIcon[1] = new ResourceLocation("mark13695", "textures/gui/Archeology_Icon.png");
		 SkillIcon[2] = new ResourceLocation("mark13695", "textures/gui/Tailory_Icon.png");
		 SkillIcon[3] = new ResourceLocation("mark13695", "textures/gui/Smithing_Icon.png");
		 SkillIcon[4] = new ResourceLocation("mark13695", "textures/gui/Tanning_Icon.png");
		 SkillIcon[5] = new ResourceLocation("mark13695", "textures/gui/Jewelry_Icon.png");
		 SkillIcon[6] = new ResourceLocation("mark13695", "textures/gui/Fletching_Icon.png");
		 SkillIcon[7] = new ResourceLocation("mark13695", "textures/gui/Cooking_Icon.png");
		 SkillIcon[8] = new ResourceLocation("mark13695", "textures/gui/Herblore_Icon.png");
		 SkillIcon[9] = new ResourceLocation("mark13695", "textures/gui/Honour_Icon.png");
		 SkillIcon[10] = new ResourceLocation("mark13695", "textures/gui/Construction_Icon.png");
		 SkillIcon[11] = new ResourceLocation("mark13695", "textures/gui/Technology_Icon.png");
		 SkillIcon[12] = new ResourceLocation("mark13695", "textures/gui/Manufactoring_Icon.png");
		 SkillIcon[13] = new ResourceLocation("mark13695", "textures/gui/Chemistry_Icon.png");
		 
		 //draws the skill icon or a blank field if the block is the basic container
		 ResourceLocation SkillIconLocation = SkillIcon[this.SkillID];
		 this.mc.getTextureManager().bindTexture(SkillIconLocation);
		 if(this.SkillID != 0){
		 drawModalRectWithCustomSizedTexture(this.x + 7, this.y + 161, 0, 0, 16, 16, 16, 16);
		 }
		 else{
			 drawModalRectWithCustomSizedTexture(this.x + 4, this.y + 158, 0, 0, 43, 28, 43, 28);
		 }
		 
		 //this draws an blank field on the oven slot if not needed, some  non-oven level I..
		 //containers and basicTable does'nt need an oven slot
		 if(!this.NeedsEnergy){
			 ResourceLocation location4 = new ResourceLocation("mark13695", "textures/gui/NoEnergy.png");
			 this.mc.getTextureManager().bindTexture(location4);
			 drawModalRectWithCustomSizedTexture(this.x + 59, this.y + 58, 0, 0, 22, 18, 22, 18);
		 }
		 else{
			 ResourceLocation location27 = new ResourceLocation("mark13695", "textures/gui/FurnaceBar.png");
			 this.mc.getTextureManager().bindTexture(location27);
			 int i = 0;
			 if (this.TE.getMaxEnergy() > 0){
			 i = (int)((this.TE.getCurEnergy() / (float)this.TE.getMaxEnergy()) * 17) >= 17 ? 16 :(int)((this.TE.getCurEnergy() / (float)this.TE.getMaxEnergy()) * 17);
			  }
			
			 drawModalRectWithCustomSizedTexture(this.x + 78, this.y + 75 - i, 0, 0, 2, i, 2, i);
				 
		 }
		
		 for (int Py = 0; Py < 5; Py++){
			 for (int Px = 0; Px < 4; Px++){
				 
				 
				 ItemStack stack = this.TE.getStackInSlot(26 + (Py * 4) + Px);
				 if (stack != null){
					 GlStateManager.disableDepth();
					 RenderHelper.enableStandardItemLighting();
					 if(this.GetItemLevel(stack) > this.Level){
						 //TODO : code om de items the GrayScalen
						 GlStateManager.colorMask(true, true, true, false);
					 this.itemRender.renderItemAndEffectIntoGUI(stack, this.x + 139 + (Px * 18), this.y + 48 + (Py * 18));
					 GlStateManager.colorMask(true, true, true, true);
					 }
					 else{
					 
					 this.itemRender.renderItemAndEffectIntoGUI(stack, this.x + 139 + (Px * 18), this.y + 48 + (Py * 18)); 
					 }
			 }}
		 }
		 

		 if(this.SkillID != 0){
			 ResourceLocation location3 = new ResourceLocation("mark13695", "textures/gui/SkillBar.png");
			 this.mc.getTextureManager().bindTexture(location3);
			
			
			drawModalRectWithCustomSizedTexture(this.x + 7, this.y + 180, 0, 0, (int) this.Degrees , 2,(int) this.Degrees , 2);
		 }
		 if(this.TE.GetisActive()){
			 ResourceLocation location28 = new ResourceLocation("mark13695", "textures/gui/CraftBar.png");
			 this.mc.getTextureManager().bindTexture(location28);
			 double bar = (((double)this.TE.getCurrentCrProg() / (double)this.TE.getMaxCrProg()) * 89.0D) < 89.0D ? (((double)this.TE.getCurrentCrProg() / (double)this.TE.getMaxCrProg()) * 89.0D) : 88.0D;
			 drawModalRectWithCustomSizedTexture(this.x + 139, this.y + 32, 0, 0, (int) bar, 2, (int) bar, 2);
		 }
		 //Draws PausePlayButtom
		 
		 if(this.TE.GetisActive()){
			 ResourceLocation location8 = new ResourceLocation("mark13695", "textures/gui/PauseButton.png");
			 this.mc.getTextureManager().bindTexture(location8);	
			drawModalRectWithCustomSizedTexture(this.x + 197, this.y + 11, 0, 0, 14, 12, 14, 12);	 
		 }
		 
		 
		 
		 
		 boolean mouseDown = Mouse.isButtonDown(0);
	        

	        if (!this.wasClicking && mouseDown && mouseX >= this.x + 215 && mouseX <= this.x + 227 && mouseY >= this.y + 48  && mouseY <= this.y + 136)
	        {
	            this.isScrolling = ((MarkContainer) this.inventorySlots).Stacks.size() > 20;
	        }

	        if (!mouseDown)
	        {
	            this.isScrolling = false;
	        }

	        this.wasClicking = mouseDown;

	        if (this.isScrolling)
	        {
	            this.ScrollVal = ((float)(mouseY - (this.y + 48)) - 7.5F) / ((float)(73) - 15.0F);
	            this.ScrollVal = MathHelper.clamp_float(this.ScrollVal, 0.0F, 1.0F);
	            ((MarkContainer)this.inventorySlots).scrollTo(this.ScrollVal);
	        }
		 
		 ResourceLocation Scrollbar = new ResourceLocation("mark13695", "textures/gui/Scroll_IconOn.png");
		 this.mc.getTextureManager().bindTexture(Scrollbar);
		 
		 
		 drawModalRectWithCustomSizedTexture(this.x + 215, this.y + 48 + (int)(this.ScrollVal * 73), 0, 0, 12, 15, 12, 15);
if(!this.TE.GetisActive()){
		 if(this.hasItemVariants == 1){
			if(this.ItemVariant == 0){
				
				ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon0.png");
				this.mc.getTextureManager().bindTexture(IngrBar);
			}
			else if (this.ItemVariant == (this.ItemVarZise - 1)){
				ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon1.png");
				this.mc.getTextureManager().bindTexture(IngrBar);
			}
			else{
				ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon.png");
				this.mc.getTextureManager().bindTexture(IngrBar);
			}
			drawModalRectWithCustomSizedTexture(this.x + 117, this.y + 79, 0, 0, 18, 11, 18, 11);
		 }
		 if(this.hasItemVariants == 2 ||this.hasItemVariants == 4 || this.hasItemVariants == 6  || this.hasItemVariants == 8 ){
				if(this.ItemVariant1 == 0){
					ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon0.png");
					this.mc.getTextureManager().bindTexture(IngrBar);
				}
				else if (this.ItemVariant1 == (this.ItemVarZise1 - 1)){
					ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon1.png");
					this.mc.getTextureManager().bindTexture(IngrBar);
				}
				else{
					ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon.png");
					this.mc.getTextureManager().bindTexture(IngrBar);
				}
				drawModalRectWithCustomSizedTexture(this.x + 117, this.y + 103, 0, 0, 18, 11, 18, 11);
			 }
		 if(this.hasItemVariants == 3 ||this.hasItemVariants == 4 || this.hasItemVariants == 7  || this.hasItemVariants == 8 ){
				if(this.ItemVariant2 == 0){
					ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon0.png");
					this.mc.getTextureManager().bindTexture(IngrBar);
				}
				else if (this.ItemVariant2 == (this.ItemVarZise2 - 1)){
					ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon1.png");
					this.mc.getTextureManager().bindTexture(IngrBar);
				}
				else{
					ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon.png");
					this.mc.getTextureManager().bindTexture(IngrBar);
				}
				drawModalRectWithCustomSizedTexture(this.x + 117, this.y + 114, 0, 0, 18, 11, 18, 11);
			 }
		 if(this.hasItemVariants == 5 ||this.hasItemVariants == 6 || this.hasItemVariants == 7  || this.hasItemVariants == 8 ){
				if(this.ItemVariant3 == 0){
					ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon0.png");
					this.mc.getTextureManager().bindTexture(IngrBar);
				}
				else if (this.ItemVariant3 == (this.ItemVarZise3 - 1)){
					ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon1.png");
					this.mc.getTextureManager().bindTexture(IngrBar);
				}
				else{
					ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon.png");
					this.mc.getTextureManager().bindTexture(IngrBar);
				}
				
				drawModalRectWithCustomSizedTexture(this.x + 117, this.y + 125, 0, 0, 18, 11, 18, 11);
			 }
	 }
else{
	ResourceLocation IngrBar2 = new ResourceLocation("mark13695", "textures/gui/ActiveTask.png");
	this.mc.getTextureManager().bindTexture(IngrBar2);
	drawModalRectWithCustomSizedTexture(this.x + 174, this.y + 3, 0, 0, 34, 28, 34, 28);
	
}
		 int SkillID2 = this.SkillID < 11 && this.SkillID != 0 ? (12 + this.SkillID) : (this.SkillID == 11 ? 28 : 8);
		 
		 if(!this.TE.GetisActive()){
		 if(this.SlotItem != null){
			 if(this.TE.getCraftStackValue() > this.MaxCraft()){
				 if(this.MaxCraft() == 0){
				 this.removeCraft();
				 }
				 this.TE.setCraftStackValue(this.MaxCraft());
				 this.MaxCr2();
				 
			 }
			 else if(this.TE.getCraftStackValue() == 0 && this.TE.getStackInSlot(25) != null){
				 this.removeCraft();
				 this.MaxCr2();
			 }

			 drawString (fontRendererObj , "" + this.getCorStackSize(this.SlotItem) + "x "+ (this.hasLevel(this.SlotItem) ?this.ItemNames(this.SlotItem, true) : "???") , this.x + 6, this.y + 80 , 0x00ffffff);
			 if(SkillID2 != 8){
			 drawString (fontRendererObj , "Requires: " + (this.GetItemLevel(this.SlotItem) + this.addLevel) + " " + this.SkillName[SkillID2] , this.x + 6, this.y + 90 , !this.hasLevel(this.SlotItem) ?  0x00ff0000 : 0x00ffffff);
			 }
			 int Colour = 0x00ff0000;
			 if(this.getRecipe(SlotItem) != null){
			 for (int i = 0; i < this.getRecipe(SlotItem).size(); i++){
				 Colour = 0x00ff0000;
				 for(int j = 0; j < 12; j++){
					 if(TE.getInventory()[j] != null){
					 if(this.getRecipe(SlotItem).get(i).getItem() == TE.getInventory()[j].getItem()){
						 if(this.getRecipe(SlotItem).get(i).stackSize <= TE.getInventory()[j].stackSize){
							 Item it = this.getRecipe(SlotItem).get(i).getItem();
							 if(this.moreMeta(it)){
								if(TE.getInventory()[j].getMetadata() == this.getRecipe(SlotItem).get(i).getMetadata()){
									Colour = 0x00ffffff; 
								}	
							 }else{Colour = 0x00ffffff;}
						 }
					 }
				 }
				 }
				if(this.hasLevel(this.SlotItem)){
			 drawString (fontRendererObj , "" + this.getRecipe(SlotItem).get(i).stackSize + "x " + this.ItemNames(getRecipe(SlotItem).get(i), false) , this.x + 6, this.y + 104 + (i * 11) , Colour);
				}
				else{
					 drawString (fontRendererObj , "" + this.getRecipe(SlotItem).get(i).stackSize + "x " + "???" , this.x + 6, this.y + 104 + (i * 11) , 0x00ff0000);
				}
			 }
		 }	 
		 }
		 else{
			 drawString (fontRendererObj , "What would you like" , this.x + 6, this.y + 80 , 0x00ffffff);
			 drawString (fontRendererObj , "to craft?" , this.x + 6, this.y + 90 , 0x00ffffff);
		 }
		 }
		 else{
			 if(this.SlotItem != null){
				 
				 int q = this.TE.getBlockType() != MarkBlocks.BasicTable ? SkillID2 : this.TE.BasicTableSkill((this.TE.getStackInSlot(25) != null ? this.TE.getStackInSlot(25).getItem() : null));
				 drawString (fontRendererObj , "Craft: " + this.ItemNames(this.SlotItem, true) , this.x + 6, this.y + 80 , 0x00ffffff);
				 drawString (fontRendererObj , "Complete in: " + this.intToTime() , this.x + 6, this.y + 94 , 0x00ffffff);
				 drawString (fontRendererObj , "Gained: " + String.format("%,d", this.TE.GainedXP) + " " + this.SkillName[q] + " XP" , this.x + 6, this.y + 108 , 0x00ffffff);
			 }
			 
		 }
		 this.searchField.drawTextBox();
		 int posfix1 = this.TE.getCraftStackValue() < 10 ? 6 :( this.TE.getCraftStackValue() > 99 ? 0 : 3);
		 if(this.TE.getCraftStackValue() > 0){
			 drawString (fontRendererObj , "" + this.TE.getCraftStackValue() , ((this.x + 176) + posfix1), this.y + 13 , 0x0000ff00);
			 }
		 
		 if(this.SkillID != 0){
			 
			 
			 
		 
		 int posfix = this.Level < 10 ? 6 :( this.Level > 99 ? 0 : 3);
		 drawString (fontRendererObj , "" + this.Level , ((this.x + 26) + posfix), this.y + 165 , 0x0000ff00);
		
		 if(mouseX >= this.x + 6 && mouseX <= this.x + 45 && mouseY >= this.y + 160 && mouseY <= this.y + 182){
			 
  	    	
			 List list = new ArrayList();
			 list.add(this.SkillName[SkillID2] +": " + this.Level);
			 list.add("XP: " + String.format("%,d",this.XP));
			 if(this.Level == 99 && this.MainLock == 1 ) {}
			 else if(this.Level == 200 && this.MainLock == 2) {}
			 else if(this.Level == 255){}
			 else{
			 list.add("Next Level: " + String.format("%,d",this.NextLevel));
			 list.add("XP Needed: " + String.format("%,d",this.XpNeed));
			 }
			 
			 this.drawHoveringText(list, this.x + 236, this.y + 16, fontRendererObj);
		 }
	 }
	
	 }
	
	
	public boolean moreMeta(Item it){
		
		Boolean b = it == Item.getItemFromBlock(Blocks.PLANKS) || it == Item.getItemFromBlock(Blocks.LOG)
				|| it == Items.DYE || it == Item.getItemFromBlock(Blocks.WOOL)
				|| it == Items.FISH || it == Item.getItemFromBlock(Blocks.LOG2)
				|| it == Item.getItemFromBlock(Blocks.RED_FLOWER) || it == Item.getItemFromBlock(Blocks.DOUBLE_PLANT)
				|| it == Item.getItemFromBlock(Blocks.SAND) || it == Item.getItemFromBlock(Blocks.STONE)
				|| it == Item.getItemFromBlock(Blocks.COBBLESTONE) || it == MarkItems.Herb
				|| it == Item.getItemFromBlock(Blocks.STONE_SLAB) || it == Items.COAL;
		return b;
	}
		
	
	 public void initGui()
	    {
		  super.initGui();
		 this.searchField = new GuiTextField(0, this.fontRendererObj, this.guiLeft + 82, this.guiTop + 6, 89, this.fontRendererObj.FONT_HEIGHT);
         this.searchField.setMaxStringLength(15);
         this.searchField.setEnableBackgroundDrawing(false);
         this.searchField.setVisible(false);
         this.searchField.setTextColor(65280);
         
         
        
        
   	    }
	 
	 protected void keyTyped(char typedChar, int keyCode) throws IOException
	    {
		 if (this.clearSearch)
         {
             this.clearSearch = false;
             this.searchField.setText("");
         }
		 
		 if (!this.checkHotbarKeys(keyCode))
         {
             if (this.searchField.textboxKeyTyped(typedChar, keyCode))
             {
            	
                 this.updateShowCaseSearch(this.searchField.getText());
             }
             else
             {
                 super.keyTyped(typedChar, keyCode);
             }
         }
	    }
	
	 private void updateShowCaseSearch(String s)
	    {
		 MarkContainer container = (MarkContainer) this.inventorySlots;
		 
		 container.GetShowcaseItems(s);
		 this.ScrollVal = 0.0F;
		 
	    }
	
	 private String intToTime(){
		 
		int a =  this.TE.TimeRemaining() / 20;
		 
		 int h = a / 3600;
		 int m = a / 60 - (h * 60);
		 int s = (a -(m * 60)) - (h * 3600) ;
		 
		 if (a < 3600){
			 return "" + m + ":" + String.format("%02d", s);
		 }
		 else{
			 return "" + h + ":" + String.format("%02d", m) + ":" + String.format("%02d", s) ;
		 }
	 }
	 
	 private ItemStack getItemInSlot(int mouseX, int mouseY){
		 
		 if(mouseX >= this.x + 138 && mouseX <= this.x + 209 && mouseY >= this.y + 47 && mouseY <= this.y + 136){	
			 
			 for(int y = 0; y < 5; y++){
				 for(int x = 0; x < 4; x++){
			 if(mouseX >= this.x + 138 + (18 * x) && mouseX <= this.x + 155 + (18 * x) && mouseY >= this.y + 47 + (18 * y) && mouseY <= this.y + 64 + (18 * y)){
				  return this.TE.getStackInSlot(26 +(y * 4) + x);
			 } 
				 }
			 }
			 
			 
		 }
		 return null;
	 }
	 
	 private void MaxCr2(){
		 ItemStack[] stack1 = new ItemStack[3];
		 if (this.player != null && this.TE.getCraftStackValue() != 0 && this.SlotItem != null){
			 
			 for (int i = 0; i < 3; i++){
				 stack1[i] = i < this.getRecipe(this.SlotItem).size() ? this.getRecipe(this.SlotItem).get(i) : null;
			 
			 }
			 MainRegistry.network.sendToServer(new CraftingPacketS(this.SlotItem, this.TE.getCraftStackValue(),this.player,this.TE.getPos(), this.TE.GetisActive(), stack1, this.remCraftstack, this.addremIngr));
		 }
		 else if (this.remCraftstack == true){
			 
			 MainRegistry.network.sendToServer(new CraftingPacketS(null, 0, this.player, this.TE.getPos(), false, stack1, this.remCraftstack, this.addremIngr));
		 }
		 
		 
		 this.remCraftstack = false;
		 this.addremIngr = false;
	 }
	 
	 
	 
	 protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException
	    {
		 
		 this.prevSearchClick = this.onSearchClick;
		 if(mouseX >= this.x + 153 && mouseX <= this.x + 226 && mouseY >= this.y + 36 && mouseY <= this.y + 45){
			 this.onSearchClick = true;	 
		 }
		 else{
			 this.onSearchClick = false;
		 }
		 if(this.prevSearchClick && this.onSearchClick){
			 this.searchField.setVisible(true);
             this.searchField.setCanLoseFocus(false);
             this.searchField.setFocused(true);
             
             this.searchField.width = 75;
             this.searchField.xPosition = this.x + 154;
             this.searchField.yPosition = this.y + 37;
             this.updateShowCaseSearch(searchField.getText());
		 }
		 if(!this.prevSearchClick && !this.onSearchClick){
             this.searchField.setCanLoseFocus(true);
             this.searchField.setFocused(false);
             
		 }
		 if(mouseX >= this.x + 138 && mouseX <= this.x + 209 && mouseY >= this.y + 47 && mouseY <= this.y + 136){		
			 if(this.getItemInSlot(mouseX, mouseY) != null){
			if(this.TE.getStackInSlot(25) == null){
			 this.SlotItem = this.getItemInSlot(mouseX, mouseY);
			 this.setCorrectList(this.SlotItem);
			}
			else{
				TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
				this.player.addChatComponentMessage(component);
			}
			 }
			 else{
				 
				 this.SlotItem = null; 
			 }
			 
		 }// TODO
		 
		 if(this.hasItemVariants == 1){
		 if(mouseX >= this.x + 117 && mouseX <= this.x + 125 && mouseY >= this.y + 79 && mouseY <= this.y + 89 && this.ItemVariant > 0){	
			 if(this.TE.getStackInSlot(25) == null){
			 if(this.ItemVariant > 0)this.ItemVariant--;
			 }
			 else{
				 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
					this.player.addChatComponentMessage(component);
			 }
		 }
		 if(mouseX >= this.x + 126 && mouseX <= this.x + 134 && mouseY >= this.y + 79 && mouseY <= this.y + 89 && this.ItemVariant < (this.ItemVarZise - 1)){	
			 if(this.TE.getStackInSlot(25) == null){
			 if(this.ItemVariant < (this.ItemVarZise - 1))this.ItemVariant++;
			 }
			 else{
				 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
					this.player.addChatComponentMessage(component);
			 }
		 }
		 }
		 if(this.hasItemVariants == 2 ||this.hasItemVariants == 4 || this.hasItemVariants == 6  || this.hasItemVariants == 8 ){
			 if(mouseX >= this.x + 117 && mouseX <= this.x + 125 && mouseY >= this.y + 103 && mouseY <= this.y + 113 && this.ItemVariant1 > 0){	
				 if(this.TE.getStackInSlot(25) == null){
				 if(this.ItemVariant1 > 0)this.ItemVariant1--;
				 }
				 else{
					 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
						this.player.addChatComponentMessage(component); 
				 }
			 }
			 if(mouseX >= this.x + 126 && mouseX <= this.x + 134 && mouseY >= this.y + 103 && mouseY <= this.y + 113 && this.ItemVariant1 < (this.ItemVarZise1 - 1)){
				 if(this.TE.getStackInSlot(25) == null){
				 if(this.ItemVariant1 < (this.ItemVarZise1 - 1))this.ItemVariant1++;
				 }
				 else{
					 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
						this.player.addChatComponentMessage(component);
				 }
			 }
			 
		 }
		 if(this.hasItemVariants == 3 ||this.hasItemVariants == 4 || this.hasItemVariants == 7  || this.hasItemVariants == 8 ){
			 if(mouseX >= this.x + 117 && mouseX <= this.x + 125 && mouseY >= this.y + 114 && mouseY <= this.y + 124 && this.ItemVariant2 > 0){		
				 if(this.TE.getStackInSlot(25) == null){
				 if(this.ItemVariant2 > 0)this.ItemVariant2--;
				 }
				 else{
					 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
						this.player.addChatComponentMessage(component);
				 }
			 }
			 if(mouseX >= this.x + 126 && mouseX <= this.x + 134 && mouseY >= this.y + 114 && mouseY <= this.y + 124 && this.ItemVariant2 < (this.ItemVarZise2 - 1)){
				 if(this.TE.getStackInSlot(25) == null){
				 if(this.ItemVariant2 < (this.ItemVarZise2 - 1))this.ItemVariant2++;
				 }
				 else{
					 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
						this.player.addChatComponentMessage(component);
				 }
			 }
			 
		 }
		 if(this.hasItemVariants == 5 ||this.hasItemVariants == 6 || this.hasItemVariants == 7  || this.hasItemVariants == 8 ){
			 if(mouseX >= this.x + 117 && mouseX <= this.x + 125 && mouseY >= this.y + 125 && mouseY <= this.y + 135 && this.ItemVariant1 > 0){		
				 if(this.TE.getStackInSlot(25) == null){
				 if(this.ItemVariant3 > 0)this.ItemVariant3--;
				 }
				 else{
					 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
						this.player.addChatComponentMessage(component);
				 }
			 }
			 if(mouseX >= this.x + 126 && mouseX <= this.x + 134 && mouseY >= this.y + 125 && mouseY <= this.y + 135 && this.ItemVariant1 < (this.ItemVarZise1 - 1)){
				 if(this.TE.getStackInSlot(25) == null){
				 if(this.ItemVariant3 < (this.ItemVarZise3 - 1))this.ItemVariant3++;
				 }
				 else{
					 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
						this.player.addChatComponentMessage(component);
				 }
			 }
			 
		 }
		 
		 if(mouseX >= this.x + 4 && mouseX <= this.x + 17 && mouseY >= this.y + 137 && mouseY <= this.y + 148){	
			 if(this.SlotItem != null){
				 if(this.TE.getStackInSlot(25) != null){
			 if(this.TE.getStackInSlot(25).getItem() != this.SlotItem.getItem()){
				 if(this.hasLevel(this.SlotItem)){
			 if(this.ContainItems(this.SlotItem, 0)){
				 
				
				 this.TE.setInventorySlotContents(25 ,p(this.SlotItem.getItem(), 1)); // slot 25 crafting
				 this.TE.setCraftStackValue(1);
				 
				 this.Craftclick = true;
				}}
				 else{
					 int SkillID2 = this.SkillID < 11 && this.SkillID != 0 ? (12 + this.SkillID) : (this.SkillID == 11 ? 28 : 8);
					 
					 TextComponentString component = new TextComponentString(TextFormatting.RED + "You need a level of " + this.GetItemLevel(this.SlotItem) + " " + this.SkillName[SkillID2] + " for this");
						this.player.addChatComponentMessage(component);
				 
			 }
		 }
		 }
				 else{
					 if(this.hasLevel(this.SlotItem)){
					 if(this.ContainItems(this.SlotItem, 0)){	
						 
					 this.TE.setInventorySlotContents(25 , p(this.SlotItem.getItem(), 1));// slot 25 crafting
					 this.TE.setCraftStackValue(1);
					 this.Craftclick = true;
						 }}
						 else{
							 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
								this.player.addChatComponentMessage(component);
						 }
				 
				 }
			 }
			 
		 }
		 if(mouseX >= this.x + 18 && mouseX <= this.x + 31 && mouseY >= this.y + 137 && mouseY <= this.y + 148){		
			this.removeCraft();
			this.SlotItem = null;
			 
		 }
		 if(mouseX >= this.x + 174 && mouseX <= this.x + 184 && mouseY >= this.y + 3 && mouseY <= this.y + 10){		
			 if(this.TE.getStackInSlot(25) != null){
				 if(!this.TE.GetisActive()){
				 if(this.TE.getCraftStackValue() < 64) this.TE.addRemCraftStackValue(1);
				 this.Craftclick = true;
				 
				 }
			 } 
			 
		 }
		 if(mouseX >= this.x + 185 && mouseX <= this.x + 195 && mouseY >= this.y + 3 && mouseY <= this.y + 10){		
			 if(this.TE.getStackInSlot(25) != null){
				 if(!this.TE.GetisActive()){
				 this.TE.addRemCraftStackValue(10);
				 if(this.TE.getCraftStackValue() > 64) this.TE.setCraftStackValue(64);
				 this.Craftclick = true;
				 
				 }
			 } 
			 
		 }
		 if(mouseX >= this.x + 174 && mouseX <= this.x + 184 && mouseY >= this.y + 23 && mouseY <= this.y + 30){		
			 if(this.TE.getStackInSlot(25) != null){
				 if(!this.TE.GetisActive()){
				 if(this.TE.getCraftStackValue() > 1) this.TE.addRemCraftStackValue(-1);
				 this.Craftclick = true;
				 
				 }
			 } 
			 
		 }
		 
		 if(mouseX >= this.x + 185 && mouseX <= this.x + 195 && mouseY >= this.y + 23 && mouseY <= this.y + 30){		
			 if(this.TE.getStackInSlot(25) != null){
				 if(!this.TE.GetisActive()){
				 this.TE.addRemCraftStackValue(-10);
				 if(this.TE.getCraftStackValue() < 1) this.TE.setCraftStackValue(1);
				 this.Craftclick = true;
				 }
			 } 
			 
		 }
		 if(mouseX >= this.x + 197 && mouseX <= this.x + 207 && mouseY >= this.y + 3 && mouseY <= this.y + 10){		
			 if(this.TE.getStackInSlot(25) != null){
				 if(!this.TE.GetisActive()){
				 this.TE.setCraftStackValue(64);
				 this.Craftclick = true;
				 }
			 } 
			 
		 }
		 if(mouseX >= this.x + 197 && mouseX <= this.x + 207 && mouseY >= this.y + 23 && mouseY <= this.y + 30){		
			 if(this.TE.getStackInSlot(25) != null){
				 if(!this.TE.GetisActive()){
				 this.TE.setCraftStackValue(1);
				 this.Craftclick = true;
				 
				 }
			 } 
			 
		 }
		 boolean setRightVal = false;
		 if(mouseX >= this.x + 197 && mouseX <= this.x + 210 && mouseY >= this.y + 11 && mouseY <= this.y + 22){
			
			if(!this.TE.GetisActive()){
				if(this.TE.getStackInSlot(25) != null){
					this.setCorrectList(this.TE.getStackInSlot(25));
					if(this.ContainItems(this.TE.getStackInSlot(25), 0) && this.TE.getCraftStackValue() > 0){
						

				this.TE.setIsActive(true);
				this.addremIngr = true;
				this.Craftclick = true;
				
				
					}
				}
			}
			
			else{
				this.addremIngr = true;
				this.TE.setIsActive(false);
				this.TE.GainedXP = 0;
				setRightVal = true;
				this.Craftclick = true;
			}
		 
		 
		 }
		 ItemStack[] stack1 = new ItemStack[3];
		 if (this.Craftclick == true && this.player != null && this.TE.getCraftStackValue() != 0 && this.SlotItem != null){
			 
			 for (int i = 0; i < 3; i++){
				 stack1[i] = i < this.getRecipe(this.SlotItem).size() ? this.getRecipe(this.SlotItem).get(i) : null;
			 
			 }
			 MainRegistry.network.sendToServer(new CraftingPacketS(this.SlotItem, this.TE.getCraftStackValue(),this.player,this.TE.getPos(), this.TE.GetisActive(), stack1, this.remCraftstack, this.addremIngr));
		 }
		 else if (this.remCraftstack == true){
			 
			 MainRegistry.network.sendToServer(new CraftingPacketS(null, 0, this.player, this.TE.getPos(), false, stack1, this.remCraftstack, this.addremIngr));
		 }
		 if(setRightVal){
			 this.TE.addRemCraftStackValue(1);
		 }
		 this.Craftclick = false;
		 this.remCraftstack = false;
		 this.addremIngr = false;
		 
		 super.mouseClicked(mouseX, mouseY, mouseButton);
	    }
	
	 
	 public void setCorrectList(ItemStack slotItem){
		 boolean correct1 = false;
		 boolean correct2 = false;
		 boolean correct3 = false;
		 this.ItemVariant = 0;
		 this.ItemVariant1 = 0;
		 this.ItemVariant2 = 0;
		 this.ItemVariant3 = 0;
		 if(slotItem != null){
		 this.getRecipe(slotItem);
		 if(this.hasItemVariants == 1){
			 
			 for(int i = 0; i < this.ItemVarZise; i++){
				 this.ItemVariant = i;
			 if(this.ContainItems(slotItem, 0)){
				
				 correct1 = true;
				 break;
			 }
			 }
			 if (!correct1){
				 this.ItemVariant = 0;
			 }
			 
			 correct2 = true;
			 correct3 = true;
			 this.ItemVariant1 = 0;
			 this.ItemVariant2 = 0;
			 this.ItemVariant3 = 0;	
		 }
		 if(this.hasItemVariants == 2 || this.hasItemVariants == 4 || this.hasItemVariants == 6 || this.hasItemVariants == 8){
			
			 for(int i = 0; i < this.ItemVarZise1; i++){
				 this.ItemVariant1 = i;
				 if(this.ContainItems(slotItem, 1)){
					
					 correct1 = true;
					 break;
				 } 
				 
			 }
			 if (!correct1){
				 this.ItemVariant1 = 0;
			 }
			 if(this.hasItemVariants == 2 || this.hasItemVariants == 6){		 
				 this.ItemVariant2 = 0; 
				 correct2 = true;
			 }
			 if(this.hasItemVariants == 2 || this.hasItemVariants == 4){
				 this.ItemVariant3 = 0;	
				 correct3 = true;
			 }
			 this.ItemVariant = 0;
			 
		 }
		 if(this.hasItemVariants == 3 || this.hasItemVariants == 4 || this.hasItemVariants == 7 || this.hasItemVariants == 8){

			 for(int i = 0; i < this.ItemVarZise2; i++){
				 this.ItemVariant2 = i;
				 if(this.ContainItems(slotItem, 2)){
					 
					 correct2 = true;
					 break;
				 } 
				 
			 }
			 if (!correct2){
				 this.ItemVariant2 = 0;
			 }
			 if(this.hasItemVariants == 3 || this.hasItemVariants == 7){		 
				 this.ItemVariant1 = 0; 
				 correct1 = true;
			 }
			 if(this.hasItemVariants == 3 || this.hasItemVariants == 4){
				 this.ItemVariant3 = 0;
				 correct3 = true;
			 }
			 this.ItemVariant = 0;
			 
		 }
		 if(this.hasItemVariants == 5 || this.hasItemVariants == 6 || this.hasItemVariants == 7 || this.hasItemVariants == 8){
			 for(int i = 0; i < this.ItemVarZise3; i++){
				 this.ItemVariant3 = i;
				 if(this.ContainItems(slotItem, 3)){
					 
					 correct3 = true;
					 break;
				 } 
			 }
			 if (!correct3){
				 this.ItemVariant3 = 0;
			 }
			 if(this.hasItemVariants == 5 || this.hasItemVariants == 7){		 
				 this.ItemVariant1 = 0; 
				 correct1 = true;
			 }
			 if(this.hasItemVariants == 5 || this.hasItemVariants == 6){
				 this.ItemVariant2 = 0;	
				 correct2 = true;
			 }
			 this.ItemVariant = 0;
		 }
		 
		 
		 }
		 else{
			 correct1 = true;
			 correct2 = true;
			 correct3 = true;
			 this.ItemVariant = 0;
			 this.ItemVariant1 = 0;
			 this.ItemVariant2 = 0;
			 this.ItemVariant3 = 0;
		 }
		 
		 
		 
		 
	 }
	 
	 
	 public void removeCraft(){
		 this.TE.removeStackFromSlot(25); // slot 25 craft: enigste veld wat slot 25 op null mag zetten
		 this.TE.setCraftStackValue(0);
		 this.remCraftstack = true;
		 this.Craftclick = true;
		 if(this.TE.GetisActive()){
		 this.addremIngr = true;
		 }
		 else{
			 this.addremIngr = false;
		 }
		 
	 }
	 
	 @Override
     public void drawGuiContainerForegroundLayer(int mouseX, int mouseY){
		 
		 super.drawGuiContainerForegroundLayer(mouseX, mouseY);
		 
		 MarkContainer c = ((MarkContainer) this.inventorySlots);
		 for (int Py = 0; Py < 5; Py++){
			 for (int Px = 0; Px < 4; Px++){ 
			 
			 
			 ItemStack stack = this.TE.getStackInSlot(26 + (Py * 4) + Px);
			 if(stack != null){
				 if(this.GetItemLevel(stack) > this.Level){
					 int x2 = 139 + (18 * Px);
					 int y2 = 48 + (18 * Py);
					 GlStateManager.disableLighting();
		                GlStateManager.disableDepth();
		                GlStateManager.colorMask(true, true, true, false);
		                this.drawGradientRect(x2 ,y2 , x2 + 16, y2 + 16, 0xAA222222, 0xAA222222);
		                GlStateManager.colorMask(true, true, true, true);
		                GlStateManager.enableLighting();
		                GlStateManager.enableDepth();
					 
				 }
			 }}
			 
			 
		 }
		 RenderHelper.disableStandardItemLighting();
		 for (int Py = 0; Py < 5; Py++){
			 for (int Px = 0; Px < 4; Px++){ 
				 
				
				 ItemStack stack = this.TE.getStackInSlot(26 + (Py * 4) + Px);
			 //TODO
			 if (stack != null){
			 if(this.GetItemLevel(stack) > this.Level){
			 int posfix = this.GetItemLevel(stack) < 10 ? 6 :( this.GetItemLevel(stack) > 99 ? 0 : 3);
			 drawString(fontRendererObj ,"" + this.GetItemLevel(stack), 138 + (18 * Px) + posfix ,  47 + (18 * Py) + 5 , 0x00ff0000);
		 }}}}
		 RenderHelper.enableStandardItemLighting();
		 
	 }
	 
	
	 
	 public Boolean ContainItems(ItemStack item, int l){
		 
		 if(this.getRecipe(item) != null){
		 boolean[] b = new boolean[this.getRecipe(item).size()];
		 for(int i = 0; i < this.getRecipe(item).size(); i++){
			 b[i] = false;
		 }
		
		 for (int j = 0; j < this.TE.getInventory().length; j++){
			 if(l == 0){
				
				
				 
		 for(int i = 0; i < this.getRecipe(item).size(); i++){
			if(!b[i]){
				if(this.TE.getInventory()[j] != null){
				if(this.TE.getInventory()[j].getItem() == this.getRecipe(item).get(i).getItem()){
					
					
					if(this.TE.getInventory()[j].stackSize >= this.getRecipe(item).get(i).stackSize){
						 Item it = this.getRecipe(item).get(i).getItem();
						 if(this.moreMeta(it)){
						if(TE.getInventory()[j].getMetadata() == this.getRecipe(item).get(i).getMetadata()){
								b[i] = true; 
								
							}}
							else{
								b[i] = true;
								
							
					}
				}
				}
				
			}
		 }
		 }
		 
		 }
			 
			 if(l == 1){
				 int i = 0;
				 
						
						if(this.TE.getInventory()[j] != null){
							
							if(this.TE.getInventory()[j].getItem() == this.getRecipe(item).get(i).getItem()){
							
							if(this.TE.getInventory()[j].stackSize >= this.getRecipe(item).get(i).stackSize){
								Item it = this.getRecipe(item).get(i).getItem();
								if(this.moreMeta(it)){
								
									if(TE.getInventory()[j].getMetadata() == this.getRecipe(item).get(i).getMetadata()){
										
										return true;
									}}
									else{
										
										return true;
									
							}
						}
						}
						
					}
				 }
				 
			 if(l == 2){
				 int i = 1;
				 
						
						if(this.TE.getInventory()[j] != null){
							if(this.TE.getInventory()[j].getItem() == this.getRecipe(item).get(i).getItem()){
							
							
							if(this.TE.getInventory()[j].stackSize >= this.getRecipe(item).get(i).stackSize){
								Item it = this.getRecipe(item).get(i).getItem();
								if(this.moreMeta(it)){
								
									if(TE.getInventory()[j].getMetadata() == this.getRecipe(item).get(i).getMetadata()){
										return true;
									}}
									else{
										return true;
									
							}
						}
						}
						
					}
				 
				 }
			 if(l == 3){
				 int i = 2;
				
						
						if(this.TE.getInventory()[j] != null){
							if(this.TE.getInventory()[j].getItem() == this.getRecipe(item).get(i).getItem()){
							
							
							if(this.TE.getInventory()[j].stackSize >= this.getRecipe(item).get(i).stackSize){
								Item it = this.getRecipe(item).get(i).getItem();
								if(this.moreMeta(it)){
								
									if(TE.getInventory()[j].getMetadata() == this.getRecipe(item).get(i).getMetadata()){
										return true;
									}}
									else{
										return true;
									
							}
						}
						}
						
					}
				 }
				 
		 }
		 if(l == 0){
		 for(int i = 0; i < b.length; i++){
			 if (b[i] == false)return false; 
		 }
		 return true;
		 }
		 }
		 return false;
	 }
	 
	 public boolean hasLevel(ItemStack item){
		 int lvl = this.GetItemLevel(item) + this.addLevel;
		 
		 return lvl <= this.Level;
	 }
	
	 
	 
	 /**
	     * Handles mouse input.
	     */
	    public void handleMouseInput() throws IOException
	    {
	        super.handleMouseInput();
	        int i = Mouse.getEventDWheel();
	        
	        

	        if (i != 0 && ((MarkContainer) this.inventorySlots).Stacks.size() > 20)
	        {
	            int j = (((MarkContainer) this.inventorySlots).Stacks.size() + 4 - 1) / 4 - 5;

	            if (i > 0)
	            {
	                i = 1;
	            }

	            if (i < 0)
	            {
	                i = -1;
	            }

	            this.ScrollVal = (float)((double)this.ScrollVal - (double)i / (double)j);
	            this.ScrollVal = MathHelper.clamp_float(this.ScrollVal, 0.0F, 1.0F);
	            ((MarkContainer)this.inventorySlots).scrollTo(this.ScrollVal);
	        }
	    }
	 
	 
	    /** gives how to the recipes are organized */
	 public List <ItemStack> getRecipe(ItemStack itemp){
		 if (itemp == null){
			 return null;
		 }
		 this.addLevel = 0;
		 Item item = itemp.getItem();
		 
		 //Crafting Tables:
		 List<ItemStack> list = new ArrayList<>();
		 Map<Item, List<ItemStack>> Recipes = new HashMap<Item, List<ItemStack>>();
		 this.hasItemVariants = 0;
		 
		 if(item == Item.getItemFromBlock(MarkBlocks.BasicTable)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 4, this.ItemVariant));
		 }
		 else if(item == Item.getItemFromBlock(MarkBlocks.TanningBench_I)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 4, this.ItemVariant), p(Items.LEATHER, 2));
		 }
		 else if(item == Item.getItemFromBlock(MarkBlocks.JewelryTable_I)){
			 this.hasItemVariants = 4;
			 this.ItemVarZise1 = 4;
			 this.ItemVarZise2 = 4;
			 Item stackJ[] = {MarkItems.GemOpal, MarkItems.GemSapphire, MarkItems.GemOlivine, MarkItems.GemHyacinth};
			 return this.ItemToList(p(Blocks.PLANKS, 4, this.ItemVariant1), p(stackJ[this.ItemVariant2], 2));
		 }
		 else if(item == Item.getItemFromBlock(MarkBlocks.FletchingTable_I)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 5, this.ItemVariant), p(Items.STICK, 4));
		 }
		 else if(item == Item.getItemFromBlock(MarkBlocks.WorkBench_I)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 6, this.ItemVariant), p(Items.STICK, 2));
		 }
		 else if(item == Item.getItemFromBlock(Blocks.TORCH)){
			 if(this.TE.getBlockType() == MarkBlocks.BasicTable){
			 this.hasItemVariants = 4;
			 this.ItemVarZise1 = 2;
			 this.ItemVarZise2 = 2;
			 ItemStack[] s = {p(Items.STICK),p(Items.BONE)};
			 return this.ItemToList(p(Items.COAL, 1, this.ItemVariant1), s[this.ItemVariant2]);
			 }
			 else{
				 this.hasItemVariants = 4;
				 this.ItemVarZise1 = 2;
				 this.ItemVarZise2 = 5;
				 ItemStack[] s = {p(Items.STICK), p(Items.BONE), p(MarkItems.Stick10), p(MarkItems.Stick20), p(MarkItems.Stick40)};
				 this.addLevel = this.ItemVariant2 == 4 ? 39 : (this.ItemVariant2 == 3 ? 19 : (this.ItemVariant2 == 2 ? 9 : 0));
				 return this.ItemToList(p(Items.COAL, 1, this.ItemVariant1), s[this.ItemVariant2]);
			 }
		 }
		 else if(item == Item.getItemFromBlock(Blocks.CHEST)){
			 if(TE.getBlockType() == MarkBlocks.BasicTable){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 4;
		 return this.ItemToList(p(Blocks.PLANKS, 8, this.ItemVariant));
			 }
			 else if(TE.getBlockType() == MarkBlocks.WorkBench_I){
				 this.hasItemVariants = 1;
				 this.ItemVarZise = 7;
				 this.addLevel = this.ItemVariant == 6 ? 39 : (this.ItemVariant == 5 || this.ItemVariant == 4 ? 19 : 0);
				 if(this.ItemVariant < 6){
				 return this.ItemToList(p(Blocks.PLANKS, 8, this.ItemVariant));
				 }
				 else{
					 return this.ItemToList(p(MarkBlocks.LogYew_Planks, 8));
				 }
			 }
			 else if(TE.getBlockType() == MarkBlocks.WorkBench_II){
				 this.hasItemVariants = 1;
				 this.ItemVarZise = 9;
				 this.addLevel = this.ItemVariant == 8 ? 79 :(this.ItemVariant == 7 ? 59 :(this.ItemVariant == 6 ? 39 : (this.ItemVariant == 5 || this.ItemVariant == 4 ? 19 : 0)));
				 if(this.ItemVariant < 6){
					 return this.ItemToList(p(Blocks.PLANKS, 8, this.ItemVariant));
					 }
					 else if(this.ItemVariant == 6){
						 return this.ItemToList(p(MarkBlocks.LogYew_Planks, 8));
					 }
					 else if(this.ItemVariant == 7){
						 return this.ItemToList(p(MarkBlocks.LogNetherBranch_Planks, 8));
					 }
					 else{
						 return this.ItemToList(p(MarkBlocks.LogCrystWood_Planks, 8));
					 }
			 }
		 }
		 
		 //Tools & Weapons
		 else if(item == Items.WOODEN_AXE){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 3, this.ItemVariant), p(Items.STICK, 2));
		 }
		 else if(item == Items.PAPER){
		 if(TE.getBlockType() == MarkBlocks.BasicTable){
		 
			 this.hasItemVariants = 0;
			 this.ItemVarZise = 0;
			 return this.ItemToList(p(Items.REEDS, 3));
		 }
		 
		 else if(TE.getBlockType() == MarkBlocks.TailoryBench_I){
			 ItemStack[] a = {p(Items.REEDS, 3), p(MarkItems.Cotton20), p(MarkItems.Cotton40)};
			 if(this.ItemVariant != 0){
				 this.addLevel = 20 * this.ItemVariant;
			 }
				 this.hasItemVariants = 1;
				 this.ItemVarZise = 3;
				 return this.ItemToList(a[this.ItemVariant]);
			 
		 }
		 else if(TE.getBlockType() == MarkBlocks.TailoryBench_II){
			 ItemStack[] a = {p(Items.REEDS, 3), p(MarkItems.Cotton20), p(MarkItems.Cotton40), p(MarkItems.Cotton60), p(MarkItems.Cotton80)};
			 if(this.ItemVariant != 0){
				 this.addLevel = 20 * this.ItemVariant;
			 }
				 this.hasItemVariants = 1;
				 this.ItemVarZise = 5;
				 return this.ItemToList(a[this.ItemVariant]);
			 
		 }
		 }
		 else if(item == Items.WOODEN_SWORD){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 2, this.ItemVariant), p(Items.STICK, 1));
		 }
		 else if(item == Items.WOODEN_HOE){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 2, this.ItemVariant), p(Items.STICK, 2));
		 }
		 else if(item == Items.WOODEN_PICKAXE){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 3, this.ItemVariant), p(Items.STICK, 2));
		 }
		 else if(item == Items.WOODEN_SHOVEL){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 1, this.ItemVariant), p(Items.STICK, 2));
		 }
		 else if(item == Items.STONE_HOE ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 2;
			 ItemStack[] S = {p(Blocks.COBBLESTONE, 2, 0), p(Blocks.STONE, 2, 0)};
			 return this.ItemToList(S[this.ItemVariant], p(Items.STICK, 2));
		 }
		 else if(item == Items.STONE_SWORD ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 2;
			 ItemStack[] S = {p(Blocks.COBBLESTONE, 2, 0), p(Blocks.STONE, 2, 0)};
			 return this.ItemToList(S[this.ItemVariant], p(Items.STICK, 1));
		 }
		 else if(item == Items.STONE_SHOVEL ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 2;
			 ItemStack[] S = {p(Blocks.COBBLESTONE, 1, 0), p(Blocks.STONE, 1, 0)};
			 
			 return this.ItemToList(S[this.ItemVariant], p(Items.STICK, 2));
		 }
		 else if(item == Items.STONE_PICKAXE || item == Items.STONE_AXE ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 2;
			 ItemStack[] S = {p(Blocks.COBBLESTONE, 3, 0), p(Blocks.STONE, 3, 0)};
			 
			 return this.ItemToList(S[this.ItemVariant], p(Items.STICK, 2));
		 }
		 else if(item == Items.IRON_HOE ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 3;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2)};
			 return this.ItemToList(p(Items.IRON_INGOT, 2, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.IRON_SWORD ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 3;
			 ItemStack[] S = {p(Items.STICK, 1), p(MarkItems.Stick10, 1), p(MarkItems.Stick20, 1)};
			 return this.ItemToList(p(Items.IRON_INGOT, 2, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.IRON_SHOVEL ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 3;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2)};
			 return this.ItemToList(p(Items.IRON_INGOT, 1, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.IRON_PICKAXE || item == Items.IRON_AXE ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 3;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2)};
			 return this.ItemToList(p(Items.IRON_INGOT, 3, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.GOLDEN_HOE ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 3;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2)};
			 return this.ItemToList(p(Items.GOLD_INGOT, 2, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.GOLDEN_SWORD ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 3;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2)};
			 return this.ItemToList(p(Items.GOLD_INGOT, 2, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.GOLDEN_SHOVEL ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 3;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2)};
			 return this.ItemToList(p(Items.GOLD_INGOT, 1, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.GOLDEN_PICKAXE || item == Items.GOLDEN_AXE ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 3;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2)};
			 return this.ItemToList(p(Items.GOLD_INGOT, 3, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.DIAMOND_HOE ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2), p(MarkItems.Stick40, 2)};
			 return this.ItemToList(p(Items.DIAMOND, 2, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.DIAMOND_SWORD ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 ItemStack[] S = {p(Items.STICK, 1), p(MarkItems.Stick10, 1), p(MarkItems.Stick20, 1), p(MarkItems.Stick40, 1)};
			 return this.ItemToList(p(Items.DIAMOND, 2, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.DIAMOND_SHOVEL ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2), p(MarkItems.Stick40, 2)};
			 return this.ItemToList(p(Items.DIAMOND, 1, 0), S[this.ItemVariant]);
		 }
		 else if(item == Items.DIAMOND_PICKAXE || item == Items.DIAMOND_AXE ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 ItemStack[] S = {p(Items.STICK, 2), p(MarkItems.Stick10, 2), p(MarkItems.Stick20, 2), p(MarkItems.Stick40, 2)};
			 return this.ItemToList(p(Items.DIAMOND, 3, 0), S[this.ItemVariant]);
		 }
		 
		 else if(item == Item.getItemFromBlock(Blocks.PLANKS) ){
			 if (itemp.getMetadata() < 4){
				 this.hasItemVariants = 1;
				 this.ItemVarZise = 4;
				 return this.ItemToList(p(Blocks.LOG, 1, this.ItemVariant));
			 }
			 else{
				 this.hasItemVariants = 1;
				 this.ItemVarZise = 2;
				 return this.ItemToList(p(Blocks.LOG, 1, this.ItemVariant + 4));
				 
			 }
		 }
			 else if(item == Item.getItemFromBlock(Blocks.STONE_SLAB)){
				 if (itemp.getMetadata() == 0){
					 return this.ItemToList(p(Blocks.STONE, 3)) ;
				 }
				 else if (itemp.getMetadata() == 1){
					 return this.ItemToList(p(Blocks.SANDSTONE, 3)) ;
				 }
				 else if (itemp.getMetadata() == 3){
					 return this.ItemToList(p(Blocks.COBBLESTONE, 3)) ;
				 }
				 else if (itemp.getMetadata() == 4){
					 return this.ItemToList(p(Blocks.BRICK_BLOCK, 3)) ;
				 }
				 else if (itemp.getMetadata() == 5){
					 return this.ItemToList(p(Blocks.STONEBRICK, 3)) ;
				 }
				 else if (itemp.getMetadata() == 6){
					 return this.ItemToList(p(Blocks.NETHER_BRICK, 3)) ;
				 }
				 else if (itemp.getMetadata() == 7){
					 return this.ItemToList(p(Blocks.QUARTZ_BLOCK, 3)) ;
				 }
			 }
			 else if(item == Item.getItemFromBlock(Blocks.STONE_SLAB2)){
				 return this.ItemToList(p(Blocks.RED_SANDSTONE, 3)) ;
			 }
			 else if(item == Item.getItemFromBlock(Blocks.WOODEN_SLAB)){
				 if (itemp.getMetadata() == 0){
					 this.hasItemVariants = 1;
					 this.ItemVarZise = 4;
				 return this.ItemToList(p(Blocks.PLANKS, 3, this.ItemVariant)) ;
				 }
				 else if (itemp.getMetadata() == 4){
					 this.hasItemVariants = 1;
					 this.ItemVarZise = 2;
				 return this.ItemToList(p(Blocks.PLANKS, 3, this.ItemVariant + 4)) ;
				 }
			 }
		 else if(item == Items.STICK ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 2, this.ItemVariant));
		 }
		 else if(item == Items.COAL ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.LOG, 1, this.ItemVariant));
		 }
		 else if(item == MarkItems.Stick20 ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 if(this.ItemVariant < 2){
			 return this.ItemToList(p(Blocks.PLANKS, 2, this.ItemVariant + 4));
			 }
			 else{
				return this.ItemToList(p(Blocks.LOG2, 1, this.ItemVariant - 2));
					 
			 }
		 }
		 else if(item == Items.BOW){
			 this.hasItemVariants = 0;
			 this.ItemVarZise = 0;
			 return this.ItemToList(p(Items.STICK, 3),p(Items.STRING, 3));
		 }
		 else if(item == Item.getItemFromBlock(Blocks.WOOL) ){
			 
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 17;
			 if(this.ItemVariant == 0){
			 return this.ItemToList(p(Items.STRING, 4));
			 }
			 else{
			 return this.ItemToList(p(Blocks.WOOL), p(Items.DYE, 1, this.ItemVariant - 1));
			 }
		 }
		 else if(item == Items.BOOK ){
			 if(TE.getBlockType() == MarkBlocks.TailoryBench_I || TE.getBlockType() == MarkBlocks.TailoryBench_II){
				 return this.ItemToList(p(Blocks.WOOL, 1), p(Items.PAPER, 3));
			 }
			 else if(TE.getBlockType() == MarkBlocks.TanningBench_I || TE.getBlockType() == MarkBlocks.TanningBench_II){
				 return this.ItemToList(p(Items.LEATHER, 1), p(Items.PAPER, 3));
			 } 
		 }
		 else if(item == MarkItems.Book20 ){
			 if(TE.getBlockType() == MarkBlocks.TailoryBench_I || TE.getBlockType() == MarkBlocks.TailoryBench_II){
				 return this.ItemToList(p(MarkItems.Silk20, 2), p(Items.PAPER, 3));
			 }
			 else if(TE.getBlockType() == MarkBlocks.TanningBench_I || TE.getBlockType() == MarkBlocks.TanningBench_II){
				 return this.ItemToList(p(MarkItems.Leather20, 1), p(Items.PAPER, 3));
			 } 
		 }
		 else if(item == MarkItems.Book40 ){
			 if(TE.getBlockType() == MarkBlocks.TailoryBench_I || TE.getBlockType() == MarkBlocks.TailoryBench_II){
				 return this.ItemToList(p(MarkItems.Silk40, 2), p(Items.PAPER, 4));
			 }
			 else if(TE.getBlockType() == MarkBlocks.TanningBench_I || TE.getBlockType() == MarkBlocks.TanningBench_II){
				 return this.ItemToList(p(MarkItems.Leather40, 1), p(Items.PAPER, 4));
			 } 
		 }
		 else if(item == MarkItems.Book60 ){
			 if(TE.getBlockType() == MarkBlocks.TailoryBench_I || TE.getBlockType() == MarkBlocks.TailoryBench_II){
				 return this.ItemToList(p(MarkItems.Silk60, 2), p(Items.PAPER, 5));
			 }
			 else if(TE.getBlockType() == MarkBlocks.TanningBench_I || TE.getBlockType() == MarkBlocks.TanningBench_II){
				 return this.ItemToList(p(MarkItems.Leather60, 1), p(Items.PAPER, 5));
			 } 
		 }
		 else if(item == MarkItems.Book80 ){
			 if(TE.getBlockType() == MarkBlocks.TailoryBench_I || TE.getBlockType() == MarkBlocks.TailoryBench_II){
				 return this.ItemToList(p(MarkItems.Silk80, 2), p(Items.PAPER, 6));
			 }
			 else if(TE.getBlockType() == MarkBlocks.TanningBench_I || TE.getBlockType() == MarkBlocks.TanningBench_II){
				 return this.ItemToList(p(MarkItems.Leather80, 1), p(Items.PAPER, 6));
			 } 
		 }
		 else if(item == Item.getItemFromBlock(Blocks.OAK_FENCE) ){
				 this.hasItemVariants = 1;
				 this.ItemVarZise = 4;
				 return this.ItemToList(p(Blocks.PLANKS, 4, this.ItemVariant), p(Items.STICK, 2));
		 }
		 else if(item == Item.getItemFromBlock(Blocks.ACACIA_FENCE) ){
			 this.hasItemVariants = 4;
			 this.ItemVarZise1 = 2;
			 this.ItemVarZise2 = 3;
			 this.addLevel = this.ItemVariant2 == 0 ? 0 : (this.ItemVariant2 == 1 ? 3 : 6);
			 ItemStack[] S1 = {p(MarkItems.Stick20, 2), p(MarkItems.Stick10, 2),p(Items.STICK , 2)};
			 return this.ItemToList(p(Blocks.PLANKS, 4, this.ItemVariant1 + 4), S1[this.ItemVariant2]);
	 }
		 else if(item == Items.OAK_DOOR){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 6, this.ItemVariant));
		 }
		 else if(item == Items.ACACIA_DOOR){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 2;
			 return this.ItemToList(p(Blocks.PLANKS, 6, this.ItemVariant + 4));
		 }
		 else if(item == Item.getItemFromBlock(Blocks.OAK_STAIRS)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 6, this.ItemVariant));
		 }
		 else if(item == Item.getItemFromBlock(Blocks.ACACIA_STAIRS)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 2;
			 return this.ItemToList(p(Blocks.PLANKS, 6, this.ItemVariant + 4));
		 }
		 else if(item == Item.getItemFromBlock(Blocks.OAK_FENCE_GATE) ){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 2, this.ItemVariant), p(Items.STICK, 4));
	 }
	 else if(item == Item.getItemFromBlock(Blocks.ACACIA_FENCE_GATE) ){
		 this.hasItemVariants = 4;
		 this.ItemVarZise1 = 2;
		 this.ItemVarZise2 = 3;
		 this.addLevel = this.ItemVariant2 == 0 ? 0 : (this.ItemVariant2 == 1 ? 3 : 6);
		 ItemStack[] S1 = {p(MarkItems.Stick20, 4), p(MarkItems.Stick10, 4),p(Items.STICK, 4)};
		 return this.ItemToList(p(Blocks.PLANKS, 2, this.ItemVariant1 + 4), S1[this.ItemVariant2]);
	 }
	 else if(item == Item.getItemFromBlock(MarkBlocks.MarkTrapE) ){
		 if(this.TE.getBlockType() == MarkBlocks.BasicTable){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 1, this.ItemVariant), p(Items.STICK, 2));
		 }else{
		 this.hasItemVariants = 4;
		 this.ItemVarZise1 = 7;
		 this.ItemVarZise2 = 4;
		 
		 if(this.ItemVariant1 == 6 || this.ItemVariant2 == 3){
			 this.addLevel = 39;
		 }
		 else if(this.ItemVariant1 == 4 || this.ItemVariant1 == 5 || this.ItemVariant2 == 2){
			 this.addLevel = 19;
		 }
		 else if(this.ItemVariant2 == 1){
			 this.addLevel = 9;
		 }
		 
		 ItemStack[] S1 = {p(Items.STICK, 2), p(MarkItems.Stick10, 2),p(MarkItems.Stick20, 2),p(MarkItems.Stick40, 2)};
		 if(this.ItemVariant1 == 6){
		 return this.ItemToList(p(MarkBlocks.LogYew_Planks, 1), S1[this.ItemVariant2]); 
		 }
		 else{
		 return this.ItemToList(p(Blocks.PLANKS, 1, this.ItemVariant1), S1[this.ItemVariant2]);
		 }}
	 }
	 else if(item == Items.BED ){
		 this.hasItemVariants = 4;
		 this.ItemVarZise1 = 6;
		 this.ItemVarZise2 = 16;
		 this.addLevel = this.ItemVariant1 < 4 ? 0 : 10;
		
		 return this.ItemToList(p(Blocks.PLANKS, 3, this.ItemVariant1), p(Blocks.WOOL, 3, this.ItemVariant2));
	 }
	 else if(item == Items.BOAT){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 4;
		
		 return this.ItemToList(p(Blocks.PLANKS, 5, this.ItemVariant));
	 }
	 else if(item == Items.BOWL){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 4;
		 return this.ItemToList(p(Blocks.PLANKS, 3, this.ItemVariant));
	 }
	 else if(item == Items.ACACIA_BOAT){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 2;
		
		 return this.ItemToList(p(Blocks.PLANKS, 5, this.ItemVariant + 4));
	 }
	 else if(item == Item.getItemFromBlock(Blocks.LADDER) ){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 3;
		 this.addLevel = this.ItemVariant == 0 ? 0 : (this.ItemVariant == 1 ? 6 : 16);
		 ItemStack[] S1 = {p(Items.STICK, 7), p(MarkItems.Stick10, 7), p(MarkItems.Stick20, 7)};
		 return this.ItemToList(S1[this.ItemVariant]);
	 }
	 else if(item == Item.getItemFromBlock(Blocks.TRAPDOOR)){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 6;
		 this.addLevel = this.ItemVariant > 3 ? 11 : 0;
		 return this.ItemToList(p(Blocks.PLANKS, 6, this.ItemVariant));
	 }
	 else if(item == Item.getItemFromBlock(Blocks.GLASS_PANE)){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 3;
		 this.addLevel = this.ItemVariant * 7;
		 ItemStack[] S = {p(MarkBlocks.DirtGlass, 6), p(MarkBlocks.GravelGlass, 6), p(Blocks.GLASS, 6)};
		 return this.ItemToList(S[this.ItemVariant]);
	 }
	 else if(item == Item.getItemFromBlock(Blocks.SANDSTONE)){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 3;		 
		 ItemStack[] S = {p(Blocks.SAND, 4, 0), p(Blocks.SANDSTONE, 4), p(Blocks.STONE_SLAB, 2, 1)};
		 return this.ItemToList(S[this.ItemVariant]);
	 }
	 else if(item == Item.getItemFromBlock(Blocks.RED_SANDSTONE)){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 3;
		 ItemStack[] S = {p(Blocks.SAND, 4, 1), p(Blocks.RED_SANDSTONE, 4), p(Blocks.STONE_SLAB2, 2)};
		 return this.ItemToList(S[this.ItemVariant]);
	 }
	 else if(item == Item.getItemFromBlock(Blocks.STONEBRICK)){
		 if(this.TE.getBlockType() == MarkBlocks.WorkBench_I || this.TE.getBlockType() == MarkBlocks.WorkBench_II){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 3;
			 if(this.ItemVariant == 0){
				 return this.ItemToList(p(Blocks.STONE, 4));
			 }
			 else if(this.ItemVariant == 1){
				 return this.ItemToList(p(Blocks.STONEBRICK, 1, 0), p(Blocks.VINE, 1));
			 }
			 else if(this.ItemVariant == 2){
				 return this.ItemToList(p(Blocks.STONE_SLAB, 2, 5));
			 }
		 }
		 else{
			 return this.ItemToList(p(Blocks.STONEBRICK, 1));
		 }
	 }
	 else if(item == MarkItems.Stick40){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 2;
		 ItemStack[] S = {p(MarkBlocks.LogYew_Planks, 2), p(MarkBlocks.LogYew, 1)};
		 return this.ItemToList(S[this.ItemVariant]);
	 }
	 else if(item == Items.LEATHER){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 2;
		 ItemStack[] S = {p(MarkItems.Hide10, 2), p(Items.RABBIT_HIDE, 4)};
		 return this.ItemToList(S[this.ItemVariant]);
	 }
	 else if(item == MarkItems.Stick60){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 2;
		 ItemStack[] S = {p(MarkBlocks.LogNetherBranch_Planks, 2), p(MarkBlocks.LogNetherBranch)};
		 return this.ItemToList(S[this.ItemVariant]);
	 }
	 else if(item == MarkItems.Stick80){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 2;
		 ItemStack[] S = {p(MarkBlocks.LogCrystWood_Planks, 2), p(MarkBlocks.LogCrystWood)};
		 return this.ItemToList(S[this.ItemVariant]);
	 }
	 else if(item == Items.DYE){
		 if(this.TE.getBlockType() == MarkBlocks.Furnace_I || this.TE.getBlockType() == MarkBlocks.Furnace_II){
			 return this.ItemToList(p(Blocks.CACTUS, 1));
		 }
		 else{
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 21;
		 if(this.ItemVariant < 17){
		 ItemStack[] S = {p(Blocks.RED_FLOWER, 1, 0), p(Blocks.RED_FLOWER, 1, 4), p(Blocks.RED_FLOWER, 1, 4), p(Blocks.DOUBLE_PLANT, 1, 4), p(Items.BEETROOT),
				 p(Blocks.RED_FLOWER, 1, 5), p(Blocks.YELLOW_FLOWER, 1), p(Blocks.DOUBLE_PLANT, 1, 0), p(Blocks.RED_FLOWER, 1, 1),
				 p(Blocks.DOUBLE_PLANT, 1, 1), p(Blocks.RED_FLOWER, 1, 2),p(Blocks.DOUBLE_PLANT, 1, 5), p(Blocks.RED_FLOWER, 1, 7),p(Items.BONE, 1),
				 p(Blocks.RED_FLOWER, 1, 3),p(Blocks.RED_FLOWER, 1, 8), p(Blocks.RED_FLOWER, 1, 6)};
		 return this.ItemToList(S[this.ItemVariant]);
		 }
		 else{
			 ItemStack[] S1 = {p(Items.DYE, 1,2),p(Items.DYE, 1,1),p(Items.DYE, 1,0),p(Items.DYE, 1,2)};
			 ItemStack[] S2 = {p(Items.DYE, 1,4),p(Items.DYE, 1,4),p(Items.DYE, 1,15),p(Items.DYE, 1,15)};
			 return this.ItemToList(S1[this.ItemVariant - 17], S2[this.ItemVariant - 17]);
		 }
		 }
	 }
	 else if(item == MarkItems.TrapKey){
		 this.hasItemVariants = 1;
		 this.ItemVarZise = 4;
		 this.addLevel = this.ItemVariant == 2 ? 5 :(this.ItemVariant == 3 ? 25 : 0);
		 ItemStack[] S = {p(Items.STICK, 2, 0), p(MarkItems.Stick10, 2, 0), p(MarkItems.Stick20, 2, 0), p(MarkItems.Stick40, 2, 0)};
		 return this.ItemToList(S[this.ItemVariant], p(Items.STRING, 1));
	 }
		 
		 Recipes.put(Items.SHEARS, this.ItemToList(p(Items.IRON_INGOT, 2)));
		 Recipes.put(Items.SUGAR, this.ItemToList(p(Items.REEDS, 1)));	
		 
		 
		 Recipes.put(item.getItemFromBlock(MarkBlocks.TailoryBench_I), this.ItemToList(p(Blocks.PLANKS, 4), p(Blocks.WOOL, 2)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.Anvil_I), this.ItemToList(p(Blocks.STONE, 7)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.Furnace_I), this.ItemToList(p(Blocks.COBBLESTONE, 9)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.GlassOven_I), this.ItemToList(p(Blocks.COBBLESTONE, 4),p(Blocks.DIRT, 5)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.Range_I), this.ItemToList(p(Blocks.COBBLESTONE, 8)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.Cauldron_I), this.ItemToList(p(Blocks.COBBLESTONE, 9)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.LogYew_Planks), this.ItemToList(p(MarkBlocks.LogYew, 1)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.LogNetherBranch_Planks), this.ItemToList(p(MarkBlocks.LogNetherBranch, 1)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.LogCrystWood_Planks), this.ItemToList(p(MarkBlocks.LogCrystWood, 1)));
		 Recipes.put(item.getItemFromBlock(Blocks.STONE), this.ItemToList(p(Blocks.COBBLESTONE, 1))); //TODO
		 Recipes.put(item.getItemFromBlock(Blocks.STONE_STAIRS), this.ItemToList(p(Blocks.COBBLESTONE, 6)));
		 Recipes.put(item.getItemFromBlock(Blocks.BRICK_BLOCK), this.ItemToList(p(Items.BRICK, 4)));
		 Recipes.put(item.getItemFromBlock(Blocks.BRICK_STAIRS), this.ItemToList(p(Blocks.BRICK_BLOCK, 6)));
		 Recipes.put(item.getItemFromBlock(Blocks.STONE_BRICK_STAIRS), this.ItemToList(p(Blocks.STONEBRICK, 6)));
		 Recipes.put(item.getItemFromBlock(Blocks.NETHER_BRICK), this.ItemToList(p(Items.NETHERBRICK, 4)));
		 Recipes.put(item.getItemFromBlock(Blocks.NETHER_BRICK_STAIRS), this.ItemToList(p(Blocks.NETHER_BRICK, 6)));
		 Recipes.put(item.getItemFromBlock(Blocks.SANDSTONE_STAIRS), this.ItemToList(p(Blocks.SANDSTONE, 6)));
		 Recipes.put(item.getItemFromBlock(Blocks.RED_SANDSTONE_STAIRS), this.ItemToList(p(Blocks.RED_SANDSTONE, 6)));
		 Recipes.put(item.getItemFromBlock(Blocks.NETHER_BRICK_FENCE), this.ItemToList(p(Blocks.NETHER_BRICK, 6)));
		 Recipes.put(MarkItems.LogYew_Door, this.ItemToList(p(MarkBlocks.LogYew_Planks, 6)));
		 Recipes.put(MarkItems.LogNetherBranch_Door, this.ItemToList(p(MarkBlocks.LogNetherBranch_Planks, 6)));
		 Recipes.put(MarkItems.LogCrystWood_Door, this.ItemToList(p(MarkBlocks.LogCrystWood_Planks, 6)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.LogYew_stairs), this.ItemToList(p(MarkBlocks.LogYew_Planks, 6)));
		 Recipes.put(Items.IRON_INGOT, this.ItemToList(p(MarkBlocks.OreIron, 1)));
		 Recipes.put(Items.GOLD_INGOT, this.ItemToList(p(MarkBlocks.OreGold, 1)));
		 Recipes.put(MarkItems.Stick10, this.ItemToList(p(Blocks.CACTUS, 2)));
		 
		 Recipes.put(Item.getItemFromBlock(MarkBlocks.DirtGlass), this.ItemToList(p(Blocks.DIRT, 3)));
		 Recipes.put(Item.getItemFromBlock(MarkBlocks.GravelGlass), this.ItemToList(p(Blocks.GRAVEL, 2)));
		 Recipes.put(Item.getItemFromBlock(Blocks.GLASS), this.ItemToList(p(Blocks.SAND, 1)));
		 Recipes.put(Item.getItemFromBlock(MarkBlocks.NetherGlass), this.ItemToList(p(MarkBlocks.NetherSand, 1)));
		 Recipes.put(Item.getItemFromBlock(MarkBlocks.SoulGlass), this.ItemToList(p(Blocks.SOUL_SAND, 1)));
		 Recipes.put(Item.getItemFromBlock(MarkBlocks.CrystGlass), this.ItemToList(p(MarkBlocks.CrystSand, 1)));
		 Recipes.put(Item.getItemFromBlock(MarkBlocks.CyantinianGlass), this.ItemToList(p(MarkBlocks.Cyantinian, 1)));
		 Recipes.put(MarkItems.GemOpal, this.ItemToList(p(MarkBlocks.GemOpalOre, 1)));
		 Recipes.put(MarkItems.GemSapphire, this.ItemToList(p(MarkBlocks.GemSapphireOre, 1)));
		 Recipes.put(MarkItems.GemOlivine, this.ItemToList(p(MarkBlocks.GemOlivineOre, 1)));
		 Recipes.put(MarkItems.GemHyacinth, this.ItemToList(p(MarkBlocks.GemHyacinthOre, 1)));
		 Recipes.put(MarkItems.GemTopaz, this.ItemToList(p(MarkBlocks.GemTopazOre, 1)));
		 Recipes.put(MarkItems.GemAmethyst, this.ItemToList(p(MarkBlocks.GemAmethystOre, 1)));
		 Recipes.put(MarkItems.GemSiam, this.ItemToList(p(MarkBlocks.GemSiamOre, 1)));
		 Recipes.put(MarkItems.GemAquamarine, this.ItemToList(p(MarkBlocks.GemAquamarineOre, 1)));
		 
		 
		 Recipes.put(MarkItems.Stick10, this.ItemToList(p(Blocks.CACTUS, 2)));
		 Recipes.put(MarkItems.Stick40, this.ItemToList(p(MarkBlocks.LogYew_Planks, 2)));
		 Recipes.put(MarkItems.Stick60, this.ItemToList(p(MarkBlocks.LogNetherBranch_Planks, 2)));
		 Recipes.put(MarkItems.Stick80, this.ItemToList(p(MarkBlocks.LogCrystWood_Planks, 1)));
		 Recipes.put(MarkItems.Silk20, this.ItemToList(p(MarkItems.Cotton20, 4)));
		 Recipes.put(MarkItems.Silk40, this.ItemToList(p(MarkItems.Cotton40, 4)));
		 Recipes.put(MarkItems.Silk60, this.ItemToList(p(MarkItems.Cotton60, 4)));
		 Recipes.put(MarkItems.Silk80, this.ItemToList(p(MarkItems.Cotton80, 4)));
		 
		 Recipes.put(MarkItems.Leather20, this.ItemToList(p(MarkItems.Hide20, 2)));
		 Recipes.put(MarkItems.Leather40, this.ItemToList(p(MarkItems.Hide40, 2)));
		 Recipes.put(MarkItems.Leather60, this.ItemToList(p(MarkItems.Hide60, 2)));
		 Recipes.put(MarkItems.Leather80, this.ItemToList(p(MarkItems.Hide80, 2)));
		 Recipes.put(MarkItems.FishRod, this.ItemToList(p(Items.STRING, 2), p(Items.STICK, 3)));
		 Recipes.put(MarkItems.Cod_Cooked, this.ItemToList(p(MarkItems.Cod_Raw, 1)));
		 Recipes.put(MarkItems.Trout_Cooked, this.ItemToList(p(MarkItems.Trout_Raw, 1)));
		 Recipes.put(MarkItems.Sardine_Cooked, this.ItemToList(p(MarkItems.Sardine_Raw, 1)));
		 Recipes.put(Items.COOKED_FISH, this.ItemToList(p(Items.FISH, 1, 1)));
		 Recipes.put(Items.COOKED_BEEF, this.ItemToList(p(Items.BEEF, 1)));
		 Recipes.put(Items.COOKED_CHICKEN, this.ItemToList(p(Items.CHICKEN, 1)));
		 Recipes.put(Items.COOKED_MUTTON, this.ItemToList(p(Items.MUTTON, 1)));
		 Recipes.put(Items.COOKED_PORKCHOP, this.ItemToList(p(Items.PORKCHOP, 1)));
		 Recipes.put(Items.COOKED_RABBIT, this.ItemToList(p(Items.RABBIT, 1)));
		 Recipes.put(Items.BREAD, this.ItemToList(p(Items.WHEAT, 3)));
		 Recipes.put(MarkItems.CakeUnf, this.ItemToList(p(Items.WHEAT, 2),p(Items.EGG, 1),p(Items.SUGAR, 3)));
		 Recipes.put(Items.CAKE, this.ItemToList(p(Items.MILK_BUCKET, 3), p(MarkItems.CakeUnf, 1)));
		 Recipes.put(MarkItems.Tuna_Cooked, this.ItemToList(p(MarkItems.Tuna_Raw, 1)));
		 Recipes.put(MarkItems.Herring_Cooked, this.ItemToList(p(MarkItems.Herring_Raw, 1)));
		 Recipes.put(MarkItems.Bass_Cooked, this.ItemToList(p(MarkItems.Bass_Raw, 1)));
		 Recipes.put(MarkItems.Eel_Cooked, this.ItemToList(p(MarkItems.Eel_Raw, 1)));
		 Recipes.put(MarkItems.Batiod_Cooked, this.ItemToList(p(MarkItems.Batiod_Raw, 1)));
		 Recipes.put(MarkItems.Shark_Cooked, this.ItemToList(p(MarkItems.Shark_Raw, 1)));
		 Recipes.put(Items.LEATHER_BOOTS, this.ItemToList(p(Items.LEATHER, 4)));
		 Recipes.put(Items.LEATHER_HELMET, this.ItemToList(p(Items.LEATHER, 5)));
		 Recipes.put(Items.LEATHER_LEGGINGS, this.ItemToList(p(Items.LEATHER, 7)));
		 Recipes.put(Items.LEATHER_CHESTPLATE, this.ItemToList(p(Items.LEATHER, 8)));
		 Recipes.put(Items.IRON_BOOTS, this.ItemToList(p(Items.IRON_INGOT, 4)));
		 Recipes.put(Items.IRON_HELMET, this.ItemToList(p(Items.IRON_INGOT, 5)));
		 Recipes.put(Items.IRON_LEGGINGS, this.ItemToList(p(Items.IRON_INGOT, 7)));
		 Recipes.put(Items.IRON_CHESTPLATE, this.ItemToList(p(Items.IRON_INGOT, 8)));
		 Recipes.put(Items.GOLDEN_BOOTS, this.ItemToList(p(Items.GOLD_INGOT, 4)));
		 Recipes.put(Items.GOLDEN_HELMET, this.ItemToList(p(Items.GOLD_INGOT, 5)));
		 Recipes.put(Items.GOLDEN_LEGGINGS, this.ItemToList(p(Items.GOLD_INGOT, 7)));
		 Recipes.put(Items.GOLDEN_CHESTPLATE, this.ItemToList(p(Items.GOLD_INGOT, 8)));
		 Recipes.put(Items.DIAMOND_BOOTS, this.ItemToList(p(Items.DIAMOND, 4)));
		 Recipes.put(Items.DIAMOND_HELMET, this.ItemToList(p(Items.DIAMOND, 5)));
		 Recipes.put(Items.DIAMOND_LEGGINGS, this.ItemToList(p(Items.DIAMOND, 7)));
		 Recipes.put(Items.DIAMOND_CHESTPLATE, this.ItemToList(p(Items.DIAMOND, 8))); 
		 Recipes.put(Items.BRICK , this.ItemToList(p(Items.CLAY_BALL, 1)));
		 Recipes.put(Items.FLOWER_POT , this.ItemToList(p(Items.BRICK, 3)));
		 Recipes.put(Items.BUCKET , this.ItemToList(p(Items.IRON_INGOT, 3)));
		 
		 list = Recipes.get(item);
		 return list;
	 }
	 
	 public int GetItemLevel(ItemStack itemp){
		 Map<Item, Integer> CraftLevel = new HashMap<Item, Integer>();
		 
		 CraftLevel.put(MarkItems.Silk20, 20);
		 CraftLevel.put(MarkItems.Silk40, 40);
		 CraftLevel.put(MarkItems.Silk60, 60);
		 CraftLevel.put(MarkItems.Silk80, 80);
		 
		 CraftLevel.put(MarkItems.Leather20, 20);
		 CraftLevel.put(MarkItems.Leather40, 40);
		 CraftLevel.put(MarkItems.Leather60, 60);
		 CraftLevel.put(MarkItems.Leather80, 80);
		 
		 CraftLevel.put(Items.MAP, 7);
		 CraftLevel.put(MarkItems.Book20, 20);
		 CraftLevel.put(MarkItems.Book40, 40);
		 CraftLevel.put(MarkItems.Book60, 60);
		 CraftLevel.put(MarkItems.Book80, 80);
		 
		 CraftLevel.put(Items.LEATHER_BOOTS, 2);
		 CraftLevel.put(Items.LEATHER_HELMET, 3);
		 CraftLevel.put(Items.LEATHER_LEGGINGS, 4);
		 CraftLevel.put(Items.LEATHER_CHESTPLATE, 5);
		 
		 CraftLevel.put(Items.STONE_HOE, 2);
		 CraftLevel.put(Items.STONE_AXE, 2);
		 CraftLevel.put(Items.STONE_SHOVEL, 2);
		 CraftLevel.put(Items.STONE_SWORD, 3);
		 CraftLevel.put(Items.SHEARS, 20);
		 CraftLevel.put(Items.IRON_PICKAXE, 21);
		 CraftLevel.put(Items.IRON_AXE, 22);
		 CraftLevel.put(Items.IRON_SHOVEL, 22);
		 CraftLevel.put(Items.IRON_HOE, 22);
		 CraftLevel.put(Items.IRON_SWORD, 23);
		 CraftLevel.put(Items.IRON_BOOTS, 24);
		 CraftLevel.put(Items.IRON_HELMET, 25);
		 CraftLevel.put(Items.BUCKET, 26);
		 CraftLevel.put(Items.IRON_LEGGINGS, 27);
		 CraftLevel.put(Items.IRON_CHESTPLATE, 29);
		 CraftLevel.put(Items.GOLDEN_PICKAXE, 31);
		 CraftLevel.put(Items.GOLDEN_AXE, 32);
		 CraftLevel.put(Items.GOLDEN_SHOVEL, 32);
		 CraftLevel.put(Items.GOLDEN_HOE, 32);
		 CraftLevel.put(Items.GOLDEN_SWORD, 33);
		 CraftLevel.put(Items.GOLDEN_BOOTS, 34);
		 CraftLevel.put(Items.GOLDEN_HELMET, 35);
		 CraftLevel.put(Items.GOLDEN_LEGGINGS, 37);
		 CraftLevel.put(Items.GOLDEN_CHESTPLATE, 39);
		 CraftLevel.put(Items.DIAMOND_PICKAXE, 41);
		 CraftLevel.put(Items.DIAMOND_AXE, 42);
		 CraftLevel.put(Items.DIAMOND_SHOVEL, 42);
		 CraftLevel.put(Items.DIAMOND_HOE, 42);
		 CraftLevel.put(Items.DIAMOND_SWORD, 43);
		 CraftLevel.put(Items.DIAMOND_BOOTS, 44);
		 CraftLevel.put(Items.DIAMOND_HELMET, 45);
		 CraftLevel.put(Items.DIAMOND_LEGGINGS, 47);
		 CraftLevel.put(Items.DIAMOND_CHESTPLATE, 49);
		 
		 CraftLevel.put(MarkItems.TrapKey, 15);
		 CraftLevel.put(MarkItems.Stick10, 10);
		 CraftLevel.put(MarkItems.Stick20, 20);
		 CraftLevel.put(MarkItems.Stick40, 40);
		 CraftLevel.put(MarkItems.Stick60, 60);
		 CraftLevel.put(MarkItems.Stick80, 80);
		 
		 CraftLevel.put(Items.IRON_INGOT, 20);
		 CraftLevel.put(Items.GOLD_INGOT, 30);
		 CraftLevel.put(MarkItems.NetheriteBar, 60);
		 CraftLevel.put(MarkItems.CrystliumBar, 80);
		 
		 CraftLevel.put(Item.getItemFromBlock(MarkBlocks.GravelGlass), 10);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.GLASS), 20);
		 CraftLevel.put(Item.getItemFromBlock(MarkBlocks.NetherGlass), 60);
		 CraftLevel.put(Item.getItemFromBlock(MarkBlocks.SoulGlass), 70);
		 CraftLevel.put(Item.getItemFromBlock(MarkBlocks.CrystGlass), 80);
		 CraftLevel.put(Item.getItemFromBlock(MarkBlocks.CyantinianGlass), 90);
		 
		 CraftLevel.put(MarkItems.GemSapphire, 5);
		 CraftLevel.put(MarkItems.GemOlivine, 10);
		 CraftLevel.put(MarkItems.GemHyacinth, 15);
		 CraftLevel.put(MarkItems.GemTopaz, 20);
		 CraftLevel.put(MarkItems.GemAmethyst, 40);
		 CraftLevel.put(MarkItems.GemSiam, 60);
		 CraftLevel.put(MarkItems.GemAquamarine, 80);
		 
		 CraftLevel.put(Items.BREAD, 5);
		 CraftLevel.put(MarkItems.Trout_Cooked, 10);
		 CraftLevel.put(MarkItems.Sardine_Cooked, 20);
		 CraftLevel.put(Items.COOKED_FISH, 30);
		 CraftLevel.put(MarkItems.Tuna_Cooked, 40);
		 CraftLevel.put(MarkItems.CakeUnf, 50);
		 CraftLevel.put(Items.CAKE, 50);
		 CraftLevel.put(MarkItems.Herring_Cooked, 50);
		 CraftLevel.put(MarkItems.Bass_Cooked, 60);
		 CraftLevel.put(MarkItems.Eel_Cooked, 70);
		 CraftLevel.put(MarkItems.Batiod_Cooked, 80);
		 CraftLevel.put(MarkItems.Shark_Cooked, 90);
		 
		 
		 
		 CraftLevel.put(Item.getItemFromBlock(MarkBlocks.LogYew_Planks), 40);
		 CraftLevel.put(Item.getItemFromBlock(MarkBlocks.LogNetherBranch_Planks), 60);
		 CraftLevel.put(Item.getItemFromBlock(MarkBlocks.LogCrystWood_Planks), 80);
		 
		 CraftLevel.put(Items.OAK_DOOR, 8);
		 CraftLevel.put(Items.SPRUCE_DOOR, 8);
		 CraftLevel.put(Items.BIRCH_DOOR, 8);
		 CraftLevel.put(Items.JUNGLE_DOOR, 8);
		 CraftLevel.put(Items.ACACIA_DOOR, 28);
		 CraftLevel.put(Items.DARK_OAK_DOOR, 28);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.OAK_FENCE), 5);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.SPRUCE_FENCE), 5);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.BIRCH_FENCE), 5);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.JUNGLE_FENCE), 5);
		 
		 CraftLevel.put(Item.getItemFromBlock(Blocks.ACACIA_FENCE), 25);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.DARK_OAK_FENCE), 25);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.OAK_FENCE_GATE), 9);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.SPRUCE_FENCE_GATE), 9);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.BIRCH_FENCE_GATE), 9);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.JUNGLE_FENCE_GATE), 9);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.ACACIA_FENCE_GATE), 29);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.DARK_OAK_FENCE_GATE), 29);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.OAK_STAIRS), 3);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.SPRUCE_STAIRS), 3);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.BIRCH_STAIRS), 3);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.JUNGLE_STAIRS), 3);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.SANDSTONE), 5);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.RED_SANDSTONE), 5);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.SANDSTONE_STAIRS), 8);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.RED_SANDSTONE_STAIRS), 8);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.ACACIA_STAIRS), 23);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.DARK_OAK_STAIRS), 23);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.STONE_STAIRS), 13);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.BRICK_BLOCK), 15);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.BRICK_STAIRS), 18);
		 CraftLevel.put(Item.getItemFromBlock(MarkBlocks.LogYew_stairs), 43);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.STONEBRICK), 30);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.STONE_BRICK_STAIRS), 33);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.NETHER_BRICK), 70);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.NETHER_BRICK_STAIRS), 73);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.NETHER_BRICK_FENCE), 75);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.LADDER), 4);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.GLASS_PANE), 6);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.TRAPDOOR), 9);
		 CraftLevel.put(Items.BOAT, 2);
		 CraftLevel.put(Items.BOWL, 5);
		 CraftLevel.put(Items.FLOWER_POT, 19);
		 CraftLevel.put(Items.ACACIA_BOAT, 22);
		 CraftLevel.put(Items.BED, 10);
		 CraftLevel.put(Items.BRICK, 10);
		 CraftLevel.put(Item.getItemFromBlock(Blocks.STONE_STAIRS), 13);
		 CraftLevel.put(MarkItems.LogYew_Door, 48);
		 CraftLevel.put(MarkItems.LogNetherBranch_Door, 68);
		 CraftLevel.put(MarkItems.LogCrystWood_Door, 88);
		 
		 if(itemp != null){
		 Item item = itemp.getItem();
		 if(item == Item.getItemFromBlock(Blocks.PLANKS)){
			 if(itemp.getMetadata() < 4){
				 return 1;
			 }
			 else{
				 return 20;
			 }
			 
		 }
		 else if(item == Items.DYE){
			if(itemp.getMetadata() == 2){
				return 5;
			}
			else if(itemp.getMetadata() == 4){
				return 25;
			}
		 }
		 else if(item == Item.getItemFromBlock(Blocks.STONE_SLAB)){
			 if(itemp.getMetadata() == 0) return 12;
			 else if(itemp.getMetadata() == 1) return 7;
			 else if(itemp.getMetadata() == 3) return 12;
			 else if(itemp.getMetadata() == 4) return 17;
			 else if(itemp.getMetadata() == 5) return 32;
			 else if(itemp.getMetadata() == 6) return 72;
			 else if(itemp.getMetadata() == 7) return 57;
		 }
		 else if(item == Item.getItemFromBlock(Blocks.STONE_SLAB2)){
			 return 7;
		 }
		 else if(item == Item.getItemFromBlock(Blocks.WOODEN_SLAB)){
			 if(itemp.getMetadata() == 0) return 2;
			 if(itemp.getMetadata() == 4) return 22;
		 }
		 return CraftLevel.get(item) == null ? 1 : CraftLevel.get(item);
		 }
		 else return 1;
	 }
	 
	 
	 public int MaxCraft(){
		 
		 float MaxFurnace = 0;
		 int MaxInvSpace = 0;
		 int MaxIngr = 0;
		 
		 if(this.NeedsEnergy){
			 if(this.TE.getStackInSlot(24) == null && this.TE.CraftEnergy(this.SlotItem.getItem()) != 0.0F){
				 MaxFurnace = this.TE.getCurEnergy() / ((float)(this.TE.getCraftTime(this.SlotItem.getItem()) / this.TE.CraftEnergy(this.SlotItem.getItem())));
			 }
			 else if(this.TE.CraftEnergy(this.SlotItem.getItem()) != 0.0F){
			 MaxFurnace = ((float)(this.TE.burnEnergy(this.TE.getStackInSlot(24).getItem()) * this.TE.getStackInSlot(24).stackSize) + this.TE.getCurEnergy()) / ((float)(this.TE.getCraftTime(this.SlotItem.getItem()) / this.TE.CraftEnergy(this.SlotItem.getItem())));	
			 	 }
			 else{
				 MaxFurnace = 64.0F; 
			 }
		 }
		 //get free inventory space
		 for (int i = 0; i < 12; i++){
			 if(this.SlotItem == null){ MaxInvSpace = 0; }
			 else if(this.TE.getStackInSlot(i + 12) == null){
				 MaxInvSpace += (64 / this.TE.getCorStackSize(this.SlotItem.getItem()));
			 }
			 else if(this.TE.getStackInSlot(i + 12).getItem() == this.SlotItem.getItem()){
				 MaxInvSpace += ((64 - this.TE.getStackInSlot(i + 12).stackSize) / this.TE.getCorStackSize(this.SlotItem.getItem()));
			 } 
		 }
		 
		 //how much ingredients you have for how many items
		 if(this.getRecipe(this.SlotItem) != null){
			 int[] stk = new int[this.getRecipe(this.SlotItem).size()];
			 for (int i = 0; i < this.getRecipe(this.SlotItem).size(); i++){
				 stk[i] = 0;
				 for (int i2 = 0; i2 < 12; i2++){
					 if(this.TE.getStackInSlot(i2) != null){
					 if(this.getRecipe(this.SlotItem).get(i).getItem() == this.TE.getStackInSlot(i2).getItem()){
						 if(this.moreMeta(this.TE.getStackInSlot(i2).getItem())){
							 if(this.TE.getStackInSlot(i2).getMetadata() == this.getRecipe(this.SlotItem).get(i).getMetadata()){
								 stk[i] += (this.TE.getStackInSlot(i2).stackSize / this.getRecipe(this.SlotItem).get(i).stackSize);
							 }
						 }
						 else{
						stk[i] += (this.TE.getStackInSlot(i2).stackSize / this.getRecipe(this.SlotItem).get(i).stackSize);
					 }}
					 }
				 }
			 }
			 if(stk.length == 1){
				 MaxIngr = stk[0];
			 }
			 for (int i = 0; i < stk.length; i++){
				 int temp = i == 0 ? 0 : MaxIngr;
				 MaxIngr = i == 0 ? stk[0] : (stk[i] < MaxIngr ? stk[i] : temp);
			 }
		 }
		 if(this.NeedsEnergy){
			 if(MaxFurnace > 64 && MaxInvSpace > 64 && MaxIngr > 64){
				 return 64;
			 }
			 else if(MaxFurnace <= MaxInvSpace && MaxFurnace <= MaxIngr){
				 return (int)MaxFurnace;
			 } 
			 else if(MaxInvSpace <= MaxIngr){
				 return MaxInvSpace;
			 }
			 else{
				 return MaxIngr;
			 }
		 }
		 else if(MaxInvSpace <= MaxIngr){
			 return MaxInvSpace;
		 }
		 else{
			 return MaxIngr;
		 }
		
	 }
	 
	 
	 
	 public List <ItemStack> ItemToList(ItemStack... stack2){
		 
		 List <ItemStack> l = new ArrayList<>();
		 
		 for (int i = 0; i < stack2.length; i++){
			 
			 l.add(stack2[i]);
		 }
		 
		 return l;
		 
	 }
	 
	 public ItemStack p(Item item){ return new ItemStack(item);} 
	 public ItemStack p(Item item, int value){ return new ItemStack(item, value); }
	 public ItemStack p(Item item, int value, int variant){ return new ItemStack(item, value, variant); }
	 public ItemStack p(Block block){ return new ItemStack(block);} 
	 public ItemStack p(Block block, int value){ return new ItemStack(block, value); }
	 public ItemStack p(Block block, int value, int variant){ return new ItemStack(block, value, variant); }
	
	
	
	public String ItemNames(ItemStack Itemp, Boolean MainItem){
		Map<Item, String> Name = new HashMap<Item, String>();
		
		Name.put(Item.getItemFromBlock(MarkBlocks.WorkBench_I), "Constr. Bench I");
		Name.put(Item.getItemFromBlock(MarkBlocks.WorkBench_II), "Constr. Bench II");
		
		
		Name.put(MarkItems.Hide10, "Common Hide");
		Name.put(MarkItems.Hide20, "Desert S.Hide");
		Name.put(MarkItems.Hide40, "Green S.Hide");
		Name.put(MarkItems.Hide60, "Red S.Hide");
		Name.put(MarkItems.Hide80, "Blue S.Hide");
		
		
		
		Name.put(Item.getItemFromBlock(Blocks.OAK_STAIRS), "T1 Stairs");
		Name.put(Item.getItemFromBlock(Blocks.ACACIA_STAIRS), "T20 Stairs");
		
	if(Itemp.getItem() == Item.getItemFromBlock(Blocks.PLANKS) && Itemp.getItem() == this.SlotItem.getItem()){
		if (Itemp.getMetadata() < 4){
			String[] V = { "Oak", "Spruce", "Birch", "Jungle"};
			return V[this.ItemVariant] + " Planks";
		}
		else{
			String[] V = { "Acacia", "Dark Oak"};
			return V[this.ItemVariant] + " planks";
		}
	}
	else if(Itemp.getItem() == Item.getItemFromBlock(Blocks.OAK_FENCE) && Itemp.getItem() == this.SlotItem.getItem()){	
			String[] V = { "Oak", "Spruce", "Birch", "Jungle"};
			return V[this.ItemVariant] + " Fence";
	}
	else if(Itemp.getItem() == Item.getItemFromBlock(Blocks.ACACIA_FENCE) && Itemp.getItem() == this.SlotItem.getItem()){
			String[] V = { "Acacia", "Dark Oak"};
			return V[this.ItemVariant] + " Fence";	
	}
	else if(Itemp.getItem() == Item.getItemFromBlock(Blocks.OAK_FENCE_GATE) && Itemp.getItem() == this.SlotItem.getItem()){	
		String[] V = { "Oak", "Spruce", "Birch", "Jungle"};
		return V[this.ItemVariant] + " Gate";
	}
	else if(Itemp.getItem() == Item.getItemFromBlock(Blocks.ACACIA_FENCE_GATE) && Itemp.getItem() == this.SlotItem.getItem()){
		String[] V = { "Acacia", "Dark Oak"};
		return V[this.ItemVariant] + " Gate";	
	}
	else if(Itemp.getItem() == Item.getItemFromBlock(Blocks.OAK_STAIRS) && Itemp.getItem() == this.SlotItem.getItem()){	
		String[] V = { "Oak", "Spruce", "Birch", "Jungle"};
		return V[this.ItemVariant] + " Stairs";
	}
	else if(Itemp.getItem() == Item.getItemFromBlock(Blocks.ACACIA_STAIRS) && Itemp.getItem() == this.SlotItem.getItem()){
		String[] V = { "Acacia", "Dark Oak"};
		return V[this.ItemVariant] + " Stairs";	
	}
	else if(Itemp.getItem() == Item.getItemFromBlock(Blocks.WOOL) && Itemp.getItem() == this.SlotItem.getItem()){
		if(MainItem){
		String[] V = {"","Black ","Red ","Green ","Brown ","Blue ","Purple ","Cyan ","Light Gray ","Gray ","Pink ","Lime ","Yellow ","Light Blue ","Magenta ","Orange ","",};
		return V[this.ItemVariant] + "Wool";
		}
	}
	
	
		Name.put(Item.getItemFromBlock(MarkBlocks.LogYew_Planks), "Yew Planks");
		Name.put(Item.getItemFromBlock(MarkBlocks.LogNetherBranch_Planks), "Nether Planks");
		Name.put(Item.getItemFromBlock(MarkBlocks.LogCrystWood_Planks), "Cryst Planks");
	
	return Name.get(Itemp.getItem()) == null ? Itemp.getDisplayName() : Name.get(Itemp.getItem());
}
	
	
	
	
	
	
	
	
	private void CalcLvl(){
		

		 this.SkillName[0] = "Constitution";
		 this.SkillName[1] = "Melee";
		 this.SkillName[2] = "Ranged";
		 this.SkillName[3] = "Magic";
		 this.SkillName[4] = "Defence";
		 this.SkillName[5] = "Endurance";
		 this.SkillName[6] = "Slayer";
		 this.SkillName[7] = "Farming";
		 this.SkillName[8] = "Mining";
		 this.SkillName[9] = "Hunter";
		 this.SkillName[10] = "Excavation";
		 this.SkillName[11] = "Woodcutting";
		 this.SkillName[12] = "Fishing";
		 this.SkillName[13] = "Archeology";
		 this.SkillName[14] = "Tailory";
		 this.SkillName[15] = "Smithing";
		 this.SkillName[16] = "Tanning";
		 this.SkillName[17] = "Jewelry";
		 this.SkillName[18] = "Fletching";
		 this.SkillName[19] = "Cooking";
		 this.SkillName[20] = "Herblore";
		 this.SkillName[21] = "Honour";
		 this.SkillName[22] = "Construction";
		 this.SkillName[23] = "Agility";
		 this.SkillName[24] = "Exploration";
		 this.SkillName[25] = "Pet Caring";
		 this.SkillName[26] = "Lifestock";
		 this.SkillName[27] = "Knowledge";
		 this.SkillName[28] = "Technology";
		 this.SkillName[29] = "Manufacturing";
		 this.SkillName[30] = "Chemistry";
		 this.SkillName[31] = "Specility";
		 this.SkillName[32] = "Mutating";
		 this.SkillName[33] = "Fisioning";
		 this.SkillName[34] = "Fusioning";
		
		 if (this.XP == 2000000000){this.Level1 = 255;}
			else if (this.XP >= 1720000000 && this.XP <= 1999999999){this.Level1 = 254;}
			else if (this.XP >= 1480000000 && this.XP <= 1719999999){this.Level1 = 253;}
			else if (this.XP >= 1280000000 && this.XP <= 1479999999){this.Level1 = 252;}
			else if (this.XP >= 1120000000 && this.XP <= 1279999999){this.Level1 = 251;}
			else if (this.XP >= 1000000000 && this.XP <= 1119999999){this.Level1 = 250;}
			else if (this.XP >= 936171373 && this.XP <= 999999999){this.Level1 = 249;}
			else if (this.XP >= 50242686 && this.XP <= 936171372){this.Level1 = ((Math.log(XP + 256)/Math.log(256))-1)*91+1;}
			else if (this.XP >= 34799106 && this.XP <= 50242685){this.Level1 = 200;}
			else if (this.XP >= 149782 && this.XP <= 34799105){this.Level1 = ((Math.log10(XP + 687)/Math.log10(687))-1)*120+1;}
			else if (this.XP >= 99539 && this.XP <= 149781){this.Level1 = 99;}
			else if (this.XP >= 0 && this.XP <= 99538){this.Level1 = ((Math.log10(this.XP + 695)/Math.log10(695))-1)*129+1;}
			else {this.Level1 = 1;}

		 this.Level = (int) Math.floor(this.Level1); /** floors level down*/
		 this.NextLevel0 = (int) (this.Level + 1);  /** says Level + 1*/
		 
			
			if (this.Level == 99 || this.Level == 200 || this.Level == 255){ this.Degrees = 0; }
			else {this.Degrees = ((XP - Math.ceil(this.Degrees1)) / (this.NextLevel - Math.ceil(this.Degrees1))) * 39;}
			
			
			if (this.Level < 99) {this.NextLevel1 = (Math.pow(695, (this.NextLevel0 - 1)/129 +1) - 695);}
			else if (this.Level == 99) {this.NextLevel1 = 701754;}
			else if (this.Level >= 100 && this.Level < 200) {this.NextLevel1 = (Math.pow(687, (this.NextLevel0 - 1)/120 +1) - 687);}
			else if (this.Level == 200) {this.NextLevel1 = 100005814;}
			else if (this.Level >= 201 && this.Level < 249) {this.NextLevel1 = (Math.pow(256, (this.NextLevel0 - 1)/91 +1) - 256);}
			else if (this.Level == 249) {this.NextLevel1 = 1000000000;}
			else if (this.Level == 250) {this.NextLevel1 = 1120000000;}
			else if (this.Level == 251) {this.NextLevel1 = 1280000000;}
			else if (this.Level == 252) {this.NextLevel1 = 1480000000;}
			else if (this.Level == 253) {this.NextLevel1 = 1720000000;}
			else if (this.Level == 254) {this.NextLevel1 = 2000000000;}
			else {this.NextLevel1 = 0;}
		
			this.NextLevel = (int) Math.ceil(this.NextLevel1);
			 this.XpNeed = (int) (this.NextLevel - XP);
			
				if (this.Level <= 98) {
					this.Degrees1 = (Math.pow(695, (this.NextLevel0 - 2)/129 +1) - 695) ;
				}
				
				else if (this.Level >= 100 && Level <= 199) {
					this.Degrees1 = (Math.pow(687, (NextLevel0 - 2)/230 +1) - 687);
				}
				else if (this.Level >= 201 && this.Level <= 249) {
					this.Degrees1 = (Math.pow(256, (this.NextLevel0 - 2)/91 +1) - 256);
				}
				else if (this.Level == 250) {
					this.Degrees1 = 1000000000;
				}
				else if (this.Level == 251) {
					this.Degrees1 = 1120000000;
				}
				else if (this.Level == 252) {
					this.Degrees1 = 1280000000;
				}
				else if (this.Level == 253) {
					this.Degrees1 = 1480000000;
				}
				else if (Level == 254) {
					this.Degrees1 = 1720000000;
				}
					
				else {
					this.Degrees1 = 0;
				}
			 
	}

	public int getCorStackSize(ItemStack itemp){
		
		Map<Item, Integer> size = new HashMap<Item, Integer>();
		size.put(Items.STICK, 4);
		size.put(Item.getItemFromBlock(Blocks.TORCH), 4);
		size.put(MarkItems.Stick10, 4);
		size.put(MarkItems.Stick20, 4);
		size.put(MarkItems.Stick40, 4);
		size.put(MarkItems.Stick60, 4);
		size.put(MarkItems.Stick80, 4);
		size.put(Item.getItemFromBlock(Blocks.PLANKS), 4);
		size.put(Item.getItemFromBlock(MarkBlocks.LogYew_Planks), 4);
		size.put(Item.getItemFromBlock(MarkBlocks.LogNetherBranch_Planks), 4);
		size.put(Item.getItemFromBlock(MarkBlocks.LogCrystWood_Planks), 4);
		size.put(Item.getItemFromBlock(Blocks.OAK_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.SPRUCE_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.BIRCH_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.JUNGLE_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.ACACIA_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.DARK_OAK_FENCE), 3);
		size.put(Items.OAK_DOOR, 3);
		size.put(Items.SPRUCE_DOOR, 3);
		size.put(Items.BIRCH_DOOR, 3);
		size.put(Items.JUNGLE_DOOR, 3);
		size.put(Items.ACACIA_DOOR, 3);
		size.put(Items.DARK_OAK_DOOR, 3);
		size.put(MarkItems.LogYew_Door, 3);
		size.put(MarkItems.LogNetherBranch_Door, 3);
		size.put(MarkItems.LogCrystWood_Door, 3);
		size.put(Item.getItemFromBlock(Blocks.OAK_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.SPRUCE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.BIRCH_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.JUNGLE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.ACACIA_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.DARK_OAK_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.SANDSTONE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.RED_SANDSTONE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.STONE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.BRICK_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.STONE_BRICK_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.NETHER_BRICK_FENCE), 6);
		size.put(Item.getItemFromBlock(Blocks.NETHER_BRICK_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.STONE_SLAB), 6);
		size.put(Item.getItemFromBlock(Blocks.STONE_SLAB2), 6);
		size.put(Item.getItemFromBlock(Blocks.WOODEN_SLAB), 6);
		size.put(Item.getItemFromBlock(Blocks.GLASS_PANE), 16);
		
		if(itemp != null){
		if(itemp.getItem() == Item.getItemFromBlock(Blocks.STONEBRICK)){
			if(this.getRecipe(itemp) != null){
			if(this.getRecipe(itemp).get(0) != null){
				if(this.getRecipe(itemp).get(0).getItem() == Item.getItemFromBlock(Blocks.STONE)){
					return 4;
				}
				else {
					return 1;
				}
			}
		}
		}
		return size.get(itemp.getItem()) != null ? size.get(itemp.getItem()) : 1;
	}
		return 1;
	}

}
