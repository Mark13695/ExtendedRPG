package com.modMark.Gui;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.modMark.Combat.MarkFoodStats;
import com.modMark.Combat.MobData;
import com.modMark.Main.MainRegistry;
import com.modMark.Packets.CombatLvlPacket;
import com.modMark.Packets.CombatLvlPacket4S;
import com.modMark.Skill.MarkData;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.client.FMLClientHandler;

public class GuiHUDBars extends Gui {

	
	
	 private Minecraft mc;
	 private final ResourceLocation HealthBar0 = new ResourceLocation("mark13695", "textures/gui/Health_Bar0.png");
	 private final ResourceLocation HealthBarE = new ResourceLocation("mark13695", "textures/gui/Health_BarEntity.png");
	 private final ResourceLocation HealthBar = new ResourceLocation("mark13695", "textures/gui/Health_Bar.png");
	 private final ResourceLocation PoisonBar = new ResourceLocation("mark13695", "textures/gui/Poison_Bar.png");
	 private final ResourceLocation WitherBar0 = new ResourceLocation("mark13695", "textures/gui/Wither_Bar0.png");
	 private final ResourceLocation WitherBar = new ResourceLocation("mark13695", "textures/gui/Wither_Bar.png");
	 private final ResourceLocation StomachBar0 = new ResourceLocation("mark13695", "textures/gui/Stomach_Bar0.png");
	 private final ResourceLocation StomachBar = new ResourceLocation("mark13695", "textures/gui/Stomach_Bar.png");
	 private int prevHP = 0;
	
	public GuiHUDBars(Minecraft mc) {
	    this.mc = mc;
	  }
	
	
	
	 public void Draw(int screenWidth, int screenHeight) {
		 World world = mc.theWorld;
		 EntityPlayer player = mc.thePlayer;
		 		 
		
		 
		
		 int x = screenWidth / 2 - 91;
		 int y = screenHeight - 38;
		 //HeadTexture
		 if(player.isPotionActive(MobEffects.WITHER)){
			 mc.renderEngine.bindTexture(WitherBar0);
			 drawModalRectWithCustomSizedTexture(x, y - 12, 0, 0, 182, 12, 182, 12);
		 }
		 else if(player.isPotionActive(MobEffects.POISON)){
			 mc.renderEngine.bindTexture(StomachBar0);
			 drawModalRectWithCustomSizedTexture(x, y - 12, 0, 0, 182, 12, 182, 12);
		 }
		 else{
			 mc.renderEngine.bindTexture(HealthBar0);
			 drawModalRectWithCustomSizedTexture(x, y - 12, 0, 0, 182, 12, 182, 12); 
		 }
		 mc.renderEngine.bindTexture(StomachBar0);
		 drawModalRectWithCustomSizedTexture(x, y, 0, 0, 182, 12, 182, 12); 
		 MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
	     float maxHp = p.getMaxHP();
	     float absorptionAmount = player.getAbsorptionAmount();
	     float effectiveHp = p.getHP() + absorptionAmount;
	     float BarVal1 = (effectiveHp / maxHp) * 180.0F;
	     float BarVal2 = player.getFoodStats() instanceof MarkFoodStats ? (((MarkFoodStats)player.getFoodStats()).getFoodLevel2() * 180) / 100 : (player.getFoodStats().getFoodLevel() * 180) / 100;
	     
	     if(player.isPotionActive(MobEffects.WITHER)){
	    	 mc.renderEngine.bindTexture(WitherBar);
	    	 drawModalRectWithCustomSizedTexture(x + 1, y - 11, 0, 0, (int)BarVal1, 10, (int)BarVal1, 10);
		 }
		 else if(player.isPotionActive(MobEffects.POISON)){
			 mc.renderEngine.bindTexture(PoisonBar);
			 drawModalRectWithCustomSizedTexture(x + 1, y - 11, 0, 0, (int)BarVal1, 10, (int)BarVal1, 10);
		 }
		 else{
			 mc.renderEngine.bindTexture(HealthBar);
			 drawModalRectWithCustomSizedTexture(x + 1, y - 11, 0, 0, (int)BarVal1, 10, (int)BarVal1, 10); 
		 }
	     mc.renderEngine.bindTexture(StomachBar);
	     drawModalRectWithCustomSizedTexture(x + 1, y + 1, 0, 0, (int)BarVal2, 10, (int)BarVal2, 10); 
	     
	     
	     int x1 = screenWidth / 2 - 91;
	     int y1 = 10;
	     RayTraceResult r = this.getMouseOverExtended(20);
	     if(r != null){
	    	Entity entity = r.entityHit;
	     if(entity != null && entity instanceof EntityLiving ){
	    	 EntityLiving Li = (EntityLiving) entity;
	    	 MobData mob = Li.getCapability(MainRegistry.ModMark136MobData, null);
	  if (mob.getCombat() == 0){
		  MainRegistry.network.sendToServer(new CombatLvlPacket4S(Li ,this.mc.thePlayer));
	  } 
	  
	    	 float maxHpE = mob.getMaxHP();
	    	 this.prevHP = mob.getMaxHP();
	    	 
	    	 float ab = (int) Li.getAbsorptionAmount();
	    	 float CurHpE = mob.getHP() + ab;
	    	 float BarValE = (CurHpE / maxHpE) * 180.0F;
	    	 int PosCorE = (int)CurHpE > 999 ? 18 : ((int)CurHpE > 99 ? 12 : ((int)CurHpE > 9 ? 6 : 0));
	    	 int OwnCb = mc.thePlayer.getCapability(MainRegistry.ModMark136Data, null).Combat;
	    	 String s1 = (int)CurHpE + "/" + (int)maxHpE;
	    	 String s2 = Li.getName();
	    	 int cbval;
	    	 if(entity instanceof EntityPlayer){
	    		MarkData p1 = entity.getCapability(MainRegistry.ModMark136Data, null);
	    		cbval = p1.Combat;
	    	 }
	    	 else{
	    		MobData p1 = entity.getCapability(MainRegistry.ModMark136MobData, null);
	    		cbval = p1.getCombat();
	    		
	    	 }
	    	 
	    	 String s3 = "[" + cbval  + "]";
	    	 
	    	 
	    	 mc.renderEngine.bindTexture(HealthBarE);
			 drawModalRectWithCustomSizedTexture(x1, y1, 0, 0, 182, 24, 182, 24);
	    	 
	    	 
	    	 mc.renderEngine.bindTexture(HealthBar);
	    	 drawModalRectWithCustomSizedTexture(x1 + 1, y1 + 13, 0, 0, (int)BarValE, 10, (int)BarValE, 10); 
		     
	    	  drawString (this.mc.fontRendererObj , "" + s1 , x1 + 82 - PosCorE, y1 + 14, (ab > 0 ? 0xFFD200 : 0xffffff));
	    	  drawString (this.mc.fontRendererObj , "" + s2 , x1 + 2 , y1 + 2, 0xffffff);
	    	  drawString (this.mc.fontRendererObj , "" + s3 , (x1 + 2) + (s2.length() * 6) , y1 + 2, this.GetCombatColour(cbval - OwnCb));
	    	 
	     }
	     }
	     
		 	
		    String s1 = (int)effectiveHp + "/" + (int)maxHp;
		    int Foodlvl = player.getFoodStats() instanceof MarkFoodStats ? ((MarkFoodStats)player.getFoodStats()).getFoodLevel2() : player.getFoodStats().getFoodLevel();
		    String s2 = "" + Foodlvl + (player.getFoodStats() instanceof MarkFoodStats ? "%" : " / 20");
		    int PosCor1 = (int)effectiveHp > 9 ? 6 : ((int)effectiveHp > 99 ? 12 : 0);
		    int PosCor2 = (int)Foodlvl > 9 ? 3 : 0;
		    
		    drawString (this.mc.fontRendererObj , "" + s1 , x + 82 - PosCor1, y - 10, (absorptionAmount > 0 ? 0xFFD200 : 0xffffff));
		    drawString (this.mc.fontRendererObj , "" + s2 , x + 85 - PosCor2, y + 2, 0xffffff);
		    
		    
		    
		    
		    
	 }
	 
	 public RayTraceResult getMouseOverExtended(float dist)
	 {
	     Entity theRenderViewEntity = mc.getRenderViewEntity();
	     AxisAlignedBB theViewBoundingBox = new AxisAlignedBB(
	             theRenderViewEntity.posX-0.5D,
	             theRenderViewEntity.posY-0.0D,
	             theRenderViewEntity.posZ-0.5D,
	             theRenderViewEntity.posX+0.5D,
	             theRenderViewEntity.posY+1.5D,
	             theRenderViewEntity.posZ+0.5D
	             );
	     RayTraceResult returnMOP = null;
	     if (mc.theWorld != null)
	     {
	         double var2 = dist;
	         returnMOP = theRenderViewEntity.rayTrace(var2, 0);
	         double calcdist = var2;
	         Vec3d pos = theRenderViewEntity.getPositionEyes(0);
	         var2 = calcdist;
	         if (returnMOP != null)
	         {
	             calcdist = returnMOP.hitVec.distanceTo(pos);
	         }
	          
	         Vec3d lookvec = theRenderViewEntity.getLook(0);
	         Vec3d var8 = pos.addVector(lookvec.xCoord * var2, 
	               lookvec.yCoord * var2, 
	               lookvec.zCoord * var2);
	         Entity pointedEntity = null;
	         float var9 = 1.0F;
	         @SuppressWarnings("unchecked")
	         List<Entity> list = mc.theWorld.getEntitiesWithinAABBExcludingEntity(
	               theRenderViewEntity, 
	               theViewBoundingBox.addCoord(
	                     lookvec.xCoord * var2, 
	                     lookvec.yCoord * var2, 
	                     lookvec.zCoord * var2).expand(var9, var9, var9));
	         double d = calcdist;
	             
	         for (Entity entity : list)
	         {
	             if (entity.canBeCollidedWith())
	             {
	                 float bordersize = entity.getCollisionBorderSize();
	                 AxisAlignedBB aabb = new AxisAlignedBB(
	                       entity.posX-entity.width/2, 
	                       entity.posY, 
	                       entity.posZ-entity.width/2, 
	                       entity.posX+entity.width/2, 
	                       entity.posY+entity.height, 
	                       entity.posZ+entity.width/2);
	                 aabb.expand(bordersize, bordersize, bordersize);
	                 RayTraceResult mop0 = aabb.calculateIntercept(pos, var8);
	                     
	                 if (aabb.isVecInside(pos))
	                 {
	                     if (0.0D < d || d == 0.0D)
	                     {
	                         pointedEntity = entity;
	                         d = 0.0D;
	                     }
	                 } else if (mop0 != null)
	                 {
	                     double d1 = pos.distanceTo(mop0.hitVec);
	                         
	                     if (d1 < d || d == 0.0D)
	                     {
	                         pointedEntity = entity;
	                         d = d1;
	                     }
	                 }
	             }
	         }
	            
	         if (pointedEntity != null && (d < calcdist || returnMOP == null))
	         {
	              returnMOP = new RayTraceResult(pointedEntity);
	         }
	     }
	     return returnMOP;
	 }
	
	 public int GetCombatColour(int difLvls){ //TODO: Find a way to let the chat accepts hex colours
			if(difLvls > 49)return 0x770077;
			else if(difLvls > 14) return 0xFF0000;
			else if(difLvls < -49)return 0x297E97;
			else if(difLvls < -14)return 0x00FF00;
	
			Map<Integer, Integer> Colour = new HashMap<Integer, Integer>();
			Colour.put(0, 0xFFFF00);
			Colour.put(1, 0xFFEE00);
			Colour.put(2, 0xFFDD00);
			Colour.put(3, 0xFFCC00);
			Colour.put(4, 0xFFBB00);
			Colour.put(5, 0xFFAA00);
			Colour.put(6, 0xFF9900);
			Colour.put(7, 0xFF8800);
			Colour.put(8, 0xFF7700);
			Colour.put(9, 0xFF6600);
			Colour.put(10, 0xFF5500);
			Colour.put(11, 0xFF4400);
			Colour.put(12, 0xFF3300);
			Colour.put(13, 0xFF2200);
			Colour.put(14, 0xFF1100);
			Colour.put(-1, 0xEEFF00);
			Colour.put(-2, 0xDDFF00);
			Colour.put(-3, 0xCCFF00);
			Colour.put(-4, 0xBBFF00);
			Colour.put(-5, 0xAAFF00);
			Colour.put(-6, 0x99FF00);
			Colour.put(-7, 0x88FF00);
			Colour.put(-8, 0x77FF00);
			Colour.put(-9, 0x66FF00);
			Colour.put(-10, 0x55FF00);
			Colour.put(-11, 0x44FF00);
			Colour.put(-12, 0x33FF00);
			Colour.put(-13, 0x22FF00);
			Colour.put(-14, 0x11FF00);
			
			return Colour.get(difLvls) == null ? 0xFFFFFF : Colour.get(difLvls);
		}
	
}
