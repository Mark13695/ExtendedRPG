package com.modMark.Gui;

import java.io.IOException;
import java.util.Arrays;

import org.apache.commons.lang3.ArrayUtils;

import com.modMark.Main.MainRegistry;
import com.modMark.Packets.HiscorePacketA;
import com.modMark.Packets.SkillPacket;
import com.modMark.Skill.MarkData;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


@SideOnly(Side.CLIENT)
public class GuiHiscoreList extends GuiScreen {
	
	public int xSize = 235;
	public int ySize = 220;
	public int w = this.width;
	public int h = this.height;
	
	public int x;
	public int y;
	public int ListID = 35;
	public String LvlTot;
	
	

	public GuiHiscoreList(){}
	
	public static int[] XPTab;
	public static String[] PlayerTab;
	public static long[] TotXPTab;
	public static int[] TotTab;
	
	public static int[] XPTab2;
	public static String[] PlayerTab2;
	public static long[] TotXPTab2;
	public static int[] TotTab2;
	public static boolean AreOff;
	
	
	/** an Array of Players with xp*/
	public static int XP[];
	
	private String[] SkillName = new String[37]; //head
	 //head
	private double[] Level1;
	private int[] Level; //head

	private int Total;
	
	private long TotXp;
	
	//own levels
public static int XP_OWN[] = new int[37];
	
	private String[] SkillName_OWN = new String[37]; //head
	 //head
	private double[] Level1_OWN = new double[37];
	private int[] Level_OWN = new int[37]; //head

	private int Total_OWN;
	
	private long TotXp_OWN;
	public static EntityPlayer player;
	
	 @Override
     public void drawScreen(int mouseX, int mouseY, float pticks) {
		 this.drawDefaultBackground();
		 ResourceLocation location = new ResourceLocation("mark13695", "textures/gui/HiscoreList.png");
		 this.mc.getTextureManager().bindTexture(location);
		 
		 this.w = this.width;
		 this.h = this.height;
		 
		 this.x = ((this.w - this.xSize) / 2);
		 this.y = ((this.h - this.ySize) / 2);
		 
		
		 this.SkillName[0] = "Constitution";
		 this.SkillName[1] = "Melee";
		 this.SkillName[2] = "Ranged";
		 this.SkillName[3] = "Magic";
		 this.SkillName[4] = "Defence";
		 this.SkillName[5] = "Endurance";
		 this.SkillName[6] = "Slayer";
		 this.SkillName[7] = "Farming";
		 this.SkillName[8] = "Mining";
		 this.SkillName[9] = "Hunter";
		 this.SkillName[10] = "Excavation";
		 this.SkillName[11] = "Woodcutting";
		 this.SkillName[12] = "Fishing";
		 this.SkillName[13] = "Archeology";
		 this.SkillName[14] = "Tailory";
		 this.SkillName[15] = "Smithing";
		 this.SkillName[16] = "Tanning";
		 this.SkillName[17] = "Jewelry";
		 this.SkillName[18] = "Fletching";
		 this.SkillName[19] = "Cooking";
		 this.SkillName[20] = "Herblore";
		 this.SkillName[21] = "Honour";
		 this.SkillName[22] = "Construction";
		 this.SkillName[23] = "Agility";
		 this.SkillName[24] = "Exploration";
		 this.SkillName[25] = "Pet Caring";
		 this.SkillName[26] = "Lifestock";
		 this.SkillName[27] = "Knowledge";
		
		 this.SkillName[35] = "Total Based";
		 this.SkillName[36] = "XP Based";
		 
		 
		 
		 for (int i = 0; i < 35;i++) {
			 
			 if (this.XP_OWN[i] == 2000000000){this.Level1_OWN[i] = 255;}
				else if (this.XP_OWN[i] >= 1720000000 && this.XP_OWN[i] <= 1999999999){this.Level1_OWN[i] = 254;}
				else if (this.XP_OWN[i] >= 1480000000 && this.XP_OWN[i] <= 1719999999){this.Level1_OWN[i] = 253;}
				else if (this.XP_OWN[i] >= 1280000000 && this.XP_OWN[i] <= 1479999999){this.Level1_OWN[i] = 252;}
				else if (this.XP_OWN[i] >= 1120000000 && this.XP_OWN[i] <= 1279999999){this.Level1_OWN[i] = 251;}
				else if (this.XP_OWN[i] >= 1000000000 && this.XP_OWN[i] <= 1119999999){this.Level1_OWN[i] = 250;}
				else if (this.XP_OWN[i] >= 936171373 && this.XP_OWN[i] <= 999999999){this.Level1_OWN[i] = 249;}
				else if (this.XP_OWN[i] >= 50242686 && this.XP_OWN[i] <= 936171372){this.Level1_OWN[i] = ((Math.log(XP_OWN[i] + 256)/Math.log(256))-1)*91+1;}
				else if (this.XP_OWN[i] >= 34799106 && this.XP_OWN[i] <= 50242685){this.Level1_OWN[i] = 200;}
				else if (this.XP_OWN[i] >= 149782 && this.XP_OWN[i] <= 34799105){this.Level1_OWN[i] = ((Math.log10(XP_OWN[i] + 687)/Math.log10(687))-1)*120+1;}
				else if (this.XP_OWN[i] >= 99539 && this.XP_OWN[i] <= 149781){this.Level1_OWN[i] = 99;}
				else if (this.XP_OWN[i] >= 0 && this.XP_OWN[i] <= 99538){this.Level1_OWN[i] = ((Math.log10(this.XP_OWN[i] + 695)/Math.log10(695))-1)*129+1;}
				else {this.Level1_OWN[i] = 1;}

			 this.Level_OWN[i] = (int) Math.floor(this.Level1_OWN[i]); // floors level down
			 
				
				
			}

		 
			
			float PoX = mouseX;
		 	float PoY = mouseY;
		 	
		 	 
			 
			 
		 	
		 
			 
			 this.SkillName[34] = "Fusioning";
			
			
			
			drawModalRectWithCustomSizedTexture(this.x, this.y, 0, 0, this.xSize, this.ySize, 235, 220);
			
			ResourceLocation locationTc = new ResourceLocation("mark13695", "textures/gui/SkillLockTc.png");
			 this.mc.getTextureManager().bindTexture(locationTc);
			 if (this.Level_OWN[15] < 20 || this.Level_OWN[18] < 20 || this.Level_OWN[22] < 20 || this.Level_OWN[27] < 35){
			 drawModalRectWithCustomSizedTexture(this.x + 99, this.y + 43, 0, 0, 16, 16, 16, 16);
			 this.SkillName[28] = "???";
			 }
			 else{this.SkillName[28] = "Technology";}
			 ResourceLocation locationPe = new ResourceLocation("mark13695", "textures/gui/SkillLockEn.png");
			 this.mc.getTextureManager().bindTexture(locationPe);
			 
			 if (this.Level_OWN[9] < 50 || this.Level_OWN[21] < 50 || this.Level_OWN[26] < 50 || this.Level_OWN[27] < 70){
			 drawModalRectWithCustomSizedTexture(this.x + 117, this.y + 43, 0, 0, 16, 16, 16, 16);
			 this.SkillName[29] = "???";
			 }
			 else{this.SkillName[29] = "Energising";}
			 ResourceLocation locationCh = new ResourceLocation("mark13695", "textures/gui/SkillLockCh.png");
			 this.mc.getTextureManager().bindTexture(locationCh);
			 if (this.Level_OWN[10] < 90 || this.Level_OWN[13] < 90 || this.Level_OWN[20] < 90 || this.Level_OWN[27] < 105){
			 drawModalRectWithCustomSizedTexture(this.x + 135, this.y + 43, 0, 0, 16, 16, 16, 16);
			 this.SkillName[30] = "???";
			 }
			 else{this.SkillName[30] = "Chemistry";}
			 ResourceLocation locationSp = new ResourceLocation("mark13695", "textures/gui/SkillLockSp.png");
			 this.mc.getTextureManager().bindTexture(locationSp);
			 if (this.Level_OWN[14] < 105 || this.Level_OWN[16] < 105 || this.Level_OWN[19] < 105 || this.Level_OWN[27] < 120){
			 drawModalRectWithCustomSizedTexture(this.x + 153, this.y + 43, 0, 0, 16, 16, 16, 16);
			 this.SkillName[31] = "???";
			 }
			 else{this.SkillName[31] = "Specility";}
			 ResourceLocation locationMu = new ResourceLocation("mark13695", "textures/gui/SkillLockMu.png");
			 this.mc.getTextureManager().bindTexture(locationMu);
			 if (this.Level_OWN[7] < 120 || this.Level_OWN[11] < 120 || this.Level_OWN[26] < 120 || this.Level_OWN[27] < 135){
			 drawModalRectWithCustomSizedTexture(this.x + 171, this.y + 43, 0, 0, 16, 16, 16, 16);
			 this.SkillName[32] = "???";
			 }
			 else{this.SkillName[32] = "Mutating";}
			 ResourceLocation locationFi = new ResourceLocation("mark13695", "textures/gui/SkillLockFi.png");
			 this.mc.getTextureManager().bindTexture(locationFi);
			 if (this.Level_OWN[8] < 135 || this.Level_OWN[23] < 135 || this.Level_OWN[24] < 135 || this.Level_OWN[27] < 150){
			 drawModalRectWithCustomSizedTexture(this.x + 189, this.y + 43, 0, 0, 16, 16, 16, 16);
			 this.SkillName[33] = "???";
			 }
			 else{this.SkillName[33] = "Fisioning";}
			 ResourceLocation locationFu = new ResourceLocation("mark13695", "textures/gui/SkillLockFu.png");
			 this.mc.getTextureManager().bindTexture(locationFu);
			 if (this.Level_OWN[15] < 150 || this.Level_OWN[17] < 150 || this.Level_OWN[30] < 150 || this.Level_OWN[27] < 175){
			 drawModalRectWithCustomSizedTexture(this.x + 207, this.y + 43, 0, 0, 16, 16, 16, 16);
			 this.SkillName[34] = "???";
			 }
			 else{this.SkillName[34] = "Fusioning";}
			 
			 boolean b0 = this.PlayerTab2 == null;
			 boolean b1 = this.PlayerTab == null;
			 boolean b2 = ListID < 35 && this.XPTab == null ;
			 boolean b3 = false;
			 boolean b4 = false;
			 if(b1 == true){
				 b3 = false;
				 b4 = false;
			 }
			 else{
				 if (this.XPTab != null){
				 b3 = ListID < 35 && (this.PlayerTab.length != this.XPTab.length) ;
				 }
				 else{
				 b3 = false;
				 }
				 if(this.TotTab != null){
				 b4 = ListID >= 35 && (this.PlayerTab.length != this.TotTab.length) ;
				 }
				 else {
					 b4 = false;
				 }
			 }
			 boolean b5 = false;
			 boolean b6 = false;
			 
			 if(b0){
				 b5 = false;
				 b6 = false;
			 }
			 else{
				 if (this.XPTab2 != null){
					 b5 = ListID < 35 && this.PlayerTab2.length != 0 && (this.PlayerTab2.length != this.XPTab2.length);
				 }
				 else{
					b5 = false; 
				 }
				 if (this.TotTab2 != null){
			 b6 = ListID >= 35 && this.PlayerTab2.length != 0 && this.PlayerTab2.length != this.TotTab2.length;
				 }
				 else{
					 b6 = false;
				 }
			 }
			 
			 if (b1 || b2 || b3 || b4 || b5 || b6){
				 System.out.println(b1 + " : " + b2 + " : " + b3 + " : " + b4 + " : " + b5 + " : " + b6);
				 drawString (fontRendererObj , "Loading..." , this.x + 6, this.y + 64, 0x0000ff00); 
				 
			 }
			 else{
				 
			 
			 
			 String Splitter = "-";
			 int L = PlayerTab.length;
			 int L1 = PlayerTab.length;
			 int L2 = 0;
			 if(PlayerTab2 != null && this.AreOff){
				  L2 = PlayerTab2.length;
				  L = PlayerTab.length + PlayerTab2.length ; 	 
			 }
			 else{
				 L = PlayerTab.length; 
				 L2 = 0;
			 }
			 String[] Stringer1 = new String[L1];
			 String[] Stringer2 = new String[L2];
			 
			 int[] level;
			 int[] level2 = null;
			 
			 
			 if(ListID < 35){
				 
				 level = getLevel(this.XPTab, this.XPTab.length);
				 if(L2 != 0){
				 level2 = getLevel(this.XPTab2, this.XPTab2.length);
				 }
				 for (int i = 0; i < L1; i++){
					 
					 Stringer1[i] = String.format("%011d", this.XPTab[i]) + Splitter + level[i] + Splitter + this.PlayerTab[i] + Splitter + 1;
				 }
				 if(L2 != 0 && Stringer2 != null){
				 for (int i = 0; i < L2; i++){
					 
					 Stringer2[i] = String.format("%011d", this.XPTab2[i]) + Splitter + level2[i] + Splitter + this.PlayerTab2[i] + Splitter + 0;
				 }
				 }
			 }
			 else if (ListID == 35){
				 for (int i = 0; i < L1; i++){
					 Stringer1[i] = String.format("%04d", this.TotTab[i]) + Splitter + String.format("%011d", this.TotXPTab[i]) + Splitter + this.PlayerTab[i] + Splitter + 1;				 
				 }
				 if(L2 != 0 && Stringer2 != null){
				 for (int i = 0; i < L2; i++){
					 Stringer2[i] = String.format("%04d", this.TotTab2[i]) + Splitter + String.format("%011d", this.TotXPTab2[i]) + Splitter + this.PlayerTab2[i] + Splitter + 0;				 
				 }
			 }}
			 else{
				 for (int i = 0; i < L1; i++){
					 Stringer1[i] = String.format("%011d", this.TotXPTab[i]) + Splitter + String.format("%04d", this.TotTab[i]) + Splitter + this.PlayerTab[i] + Splitter + 1; 
				 }	
				 if(L2 != 0 && Stringer2 != null){
				 for (int i = 0; i < L2; i++){
					 Stringer2[i] = String.format("%011d", this.TotXPTab2[i]) + Splitter + String.format("%04d", this.TotTab2[i]) + Splitter + this.PlayerTab2[i] + Splitter + 0; 
				 }}
			 }
			 
			 String[] Stringer = ArrayUtils.addAll(Stringer1 , Stringer2);
			 Arrays.sort(Stringer);
			 
			
			 String[] HSPlayer = new String[L];
			 int[] HSXP = new int[L];
			 int[] HSTOT = new int[L];
			 int[] off = new int[L];
			 if(this.ListID == 35 || this.ListID == 36){
				 this.LvlTot = "TOT";
				 
				 if(this.ListID == 35){
				 for (int p1 = 0; p1 < L ; p1++){
					 if(Stringer[p1].contains("-")){
						 String[] HSParts = Stringer[p1].split("-");
						 HSXP[p1] = Integer.parseInt(HSParts[1]);
						 HSTOT[p1] = Integer.parseInt(HSParts[0]);	 
						 HSPlayer[p1] = HSParts[2];
						 off[p1] = Integer.parseInt(HSParts[3]);
						 
					 }
					 else{
						 throw new IllegalArgumentException("String " + Stringer[p1] + " does not contain -");

					 }
				 }}
				 else if(this.ListID == 36){
					 for (int p1 = 0; p1 < L ; p1++){
						 if(Stringer[p1].contains("-")){
							 String[] HSParts = Stringer[p1].split("-");
							 HSXP[p1] = Integer.parseInt(HSParts[0]);
							 HSTOT[p1] = Integer.parseInt(HSParts[1]);	 
							 HSPlayer[p1] = HSParts[2];
							 off[p1] = Integer.parseInt(HSParts[3]);
						 }
						 else{
							 throw new IllegalArgumentException("String " + Stringer[p1] + " does not contain -");

						 }
					 }
					 
					 
				 }
				 
			 }
			 else{
				 this.LvlTot = "LVL";
				 
				 for (int p1 = 0; p1 < L ; p1++){
					 if(Stringer[p1].contains("-")){
						 String[] HSParts = Stringer[p1].split("-");
						 HSXP[p1] = Integer.parseInt(HSParts[0]);
						 HSPlayer[p1] = HSParts[2];
						 HSTOT[p1] = Integer.parseInt(HSParts[1]);
						 off[p1] = Integer.parseInt(HSParts[3]);
					 }
					 else{
						 throw new IllegalArgumentException("String " + Stringer[p1] + " does not contain -");

					 }
				 }
			 }
			 
			 
			 
			 
			
			
			 
			 drawString (fontRendererObj , "" + this.SkillName[ListID] , this.x + 6, this.y + 64, 0x0000ff00);
			
			 drawString (fontRendererObj , "No." , this.x + 6, this.y + 78, 0x0000ff00);
			 drawString (fontRendererObj , "Player" , this.x + 30, this.y + 78, 0x0000ff00);
			 drawString (fontRendererObj , LvlTot , this.x + 125, this.y + 78, 0x0000ff00);	
			 drawString (fontRendererObj , "XP" , this.x + 157, this.y + 78, 0x0000ff00);
			 
			 
			 if(L < 11){
			 for (int hs = 0; hs < L; hs++){
				 int hs2 = ((L-hs) - 1);
				 
			 drawString (fontRendererObj , "" + (hs + 1) , this.x + 6, this.y + 93 + (hs * 12), 0x0000ff00);
			 drawString (fontRendererObj , HSPlayer[hs2] , this.x + 30, this.y + 93 + (hs * 12), off[hs2] == 1 ? 0x0000ff00 : 0x00009900);
			 drawString (fontRendererObj , "" + String.format("%,d",HSTOT[hs2]) , this.x + 125, this.y + 93 + (hs * 12), off[hs2] == 1 ? 0x0000ff00 : 0x00009900);
			 drawString (fontRendererObj , "" + String.format("%,d",HSXP[hs2]) , this.x + 157, y + 93 + (hs * 12), off[hs2] == 1 ? 0x0000ff00 : 0x00009900);
			 }
			 }
			 else if(L > 10){
				 for (int hs = 0; hs < 9; hs++){
					 int hs2 = ((L-hs) - 1);
				 drawString (fontRendererObj , "" + (hs + 1) , this.x + 6, this.y + 93 + (hs * 12), 0x0000ff00);
				 drawString (fontRendererObj , HSPlayer[hs2] , this.x + 30, this.y + 93 + (hs * 12), off[hs2] == 1 ? 0x0000ff00 : 0x00009900);
				 drawString (fontRendererObj , "" + String.format("%,d",HSTOT[hs2]) , this.x + 125, this.y + 93 + (hs * 12), off[hs2] == 1 ? 0x0000ff00 : 0x00009900);
				 drawString (fontRendererObj , "" + String.format("%,d",HSXP[hs2]) , this.x + 157, y + 93 + (hs * 12), off[hs2] == 1 ? 0x0000ff00 : 0x00009900);
				 }
				 for (int hs = 0; hs < L; hs++){
					 int hs2 = ((L-hs) - 1);
		
					if (HSPlayer[hs2].equals(this.player.getName())){
						if(hs < 10){
							 drawString (fontRendererObj , "10" , this.x + 6, this.y + 201, 0x0000ff00);
							 drawString (fontRendererObj , HSPlayer[(L-10)] , this.x + 30, this.y + 201, off[(L-10)] == 1 ? 0x0000ff00 : 0x00009900);
							 drawString (fontRendererObj , "" + String.format("%,d",HSTOT[(L-10)]) , this.x + 125, this.y + 201, off[L-10] == 1 ? 0x0000ff00 : 0x00009900);
							 drawString (fontRendererObj , "" + String.format("%,d",HSXP[(L-10)]) , this.x + 157, y + 201, off[L-10] == 1 ? 0x0000ff00 : 0x00009900);
							 break;	 
						}
						else{
							 drawString (fontRendererObj , "" + (hs + 1) , this.x + 6, this.y + 201, 0x0000ff00 );
							 drawString (fontRendererObj , HSPlayer[hs2] , this.x + 30, this.y + 201, off[hs2] == 1 ? 0x0000ff00 : 0x00009900);
							 drawString (fontRendererObj , "" + String.format("%,d",HSTOT[hs2]) , this.x + 125, this.y + 201, off[hs2] == 1 ? 0x0000ff00 : 0x00009900);
							 drawString (fontRendererObj , "" + String.format("%,d",HSXP[hs2]) , this.x + 157, y + 201, off[hs2] == 1 ? 0x0000ff00 : 0x00009900);
							 
							
							 break;	
						}
						
					}

					
				 }
				 
				 }
			 }
			 
			  
			 
			 
			 
			 
			 
	 }
	 
	 
	 public int[] getLevel(int[] xp, int Length){
		 
		 
		 int[] XP = xp;
		 int Le = Length;
		 this.Level1 = new double[Le];
		 this.Level = new int[Le];
			for (int i = 0; i < Le;i++) {
				 
				 if (XP[i] == 2000000000){this.Level1[i] = 255;}
					else if (XP[i] >= 1720000000 && XP[i] <= 1999999999){this.Level1[i] = 254;}
					else if (XP[i] >= 1480000000 && XP[i] <= 1719999999){this.Level1[i] = 253;}
					else if (XP[i] >= 1280000000 && XP[i] <= 1479999999){this.Level1[i] = 252;}
					else if (XP[i] >= 1120000000 && XP[i] <= 1279999999){this.Level1[i] = 251;}
					else if (XP[i] >= 1000000000 && XP[i] <= 1119999999){this.Level1[i] = 250;}
					else if (XP[i] >= 936171373 && XP[i] <= 999999999){this.Level1[i] = 249;}
					else if (XP[i] >= 50242686 && XP[i] <= 936171372){this.Level1[i] = ((Math.log(XP[i] + 256)/Math.log(256))-1)*91+1;}
					else if (XP[i] >= 34799106 && XP[i] <= 50242685){this.Level1[i] = 200;}
					else if (XP[i] >= 149782 && XP[i] <= 34799105){this.Level1[i] = ((Math.log10(XP[i] + 687)/Math.log10(687))-1)*120+1;}
					else if (XP[i] >= 99539 && XP[i] <= 149781){this.Level1[i] = 99;}
					else if (XP[i] >= 0 && XP[i] <= 99538){this.Level1[i] = ((Math.log10(XP[i] + 695)/Math.log10(695))-1)*129+1;}
					else {this.Level1[i] = 1;}

				 this.Level[i] = (int) Math.floor(this.Level1[i]); /** floors level down*/
				 
					
					
				}
		 return Level;
		 
	 }
	 
	public GuiButton[] button = new GuiButton[37];
	
	 
	 @Override
	 public void initGui(){
		 
		 
		
		 
		 for (int i = 0; i < 11; i++){
		 this.buttonList.add(this.button[i] = new GuiButton( i + 10 , ((this.width - 235) / 2) +(i * 18) + 17, ((this.height - 220) / 2) + 6, 18, 18, this.SkillName[i] + " button"));
		 }
		 for (int j = 0; j < 12; j++){
		 this.buttonList.add(this.button[j + 11] = new GuiButton( j + 21 , ((this.width - 235) / 2) +(j * 18) + 8, ((this.height - 220) / 2) + 24, 18, 18, this.SkillName[j + 11] + " button"));
		 }
		 for (int j = 0; j < 12; j++){
		 this.buttonList.add(this.button[j + 23] = new GuiButton( j + 33 , ((this.width - 235) / 2) +(j * 18) + 8, ((this.height - 220) / 2) + 42, 18, 18, this.SkillName[j + 23] + " button"));
		 }
		 for (int j = 0; j < 2; j++){
		 this.buttonList.add(this.button[j + 35] = new GuiButton(j + 45 , ((this.width - 235) / 2) +(j * 18) + 188 , ((this.height - 220) / 2) + 60, 18, 18, this.SkillName[j + 35] + " button"));
		 }
	}
	 
	 @Override
	 protected void actionPerformed(GuiButton guibutton) throws IOException {
		 for (int i = 0;i < 37 ; i++)
		 if(guibutton == button[i]){
			 this.ListID = i;
			 MainRegistry.network.sendToServer(new HiscorePacketA(this.ListID, this.player));
		 }
		 
		 
	 }
	 
	
}
