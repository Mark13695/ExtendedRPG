package com.modMark.Gui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.modMark.Crafting.MarkContainerInv;
import com.modMark.Crafting.MarkInventory;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Main.MainRegistry;
import com.modMark.Packets.CraftingPacketS;
import com.modMark.Packets.InventoryPacketS;
import com.modMark.Packets.InventoryPacketS2;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class GuiInventory2 extends GuiContainer {
	
	private float PoX;
	private float PoY;
	private int xsize = 235;
	private int ysize = 220;
	private int w = this.width;
	private int h = this.height;
	private int x = ((w - xsize)  / 2);
	private int y = ((h - ysize) / 2);
	private int z = 1;
	private InventoryPlayer invP;
	private float oldMouseX;
	private float oldMouseY;
	private int addLevel = 0;
	private int hasItemVariants = 0;
	private int ItemVariant = 0;
	private int ItemVariant1 = 0;
	private int ItemVariant2 = 0;
	private int ItemVariant3 = 0;
	private int ItemVarZise = 0;
	private int ItemVarZise1 = 0;
	private int ItemVarZise2 = 0;
	private int ItemVarZise3 = 0;
	private MarkInventory Showcase;
	private ItemStack SlotItem;
	private String[] SkillName = new String[35];

	
	
	public GuiInventory2(InventoryPlayer invPlayer, MarkInventory inv) {
		super(new MarkContainerInv(invPlayer, inv));
		this.invP = invPlayer;
		this.Showcase = inv;
	
		xSize = 235;
		ySize = 220;
		
	}
	@Override
	 public void drawScreen(int mouseX, int mouseY, float partialTicks)
	    {
		
	        super.drawScreen(mouseX, mouseY, partialTicks);
	        this.oldMouseX = (float)mouseX;
	        this.oldMouseY = (float)mouseY;
	    }

	@Override
	protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
		this.drawDefaultBackground();
		ResourceLocation location = new ResourceLocation("mark13695", "textures/gui/MarkInventory.png");
		 this.mc.getTextureManager().bindTexture(location);
		 
		// positions
		 	this.PoX = mouseX;
		 	this.PoY = mouseY;
		 	this.xsize = 235;
		 	this.ysize = 220;
		 	this.w = this.width;
		 	this.h = this.height;
		 	this.x = ((w - 235)  / 2);
		 	this.y = ((h - 220) / 2);
		 	this.z = 1;
		 	
		 	this.SkillName[0] = "Constitution";
			 this.SkillName[1] = "Melee";
			 this.SkillName[2] = "Ranged";
			 this.SkillName[3] = "Magic";
			 this.SkillName[4] = "Defence";
			 this.SkillName[5] = "Endurance";
			 this.SkillName[6] = "Slayer";
			 this.SkillName[7] = "Farming";
			 this.SkillName[8] = "Mining";
			 this.SkillName[9] = "Hunter";
			 this.SkillName[10] = "Excavation";
			 this.SkillName[11] = "Woodcutting";
			 this.SkillName[12] = "Fishing";
			 this.SkillName[13] = "Archeology";
			 this.SkillName[14] = "Tailory";
			 this.SkillName[15] = "Smithing";
			 this.SkillName[16] = "Tanning";
			 this.SkillName[17] = "Jewelry";
			 this.SkillName[18] = "Fletching";
			 this.SkillName[19] = "Cooking";
			 this.SkillName[20] = "Herblore";
			 this.SkillName[21] = "Honour";
			 this.SkillName[22] = "Construction";
			 this.SkillName[23] = "Agility";
			 this.SkillName[24] = "Exploration";
			 this.SkillName[25] = "Pet Caring";
			 this.SkillName[26] = "Lifestock";
			 this.SkillName[27] = "Knowledge";
			 this.SkillName[28] = "Technology";
			 this.SkillName[29] = "Manufacturing";
			 this.SkillName[30] = "Chemistry";
			 this.SkillName[31] = "Specility";
			 this.SkillName[32] = "Mutating";
			 this.SkillName[33] = "Fisioning";
			 this.SkillName[34] = "Fusioning";
			
			//draws the head picture
			drawModalRectWithCustomSizedTexture(this.x, this.y, 0, 0, this.xsize, this.ysize, 235, 220);
		 
			//draws a lock on the last ItemSlot
			ResourceLocation location2 = new ResourceLocation("mark13695", "textures/gui/ItemLock.png");
			 this.mc.getTextureManager().bindTexture(location2);
			 drawModalRectWithCustomSizedTexture(this.x + 194, this.y + 97, 0, 0, 16, 16, 16, 16);
		
			 drawEntityOnScreen(this.x + 51, this.y + 75, 30, (float)(this.x + 51) - this.oldMouseX, (float)(this.y + 75 - 50) - this.oldMouseY, this.mc.thePlayer);
			 
			 if(this.invP.getStackInSlot(39) == null){
			 ResourceLocation locHead = new ResourceLocation("mark13695", "textures/gui/empty_armor_slot_helmet.png");
			 this.mc.getTextureManager().bindTexture(locHead);
			 drawModalRectWithCustomSizedTexture(this.x + 5, this.y + 7, 0, 0, 16, 16, 16, 16);
			 }
			 if(this.invP.getStackInSlot(38) == null){
			 ResourceLocation locBody = new ResourceLocation("mark13695", "textures/gui/empty_armor_slot_chestplate.png");
			 this.mc.getTextureManager().bindTexture(locBody);
			 drawModalRectWithCustomSizedTexture(this.x + 5, this.y + 25, 0, 0, 16, 16, 16, 16);
			 }
			 if(this.invP.getStackInSlot(37) == null){
			 ResourceLocation locLegs = new ResourceLocation("mark13695", "textures/gui/empty_armor_slot_leggings.png");
			 this.mc.getTextureManager().bindTexture(locLegs);
			 drawModalRectWithCustomSizedTexture(this.x + 5, this.y + 43, 0, 0, 16, 16, 16, 16);
			 }
			 if(this.invP.getStackInSlot(36) == null){
			 ResourceLocation locBoots = new ResourceLocation("mark13695", "textures/gui/empty_armor_slot_boots.png");
			 this.mc.getTextureManager().bindTexture(locBoots);
			 drawModalRectWithCustomSizedTexture(this.x + 5, this.y + 61, 0, 0, 16, 16, 16, 16);
			 }
			 if(this.invP.getStackInSlot(40) == null){
				 ResourceLocation locOffhand = new ResourceLocation("mark13695", "textures/gui/empty_armor_slot_offhand.png");
				 this.mc.getTextureManager().bindTexture(locOffhand);
				 drawModalRectWithCustomSizedTexture(this.x + 77, this.y + 61, 0, 0, 16, 16, 16, 16);
				 
			 }
			 
			 
				 if(this.hasItemVariants == 1){
					if(this.ItemVariant == 0){
						
						ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon0.png");
						this.mc.getTextureManager().bindTexture(IngrBar);
					}
					else if (this.ItemVariant == (this.ItemVarZise - 1)){
						ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon1.png");
						this.mc.getTextureManager().bindTexture(IngrBar);
					}
					else{
						ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon.png");
						this.mc.getTextureManager().bindTexture(IngrBar);
					}
					drawModalRectWithCustomSizedTexture(this.x + 117, this.y + 79, 0, 0, 18, 11, 18, 11);
				 }
				 if(this.hasItemVariants == 2 ||this.hasItemVariants == 4 || this.hasItemVariants == 6  || this.hasItemVariants == 8 ){
						if(this.ItemVariant1 == 0){
							ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon0.png");
							this.mc.getTextureManager().bindTexture(IngrBar);
						}
						else if (this.ItemVariant1 == (this.ItemVarZise1 - 1)){
							ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon1.png");
							this.mc.getTextureManager().bindTexture(IngrBar);
						}
						else{
							ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon.png");
							this.mc.getTextureManager().bindTexture(IngrBar);
						}
						drawModalRectWithCustomSizedTexture(this.x + 117, this.y + 103, 0, 0, 18, 11, 18, 11);
					 }
				 if(this.hasItemVariants == 3 ||this.hasItemVariants == 4 || this.hasItemVariants == 7  || this.hasItemVariants == 8 ){
						if(this.ItemVariant2 == 0){
							ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon0.png");
							this.mc.getTextureManager().bindTexture(IngrBar);
						}
						else if (this.ItemVariant2 == (this.ItemVarZise2 - 1)){
							ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon1.png");
							this.mc.getTextureManager().bindTexture(IngrBar);
						}
						else{
							ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon.png");
							this.mc.getTextureManager().bindTexture(IngrBar);
						}
						drawModalRectWithCustomSizedTexture(this.x + 117, this.y + 114, 0, 0, 18, 11, 18, 11);
					 }
				 if(this.hasItemVariants == 5 ||this.hasItemVariants == 6 || this.hasItemVariants == 7  || this.hasItemVariants == 8 ){
						if(this.ItemVariant3 == 0){
							ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon0.png");
							this.mc.getTextureManager().bindTexture(IngrBar);
						}
						else if (this.ItemVariant3 == (this.ItemVarZise3 - 1)){
							ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon1.png");
							this.mc.getTextureManager().bindTexture(IngrBar);
						}
						else{
							ResourceLocation IngrBar = new ResourceLocation("mark13695", "textures/gui/IngredientsIcon.png");
							this.mc.getTextureManager().bindTexture(IngrBar);
						}
						
						drawModalRectWithCustomSizedTexture(this.x + 117, this.y + 125, 0, 0, 18, 11, 18, 11);
					 
			 }
			 
			
			
			 
				 if(this.SlotItem != null){
					 if(((MarkContainerInv)this.inventorySlots).getCraftStackValue() > this.MaxCraft()){
						 if(this.MaxCraft() == 0){
						 this.SlotItem = null;
						 }
						 ((MarkContainerInv)this.inventorySlots).setCraftStackValue(this.MaxCraft());
						 this.MaxCr2();
						 
					 }
				 

					 drawString (fontRendererObj , ""+ this.getCorStackSize(this.SlotItem.getItem()) + "x " + this.ItemNames(this.SlotItem, true) , this.x + 6, this.y + 80 , 0x00ffffff); //TODO
					 
					 int Colour = 0x00ff0000;
					 if(this.getRecipe(SlotItem.getItem()) != null){
					 for (int i = 0; i < this.getRecipe(SlotItem.getItem()).size(); i++){
						 Colour = 0x00ff0000;
						 for(int j = 0; j < 35; j++){
							 if(((MarkContainerInv)this.inventorySlots).getInventory2()[j] != null){
							 if(this.getRecipe(SlotItem.getItem()).get(i).getItem() == ((MarkContainerInv)this.inventorySlots).getInventory2()[j].getItem()){
								 if(this.getRecipe(SlotItem.getItem()).get(i).stackSize <= ((MarkContainerInv)this.inventorySlots).getInventory2()[j].stackSize){
									 Item it = this.getRecipe(SlotItem.getItem()).get(i).getItem();
									 if(this.MoreMeta(it)){
										if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].getMetadata() == this.getRecipe(SlotItem.getItem()).get(i).getMetadata()){
											Colour = 0x00ffffff; 
										}	
									 }else{Colour = 0x00ffffff;}
								 }
							 }
						 }
						 }
						
					 drawString (fontRendererObj , "" + this.getRecipe(SlotItem.getItem()).get(i).stackSize + "x " + this.ItemNames(this.getRecipe(SlotItem.getItem()).get(i), false) , this.x + 6, this.y + 104 + (i * 11) , Colour);
					 }
				 }	 
				 }
				 else{
					 drawString (fontRendererObj , "What would you like" , this.x + 6, this.y + 80 , 0x00ffffff);
					 drawString (fontRendererObj , "to craft?" , this.x + 6, this.y + 90 , 0x00ffffff);
				 }
				 
				
			 if(((MarkContainerInv)this.inventorySlots).getCraftStackValue() > 0){
				 int posfix1 = ((MarkContainerInv)this.inventorySlots).getCraftStackValue() < 10 ? 6 :( ((MarkContainerInv)this.inventorySlots).getCraftStackValue() > 99 ? 0 : 3);
				 drawString (fontRendererObj , "" + ((MarkContainerInv)this.inventorySlots).getCraftStackValue() , ((this.x + 177) + posfix1), this.y + 16 , 0x0000ff00);
				 }
			 
	}
	private void MaxCr2(){
		ItemStack[] stack1 = new ItemStack[3];
		 Item TEMP1 = null;
		 int TEMP2 = 0;
		 int TEMP3 = 0;
		 if(this.SlotItem != null){
		 for (int i = 0; i < 3; i++){
			 if(i < this.getRecipe(this.SlotItem.getItem()).size() && ((MarkContainerInv)this.inventorySlots).getCraftStackValue() >= 0){
			 TEMP1 =  this.getRecipe(this.SlotItem.getItem()).get(i).getItem();
			 TEMP2 = this.getRecipe(this.SlotItem.getItem()).get(i).stackSize;
			 TEMP3 = this.getRecipe(this.SlotItem.getItem()).get(i).getMetadata();
			 }
			 else{
				 TEMP1 = null;
				 TEMP2 = 0;
				 TEMP3 = 0;
			 }
			 if(TEMP1 != null || TEMP2 > 0){
			 stack1[i] = new ItemStack(TEMP1, (TEMP2 * (((MarkContainerInv)this.inventorySlots).getCraftStackValue())), TEMP3);
			 }
			 else{
				 stack1[i] = null;
			 }
			 
		 }
		 }
		 if (this.invP.player != null && ((MarkContainerInv)this.inventorySlots).getCraftStackValue() != 0 && this.SlotItem != null){
			 
			 MainRegistry.network.sendToServer(new InventoryPacketS(this.SlotItem, ((MarkContainerInv)this.inventorySlots).getCraftStackValue(),this.invP.player, stack1));
		 }
	 }
	
	
	
	 protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException
	    {
		 
		 if(mouseX >= this.x + 139 && mouseX <= this.x + 228 && mouseY >= this.y + 42 && mouseY <= this.y + 113){		
			 if(this.getItemInSlot(mouseX, mouseY) != null){
			if(this.Showcase.getStackInSlot(18) == null){
			 this.SlotItem = this.getItemInSlot(mouseX, mouseY);
			 this.setCorrectList(this.SlotItem);
			}
			else{
				TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
				this.mc.thePlayer.addChatComponentMessage(component);
			}
			 }
			 else{
				 
				 this.SlotItem = null; 
			 }
			 
		 }
		 
		 if(this.hasItemVariants == 1){
			 if(mouseX >= this.x + 117 && mouseX <= this.x + 125 && mouseY >= this.y + 79 && mouseY <= this.y + 89 && this.ItemVariant > 0){	
				 if(this.Showcase.getStackInSlot(18) == null){
				 if(this.ItemVariant > 0)this.ItemVariant--;
				 }
				 else{
					 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
						this.mc.thePlayer.addChatComponentMessage(component);
				 }
			 }
			 if(mouseX >= this.x + 126 && mouseX <= this.x + 134 && mouseY >= this.y + 79 && mouseY <= this.y + 89 && this.ItemVariant < (this.ItemVarZise - 1)){	
				 if(this.Showcase.getStackInSlot(18) == null){
				 if(this.ItemVariant < (this.ItemVarZise - 1))this.ItemVariant++;
				 }
				 else{
					 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
						this.mc.thePlayer.addChatComponentMessage(component);
				 }
			 }
			 }
			 if(this.hasItemVariants == 2 ||this.hasItemVariants == 4 || this.hasItemVariants == 6  || this.hasItemVariants == 8 ){
				 if(mouseX >= this.x + 117 && mouseX <= this.x + 125 && mouseY >= this.y + 103 && mouseY <= this.y + 113 && this.ItemVariant1 > 0){	
					 if(this.Showcase.getStackInSlot(18) == null){
					 if(this.ItemVariant1 > 0)this.ItemVariant1--;
					 }
					 else{
						 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
							this.mc.thePlayer.addChatComponentMessage(component); 
					 }
				 }
				 if(mouseX >= this.x + 126 && mouseX <= this.x + 134 && mouseY >= this.y + 103 && mouseY <= this.y + 113 && this.ItemVariant1 < (this.ItemVarZise1 - 1)){
					 if(this.Showcase.getStackInSlot(18) == null){
					 if(this.ItemVariant1 < (this.ItemVarZise1 - 1))this.ItemVariant1++;
					 }
					 else{
						 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
							this.mc.thePlayer.addChatComponentMessage(component);
					 }
				 }
				 
			 }
			 if(this.hasItemVariants == 3 ||this.hasItemVariants == 4 || this.hasItemVariants == 7  || this.hasItemVariants == 8 ){
				 if(mouseX >= this.x + 117 && mouseX <= this.x + 125 && mouseY >= this.y + 114 && mouseY <= this.y + 124 && this.ItemVariant2 > 0){		
					 if(this.Showcase.getStackInSlot(18) == null){
					 if(this.ItemVariant2 > 0)this.ItemVariant2--;
					 }
					 else{
						 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
							this.mc.thePlayer.addChatComponentMessage(component);
					 }
				 }
				 if(mouseX >= this.x + 126 && mouseX <= this.x + 134 && mouseY >= this.y + 114 && mouseY <= this.y + 124 && this.ItemVariant2 < (this.ItemVarZise2 - 1)){
					 if(this.Showcase.getStackInSlot(18) == null){
					 if(this.ItemVariant2 < (this.ItemVarZise2 - 1))this.ItemVariant2++;
					 }
					 else{
						 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
							this.mc.thePlayer.addChatComponentMessage(component);
					 }
				 }
				 
			 }
			 if(this.hasItemVariants == 5 ||this.hasItemVariants == 6 || this.hasItemVariants == 7  || this.hasItemVariants == 8 ){
				 if(mouseX >= this.x + 117 && mouseX <= this.x + 125 && mouseY >= this.y + 125 && mouseY <= this.y + 135 && this.ItemVariant1 > 0){		
					 if(this.Showcase.getStackInSlot(18) == null){
					 if(this.ItemVariant3 > 0)this.ItemVariant3--;
					 }
					 else{
						 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
							this.mc.thePlayer.addChatComponentMessage(component);
					 }
				 }
				 if(mouseX >= this.x + 126 && mouseX <= this.x + 134 && mouseY >= this.y + 125 && mouseY <= this.y + 135 && this.ItemVariant1 < (this.ItemVarZise1 - 1)){
					 if(this.Showcase.getStackInSlot(18) == null){
					 if(this.ItemVariant3 < (this.ItemVarZise3 - 1))this.ItemVariant3++;
					 }
					 else{
						 TextComponentString component = new TextComponentString(TextFormatting.RED + "You cant do this right now, please remove your Crafting preset slot");
							this.mc.thePlayer.addChatComponentMessage(component);
					 }
				 }
				 
			 }
			 
			 ItemStack[] stack1 = new ItemStack[3];
			 Item TEMP1 = null;
			 int TEMP2 = 0;
			 int TEMP3 = 0;
			 if(this.SlotItem != null){
			 for (int i = 0; i < 3; i++){
				 if(i < this.getRecipe(this.SlotItem.getItem()).size() && ((MarkContainerInv)this.inventorySlots).getCraftStackValue() >= 0){
				 TEMP1 =  this.getRecipe(this.SlotItem.getItem()).get(i).getItem();
				 TEMP2 = this.getRecipe(this.SlotItem.getItem()).get(i).stackSize;
				 TEMP3 = this.getRecipe(this.SlotItem.getItem()).get(i).getMetadata();
				 }
				 else{
					 TEMP1 = null;
					 TEMP2 = 0;
					 TEMP3 = 0;
				 }
				 if(TEMP1 != null || TEMP2 > 0){
				 stack1[i] = new ItemStack(TEMP1, (TEMP2 * (((MarkContainerInv)this.inventorySlots).getCraftStackValue()+ 1)), TEMP3);
				 }
				 else{
					 stack1[i] = null;
				 }
				 
			 }
			 }
			 if(mouseX >= this.x + 4 && mouseX <= this.x + 17 && mouseY >= this.y + 137 && mouseY <= this.y + 148){	
				 if(this.SlotItem != null && this.MaxCraft() != 0){
					 if(this.Showcase.getStackInSlot(18) != null){
				 if(this.Showcase.getStackInSlot(18).getItem() != this.SlotItem.getItem()){
					
				 if(this.ContainItems(this.SlotItem.getItem(), 0)){
					 
					//  ---------------------------------------
					 this.Showcase.setInventorySlotContents(18 ,p(this.SlotItem.getItem(), 1)); // slot 25 crafting
					 ((MarkContainerInv)this.inventorySlots).setCraftStackValue(1);
					 
				
					}
					 
			 }
			 }
					 else{
						 if(this.ContainItems(this.SlotItem.getItem(), 0)){	
							 
						 this.Showcase.setInventorySlotContents(18 , p(this.SlotItem.getItem(), 1));// slot 25 crafting
						 ((MarkContainerInv)this.inventorySlots).setCraftStackValue(1);
				
							 }
					 
					 }
					 int CrValue = ((MarkContainerInv)this.inventorySlots).getCraftStackValue();
					 MainRegistry.network.sendToServer(new InventoryPacketS(this.SlotItem, CrValue ,this.mc.thePlayer , stack1));
					 
						
				 }
				 
			 }
			 if(mouseX >= this.x + 18 && mouseX <= this.x + 31 && mouseY >= this.y + 137 && mouseY <= this.y + 148){		
				 this.SlotItem = null;
				 ((MarkContainerInv)this.inventorySlots).setCraftStackValue(0);
				 int CrValue = ((MarkContainerInv)this.inventorySlots).getCraftStackValue();
				 MainRegistry.network.sendToServer(new InventoryPacketS(this.SlotItem, CrValue ,this.mc.thePlayer , stack1));
				
					
					 
			 }
			 if(mouseX >= this.x + 174 && mouseX <= this.x + 184 && mouseY >= this.y + 3 && mouseY <= this.y + 10){		
				 if(this.Showcase.getStackInSlot(18) != null && this.MaxCraft() != 0){
					 
					 if(((MarkContainerInv)this.inventorySlots).getCraftStackValue() < 64) ((MarkContainerInv)this.inventorySlots).addRemCraftStackValue(1);
					 int CrValue = ((MarkContainerInv)this.inventorySlots).getCraftStackValue();
					 MainRegistry.network.sendToServer(new InventoryPacketS(this.SlotItem, CrValue ,this.mc.thePlayer , stack1));
					 
					 
				 } 
				 
			 }
			 if(mouseX >= this.x + 185 && mouseX <= this.x + 195 && mouseY >= this.y + 3 && mouseY <= this.y + 10){		
				 if(this.Showcase.getStackInSlot(18) != null && this.MaxCraft() != 0){
					 
						 ((MarkContainerInv)this.inventorySlots).addRemCraftStackValue(10);
					 if(((MarkContainerInv)this.inventorySlots).getCraftStackValue() > 64) ((MarkContainerInv)this.inventorySlots).setCraftStackValue(64);
					 int CrValue = ((MarkContainerInv)this.inventorySlots).getCraftStackValue();
					 MainRegistry.network.sendToServer(new InventoryPacketS(this.SlotItem, CrValue ,this.mc.thePlayer , stack1));
					 
					 
				 } 
				 
			 }
			 if(mouseX >= this.x + 174 && mouseX <= this.x + 184 && mouseY >= this.y + 23 && mouseY <= this.y + 30){		
				 if(this.Showcase.getStackInSlot(18) != null && this.MaxCraft() != 0){
					 
					 if(((MarkContainerInv)this.inventorySlots).getCraftStackValue() > 1) ((MarkContainerInv)this.inventorySlots).addRemCraftStackValue(-1);
					 int CrValue = ((MarkContainerInv)this.inventorySlots).getCraftStackValue();
					 MainRegistry.network.sendToServer(new InventoryPacketS(this.SlotItem, CrValue ,this.mc.thePlayer , stack1));
					
					 
				 } 
				 
			 }
			 
			 if(mouseX >= this.x + 185 && mouseX <= this.x + 195 && mouseY >= this.y + 23 && mouseY <= this.y + 30){		
				 if(this.Showcase.getStackInSlot(18) != null && this.MaxCraft() != 0){
					
						 ((MarkContainerInv)this.inventorySlots).addRemCraftStackValue(-10);
					 if(((MarkContainerInv)this.inventorySlots).getCraftStackValue() < 1) ((MarkContainerInv)this.inventorySlots).setCraftStackValue(1);
					 int CrValue = ((MarkContainerInv)this.inventorySlots).getCraftStackValue();
					  MainRegistry.network.sendToServer(new InventoryPacketS(this.SlotItem, CrValue ,this.mc.thePlayer , stack1));
					 
				 } 
				 
			 }
			 
			 if(mouseX >= this.x + 197 && mouseX <= this.x + 210 && mouseY >= this.y + 11 && mouseY <= this.y + 22){
				if(this.Showcase.getStackInSlot(18) != null){
					this.setCorrectList(this.Showcase.getStackInSlot(18));
					if(this.ContainItems(this.Showcase.getStackInSlot(18).getItem(), 0) && ((MarkContainerInv)this.inventorySlots).getCraftStackValue() > 0){
						int CrValue = ((MarkContainerInv)this.inventorySlots).getCraftStackValue();
						((MarkContainerInv)this.inventorySlots).Craft();
						MainRegistry.network.sendToServer(new InventoryPacketS2(this.mc.thePlayer));
					}
				}
			 }
				 
				 
			 
			 if (this.mc.thePlayer != null && ((MarkContainerInv)this.inventorySlots).getCraftStackValue() != 0 && this.SlotItem != null){
				 
				 
				 int CrValue = ((MarkContainerInv)this.inventorySlots).getCraftStackValue();
				 
				 	
			 } 
				 super.mouseClicked(mouseX, mouseY, mouseButton);	    
		 
}    
	 
	 
 public Boolean ContainItems(Item item, int l){
		 
		 if(this.getRecipe(item) != null){
		 boolean[] b = new boolean[this.getRecipe(item).size()];
		 for(int i = 0; i < this.getRecipe(item).size(); i++){
			 b[i] = false;
		 }
		
		 for (int j = 0; j < ((MarkContainerInv)this.inventorySlots).getInventory2().length; j++){
			 if(l == 0){
				
				
				 
		 for(int i = 0; i < this.getRecipe(item).size(); i++){
			if(!b[i]){
				if(((MarkContainerInv)this.inventorySlots).getInventory2()[j] != null){
				if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].getItem() == this.getRecipe(item).get(i).getItem()){
					
					
					if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].stackSize >= this.getRecipe(item).get(i).stackSize){
						 Item it = this.getRecipe(item).get(i).getItem();
						 if(this.MoreMeta(it)){
						if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].getMetadata() == this.getRecipe(item).get(i).getMetadata()){
								b[i] = true; 
								
							}}
							else{
								b[i] = true;
								
							
					}
				}
				}
				
			}
		 }
		 }
		 
		 }
			 
			 else if(l == 1){
				 int i = 0;
				 
						
						if(((MarkContainerInv)this.inventorySlots).getInventory2()[j] != null){
							
							if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].getItem() == this.getRecipe(item).get(i).getItem()){
							
							if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].stackSize >= this.getRecipe(item).get(i).stackSize){
								Item it = this.getRecipe(item).get(i).getItem();
								 if(this.MoreMeta(it)){
								
									if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].getMetadata() == this.getRecipe(item).get(i).getMetadata()){
										
										return true;
									}}
									else{
										
										return true;
									
							}
						}
						}
						
					}
				 }
				 
			 else if(l == 2){
				 int i = 1;
				 
						
						if(((MarkContainerInv)this.inventorySlots).getInventory2()[j] != null){
							if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].getItem() == this.getRecipe(item).get(i).getItem()){
							
							
							if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].stackSize >= this.getRecipe(item).get(i).stackSize){
								Item it = this.getRecipe(item).get(i).getItem();
								if(this.MoreMeta(it)){
									if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].getMetadata() == this.getRecipe(item).get(i).getMetadata()){
										return true;
									}}
									else{
										return true;
									
							}
						}
						}
						
					}
				 
				 }
			 else if(l == 3){
				 int i = 2;
				
						
						if(((MarkContainerInv)this.inventorySlots).getInventory2()[j] != null){
							if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].getItem() == this.getRecipe(item).get(i).getItem()){
							
							
							if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].stackSize >= this.getRecipe(item).get(i).stackSize){
								Item it = this.getRecipe(item).get(i).getItem();
								if(this.MoreMeta(it)){
									if(((MarkContainerInv)this.inventorySlots).getInventory2()[j].getMetadata() == this.getRecipe(item).get(i).getMetadata()){
										return true;
									}}
									else{
										return true;
									
							}
						}
						}
						
					}
				 }
				 
		 }
		 if(l == 0){
		 for(int i = 0; i < b.length; i++){
			 if (b[i] == false)return false; 
		 }
		 return true;
		 }
		 }
		 return false;
	 }
	 
	 public void setCorrectList(ItemStack slotItem){
		 boolean correct1 = false;
		 boolean correct2 = false;
		 boolean correct3 = false;
		 this.ItemVariant = 0;
		 this.ItemVariant1 = 0;
		 this.ItemVariant2 = 0;
		 this.ItemVariant3 = 0;
		 if(slotItem != null){
		 this.getRecipe(slotItem.getItem());
		 if(this.hasItemVariants == 1){
			 
			 for(int i = 0; i < this.ItemVarZise; i++){
				 this.ItemVariant = i;
			 if(this.ContainItems(slotItem.getItem(), 0)){
				
				 correct1 = true;
				 break;
			 }
			 }
			 if (!correct1){
				 this.ItemVariant = 0;
			 }
			 
			 correct2 = true;
			 correct3 = true;
			 this.ItemVariant1 = 0;
			 this.ItemVariant2 = 0;
			 this.ItemVariant3 = 0;	
		 }
		 if(this.hasItemVariants == 2 || this.hasItemVariants == 4 || this.hasItemVariants == 6 || this.hasItemVariants == 8){
			
			 for(int i = 0; i < this.ItemVarZise1; i++){
				 this.ItemVariant1 = i;
				 if(this.ContainItems(slotItem.getItem(), 1)){
					
					 correct1 = true;
					 break;
				 } 
				 
			 }
			 if (!correct1){
				 this.ItemVariant1 = 0;
			 }
			 if(this.hasItemVariants == 2 || this.hasItemVariants == 6){		 
				 this.ItemVariant2 = 0; 
				 correct2 = true;
			 }
			 if(this.hasItemVariants == 2 || this.hasItemVariants == 4){
				 this.ItemVariant3 = 0;	
				 correct3 = true;
			 }
			 this.ItemVariant = 0;
			 
		 }
		 if(this.hasItemVariants == 3 || this.hasItemVariants == 4 || this.hasItemVariants == 7 || this.hasItemVariants == 8){

			 for(int i = 0; i < this.ItemVarZise2; i++){
				 this.ItemVariant2 = i;
				 if(this.ContainItems(slotItem.getItem(), 2)){
					 
					 correct2 = true;
					 break;
				 } 
				 
			 }
			 if (!correct2){
				 this.ItemVariant2 = 0;
			 }
			 if(this.hasItemVariants == 3 || this.hasItemVariants == 7){		 
				 this.ItemVariant1 = 0; 
				 correct1 = true;
			 }
			 if(this.hasItemVariants == 3 || this.hasItemVariants == 4){
				 this.ItemVariant3 = 0;
				 correct3 = true;
			 }
			 this.ItemVariant = 0;
			 
		 }
		 if(this.hasItemVariants == 5 || this.hasItemVariants == 6 || this.hasItemVariants == 7 || this.hasItemVariants == 8){
			 for(int i = 0; i < this.ItemVarZise3; i++){
				 this.ItemVariant3 = i;
				 if(this.ContainItems(slotItem.getItem(), 3)){
					 
					 correct3 = true;
					 break;
				 } 
			 }
			 if (!correct3){
				 this.ItemVariant3 = 0;
			 }
			 if(this.hasItemVariants == 5 || this.hasItemVariants == 7){		 
				 this.ItemVariant1 = 0; 
				 correct1 = true;
			 }
			 if(this.hasItemVariants == 5 || this.hasItemVariants == 6){
				 this.ItemVariant2 = 0;	
				 correct2 = true;
			 }
			 this.ItemVariant = 0;
		 }
		 
		 
		 }
		 else{
			 correct1 = true;
			 correct2 = true;
			 correct3 = true;
			 this.ItemVariant = 0;
			 this.ItemVariant1 = 0;
			 this.ItemVariant2 = 0;
			 this.ItemVariant3 = 0;
		 }
		 
		 
		 
		 
	 }
	 
	 public String ItemNames(ItemStack Itemp, Boolean MainItem){
			Map<Item, String> Name = new HashMap<Item, String>();
			
			if(Itemp.getItem() == Item.getItemFromBlock(Blocks.PLANKS) && Itemp.getItem() == this.SlotItem.getItem()){
					String[] V = { "Oak", "Spruce", "Birch", "Jungle"};
					return V[this.ItemVariant] + " Planks";
			}
			else if(Itemp.getItem() == Item.getItemFromBlock(Blocks.WOOL) && Itemp.getItem() == this.SlotItem.getItem()){
				if(MainItem){
				String[] V = {"","Black ","Red ","Green ","Brown ","Blue ","Purple ","Cyan ","Light Gray ","Gray ","Pink ","Lime ","Yellow ","Light Blue ","Magenta ","Orange ","",};
				return V[this.ItemVariant] + "Wool";
				}
			}
			
			Name.put(Item.getItemFromBlock(MarkBlocks.WorkBench_I), "Constr. Bench I");
			
			return Name.get(Itemp.getItem()) != null ? Name.get(Itemp.getItem()) : Itemp.getDisplayName();
	 }
	 
	 private ItemStack getItemInSlot(int mouseX, int mouseY){
		 
		 if(mouseX >= this.x + 139 && mouseX <= this.x + 228 && mouseY >= this.y + 42 && mouseY <= this.y + 113){	
			 
			 for(int y = 0; y < 4; y++){
				 for(int x = 0; x < 5; x++){
					 if(y == 3){
						 if(x != 0 || x != 4){
							 if(mouseX >= this.x + 139 + (18 * x) && mouseX <= this.x + 156 + (18 * x) && mouseY >= this.y + 42 + (18 * y) && mouseY <= this.y + 59 + (18 * y)){
								  return this.Showcase.getStackInSlot((y * 5) + (x - 1));
							 } 
						 }
					 }
					 else{
						 if(mouseX >= this.x + 139 + (18 * x) && mouseX <= this.x + 156 + (18 * x) && mouseY >= this.y + 42 + (18 * y) && mouseY <= this.y + 59 + (18 * y)){
							  return this.Showcase.getStackInSlot((y * 5) + x);
						 } 
					 }
				 }
			 }
			 
			 
		 }
		 return null;
	 }
	 
public List <ItemStack> getRecipe(Item item){
	this.hasItemVariants = 0;
	this.ItemVarZise = 0;
	this.ItemVarZise1 = 0;
	this.ItemVarZise2 = 0;
	this.ItemVarZise3 = 0;
		 
		 List<ItemStack> list = new ArrayList<>();
		 Map<Item, List<ItemStack>> Recipes = new HashMap<Item, List<ItemStack>>();
		 if(item == Items.STICK){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 2, this.ItemVariant));
		 }
		 else if(item == Item.getItemFromBlock(Blocks.PLANKS)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.LOG, 1, this.ItemVariant));
		 }
		 else if(item == Item.getItemFromBlock(Blocks.WOOL) ){
			 
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 17;
			 if(this.ItemVariant == 0){
			 return this.ItemToList(p(Items.STRING, 4));
			 }
			 else{
			 return this.ItemToList(p(Blocks.WOOL), p(Items.DYE, 1, this.ItemVariant - 1));
			 }
		 }

		 else if(item == Item.getItemFromBlock(Blocks.TORCH)){
				 this.hasItemVariants = 4;
				 this.ItemVarZise1 = 2;
				 this.ItemVarZise2 = 2;
				 ItemStack[] s = {p(Items.STICK),p(Items.BONE)};
				 return this.ItemToList(p(Items.COAL, 1, this.ItemVariant1), s[this.ItemVariant2]);
			 }
		 else if(item == Item.getItemFromBlock(MarkBlocks.BasicTable)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 4, this.ItemVariant));
		 }
		 else if(item == Item.getItemFromBlock(MarkBlocks.TanningBench_I)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 4, this.ItemVariant), p(Items.LEATHER, 2));
		 }
		 else if(item == Item.getItemFromBlock(MarkBlocks.JewelryTable_I)){
			 this.hasItemVariants = 4;
			 this.ItemVarZise1 = 4;
			 this.ItemVarZise2 = 4;
			 Item stackJ[] = {MarkItems.GemOpal, MarkItems.GemSapphire, MarkItems.GemOlivine, MarkItems.GemHyacinth};
			 return this.ItemToList(p(Blocks.PLANKS, 4, this.ItemVariant1), p(stackJ[this.ItemVariant2], 2));
		 }
		 else if(item == Item.getItemFromBlock(MarkBlocks.FletchingTable_I)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 5, this.ItemVariant), p(Items.STICK, 4));
		 }
		 else if(item == Item.getItemFromBlock(MarkBlocks.WorkBench_I)){
			 this.hasItemVariants = 1;
			 this.ItemVarZise = 4;
			 return this.ItemToList(p(Blocks.PLANKS, 6, this.ItemVariant), p(Items.STICK, 2));
		 }
		 

		 Recipes.put(item.getItemFromBlock(MarkBlocks.TailoryBench_I), this.ItemToList(p(Blocks.PLANKS, 4), p(Blocks.WOOL, 2)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.Anvil_I), this.ItemToList(p(Blocks.STONE, 7)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.Furnace_I), this.ItemToList(p(Blocks.COBBLESTONE, 9)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.GlassOven_I), this.ItemToList(p(Blocks.COBBLESTONE, 4),p(Blocks.DIRT, 5)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.Range_I), this.ItemToList(p(Blocks.COBBLESTONE, 8)));
		 Recipes.put(item.getItemFromBlock(MarkBlocks.Cauldron_I), this.ItemToList(p(Blocks.COBBLESTONE, 9)));
		 Recipes.put(Items.SUGAR, this.ItemToList(p(Items.REEDS, 1)));
		 Recipes.put(Items.FLINT_AND_STEEL, this.ItemToList(p(Items.FLINT, 1), p(Items.IRON_INGOT, 1)));
		 
		 

		 return Recipes.get(item);
}
	 /**
     * Draws an entity on the screen looking toward the cursor.
     */
    public static void drawEntityOnScreen(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent)
    {
        GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate((float)posX, (float)posY, 50.0F);
        GlStateManager.scale((float)(-scale), (float)scale, (float)scale);
        GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
        float f = ent.renderYawOffset;
        float f1 = ent.rotationYaw;
        float f2 = ent.rotationPitch;
        float f3 = ent.prevRotationYawHead;
        float f4 = ent.rotationYawHead;
        GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
        ent.renderYawOffset = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
        ent.rotationYaw = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
        ent.rotationPitch = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
        ent.rotationYawHead = ent.rotationYaw;
        ent.prevRotationYawHead = ent.rotationYaw;
        GlStateManager.translate(0.0F, 0.0F, 0.0F);
        RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
        rendermanager.setPlayerViewY(180.0F);
        rendermanager.setRenderShadow(false);
        rendermanager.doRenderEntity(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F, false);
        rendermanager.setRenderShadow(true);
        ent.renderYawOffset = f;
        ent.rotationYaw = f1;
        ent.rotationPitch = f2;
        ent.prevRotationYawHead = f3;
        ent.rotationYawHead = f4;
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    }
    
    public List <ItemStack> ItemToList(ItemStack... stack2){
		 
		 List <ItemStack> l = new ArrayList<>();
		 
		 for (int i = 0; i < stack2.length; i++){
			 
			 l.add(stack2[i]);
		 }
		 
		 return l;
		 
	 }
    public int getCorStackSize(Item item){
    	if(item == Item.getItemFromBlock(Blocks.PLANKS)){
    		return 4;
    	}
    	else if(item == Item.getItemFromBlock(Blocks.TORCH)){
    		return 4;
    	}
    	else if(item == Items.STICK){
    		return 2;
    	}
    	else{
    	return 1;
    	}
    }
    
    public int MaxCraft(){
		 
		 int MaxFurnace = 0;
		 int MaxInvSpace = 0;
		 int MaxIngr = 0;
		 
		 //get free inventory space
		 for (int i = 0; i < 35; i++){
			 if(this.SlotItem == null){ MaxInvSpace = 0; }
			 else if(this.invP.getStackInSlot(i) == null){
				 MaxInvSpace += (64 / this.getCorStackSize(this.SlotItem.getItem()));
			 }
			 else if(this.invP.getStackInSlot(i).getItem() == this.SlotItem.getItem()){
				 MaxInvSpace += ((64 - this.invP.getStackInSlot(i).stackSize) / this.getCorStackSize(this.SlotItem.getItem()));
			 } 
		 }
		 
		 //how much ingredients you have for how many items
		 if(this.SlotItem != null){
		 if(this.getRecipe(this.SlotItem.getItem()) != null){
			 int[] stk = new int[this.getRecipe(this.SlotItem.getItem()).size()];
			 for (int i = 0; i < this.getRecipe(this.SlotItem.getItem()).size(); i++){
				 stk[i] = 0;
				 for (int i2 = 0; i2 < 35; i2++){
					 if(this.invP.getStackInSlot(i2) != null){
					 if(this.getRecipe(this.SlotItem.getItem()).get(i).getItem() == this.invP.getStackInSlot(i2).getItem()){
						 if(this.MoreMeta(this.invP.getStackInSlot(i2).getItem())){
							 if(this.getRecipe(this.SlotItem.getItem()).get(i).getMetadata() == this.invP.getStackInSlot(i2).getMetadata()){
								 stk[i] += (this.invP.getStackInSlot(i2).stackSize / this.getRecipe(this.SlotItem.getItem()).get(i).stackSize); 
							 }
						 }
						 else{
						stk[i] += (this.invP.getStackInSlot(i2).stackSize / this.getRecipe(this.SlotItem.getItem()).get(i).stackSize);
					 }}
					 }
				 }
			 }
			 if(stk.length == 1){
				 MaxIngr = stk[0];
			 }
			 for (int i = 0; i < stk.length; i++){
				 int temp = i == 0 ? 0 : MaxIngr;
				 MaxIngr = i == 0 ? stk[0] : (stk[i] < MaxIngr ? stk[i] : temp);
			 }
		 }
		 
		 if(MaxInvSpace <= MaxIngr){
			 return MaxInvSpace;
		 }
		 else{
			 return MaxIngr;
		 }
		 }
		 return 1;
	 }
	 
	 public ItemStack p(Item item){ return new ItemStack(item);} 
	 public ItemStack p(Item item, int value){ return new ItemStack(item, value); }
	 public ItemStack p(Item item, int value, int variant){ return new ItemStack(item, value, variant); }
	 public ItemStack p(Block block){ return new ItemStack(block);} 
	 public ItemStack p(Block block, int value){ return new ItemStack(block, value); }
	 public ItemStack p(Block block, int value, int variant){ return new ItemStack(block, value, variant); }
	
	 
	 public boolean MoreMeta(Item it){
		 
		 boolean b = it == Item.getItemFromBlock(Blocks.PLANKS) || it == Item.getItemFromBlock(Blocks.LOG) || it == Items.DYE || it == Item.getItemFromBlock(Blocks.WOOL);
		 return b;
	 }
	 
}
