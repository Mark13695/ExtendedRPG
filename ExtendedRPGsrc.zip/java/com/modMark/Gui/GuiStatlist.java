package com.modMark.Gui;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.modMark.Skill.MarkData;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import scala.swing.Alignment;
import scala.tools.nsc.transform.patmat.PatternExpander.Aligned;

@SideOnly(Side.CLIENT)
public class GuiStatlist extends GuiScreen {
	
	public GuiStatlist(){}
	
	
	public static int[] XP = new int[35];
	
	public int MainLock = 1;
	
	
	
	
	private String[] SkillName = new String[35]; //head
	 //head
	private double[] Level1 = new double[35];
	private int[] Level = new int[35]; //head
	private double[] NextLevel0 = new double[35];
	private double[] NextLevel1 = new double[35];
	private int[] NextLevel = new int[35]; //head
	private int[] XpNeed = new int[35]; //head
	private double[] Degrees1 = new double[35];
	private double[] Degrees = new double[35]; //head
	
	private int Total;
	private double Combat1;
	private int Combat;
	private long TotXp;
	
	
	 @Override
     public void drawScreen(int mouseX, int mouseY, float pticks) {
		 this.drawDefaultBackground();
		 ResourceLocation location = new ResourceLocation("mark13695", "textures/gui/skillList.png");
		 this.mc.getTextureManager().bindTexture(location);
		 
		 
		 
		 this.SkillName[0] = "Constitution";
		 this.SkillName[1] = "Melee";
		 this.SkillName[2] = "Ranged";
		 this.SkillName[3] = "Magic";
		 this.SkillName[4] = "Defence";
		 this.SkillName[5] = "Endurance";
		 this.SkillName[6] = "Slayer";
		 this.SkillName[7] = "Farming";
		 this.SkillName[8] = "Mining";
		 this.SkillName[9] = "Hunter";
		 this.SkillName[10] = "Excavation";
		 this.SkillName[11] = "Woodcutting";
		 this.SkillName[12] = "Fishing";
		 this.SkillName[13] = "Archeology";
		 this.SkillName[14] = "Tailory";
		 this.SkillName[15] = "Smithing";
		 this.SkillName[16] = "Tanning";
		 this.SkillName[17] = "Jewelry";
		 this.SkillName[18] = "Fletching";
		 this.SkillName[19] = "Cooking";
		 this.SkillName[20] = "Herblore";
		 this.SkillName[21] = "Honour";
		 this.SkillName[22] = "Construction";
		 this.SkillName[23] = "Agility";
		 this.SkillName[24] = "Exploration";
		 this.SkillName[25] = "Pet Caring";
		 this.SkillName[26] = "Lifestock";
		 this.SkillName[27] = "Knowledge";
		 this.SkillName[28] = "Technology";
		 this.SkillName[29] = "Manufacturing";
		 this.SkillName[30] = "Chemistry";
		 this.SkillName[31] = "Specility";
		 this.SkillName[32] = "Mutating";
		 this.SkillName[33] = "Fisioning";
		 this.SkillName[34] = "Fusioning";
		
		 for (int i = 0; i < 35;i++) {
			 
			 if (this.XP[i] == 2000000000){this.Level1[i] = 255;}
				else if (this.XP[i] >= 1720000000 && this.XP[i] <= 1999999999){this.Level1[i] = 254;}
				else if (this.XP[i] >= 1480000000 && this.XP[i] <= 1719999999){this.Level1[i] = 253;}
				else if (this.XP[i] >= 1280000000 && this.XP[i] <= 1479999999){this.Level1[i] = 252;}
				else if (this.XP[i] >= 1120000000 && this.XP[i] <= 1279999999){this.Level1[i] = 251;}
				else if (this.XP[i] >= 1000000000 && this.XP[i] <= 1119999999){this.Level1[i] = 250;}
				else if (this.XP[i] >= 936171373 && this.XP[i] <= 999999999){this.Level1[i] = 249;}
				else if (this.XP[i] >= 50242686 && this.XP[i] <= 936171372){this.Level1[i] = ((Math.log(XP[i] + 256)/Math.log(256))-1)*91+1;}
				else if (this.XP[i] >= 34799106 && this.XP[i] <= 50242685){this.Level1[i] = 200;}
				else if (this.XP[i] >= 149782 && this.XP[i] <= 34799105){this.Level1[i] = ((Math.log10(XP[i] + 687)/Math.log10(687))-1)*120+1;}
				else if (this.XP[i] >= 99539 && this.XP[i] <= 149781){this.Level1[i] = 99;}
				else if (this.XP[i] >= 0 && this.XP[i] <= 99538){this.Level1[i] = ((Math.log10(this.XP[i] + 695)/Math.log10(695))-1)*129+1;}
				else {this.Level1[i] = 1;}

			 this.Level[i] = (int) Math.floor(this.Level1[i]); /** floors level down*/
			 this.NextLevel0[i] = (int) (this.Level[i] + 1);  /** says Level + 1*/
			 this.NextLevel[i] = (int) Math.ceil(this.NextLevel1[i]);
			 this.XpNeed[i] = (int) (this.NextLevel[i] - XP[i]);
				
				if (this.Level[i] == 99 || this.Level[i] == 200 || this.Level[i] == 255){ this.Degrees[i] = 0; }
				else {this.Degrees[i] = ((XP[i] - Math.ceil(this.Degrees1[i])) / (this.NextLevel[i] - Math.ceil(this.Degrees1[i]))) * 39;}
				
				
				if (this.Level[i] < 99) {this.NextLevel1[i] = (Math.pow(695, (this.NextLevel0[i] - 1)/129 +1) - 695);}
				else if (this.Level[i] == 99) {this.NextLevel1[i] = 701754;}
				else if (this.Level[i] >= 100 && this.Level[i] < 200) {this.NextLevel1[i] = (Math.pow(687, (this.NextLevel0[i] - 1)/120 +1) - 687);}
				else if (this.Level[i] == 200) {this.NextLevel1[i] = 100005814;}
				else if (this.Level[i] >= 201 && this.Level[i] < 249) {this.NextLevel1[i] = (Math.pow(256, (this.NextLevel0[i] - 1)/91 +1) - 256);}
				else if (this.Level[i] == 249) {this.NextLevel1[i] = 1000000000;}
				else if (this.Level[i] == 250) {this.NextLevel1[i] = 1120000000;}
				else if (this.Level[i] == 251) {this.NextLevel1[i] = 1280000000;}
				else if (this.Level[i] == 252) {this.NextLevel1[i] = 1480000000;}
				else if (this.Level[i] == 253) {this.NextLevel1[i] = 1720000000;}
				else if (this.Level[i] == 254) {this.NextLevel1[i] = 2000000000;}
				else {this.NextLevel1[i] = 0;}
				
				
				
				if (this.Level[i] <= 98) {
					this.Degrees1[i] = (Math.pow(695, (this.NextLevel0[i] - 2)/129 +1) - 695) ;
				}
				
				else if (this.Level[i] >= 100 && Level[i] <= 199) {
					this.Degrees1[i] = (Math.pow(687, (NextLevel0[i] - 2)/230 +1) - 687);
				}
				else if (this.Level[i] >= 201 && this.Level[i] <= 249) {
					this.Degrees1[i] = (Math.pow(256, (this.NextLevel0[i] - 2)/91 +1) - 256);
				}
				else if (this.Level[i] == 250) {
					this.Degrees1[i] = 1000000000;
				}
				else if (this.Level[i] == 251) {
					this.Degrees1[i] = 1120000000;
				}
				else if (this.Level[i] == 252) {
					this.Degrees1[i] = 1280000000;
				}
				else if (this.Level[i] == 253) {
					this.Degrees1[i] = 1480000000;
				}
				else if (Level[i] == 254) {
					this.Degrees1[i] = 1720000000;
				}
					
				else {
					this.Degrees1[i] = 0;
				}
			}
		 
		 double d1, d2, d3, d4, d5, d6, d7;

			int i1, i2, i3, i4;
				
			if(this.Level[1] == 255 && this.Level[2] == 255 && this.Level[3] != 255 || this.Level[1] == 255 && this.Level[2] != 255 && this.Level[3] == 255 || this.Level[1] != 255 && this.Level[2] == 255 && this.Level[3] == 255 ){
				
				i1 = 2;
			}
			else if(this.Level[1] == 255 && this.Level[2] == 255 && this.Level[3] == 255){
				
				i1 = 3;
			}
			else{
				
				i1 = 1;
			}
				 
				 
				 
			if(this.Level[1] >= this.Level[2] && this.Level[1] >= this.Level[3]){
				d1 = this.Level[1];
			}
			else if(this.Level[2] >= this.Level[3]){
				d1 = this.Level[2];
			}
			else
			{
				d1 = this.Level[3];
			}
			
			if(d1 >= this.Level[5]){
				d2 = d1;
				d3 = this.Level[5];
			}
			else
			{
				d2 = this.Level[5];
				d3 = d1;
			}
			
			d4 =  (Math.pow(d2, 3)/Math.pow(d2, 2) + (d3 / 10)) / 280.5D * 239;
			i2 = (int) Math.floor(d4);
			
			if (this.Level[0] >= this.Level[5]){
				
				d5 = this.Level[0];
				d6 = this.Level[5];
			}
			else
			{
				d5 = this.Level[5];
				d6 = this.Level[0];
			}
			
			d7 = (Math.pow(d5, 3)/Math.pow(d5, 2) + (d6 * (3/2))) / 637.5D * 138;
			i3 = (int) Math.floor(d7);
			
			this.Combat = i1 + i2 + i3;
			 
			 
			this.Total = 0;
			for (int i = 0; i < 35; i++){
				Total += this.Level[i];
			}
			
		 /** zorgen voor dat die gui texture word geladen */
		 
		 
		 	float PoX = mouseX;
		 	float PoY = mouseY;
		 	int xSize = 235;
			int ySize = 220;
			int w = this.width;
			int h = this.height;
			int x = ((w - xSize)  / 2);
			int y = ((h - ySize) / 2);
			int z = 1;
			
			drawModalRectWithCustomSizedTexture(x, y, 0, 0, xSize, ySize, 235, 220);
			
			/** laadbalkjes */
			
			ResourceLocation location2 = new ResourceLocation("mark13695", "textures/gui/SkillBarL.png");
			 this.mc.getTextureManager().bindTexture(location2);
			
			 if (this.Level[15] < 20 || this.Level[18] < 20 || this.Level[22] < 20 || this.Level[27] < 35) {
				 drawModalRectWithCustomSizedTexture(x + 181, y + 36, 0, 0, (int) 38 , 2,(int) 38 , 2);
			 }
			 if (this.Level[9] < 50 || this.Level[21] < 50 || this.Level[26] < 50 || this.Level[27] < 70) {
				 drawModalRectWithCustomSizedTexture(x + 181, y + 63, 0, 0, (int) 38 , 2,(int) 38 , 2);
			 }
			 if (this.Level[10] < 90 || this.Level[13] < 90 || this.Level[20] < 90 || this.Level[27] < 105) {
				 drawModalRectWithCustomSizedTexture(x + 181, y + 90, 0, 0, (int) 38 , 2,(int) 38 , 2);
			 }
			 if (this.Level[14] < 105 || this.Level[16] < 105 || this.Level[19] < 105 || this.Level[27] < 120) {
				 drawModalRectWithCustomSizedTexture(x + 181, y + 117, 0, 0, (int) 38 , 2,(int) 38 , 2);
			 }
			 if (this.Level[7] < 120 || this.Level[11] < 120 || this.Level[26] < 120 || this.Level[27] < 135) {
				 drawModalRectWithCustomSizedTexture(x + 181, y + 144, 0, 0, (int) 38 , 2,(int) 38 , 2);
			 }
			 if (this.Level[8] < 135 || this.Level[23] < 135 || this.Level[24] < 135 || this.Level[27] < 150) {
				 drawModalRectWithCustomSizedTexture(x + 181, y + 171, 0, 0, (int) 38 , 2,(int) 38 , 2);
			 }
			 if (this.Level[15] < 150 || this.Level[17] < 150 || this.Level[30] < 150 || this.Level[27] < 175) {
				 drawModalRectWithCustomSizedTexture(x + 181, y + 198, 0, 0, (int) 38 , 2,(int) 38 , 2);
			 }
			 
			ResourceLocation location3 = new ResourceLocation("mark13695", "textures/gui/SkillBar.png");
			 this.mc.getTextureManager().bindTexture(location3);
			
			
			drawModalRectWithCustomSizedTexture(x + 9, y + 36, 0, 0, (int) this.Degrees[0] , 2,(int) this.Degrees[0] , 2);
			drawModalRectWithCustomSizedTexture(x + 9, y + 63, 0, 0, (int) this.Degrees[1] , 2,(int) this.Degrees[1] , 2);
			drawModalRectWithCustomSizedTexture(x + 9, y + 90, 0, 0, (int) this.Degrees[2] , 2,(int) this.Degrees[2] , 2);
			drawModalRectWithCustomSizedTexture(x + 9, y + 117, 0, 0, (int) this.Degrees[3] , 2,(int) this.Degrees[3] , 2);
			drawModalRectWithCustomSizedTexture(x + 9, y + 144, 0, 0, (int) this.Degrees[4] , 2,(int) this.Degrees[4] , 2);
			drawModalRectWithCustomSizedTexture(x + 9, y + 171, 0, 0, (int) this.Degrees[5] , 2,(int) this.Degrees[5] , 2);
			drawModalRectWithCustomSizedTexture(x + 9, y + 198, 0, 0, (int) this.Degrees[6] , 2,(int) this.Degrees[6] , 2);
			drawModalRectWithCustomSizedTexture(x + 52, y + 36, 0, 0, (int) this.Degrees[7] , 2,(int) this.Degrees[7] , 2);
			drawModalRectWithCustomSizedTexture(x + 52, y + 63, 0, 0, (int) this.Degrees[8] , 2,(int) this.Degrees[8] , 2);
			drawModalRectWithCustomSizedTexture(x + 52, y + 90, 0, 0, (int) this.Degrees[9] , 2,(int) this.Degrees[9] , 2);
			drawModalRectWithCustomSizedTexture(x + 52, y + 117, 0, 0, (int) this.Degrees[10] , 2,(int) this.Degrees[10] , 2);
			drawModalRectWithCustomSizedTexture(x + 52, y + 144, 0, 0, (int) this.Degrees[11] , 2,(int) this.Degrees[11] , 2);
			drawModalRectWithCustomSizedTexture(x + 52, y + 171, 0, 0, (int) this.Degrees[12] , 2,(int) this.Degrees[12] , 2);
			drawModalRectWithCustomSizedTexture(x + 52, y + 198, 0, 0, (int) this.Degrees[13] , 2,(int) this.Degrees[13] , 2);
			drawModalRectWithCustomSizedTexture(x + 95, y + 36, 0, 0, (int) this.Degrees[14] , 2,(int) this.Degrees[14] , 2);
			drawModalRectWithCustomSizedTexture(x + 95, y + 63, 0, 0, (int) this.Degrees[15] , 2,(int) this.Degrees[15] , 2);
			drawModalRectWithCustomSizedTexture(x + 95, y + 90, 0, 0, (int) this.Degrees[16] , 2,(int) this.Degrees[16] , 2);
			drawModalRectWithCustomSizedTexture(x + 95, y + 117, 0, 0, (int) this.Degrees[17] , 2,(int) this.Degrees[17] , 2);
			drawModalRectWithCustomSizedTexture(x + 95, y + 144, 0, 0, (int) this.Degrees[18] , 2,(int) this.Degrees[18] , 2);
			drawModalRectWithCustomSizedTexture(x + 95, y + 171, 0, 0, (int) this.Degrees[19] , 2,(int) this.Degrees[19] , 2);
			drawModalRectWithCustomSizedTexture(x + 95, y + 198, 0, 0, (int) this.Degrees[20] , 2,(int) this.Degrees[20] , 2);
			drawModalRectWithCustomSizedTexture(x + 138, y + 36, 0, 0, (int) this.Degrees[21] , 2,(int) this.Degrees[21] , 2);
			drawModalRectWithCustomSizedTexture(x + 138, y + 63, 0, 0, (int) this.Degrees[22] , 2,(int) this.Degrees[22] , 2);
			drawModalRectWithCustomSizedTexture(x + 138, y + 90, 0, 0, (int) this.Degrees[23] , 2,(int) this.Degrees[23] , 2);
			drawModalRectWithCustomSizedTexture(x + 138, y + 117, 0, 0, (int) this.Degrees[24] , 2,(int) this.Degrees[24] , 2);
			drawModalRectWithCustomSizedTexture(x + 138, y + 144, 0, 0, (int) this.Degrees[25] , 2,(int) this.Degrees[25] , 2);
			drawModalRectWithCustomSizedTexture(x + 138, y + 171, 0, 0, (int) this.Degrees[26] , 2,(int) this.Degrees[26] , 2);
			drawModalRectWithCustomSizedTexture(x + 138, y + 198, 0, 0, (int) this.Degrees[27] , 2,(int) this.Degrees[27] , 2);
			drawModalRectWithCustomSizedTexture(x + 181, y + 36, 0, 0, (int) this.Degrees[28] , 2,(int) this.Degrees[28] , 2);
			drawModalRectWithCustomSizedTexture(x + 181, y + 63, 0, 0, (int) this.Degrees[29] , 2,(int) this.Degrees[29] , 2);
			drawModalRectWithCustomSizedTexture(x + 181, y + 90, 0, 0, (int) this.Degrees[30] , 2,(int) this.Degrees[30] , 2);
			drawModalRectWithCustomSizedTexture(x + 181, y + 117, 0, 0, (int) this.Degrees[31] , 2,(int) this.Degrees[31] , 2);
			drawModalRectWithCustomSizedTexture(x + 181, y + 144, 0, 0, (int) this.Degrees[32] , 2,(int) this.Degrees[32] , 2);
			drawModalRectWithCustomSizedTexture(x + 181, y + 171, 0, 0, (int) this.Degrees[33] , 2,(int) this.Degrees[33] , 2);
			drawModalRectWithCustomSizedTexture(x + 181, y + 198, 0, 0, (int) this.Degrees[34] , 2,(int) this.Degrees[34] , 2);
			
			
			//technology
			ResourceLocation locationTc = new ResourceLocation("mark13695", "textures/gui/SkillLockTc.png");
			 this.mc.getTextureManager().bindTexture(locationTc);
			 if (this.Level[15] < 20 || this.Level[18] < 20 || this.Level[22] < 20 || this.Level[27] < 35){
			 drawModalRectWithCustomSizedTexture(x + 181, y + 17, 0, 0, 16, 16, 16, 16);
			 }
			 else{}
			 ResourceLocation locationPe = new ResourceLocation("mark13695", "textures/gui/SkillLockEn.png");
			 this.mc.getTextureManager().bindTexture(locationPe);
			 
			 if (this.Level[9] < 50 || this.Level[21] < 50 || this.Level[26] < 50 || this.Level[27] < 70){
			 drawModalRectWithCustomSizedTexture(x + 181, y + 44, 0, 0, 16, 16, 16, 16);
			 }
			 else{}
			 ResourceLocation locationCh = new ResourceLocation("mark13695", "textures/gui/SkillLockCh.png");
			 this.mc.getTextureManager().bindTexture(locationCh);
			 if (this.Level[10] < 90 || this.Level[13] < 90 || this.Level[20] < 90 || this.Level[27] < 105){
			 drawModalRectWithCustomSizedTexture(x + 181, y + 71, 0, 0, 16, 16, 16, 16);
			 }
			 else{}
			 ResourceLocation locationSp = new ResourceLocation("mark13695", "textures/gui/SkillLockSp.png");
			 this.mc.getTextureManager().bindTexture(locationSp);
			 if (this.Level[14] < 105 || this.Level[16] < 105 || this.Level[19] < 105 || this.Level[27] < 120){
			 drawModalRectWithCustomSizedTexture(x + 181, y + 98, 0, 0, 16, 16, 16, 16);
			 }
			 else{}
			 ResourceLocation locationMu = new ResourceLocation("mark13695", "textures/gui/SkillLockMu.png");
			 this.mc.getTextureManager().bindTexture(locationMu);
			 if (this.Level[7] < 120 || this.Level[11] < 120 || this.Level[26] < 120 || this.Level[27] < 135){
			 drawModalRectWithCustomSizedTexture(x + 181, y + 125, 0, 0, 16, 16, 16, 16);
			 }
			 else{}
			 ResourceLocation locationFi = new ResourceLocation("mark13695", "textures/gui/SkillLockFi.png");
			 this.mc.getTextureManager().bindTexture(locationFi);
			 if (this.Level[8] < 135 || this.Level[23] < 135 || this.Level[24] < 135 || this.Level[27] < 150){
			 drawModalRectWithCustomSizedTexture(x + 181, y + 152, 0, 0, 16, 16, 16, 16);
			 }
			 else{}
			 ResourceLocation locationFu = new ResourceLocation("mark13695", "textures/gui/SkillLockFu.png");
			 this.mc.getTextureManager().bindTexture(locationFu);
			 if (this.Level[15] < 150 || this.Level[17] < 150 || this.Level[30] < 150 || this.Level[27] < 175){
			 drawModalRectWithCustomSizedTexture(x + 181, y + 179, 0, 0, 16, 16, 16, 16);
			 }
			 else{}
			 
			 
			 /** draws the levels */
			 int red = 0x00ff0000;
			 int green = 0x0000ff00;
			 int color;
			 int xposadd1;
			 int xposadd2 = 0;
			 int[] xposadd = new int[7]; 
			 int ypos = y + 21;
			 int yposred;
			 
			 for(int i = 0;i < 28; i++){
				 if( i < 7){
					 xposadd1 = x + 28;
					 yposred = 0;
				 }
				 else if(i >= 7 && i < 14){
					 
					 xposadd1 = x + 71;
					 yposred = 189;
				 }
				 else if (i >= 14 && i < 21){
					 
					 xposadd1 = x + 114;
					 yposred = 378;
				 }
				 else{
					 
					 xposadd1 = x + 157;
					 yposred = 567;
				 }
				 
				 if(this.Level[i] < 10){
					 
					 xposadd2 = 6;
					 
				 }
				 else if(this.Level[i] > 99){
					 
					 xposadd2 = 0;
					 
				 }
				 else{
					 xposadd2 = 3;
				 }
				 
				 
				 
				 if(i < 7  || i == 21 || i == 23 || i == 24 || i == 25){
					 
					 color = red;
				 }
				 else{
					 color = green;
				 }
			 drawString (fontRendererObj , "" + this.Level[i] , (xposadd1 + xposadd2), ((ypos + (i * 27)) - yposred), color);
			 }
			 
			for(int i = 0; i < 7; i++){
				
				if(this.Level[i + 28] < 10){
					 
					 xposadd[i] = 6;
					 
				 }
				 else if(this.Level[i + 28] > 99){
					 
					 xposadd[i] = 0;
					 
				 }
				 else{
					 xposadd[i] = 3;
				 }
			}
			
			if (this.Level[15] < 20 || this.Level[18] < 20 || this.Level[22] < 20 || this.Level[27] < 35)	{drawString (fontRendererObj , "" + this.Level[28] , (x + 200 + xposadd[0]), y + 21, 0x33333333);}
			else{
			drawString (fontRendererObj , "" + this.Level[28] , (x + 200 + xposadd[0]), y + 21, 0x00ff0000);}
			if (this.Level[9] < 50 || this.Level[21] < 50 || this.Level[26] < 50 || this.Level[27] < 70)	{drawString (fontRendererObj , "" + this.Level[29] , (x + 200 + xposadd[1]), y + 48, 0x33333333);}
			else{
			drawString (fontRendererObj , "" + this.Level[29] , (x + 200 + xposadd[1]), y + 48, 0x00ff0000);}
			if (this.Level[10] < 90 || this.Level[13] < 90 || this.Level[20] < 90 || this.Level[27] < 105)	{drawString (fontRendererObj , "" + this.Level[30] , (x + 200 + xposadd[2]), y + 75, 0x33333333);}
			else{
			drawString (fontRendererObj , "" + this.Level[30] , (x + 200 + xposadd[2]), y + 75, 0x0000ff00);}
			if (this.Level[14] < 105 || this.Level[16] < 105 || this.Level[19] < 105 || this.Level[27] < 120)	{drawString (fontRendererObj , "" + this.Level[31] , (x + 200 + xposadd[3]), y + 102, 0x33333333);}
			else{
			drawString (fontRendererObj , "" + this.Level[31] , (x + 200 + xposadd[3]), y + 102, 0x0000ff00);}
			if (this.Level[7] < 120 || this.Level[11] < 120 || this.Level[26] < 120 || this.Level[27] < 135)	{drawString (fontRendererObj , "" + this.Level[32] , (x + 200 + xposadd[4]), y + 129, 0x33333333);}
			else{
			drawString (fontRendererObj , "" + this.Level[32] , (x + 200 + xposadd[4]), y + 129, 0x0000ff00);}
			if (this.Level[8] < 135 || this.Level[23] < 135 || this.Level[24] < 135 || this.Level[27] < 150)	{drawString (fontRendererObj , "" + this.Level[33] , (x + 200 + xposadd[5]), y + 156, 0x33333333);}
			else{
			drawString (fontRendererObj , "" + this.Level[33] , (x + 200 + xposadd[5]), y + 156, 0x0000ff00);}
			if (this.Level[15] < 150 || this.Level[17] < 150 || this.Level[30] < 150 || this.Level[27] < 175)	{drawString (fontRendererObj , "" + this.Level[34] , (x + 200 + xposadd[6]), y + 183, 0x33333333);}
			else{
			drawString (fontRendererObj , "" + this.Level[34] , (x + 200 + xposadd[6]), y + 183, 0x0000ff00);}
			
			TotXp = 0;
			for (int txp = 0; txp < 35; txp++){
				
				TotXp += XP[txp];
				
			}
			
			drawString (fontRendererObj , "COMBAT: " + this.Combat , x + 10, y + 205, 0x0000ff00);
			drawString (fontRendererObj , "TOTAL: " + String.format("%,d", this.Total) , x + 154, y + 205, 0x0000ff00);
			
			
			
			 /**constitution -------------------------------------------------------------- */
		 	
			 
			 if(mouseX >= x + 9 && mouseX <= x + 47 && mouseY >= y + 17 && mouseY <= y + 33){
				 List listHp = new ArrayList();
				 listHp.add(this.SkillName[0] +": " + this.Level[0]);
				 listHp.add("XP: " + String.format("%,d",this.XP[0]));
				 if(this.Level[0] == 99 && this.MainLock == 1 ) {}
				 else if(this.Level[0] == 200 && this.MainLock == 2) {}
				 else if(this.Level[0] == 255){}
				 else{
				 listHp.add("Next Level: " + String.format("%,d",this.NextLevel[0]));
				 listHp.add("XP Needed: " + String.format("%,d",this.XpNeed[0]));
				 }
				 
				 this.drawHoveringText(listHp, x + 236, y + 16, fontRendererObj);
			 }
				 /**Melee--------------------------------------------------------------------------*/
				 
			 if(mouseX >= x + 9 && mouseX <= x + 47 && mouseY >= y + 44 && mouseY <= y + 60) {
					 List listMl = new ArrayList();
					 listMl.add(this.SkillName[1] +": " + this.Level[1]);
					 listMl.add("XP: " + String.format("%,d",this.XP[1]));
					 if(this.Level[1] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[1] == 200 && this.MainLock == 2) {}
					 else if(this.Level[1] == 255){}
					 else{
					 listMl.add("Next Level: " + String.format("%,d",this.NextLevel[1]));
					 listMl.add("XP Needed: " + String.format("%,d",this.XpNeed[1]));
					 }
					 this.drawHoveringText(listMl, x + 236, y + 16, fontRendererObj);
				}
				
				/**Ranged--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 9 && mouseX <= x + 47 && mouseY >= y + 71 && mouseY <= y + 87) {
					 List listRn = new ArrayList();
					 listRn.add(this.SkillName[2] +": " + this.Level[2]);
					 listRn.add("XP: " + String.format("%,d",this.XP[2]));
					 if(this.Level[2] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[2] == 200 && this.MainLock == 2) {}
					 else if(this.Level[2] == 255){}
					 else{
					 listRn.add("Next Level: " + String.format("%,d",this.NextLevel[2]));
					 listRn.add("XP Needed: " + String.format("%,d",this.XpNeed[2]));
					 }
					 this.drawHoveringText(listRn, x + 236, y + 16, fontRendererObj);
				}
				
				/**Magic--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 9 && mouseX <= x + 47 && mouseY >= y + 98 && mouseY <= y + 114) {
					 List listMg = new ArrayList();
					 listMg.add(SkillName[3] +": " + this.Level[3]);
					 listMg.add("XP: " + String.format("%,d",this.XP[3]));
					 if(Level[3] == 99 && this.MainLock == 1 ) {}
					 else if(Level[3] == 200 && this.MainLock == 2) {}
					 else if(Level[3] == 255){}
					 else{
					 listMg.add("Next Level: " + String.format("%,d",this.NextLevel[3]));
					 listMg.add("XP Needed: " + String.format("%,d",this.XpNeed[3]));
					 }
					 this.drawHoveringText(listMg, x + 236, y + 16, fontRendererObj);
				}
				
				/**Defence--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 9 && mouseX <= x + 47 && mouseY >= y + 125 && mouseY <= y + 141) {
					 List listDf = new ArrayList();
					 listDf.add(this.SkillName[4] +": " + this.Level[4]);
					 listDf.add("XP: " + String.format("%,d",this.XP[4]));
					 if(this.Level[4] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[4] == 200 && this.MainLock == 2) {}
					 else if(this.Level[4] == 255){}
					 else{
					 listDf.add("Next Level: " + String.format("%,d",this.NextLevel[4]));
					 listDf.add("XP Needed: " + String.format("%,d",this.XpNeed[4]));
					 }
					 this.drawHoveringText(listDf, x + 236, y + 16, fontRendererObj);
				}
				
				/**Endurance--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 9 && mouseX <= x + 47 && mouseY >= y + 152 && mouseY <= y + 168) {
					 List listEn = new ArrayList();
					 listEn.add(this.SkillName[5] +": " + this.Level[5]);
					 listEn.add("XP: " + String.format("%,d",this.XP[5]));
					 if(this.Level[5] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[5] == 200 && this.MainLock == 2) {}
					 else if(this.Level[5] == 255){}
					 else{
					 listEn.add("Next Level: " + String.format("%,d",this.NextLevel[5]));
					 listEn.add("XP Needed: " + String.format("%,d",this.XpNeed[5]));
					 }
					 this.drawHoveringText(listEn, x + 236, y + 16, fontRendererObj);
				}
				
				/**Slayer--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 9 && mouseX <= x + 47 && mouseY >= y + 179 && mouseY <= y + 195) {
					 List listSl = new ArrayList();
					 listSl.add(this.SkillName[6] +": " + this.Level[6]);
					 listSl.add("XP: " + String.format("%,d",this.XP[6]));
					 if(this.Level[6] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[6] == 200 && this.MainLock == 2) {}
					 else if(this.Level[6] == 255){}
					 else{
					 listSl.add("Next Level: " + String.format("%,d",this.NextLevel[6]));
					 listSl.add("XP Needed: " + String.format("%,d",this.XpNeed[6]));
					 }
					 this.drawHoveringText(listSl, x + 236, y + 16, fontRendererObj);
				}
				
				/**Farming--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 52 && mouseX <= x + 90 && mouseY >= y + 17 && mouseY <= y + 33) {
					 List listFr = new ArrayList();
					 listFr.add(this.SkillName[7] +": " + this.Level[7]);
					 listFr.add("XP: " + String.format("%,d",this.XP[7]));
					 if(this.Level[7] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[7] == 200 && this.MainLock == 2) {}
					 else if(this.Level[7] == 255){}
					 else{
					 listFr.add("Next Level: " + String.format("%,d",this.NextLevel[7]));
					 listFr.add("XP Needed: " + String.format("%,d",this.XpNeed[7]));
					 }
					 this.drawHoveringText(listFr, x + 236, y + 16, fontRendererObj);
				}
				
				/**Mining--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 52 && mouseX <= x + 90 && mouseY >= y + 44 && mouseY <= y + 60) {
					 List listMn = new ArrayList();
					 listMn.add(this.SkillName[8] +": " + this.Level[8]);
					 listMn.add("XP: " + String.format("%,d",this.XP[8]));
					 if(this.Level[8] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[8] == 200 && this.MainLock == 2) {}
					 else if(this.Level[8] == 255){}
					 else{
					 listMn.add("Next Level: " + String.format("%,d",this.NextLevel[8]));
					 listMn.add("XP Needed: " + String.format("%,d",this.XpNeed[8]));
					 }
					 this.drawHoveringText(listMn, x + 236, y + 16, fontRendererObj);
				}
				 
				 
				
					
					/**Hunter--------------------------------------------------------------------------------------------------------------------*/
					
				 if(mouseX >= x + 52 && mouseX <= x + 90 && mouseY >= y + 71 && mouseY <= y + 87) {
					 List listHu = new ArrayList();
					 listHu.add(this.SkillName[9]+ ": " + this.Level[9]);
					 listHu.add("XP: " + String.format("%,d",this.XP[9]));
					 if(this.Level[9] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[9] == 200 && this.MainLock == 2) {}
					 else if(this.Level[9] == 255){}
					 else{
					 listHu.add("Next Level: " + String.format("%,d",this.NextLevel[9]));
					 listHu.add("XP Needed: " + String.format("%,d",this.XpNeed[9]));
					 }
					 this.drawHoveringText(listHu, x + 236, y + 16, fontRendererObj);
				}
				
				/**Excavation--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 52 && mouseX <= x + 90 && mouseY >= y + 98 && mouseY <= y + 114) {
					 List listEx = new ArrayList();
					 listEx.add(this.SkillName[10]+ ": " + this.Level[10]);
					 listEx.add("XP: " + String.format("%,d",this.XP[10]));
					 if(this.Level[10] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[10] == 200 && this.MainLock == 2) {}
					 else if(this.Level[10] == 255){}
					 else{
					 listEx.add("Next Level: " + String.format("%,d",this.NextLevel[10]));
					 listEx.add("XP Needed: " + String.format("%,d",this.XpNeed[10]));
					 }
					 this.drawHoveringText(listEx, x + 236, y + 16, fontRendererObj);
				}
				
				
				 
				/**Woodcutting--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 52 && mouseX <= x + 90 && mouseY >= y + 125 && mouseY <= y + 141) {
					 List listWc = new ArrayList();
					 listWc.add(this.SkillName[11]+ ": " + this.Level[11]);
					 listWc.add("XP: " + String.format("%,d",this.XP[11]));
					 if(this.Level[11] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[11] == 200 && this.MainLock == 2) {}
					 else if(this.Level[11] == 255){}
					 else{
					 listWc.add("Next Level: " + String.format("%,d",this.NextLevel[11]));
					 listWc.add("XP Needed: " + String.format("%,d",this.XpNeed[11]));
					 }
					 this.drawHoveringText(listWc, x + 236, y + 16, fontRendererObj);
				}
				
				/**Fishing--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 52 && mouseX <= x + 90 && mouseY >= y + 152 && mouseY <= y + 168) {
					 List listFs = new ArrayList();
					 listFs.add(this.SkillName[12]+ ": " + this.Level[12]);
					 listFs.add("XP: " + String.format("%,d",this.XP[12]));
					 if(this.Level[12] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[12] == 200 && this.MainLock == 2) {}
					 else if(this.Level[12] == 255){}
					 else{
					 listFs.add("Next Level: " + String.format("%,d",this.NextLevel[12]));
					 listFs.add("XP Needed: " + String.format("%,d",this.XpNeed[12]));
					 }
					 this.drawHoveringText(listFs, x + 236, y + 16, fontRendererObj);
				}
				
				/**Archeology--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 52 && mouseX <= x + 90 && mouseY >= y + 179 && mouseY <= y + 195) {
					 List listAr = new ArrayList();
					 listAr.add(this.SkillName[13]+ ": " + this.Level[13]);
					 listAr.add("XP: " + String.format("%,d",this.XP[13]));
					 if(this.Level[13] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[13] == 200 && this.MainLock == 2) {}
					 else if(this.Level[13] == 255){}
					 else{
					 listAr.add("Next Level: " + String.format("%,d",this.NextLevel[13]));
					 listAr.add("XP Needed: " + String.format("%,d",this.XpNeed[13]));
					 }
					 this.drawHoveringText(listAr, x + 236, y + 16, fontRendererObj);
				}
				 
				 /**Tailory--------------------------------------------------------------------------------------------------------------------*/
					
				 if(mouseX >= x + 95 && mouseX <= x + 133 && mouseY >= y + 17 && mouseY <= y + 33) {
					 List listTa = new ArrayList();
					 listTa.add(this.SkillName[14] +": " + this.Level[14]);
					 listTa.add("XP: " + String.format("%,d",this.XP[14]));
					 if(this.Level[14] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[14] == 200 && this.MainLock == 2) {}
					 else if(this.Level[14] == 255){}
					 else{
					 listTa.add("Next Level: " + String.format("%,d",this.NextLevel[14]));
					 listTa.add("XP Needed: " + String.format("%,d",this.XpNeed[14]));
					 }
					 this.drawHoveringText(listTa, x + 236, y + 16, fontRendererObj);
				}
				
				/**Smithing--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 95 && mouseX <= x + 133 && mouseY >= y + 44 && mouseY <= y + 60) {
					 List listSm = new ArrayList();
					 listSm.add(this.SkillName[15] +": " + this.Level[15]);
					 listSm.add("XP: " + String.format("%,d",this.XP[15]));
					 if(this.Level[15] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[15] == 200 && this.MainLock == 2) {}
					 else if(this.Level[15] == 255){}
					 else{
					 listSm.add("Next Level: " + String.format("%,d",this.NextLevel[15]));
					 listSm.add("XP Needed: " + String.format("%,d",this.XpNeed[15]));
					 }
					 this.drawHoveringText(listSm, x + 236, y + 16, fontRendererObj);
				}
				 
					/**Tanning--------------------------------------------------------------------------------------------------------------------*/
					
				 if(mouseX >= x + 95 && mouseX <= x + 133 && mouseY >= y + 71 && mouseY <= y + 87) {
					 List listTn = new ArrayList();
					 listTn.add(this.SkillName[16]+ ": " + this.Level[16]);
					 listTn.add("XP: " + String.format("%,d",this.XP[16]));
					 if(this.Level[16] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[16] == 200 && this.MainLock == 2) {}
					 else if(this.Level[16] == 255){}
					 else{
					 listTn.add("Next Level: " + String.format("%,d",this.NextLevel[16]));
					 listTn.add("XP Needed: " + String.format("%,d",this.XpNeed[16]));
					 }
					 this.drawHoveringText(listTn, x + 236, y + 16, fontRendererObj);
				}
				
				/**Jewelry--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 95 && mouseX <= x + 133 && mouseY >= y + 98 && mouseY <= y + 114) {
					 List listJe = new ArrayList();
					 listJe.add(this.SkillName[17]+ ": " + this.Level[17]);
					 listJe.add("XP: " + String.format("%,d",this.XP[17]));
					 if(this.Level[17] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[17] == 200 && this.MainLock == 2) {}
					 else if(this.Level[17] == 255){}
					 else{
					 listJe.add("Next Level: " + String.format("%,d",this.NextLevel[17]));
					 listJe.add("XP Needed: " + String.format("%,d",this.XpNeed[17]));
					 }
					 this.drawHoveringText(listJe, x + 236, y + 16, fontRendererObj);
				}
				
				/**Fletching--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 95 && mouseX <= x + 133 && mouseY >= y + 125 && mouseY <= y + 141) {
					 List listWc = new ArrayList();
					 listWc.add(this.SkillName[18]+ ": " + this.Level[18]);
					 listWc.add("XP: " + String.format("%,d",this.XP[18]));
					 if(this.Level[18] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[18] == 200 && this.MainLock == 2) {}
					 else if(this.Level[18] == 255){}
					 else{
					 listWc.add("Next Level: " + String.format("%,d",this.NextLevel[18]));
					 listWc.add("XP Needed: " + String.format("%,d",this.XpNeed[18]));
					 }
					 this.drawHoveringText(listWc, x + 236, y + 16, fontRendererObj);
				}
				
				/**Cooking--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 95 && mouseX <= x + 133 && mouseY >= y + 152 && mouseY <= y + 168) {
					 List listCo = new ArrayList();
					 listCo.add(this.SkillName[19]+ ": " + this.Level[19]);
					 listCo.add("XP: " + String.format("%,d",this.XP[19]));
					 if(this.Level[19] == 99 && MainLock == 1 ) {}
					 else if(this.Level[19] == 200 && MainLock == 2) {}
					 else if(this.Level[19] == 255){}
					 else{
					 listCo.add("Next Level: " + String.format("%,d",this.NextLevel[19]));
					 listCo.add("XP Needed: " + String.format("%,d",this.XpNeed[19]));
					 }
					 this.drawHoveringText(listCo, x + 236, y + 16, fontRendererObj);
				}
				
				/**Herblore--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 95 && mouseX <= x + 133 && mouseY >= y + 179 && mouseY <= y + 195) {
					 List listHr = new ArrayList();
					 listHr.add(this.SkillName[20]+ ": " + this.Level[20]);
					 listHr.add("XP: " + String.format("%,d",this.XP[20]));
					 if(this.Level[20] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[20] == 200 && this.MainLock == 2) {}
					 else if(this.Level[20] == 255){}
					 else{
					 listHr.add("Next Level: " + String.format("%,d",this.NextLevel[20]));
					 listHr.add("XP Needed: " + String.format("%,d",this.XpNeed[20]));
					 }
					 this.drawHoveringText(listHr, x + 236, y + 16, fontRendererObj);
				}
				 
				 
				 /**Honour--------------------------------------------------------------------------------------------------------------------*/
					
				 if(mouseX >= x + 138 && mouseX <= x + 176 && mouseY >= y + 17 && mouseY <= y + 33) {
					 List listHn = new ArrayList();
					 listHn.add(this.SkillName[21] +": " + this.Level[21]);
					 listHn.add("XP: " + String.format("%,d",XP[21]));
					 if(this.Level[21] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[21] == 200 && this.MainLock == 2) {}
					 else if(this.Level[21] == 255){}
					 else{
					 listHn.add("Next Level: " + String.format("%,d",this.NextLevel[21]));
					 listHn.add("XP Needed: " + String.format("%,d",this.XpNeed[21]));
					 }
					 this.drawHoveringText(listHn, x + 236, y + 16, fontRendererObj);
				}
				
				/**Construction--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 138 && mouseX <= x + 176 && mouseY >= y + 44 && mouseY <= y + 60) {
					 List listSm = new ArrayList();
					 listSm.add(this.SkillName[22] +": " + this.Level[22]);
					 listSm.add("XP: " + String.format("%,d",this.XP[22]));
					 if(this.Level[22] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[22] == 200 && this.MainLock == 2) {}
					 else if(this.Level[22] == 255){}
					 else{
					 listSm.add("Next Level: " + String.format("%,d",this.NextLevel[22]));
					 listSm.add("XP Needed: " + String.format("%,d",this.XpNeed[22]));
					 }
					 this.drawHoveringText(listSm, x + 236, y + 16, fontRendererObj);
				}
				 
					/**Agility--------------------------------------------------------------------------------------------------------------------*/
					
				 if(mouseX >= x + 138 && mouseX <= x + 176 && mouseY >= y + 71 && mouseY <= y + 87) {
					 List listAg = new ArrayList();
					 listAg.add(this.SkillName[23]+ ": " + this.Level[23]);
					 listAg.add("XP: " + String.format("%,d",this.XP[23]));
					 if(this.Level[23] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[23] == 200 && this.MainLock == 2) {}
					 else if(this.Level[23] == 255){}
					 else{
					 listAg.add("Next Level: " + String.format("%,d",this.NextLevel[23]));
					 listAg.add("XP Needed: " + String.format("%,d",this.XpNeed[23]));
					 }
					 this.drawHoveringText(listAg, x + 236, y + 16, fontRendererObj);
				}
				
				/**Dungeoneering--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 138 && mouseX <= x + 176 && mouseY >= y + 98 && mouseY <= y + 114) {
					 List listDu = new ArrayList();
					 listDu.add(this.SkillName[24]+ ": " + this.Level[24]);
					 listDu.add("XP: " + String.format("%,d",this.XP[24]));
					 if(this.Level[24] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[24] == 200 && this.MainLock == 2) {}
					 else if(this.Level[24] == 255){}
					 else{
					 listDu.add("Next Level: " + String.format("%,d",this.NextLevel[24]));
					 listDu.add("XP Needed: " + String.format("%,d",this.XpNeed[24]));
					 }
					 this.drawHoveringText(listDu, x + 236, y + 16, fontRendererObj);
				}
				
				/**Firemaking--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 138 && mouseX <= x + 176 && mouseY >= y + 125 && mouseY <= y + 141) {
					 List listFm = new ArrayList();
					 listFm.add(this.SkillName[25]+ ": " + this.Level[25]);
					 listFm.add("XP: " + String.format("%,d",XP[25]));
					 if(this.Level[25] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[25] == 200 && this.MainLock == 2) {}
					 else if(this.Level[25] == 255){}
					 else{
					 listFm.add("Next Level: " + String.format("%,d",this.NextLevel[25]));
					 listFm.add("XP Needed: " + String.format("%,d",this.XpNeed[25]));
					 }
					 this.drawHoveringText(listFm, x + 236, y + 16, fontRendererObj);
				}
				
				/**Lifestock--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 138 && mouseX <= x + 176 && mouseY >= y + 152 && mouseY <= y + 168) {
					 List listLs = new ArrayList();
					 listLs.add(this.SkillName[26]+ ": " + this.Level[26]);
					 listLs.add("XP: " + String.format("%,d",this.XP[26]));
					 if(this.Level[26] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[26] == 200 && this.MainLock == 2) {}
					 else if(this.Level[26] == 255){}
					 else{
					 listLs.add("Next Level: " + String.format("%,d",this.NextLevel[26]));
					 listLs.add("XP Needed: " + String.format("%,d",this.XpNeed[26]));
					 }
					 this.drawHoveringText(listLs, x + 236, y + 16, fontRendererObj);
				}
				
				/**Knowledge--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 138 && mouseX <= x + 176 && mouseY >= y + 179 && mouseY <= y + 195) {
					 List listKn = new ArrayList();
					 listKn.add(this.SkillName[27]+ ": " + this.Level[27]);
					 listKn.add("XP: " + String.format("%,d",this.XP[27]));
					 if(this.Level[27] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[27] == 200 && this.MainLock == 2) {}
					 else if(this.Level[27] == 255){}
					 else{
					 listKn.add("Next Level: " + String.format("%,d",this.NextLevel[27]));
					 listKn.add("XP Needed: " + String.format("%,d",this.XpNeed[27]));
					 }
					 this.drawHoveringText(listKn, x + 236, y + 16, fontRendererObj);
				}
				 
				 /**Technology--------------------------------------------------------------------------------------------------------------------*/
					
				 if(mouseX >= x + 181 && mouseX <= x + 219 && mouseY >= y + 17 && mouseY <= y + 33) {
					 List listTc = new ArrayList();
					 if (this.Level[15] < 20 || this.Level[18] < 20 || this.Level[22] < 20 || this.Level[27] < 35){
					 listTc.add("Locked");}
					 else{
					 listTc.add(this.SkillName[28] +": " + this.Level[28]);
					 listTc.add("XP: " + String.format("%,d",this.XP[28]));
					 if(this.Level[21] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[28] == 200 && this.MainLock == 2) {}
					 else if(this.Level[28] == 255){}
					 else{
					 listTc.add("Next Level: " + String.format("%,d",this.NextLevel[28]));
					 listTc.add("XP Needed: " + String.format("%,d",this.XpNeed[28]));
					 }}
					 this.drawHoveringText(listTc, x + 236, y + 16, fontRendererObj);
				
				 }
				/**Petting--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 181 && mouseX <= x + 219 && mouseY >= y + 44 && mouseY <= y + 60) {
					 List listPe = new ArrayList();
					 if (this.Level[9] < 50 || this.Level[21] < 50 || this.Level[26] < 50 || this.Level[27] < 70){
						 listPe.add("Locked");}
						 else{
					 listPe.add(this.SkillName[29] +": " + this.Level[29]);
					 listPe.add("XP: " + String.format("%,d",this.XP[22]));
					 if(this.Level[29] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[29] == 200 && this.MainLock == 2) {}
					 else if(this.Level[29] == 255){}
					 else{
					 listPe.add("Next Level: " + String.format("%,d",this.NextLevel[29]));
					 listPe.add("XP Needed: " + String.format("%,d",this.XpNeed[29]));
					 }}
					 this.drawHoveringText(listPe, x + 236, y + 16, fontRendererObj);
				
				 }
					/**Chemistry--------------------------------------------------------------------------------------------------------------------*/
					
				 if(mouseX >= x + 181 && mouseX <= x + 219 && mouseY >= y + 71 && mouseY <= y + 87) {
					 List listCh = new ArrayList();
					 if (this.Level[10] < 90 || this.Level[13] < 90 || this.Level[20] < 90 || this.Level[27] < 105){
						 listCh.add("Locked");}
						 else{
					 listCh.add(this.SkillName[30]+ ": " + this.Level[30]);
					 listCh.add("XP: " + String.format("%,d",XP[30]));
					 if(this.Level[30] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[30] == 200 && this.MainLock == 2) {}
					 else if(this.Level[30] == 255){}
					 else{
					 listCh.add("Next Level: " + String.format("%,d",this.NextLevel[30]));
					 listCh.add("XP Needed: " + String.format("%,d",this.XpNeed[30]));
					 }}
					 this.drawHoveringText(listCh, x + 236, y + 16, fontRendererObj);
				
				 }
				/**Specility--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 181 && mouseX <= x + 219 && mouseY >= y + 98 && mouseY <= y + 114) {
					 List listSp = new ArrayList();
					 if (this.Level[14] < 105 || this.Level[16] < 105 || this.Level[19] < 105 || this.Level[27] < 120){
						 listSp.add("Locked");}
						 else{
					 listSp.add(this.SkillName[31]+ ": " + this.Level[31]);
					 listSp.add("XP: " + String.format("%,d",this.XP[31]));
					 if(this.Level[31] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[31] == 200 && this.MainLock == 2) {}
					 else if(this.Level[31] == 255){}
					 else{
					 listSp.add("Next Level: " + String.format("%,d",this.NextLevel[31]));
					 listSp.add("XP Needed: " + String.format("%,d",this.XpNeed[31]));
					 }}
					 this.drawHoveringText(listSp, x + 236, y + 16, fontRendererObj);
				
				 }
				/**Mutating--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 181 && mouseX <= x + 219 && mouseY >= y + 125 && mouseY <= y + 141) {
					 List listMu = new ArrayList();
					 if (this.Level[7] < 120 || this.Level[11] < 120 || this.Level[26] < 120 || this.Level[27] < 135){
						 listMu.add("Locked");}
						 else{
					 listMu.add(this.SkillName[32]+ ": " + this.Level[32]);
					 listMu.add("XP: " + String.format("%,d",this.XP[32]));
					 if(this.Level[32] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[32] == 200 && this.MainLock == 2) {}
					 else if(this.Level[32] == 255){}
					 else{
					 listMu.add("Next Level: " + String.format("%,d",this.NextLevel[32]));
					 listMu.add("XP Needed: " + String.format("%,d",this.XpNeed[32]));
					 }}
					 this.drawHoveringText(listMu, x + 236, y + 16, fontRendererObj);
				
				 }
				/**Fisioning--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 181 && mouseX <= x + 219 && mouseY >= y + 152 && mouseY <= y + 168) {
					 List listFi = new ArrayList();
					 if (this.Level[8] < 135 || this.Level[23] < 135 || this.Level[24] < 135 || this.Level[27] < 150){
						 listFi.add("Locked");}
						 else{
					 listFi.add(this.SkillName[33]+ ": " + this.Level[33]);
					 listFi.add("XP: " + String.format("%,d",this.XP[33]));
					 if(this.Level[33] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[33] == 200 && this.MainLock == 2) {}
					 else if(this.Level[33] == 255){}
					 else{
					 listFi.add("Next Level: " + String.format("%,d",this.NextLevel[33]));
					 listFi.add("XP Needed: " + String.format("%,d",this.XpNeed[33]));
					 }}
					 this.drawHoveringText(listFi, x + 236, y + 16, fontRendererObj);
				
				 }
				/**Fusioning--------------------------------------------------------------------------------------------------------------------*/
				
				 if(mouseX >= x + 181 && mouseX <= x + 219 && mouseY >= y + 179 && mouseY <= y + 195) {
					 List listFu = new ArrayList();
					 if (this.Level[15] < 150 || this.Level[17] < 150 || this.Level[30] < 150 || this.Level[27] < 175){
						 listFu.add("Locked");}
						 else{
					 listFu.add(this.SkillName[34]+ ": " + this.Level[34]);
					 listFu.add("XP: " + String.format("%,d",this.XP[34]));
					 if(this.Level[34] == 99 && this.MainLock == 1 ) {}
					 else if(this.Level[34] == 200 && this.MainLock == 2) {}
					 else if(this.Level[34] == 255){}
					 else{
					 listFu.add("Next Level: " + String.format("%,d",this.NextLevel[34]));
					 listFu.add("XP Needed: " + String.format("%,d",this.XpNeed[34]));
					 }}
					 this.drawHoveringText(listFu, x + 236, y + 16, fontRendererObj);
				
				 }
				 if(mouseX >= x + 153 && mouseX <= x + 218 && mouseY >= y + 204 && mouseY <= y + 213) {
					 List listTt = new ArrayList();
					 listTt.add("Total Xp: " + String.format("%,d", this.TotXp));
					 this.drawHoveringText(listTt, x + 236, y + 16, fontRendererObj);
				 }
		 
	 
			 
			 
			 }
				
			 
			 
	 
	 
	 
	
	 
		
	 
		 
		 
	 
		 
	 @Override
	 public boolean doesGuiPauseGame() {
	 return false;
                      
     }
	 
	 @Override
	    public void initGui() {
					
			
			
	 }
	 
	
		 
		 
	 
	 
	 @Override
     public void updateScreen() {
         super.updateScreen();
	 }
}
