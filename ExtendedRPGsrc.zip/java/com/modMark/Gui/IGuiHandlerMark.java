package com.modMark.Gui;

import com.modMark.Crafting.MarkContainer;
import com.modMark.Crafting.MarkContainerInv;
import com.modMark.Crafting.MarkInventory;
import com.modMark.Item_Block.TileEntity.TECraftingTable;
import com.modMark.Item_Block.TileEntity.TETrap;
import com.modMark.Skill.MarkData;


import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class IGuiHandlerMark implements IGuiHandler {
	

	public static final int SkillsGui = 0;
	public static final int HiscoreGui = 1;
	public static final int CraftTable = 2;
	public static final int Inventory = 3;
	
	
		@Override
        public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
			
			if(ID == CraftTable){
				BlockPos pos = new BlockPos(x,y,z);
        		
        		TileEntity tileentity = world.getTileEntity(pos);
        		System.out.println("pos:(" + x + "," + y + "," + z + ") TE:" + (tileentity == null ? null : tileentity.toString()));
       		 if (tileentity instanceof TECraftingTable) {
       		TECraftingTable TE = (TECraftingTable) tileentity;
       		System.out.println("Block Activated on server Side");
        		return new MarkContainer(player.inventory, TE);
        	}
       		 return null;
			}
			if(ID == Inventory){
        		
				return new MarkContainerInv(player.inventory, new MarkInventory());
        		
        	}
			else{
                return null;
			}
        }

        @Override
        public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        	
        	if (ID == SkillsGui){
        		return new GuiStatlist();
        	}
        	if (ID == HiscoreGui){
        		return new GuiHiscoreList();
        	}
        	if(ID == CraftTable){
				BlockPos pos = new BlockPos(x,y,z);
        		
        		TileEntity tileentity = world.getTileEntity(pos);
        		System.out.println("pos:(" + x + "," + y + "," + z + ") TE:" + (tileentity == null ? null : tileentity.toString()));
       		 if (tileentity instanceof TECraftingTable) {
       		TECraftingTable TE = (TECraftingTable) tileentity;
       		System.out.println("Block Activated on server Side");
        		return new GuiCraftingTable(player.inventory, TE);
        	}
       		 return null;
			}
        	if(ID == Inventory){
        		return new GuiInventory2(player.inventory, new MarkInventory());
        		
        	}
			else{
                return null;
			}
        }
}