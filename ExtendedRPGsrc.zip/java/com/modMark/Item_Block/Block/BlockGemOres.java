package com.modMark.Item_Block.Block;

import java.util.Random;

import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkHashMaps;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;


public class BlockGemOres extends Block{

	 public static final PropertyBool Natural = PropertyBool.create("natural");
	 
	 public BlockGemOres(String unlocalizedName) {
         this(unlocalizedName, Material.GROUND, 3.0F , 5.0F);
     }
	 
	public BlockGemOres(String unlocalizedName, Material material, float H, float R) {
        super(material);
        this.setUnlocalizedName(unlocalizedName);
        this.setCreativeTab(MainRegistry.tabMark);
        this.setHardness(H);
        this.setResistance(R);
        this.setSoundType(SoundType.SAND);

	}	
	public Item getItemDropped(IBlockState state, Random rand, int fortune)
    {
        return Item.getItemFromBlock(this.getDefaultState().withProperty(Natural, false).getBlock());
    }
	
	public boolean isNatural(IBlockState state){
		return state.getValue(Natural);
		
	}
	
	 public IBlockState getStateFromMeta(int meta)
	    {
	        return this.getDefaultState().withProperty(Natural, meta == 0 ? false : true);
	    }

	    /**
	     * Convert the BlockState into the correct metadata value
	     */
	    public int getMetaFromState(IBlockState state)
	    {
	       
	        return this.isNatural(state) ? 1 : 0;
	        
	    }

	    protected BlockStateContainer createBlockState()
	    {
	        return new BlockStateContainer(this, new IProperty[] {Natural});
	    }
	
	
}

