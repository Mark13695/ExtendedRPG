package com.modMark.Item_Block.Block;

import java.util.UUID;

import javax.annotation.Nullable;

import com.modMark.Gui.IGuiHandlerMark;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.TileEntity.TECraftingTable;
import com.modMark.Item_Block.TileEntity.TETrap;
import com.modMark.Main.MainRegistry;
import com.modMark.Packets.CraftingPacketA;
import com.modMark.Skill.MarkData;

import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.client.FMLClientHandler;

public class MarkCraftingTable extends Block implements ITileEntityProvider{
	
	private int SkillID = 0;
	public static final PropertyDirection FACING = BlockHorizontal.FACING;
	public static final PropertyBool isActive = PropertyBool.create("active");
	

	
	public MarkCraftingTable(String unlocalizedName, Material material, int skillID) {
        super(material);
        this.setUnlocalizedName(unlocalizedName);
        this.setCreativeTab(MainRegistry.tabMark);
        this.setHardness(3.0F);
        this.setResistance(5.0F);
        this.setSoundType(material == Material.WOOD ? SoundType.WOOD : SoundType.STONE);
        this.SkillID = skillID;
        this.setDefaultState(this.blockState.getBaseState().withProperty(isActive, Boolean.valueOf(false)));
	}

	 public void onBlockAdded(World worldIn, BlockPos pos, IBlockState state)
	    {
	        this.setDefaultFacing(worldIn, pos, state);
	    }

	    private void setDefaultFacing(World worldIn, BlockPos pos, IBlockState state)
	    {
	        if (!worldIn.isRemote)
	        {
	            IBlockState iblockstate = worldIn.getBlockState(pos.north());
	            IBlockState iblockstate1 = worldIn.getBlockState(pos.south());
	            IBlockState iblockstate2 = worldIn.getBlockState(pos.west());
	            IBlockState iblockstate3 = worldIn.getBlockState(pos.east());
	            EnumFacing enumfacing = (EnumFacing)state.getValue(FACING);

	            if (enumfacing == EnumFacing.NORTH && iblockstate.isFullBlock() && !iblockstate1.isFullBlock())
	            {
	                enumfacing = EnumFacing.SOUTH;
	            }
	            else if (enumfacing == EnumFacing.SOUTH && iblockstate1.isFullBlock() && !iblockstate.isFullBlock())
	            {
	                enumfacing = EnumFacing.NORTH;
	            }
	            else if (enumfacing == EnumFacing.WEST && iblockstate2.isFullBlock() && !iblockstate3.isFullBlock())
	            {
	                enumfacing = EnumFacing.EAST;
	            }
	            else if (enumfacing == EnumFacing.EAST && iblockstate3.isFullBlock() && !iblockstate2.isFullBlock())
	            {
	                enumfacing = EnumFacing.WEST;
	            }
	            boolean bool = state.getValue(isActive);
	            System.out.println("" + bool);
	            worldIn.setBlockState(pos, state.withProperty(FACING, enumfacing).withProperty(isActive, Boolean.valueOf(bool)), 2);
	        }
	    }
	    
	    public IBlockState onBlockPlaced(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer)
	    {
	        return this.getDefaultState().withProperty(FACING, placer.getHorizontalFacing().getOpposite()).withProperty(isActive, Boolean.valueOf(false));
	    }
	    
	    /**
	     * Convert the given metadata into a BlockState for this Block
	     */
	    public IBlockState getStateFromMeta(int meta)
	    {
	        EnumFacing enumfacing = EnumFacing.getFront(meta - ((meta / 8) * 8));

	        if (enumfacing.getAxis() == EnumFacing.Axis.Y)
	        {
	            enumfacing = EnumFacing.NORTH;
	        }

	        return this.getDefaultState().withProperty(FACING, enumfacing).withProperty(isActive, meta > 7 ? Boolean.valueOf(true) : Boolean.valueOf(false));
	    }
public void MigrateTEToNewState(World world, TECraftingTable TE_OLD, boolean Used, BlockPos pos, IBlockState state, UUID uuid){
	int TempCraftVal = TE_OLD.getCraftStackValue();
	float TempCurEng = TE_OLD.getCurEnergy();
	float TempMaxEng = TE_OLD.getMaxEnergy();
	ItemStack[] TempInv = TE_OLD.getCurInventory();
	UUID Tempuuid = uuid;
	
	world.setBlockState(pos, state.withProperty(isActive, Boolean.valueOf(Used)));
	
	TileEntity t = world.getTileEntity(pos);
	if (t instanceof TECraftingTable){
		TECraftingTable TE = (TECraftingTable) t;
		TE.setCraftStackValue(TempCraftVal);
		TE.setCurEnergy(TempCurEng);
		TE.setMaxEnergy(TempMaxEng);
		TE.setCurInventory(TempInv);
		TE.setPlayerUUID(Tempuuid);
		
	}
}
	    /**
	     * Convert the BlockState into the correct metadata value
	     */
	    public int getMetaFromState(IBlockState state)
	    {
	    	int a = ((EnumFacing)state.getValue(FACING)).getIndex();
	        int b = state.getValue(isActive) == false ? 0 : 8;
	         return a + b;
	    }

	    /**
	     * Returns the blockstate with the given rotation from the passed blockstate. If inapplicable, returns the passed
	     * blockstate.
	     */
	    public IBlockState withRotation(IBlockState state, Rotation rot)
	    {
	    	boolean bool = state.getValue(isActive);
	    	System.out.println("" + bool);
	        return state.withProperty(FACING, rot.rotate((EnumFacing)state.getValue(FACING))).withProperty(isActive, Boolean.valueOf(bool));
	    }

	    /**
	     * Returns the blockstate with the given mirror of the passed blockstate. If inapplicable, returns the passed
	     * blockstate.
	     */
	    public IBlockState withMirror(IBlockState state, Mirror mirrorIn)
	    {
	        return state.withRotation(mirrorIn.toRotation((EnumFacing)state.getValue(FACING)));
	    }

	    protected BlockStateContainer createBlockState()
	    {
	        return new BlockStateContainer(this, new IProperty[] {FACING, isActive});
	    }
	    
	    protected boolean isInvalidNeighbor(World worldIn, BlockPos pos, EnumFacing facing)
	    {
	        return worldIn.getBlockState(pos.offset(facing)).getMaterial() == Material.CACTUS;
	    }

	    protected boolean hasInvalidNeighbor(World worldIn, BlockPos pos)
	    {
	        return this.isInvalidNeighbor(worldIn, pos, EnumFacing.NORTH) || this.isInvalidNeighbor(worldIn, pos, EnumFacing.SOUTH) || this.isInvalidNeighbor(worldIn, pos, EnumFacing.WEST) || this.isInvalidNeighbor(worldIn, pos, EnumFacing.EAST);
	    }
	    
	    public boolean eventReceived(IBlockState state, World worldIn, BlockPos pos, int id, int param)
	    {
	        super.eventReceived(state, worldIn, pos, id, param);
	        TileEntity tileentity = worldIn.getTileEntity(pos);
	        return tileentity == null ? false : tileentity.receiveClientEvent(id, param);
	    }
	    
	    @Override
	    public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, @Nullable ItemStack heldItem, EnumFacing side, float hitX, float hitY, float hitZ)
	    {
	        TileEntity te = worldIn.getTileEntity(pos);
	       
	        
	        if(te instanceof TECraftingTable){
	    			TECraftingTable TE = (TECraftingTable) te;
	    			if(TE.getPlayerUUID() == null ||TE.getPlayerUUID().equals(playerIn.getUniqueID())){
	    			
	    			
	    			TE.setPlayerUUID(playerIn.getUniqueID());
	    			if(playerIn != null){
	    			this.MigrateTEToNewState(worldIn, TE, true, pos, state, TE.getPlayerUUID());
	    			}
	    		
	    
	        	 if (!FMLClientHandler.instance().isGUIOpen(GuiChat.class)) {
	        		 if(!worldIn.isRemote){
	        		boolean b = this != MarkBlocks.BasicTable && this != MarkBlocks.TailoryBench_I && this != MarkBlocks.Anvil_I && this != MarkBlocks.TanningBench_I && this != MarkBlocks.JewelryTable_I && this != MarkBlocks.FletchingTable_I && this != MarkBlocks.Cauldron_I && this != MarkBlocks.WorkBench_I;
	     	    	MarkData p = playerIn.getCapability(MainRegistry.ModMark136Data, null);
	     	    	
	     	    	int SkillID2 = SkillID < 11 && SkillID != 0 ? (12 + SkillID) : (SkillID == 11 ? 28 : 8);
	     	    		
	     	    	
	     	    	
	     	    	
	     	       	 MainRegistry.network.sendTo(new CraftingPacketA(p.XP[SkillID2], SkillID, b, playerIn), (EntityPlayerMP) playerIn);
	        		 }
	     	       	playerIn.openGui( MainRegistry.instance, IGuiHandlerMark.CraftTable , playerIn.worldObj , (int) pos.getX() , (int) pos.getY() , (int) pos.getZ() );
	     	        }
	    			}
	    			else{
	    			TextComponentString component = new TextComponentString(TextFormatting.RED + "this Container is already in use.");
					playerIn.addChatComponentMessage(component);
	    			}
	        }
	        
	        
	           return true;
	        
	        
	        
	    }
	    
	    @Override
		public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {

			IInventory inventory = worldIn.getTileEntity(pos) instanceof IInventory ? (IInventory)worldIn.getTileEntity(pos) : null;

			if (inventory != null){
				// For each slot in the inventory
				for (int i = 0; i < 25; i++){
					// If the slot is not empty
					if (inventory.getStackInSlot(i) != null)
					{
						// Create a new entity item with the item stack in the slot
						EntityItem item = new EntityItem(worldIn, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, inventory.getStackInSlot(i));

						// Apply some random motion to the item
						float multiplier = 0.1f;
						float motionX = worldIn.rand.nextFloat() - 0.5f;
						float motionY = worldIn.rand.nextFloat() - 0.5f;
						float motionZ = worldIn.rand.nextFloat() - 0.5f;

						item.motionX = motionX * multiplier;
						item.motionY = motionY * multiplier;
						item.motionZ = motionZ * multiplier;

						// Spawn the item in the world
						worldIn.spawnEntityInWorld(item);
					}
				}

				// Clear the inventory so nothing else (such as another mod) can do anything with the items
				inventory.clear();
			}
	    }
	    
	    @Override
	    public TileEntity createNewTileEntity(World worldIn, int meta) {
	    	
	    	return new TECraftingTable();
	    }
	    
	   
	    
}
