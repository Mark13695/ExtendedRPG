package com.modMark.Item_Block.Block;

import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.IGrowable;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkCrops extends BlockCrops {
	
		
	
	private Block Ground;
	
	
	public MarkCrops(String unlocalizedName){
		this(unlocalizedName, Blocks.FARMLAND);
	}
	
	public MarkCrops(String unlocalizedName, Block ground){
		
		this.setUnlocalizedName(unlocalizedName);
		this.Ground = ground;
		
	}
	
	protected boolean canPlaceBlockOn(Block ground)
    {
        return ground == this.Ground;
    }
	
	
    
    
 

    protected Item getSeed()
    {
    	if (this == MarkBlocks.OnionCrop){
    		return MarkItems.OnionSeed;
    	}
    	else if (this == MarkBlocks.TomatoCrop){
    		return MarkItems.TomatoSeed;
    	}
    	else if (this == MarkBlocks.BlueberryCrop){
    		return MarkItems.BlueberrySeed;
    	}
    	
    	
    	else if (this == MarkBlocks.CommonCottonCrop){
    		System.out.println(" You killed A CommonCotton Crop!");
    		return MarkItems.CommonCottonSeed;
    	}
    	else if (this == MarkBlocks.GreenCottonCrop){
    		return MarkItems.GreenCottonSeed;
    	}
    	else if (this == MarkBlocks.RedCottonCrop){
    		return MarkItems.RedCottonSeed;
    	}
    	else if (this == MarkBlocks.BlueCottonCrop){
    		return MarkItems.BlueCottonSeed;
    	}
    	else{
        return null;}
    }
    
    protected Item getCrop()
    {
    	if (this == MarkBlocks.OnionCrop){
    		return MarkItems.Onion;
    	}
    	else if (this == MarkBlocks.TomatoCrop){
    		return MarkItems.Tomato;
    	}
    	else if (this == MarkBlocks.BlueberryCrop){
    		return MarkItems.Blueberry;
    	}
    	
    	
    	else if (this == MarkBlocks.CommonCottonCrop){
    		
    		return MarkItems.Cotton20;
    	}
    	else if (this == MarkBlocks.GreenCottonCrop){
    		return MarkItems.Cotton40;
    	}
    	else if (this == MarkBlocks.RedCottonCrop){
    		return MarkItems.Cotton60;
    	}
    	else if (this == MarkBlocks.BlueCottonCrop){
    		return MarkItems.Cotton80;
    	}
    	else{
        return null;}
    }

    
	
	
    
    

}
