package com.modMark.Item_Block.Block;

import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class MarkCrystalBush extends BlockBush {
	
	public MarkCrystalBush(String unlocalizedName, Material material){
		this(unlocalizedName, material , 0.5F, 5.0F);
	}
	
	
	
	public MarkCrystalBush(String unlocalizedName, Material material, float hardness, float resistance){
	this.setUnlocalizedName(unlocalizedName);
	this.setCreativeTab(MainRegistry.tabMark);
	this.setHardness(hardness);
	this.setResistance(resistance);
	this.setSoundType(SoundType.WOOD);
    float f = 0.4F;
    
    
	}
	
	
	 /**
     * is the block grass, dirt or farmland
     */
    protected boolean canPlaceBlockOn(Block ground)
    {
        return ground == MarkBlocks.EnrichedGrass;
    }
    protected boolean canSustainBush(IBlockState state)
    {
    	return state.getBlock() == MarkBlocks.EnrichedGrass;
    }
    /**
     * Get the Item that this Block should drop when harvested.
     */
    public Item getItemDropped(IBlockState state, Random rand, int fortune)
    {
        return null;
    }
	
    public boolean canBlockStay(World worldIn, BlockPos pos, IBlockState state)
    {
        BlockPos down = pos.down();
        IBlockState s = worldIn.getBlockState(down);
        Block soil = s.getBlock();
        if (state.getBlock() != this) return this.canPlaceBlockOn(soil); //Forge: This function is called during world gen and placement, before this block is set, so if we are not 'here' then assume it's the pre-check.
        return soil.canSustainPlant(s, worldIn, down, net.minecraft.util.EnumFacing.UP, this);
    }
	
}
