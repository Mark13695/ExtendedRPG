package com.modMark.Item_Block.Block;

import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Item_Block.TileEntity.TETrap;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;

import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class MarkFullTrap extends Block implements ITileEntityProvider {
	
	public MarkFullTrap(String unlocalizedName) {
        this(unlocalizedName, 0.5f, 5.0f);
    }
	 
	 public MarkFullTrap(String unlocalizedName, float hardness, float resistance) {
        this(unlocalizedName, MarkBlocks.Trap, hardness, resistance);
    }
	 
	public MarkFullTrap(String unlocalizedName, Material material, float hardness, float resistance) {
       super(material);
       this.setUnlocalizedName(unlocalizedName);
       // I'M NOT GONNA ADD THIS IN CREATIVE TAB BECAUSE A FULL TRAP WIL GIVE MUCH XP AND I DON'T LIKE CHEATING
       //this.setCreativeTab(MainRegistry.tabMark);
       this.setHardness(hardness);
       this.setResistance(resistance);
       this.setSoundType(SoundType.METAL);
       
	}
	
	public Item getItemDropped(IBlockState state, Random rand, int fortune)
    {
		return this == MarkBlocks.MarkTrap01 ? Items.RABBIT_HIDE :
			(this == MarkBlocks.MarkTrap10 ? MarkItems.Hide10 :
			(this == MarkBlocks.MarkTrap20 ? MarkItems.Hide20 :
			(this == MarkBlocks.MarkTrap40 ? MarkItems.Hide40 :
			(this == MarkBlocks.MarkTrap60 ? MarkItems.Hide60 :
			(this == MarkBlocks.MarkTrap80 ? MarkItems.Hide80 :	
			(this == MarkBlocks.MarkTrapB ? Item.getItemFromBlock(MarkBlocks.MarkTrapE) : Item.getItemFromBlock(this)))))));
    }
	
	public AxisAlignedBB getCollisionBoundingBox(World worldIn, BlockPos pos, IBlockState state)
    {
        float f = 0.0625F;
        return new AxisAlignedBB((double)((float)pos.getX() + f), (double)pos.getY(), (double)((float)pos.getZ() + f), (double)((float)(pos.getX() + 1) - f), (double)((float)(pos.getY() + 1) - f), (double)((float)(pos.getZ() + 1) - f));
    }
	
	protected boolean canPlaceBlockOn(Block ground)
    {
        return ground == Blocks.SAND || ground == Blocks.HARDENED_CLAY || ground == Blocks.STAINED_HARDENED_CLAY || ground == Blocks.DIRT || ground == Blocks.SOUL_SAND || ground == Blocks.NETHERRACK || ground == MarkBlocks.CrystRack || ground == MarkBlocks.CrystSand || ground == MarkBlocks.EnrichedGrass;
    }
	
	@Override
	public TileEntity createNewTileEntity(World worldIn, int meta) {
		return new TETrap();
	}
	
	public IBlockState setTEPlayer(World world, BlockPos pos, EntityPlayer playerIn){
		
		TileEntity tileentity = world.getTileEntity(pos);
		if (tileentity instanceof TETrap) {
		TETrap TE = (TETrap) tileentity;
		TE.setPlayer(playerIn.getUniqueID());
		}
		return this.getDefaultState();
		
	}
	
	public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
    {
		EntityPlayer player = (EntityPlayer) placer;
		MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
		TileEntity tileentity = worldIn.getTileEntity(pos);
		 if (tileentity instanceof TETrap) {
		TETrap TE = (TETrap) tileentity;
		TE.setPlayer(null);
		TE.setTrapLevel(1);
		
		
		 }
    }

}
