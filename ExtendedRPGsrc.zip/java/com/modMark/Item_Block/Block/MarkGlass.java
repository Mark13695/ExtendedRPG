package com.modMark.Item_Block.Block;

import java.util.Random;

import com.modMark.Main.MainRegistry;

import net.minecraft.block.BlockBreakable;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.BlockRenderLayer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkGlass extends BlockBreakable
{
	public MarkGlass(String unlocalizedName){
		this(unlocalizedName,Material.GLASS, 3.0F, 5.0F);	
	}
	
	
    public MarkGlass(String UnlocalisedName, Material material, float H, float R)
    {
        super(material, false);
        this.setUnlocalizedName(UnlocalisedName);
        this.setCreativeTab(MainRegistry.tabMark);
        this.setHardness(H);
        this.setResistance(R);
        this.setSoundType(SoundType.GLASS);
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random random)
    {
        return 0;
    }

    @SideOnly(Side.CLIENT)
    public BlockRenderLayer getBlockLayer()
    {
        return BlockRenderLayer.CUTOUT;
    }

    public boolean isFullCube(IBlockState state)
    {
        return false;
    }
}
