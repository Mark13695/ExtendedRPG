package com.modMark.Item_Block.Block;

import java.util.List;
import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockPlanks.EnumType;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkLeaf extends BlockLeaves{

	public MarkLeaf(String unlocalizedName) {
        this(unlocalizedName, 0.5f, 3.0f);
    }
	 
	 public MarkLeaf(String unlocalizedName, float hardness, float resistance) {
        this(unlocalizedName, Material.LEAVES, hardness, resistance);
    }
	
		public MarkLeaf(String unlocalizedName, Material material, float hardness, float resistance) {
		 super();
		this.setDefaultState(this.blockState.getBaseState().withProperty(CHECK_DECAY, Boolean.valueOf(true)).withProperty(DECAYABLE, Boolean.valueOf(true)));
		this.setUnlocalizedName(unlocalizedName);
		this.setCreativeTab(MainRegistry.tabMark);
		this.setSoundType(SoundType.PLANT);
	}
		
		
	@Override
	public List<ItemStack> onSheared(ItemStack item, IBlockAccess world, BlockPos pos, int fortune) {
		
		IBlockState state = world.getBlockState(pos);
		return new java.util.ArrayList(java.util.Arrays.asList(new ItemStack(this, 1, 0)));
	}
	
	public IBlockState getStateFromMeta(int meta) {
		return this.getDefaultState().withProperty(DECAYABLE, Boolean.valueOf((meta & 4) == 0)).withProperty(CHECK_DECAY, Boolean.valueOf((meta & 8) > 0));
	}

	public int getMetaFromState(IBlockState state) {
		byte b = 0;
		int i = b;

		if (!((Boolean) state.getValue(DECAYABLE)).booleanValue()) {
			i |= 4;
		}

		if (((Boolean) state.getValue(CHECK_DECAY)).booleanValue()) {
			i |= 8;
		}

		return i;
	}

	
	@Override
	public EnumType getWoodType(int meta) {
		
		return null;
	}

	
	protected BlockStateContainer createBlockState()
    {
        return new BlockStateContainer(this, new IProperty[] {CHECK_DECAY, DECAYABLE});
    }

	@Override
	@SideOnly(Side.CLIENT)
	 public BlockRenderLayer getBlockLayer()
    {
		Block block = blockState.getBlock();
		return Blocks.LEAVES.getBlockLayer();
	}
	
	public int colorMultiplier(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        return this == MarkBlocks.LogYew_Leaf ? 64636 : (
        this == MarkBlocks.LogNetherBranch_Leaf ? 3755981 : (
        this == MarkBlocks.LogCrystWood_Leaf ? 15570276 : 16777215));
    }
	
	 public Item getItemDropped(IBlockState state, Random rand, int fortune)
	    {
	        return state == MarkBlocks.LogYew_Leaf.getDefaultState() ? Item.getItemFromBlock(MarkBlocks.LogYew_Sapling) :
	        	(state == MarkBlocks.LogNetherBranch_Leaf.getDefaultState() ? Item.getItemFromBlock(MarkBlocks.LogNetherBranch_Sapling) :
	        		(state == MarkBlocks.LogCrystWood_Leaf.getDefaultState() ? Item.getItemFromBlock(MarkBlocks.LogCrystWood_Sapling) :
	        			Item.getItemFromBlock(MarkBlocks.LogYew_Sapling)));
	    }
}
