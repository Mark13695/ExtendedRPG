package com.modMark.Item_Block.Block;

import com.modMark.Main.MainRegistry;

import net.minecraft.block.BlockLog;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class MarkLog extends BlockLog {

	public MarkLog(String unlocalizedName) {
        this(unlocalizedName, 3.0f, 10.0f);
    }
	 
	 public MarkLog(String unlocalizedName, float hardness, float resistance) {
        this(unlocalizedName, Material.WOOD, hardness, resistance);
    }
	 
	public MarkLog(String unlocalizedName, Material material, float hardness, float resistance) {
       super();
       this.setUnlocalizedName(unlocalizedName);
       this.setCreativeTab(MainRegistry.tabMark);
       this.setHardness(hardness);
       this.setResistance(resistance);
       this.setSoundType(SoundType.WOOD);
	}	
	
	public IBlockState getStateFromMeta(int meta)
    {
        IBlockState state = this.getDefaultState();

        switch (meta & 12)
        {
            case 0:
                state = state.withProperty(LOG_AXIS, BlockLog.EnumAxis.Y);
                break;

            case 4:
                state = state.withProperty(LOG_AXIS, BlockLog.EnumAxis.X);
                break;

            case 8:
                state = state.withProperty(LOG_AXIS, BlockLog.EnumAxis.Z);
                break;

            default:
                state = state.withProperty(LOG_AXIS, BlockLog.EnumAxis.NONE);
                break;
        }

        return state;
    }

    /**
     * Convert the BlockState into the correct metadata value
     */
	@SuppressWarnings("incomplete-switch")
    public int getMetaFromState(IBlockState state)
    {
		int i = 0;
        switch ((BlockLog.EnumAxis)state.getValue(LOG_AXIS))
        {
            case X: 
            	i |= 4;
            	break;
            case Z: 
            	i |= 8;
            	break;
            case NONE: 
            	i |= 12;
            	break;
        }
        return i;
    }

	 protected BlockStateContainer createBlockState()
	    {
	        return new BlockStateContainer(this, new IProperty[] {LOG_AXIS});
	    }
        
    
    
    
}
