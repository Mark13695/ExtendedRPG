package com.modMark.Item_Block.Block;

import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class MarkPlanks extends Block {
	
	public MarkPlanks(String unlocalizedName) {
        this(unlocalizedName, 3.0f, 5.0f);
    }
	 
	 public MarkPlanks(String unlocalizedName, float hardness, float resistance) {
        this(unlocalizedName, Material.WOOD, hardness, resistance);
    }
	 
	public MarkPlanks(String unlocalizedName, Material material, float hardness, float resistance) {
       super(material);
       this.setUnlocalizedName(unlocalizedName);
       this.setCreativeTab(MainRegistry.tabMark);
       this.setHardness(hardness);
       this.setResistance(resistance);
       this.setSoundType(SoundType.WOOD);
	}	
}