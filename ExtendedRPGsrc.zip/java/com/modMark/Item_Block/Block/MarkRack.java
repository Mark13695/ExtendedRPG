package com.modMark.Item_Block.Block;

import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class MarkRack extends Block {

	
	
	public MarkRack(String unlocalizedName) {
        this(unlocalizedName, 3.0f, 5.0f);
    }
	 
	 public MarkRack(String unlocalizedName, float hardness, float resistance) {
        this(unlocalizedName, Material.ROCK, hardness, resistance);
    }
	 
	public MarkRack(String unlocalizedName, Material material, float hardness, float resistance) {
       super(material);
       this.setUnlocalizedName(unlocalizedName);
       this.setCreativeTab(MainRegistry.tabMark);
       this.setHardness(hardness);
       this.setResistance(resistance);
       this.setSoundType(SoundType.STONE);
	}	
}
