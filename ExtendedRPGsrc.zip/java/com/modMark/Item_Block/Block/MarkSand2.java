package com.modMark.Item_Block.Block;

import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.IGrowable;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;


public class MarkSand2 extends Block implements IGrowable {
	
	
	
	public MarkSand2(String unlocalizedName, int HarvestLvl) {
        this(unlocalizedName, 0.5f, 2.0f, HarvestLvl);
    }
	 
	 public MarkSand2(String unlocalizedName, float hardness, float resistance, int HarvestLvl) {
        this(unlocalizedName, Material.SAND , hardness, resistance, HarvestLvl);
    }
	 
	public MarkSand2(String unlocalizedName, Material material, float hardness, float resistance, int HarvestLvl) {
       super(material);
       this.setUnlocalizedName(unlocalizedName);
       this.setCreativeTab(MainRegistry.tabMark);
       this.setHardness(hardness);
       this.setResistance(resistance);
       this.setSoundType(SoundType.SAND);
	}	
	

	
	 public boolean isFireSource(World world, BlockPos pos, EnumFacing side)
	    {
	        if (this == MarkBlocks.NetherSand && side == EnumFacing.UP)
	        {
	            return true;
	        }
	        return false;
	    }

	@Override
	public boolean canGrow(World worldIn, BlockPos pos, IBlockState state, boolean isClient) {
		
		return true;
	}

	@Override
	public boolean canUseBonemeal(World worldIn, Random rand, BlockPos pos, IBlockState state) {
		
		return true;
	}

	@Override
	public void grow(World worldIn, Random rand, BlockPos pos, IBlockState state) {
		{
	        BlockPos blockpos = pos.up();

	        for (int i = 0; i < 128; ++i)
	        {
	            BlockPos blockpos1 = blockpos;
	            int j = 0;

	            while (true)
	            {
	                if (j >= i / 16)
	                {
	                    if (worldIn.isAirBlock(blockpos1))
	                    {
	                     
	                            IBlockState iblockstate1 = MarkBlocks.TallGrass60.getDefaultState();
	                            IBlockState iblockstate2 = MarkBlocks.TallGrass80.getDefaultState();

	                            if (((BlockBush) MarkBlocks.TallGrass60).canBlockStay(worldIn, blockpos1, iblockstate1) && rand.nextInt(9) == 0)
	                            {
	                                worldIn.setBlockState(blockpos1, iblockstate1, 3);
	                            }
	                            if (((BlockBush) MarkBlocks.TallGrass80).canBlockStay(worldIn, blockpos1, iblockstate2) && rand.nextInt(9) == 0)
	                            {
	                                worldIn.setBlockState(blockpos1, iblockstate2, 3);
	                            }
	                       
	                    }

	                    break;
	                }

	                blockpos1 = blockpos1.add(rand.nextInt(3) - 1, (rand.nextInt(3) - 1) * rand.nextInt(3) / 2, rand.nextInt(3) - 1);

	                if (worldIn.getBlockState(blockpos1.down()).getBlock() != MarkBlocks.NetherSand || worldIn.getBlockState(blockpos1.down()).getBlock() != MarkBlocks.CrystSand || worldIn.getBlockState(blockpos1).getBlock().isNormalCube(state, worldIn, blockpos1))
	                {
	                    break;
	                }

	                ++j;
	            }
	        }
	    }
		
	}
	
	
	

}
