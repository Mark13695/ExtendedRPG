package com.modMark.Item_Block.Block;

import java.util.List;
import java.util.Random;
import java.util.UUID;

import javax.annotation.Nullable;

import com.modMark.Generator.MarkGen;
import com.modMark.Generator.WorldGenMarkTrees;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.TileEntity.TESapling;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockSapling;
import net.minecraft.block.IGrowable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenBigTree;
import net.minecraft.world.gen.feature.WorldGenTrees;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class MarkSapling extends BlockBush implements IGrowable, ITileEntityProvider {
	public IBlockState StateA;
	public IBlockState StateB;

	public static final PropertyInteger STAGE = PropertyInteger.create("stage", 0, 1);
	
	public MarkSapling(String unlocalizedName) {
        this(unlocalizedName, 0.0f, 3.0f, MarkBlocks.LogYew.getDefaultState(), MarkBlocks.LogYew_Leaf.getDefaultState());
    }
	
	public MarkSapling(String unlocalizedName, IBlockState metaWood, IBlockState metaLeaves) {
        this(unlocalizedName, 0.0f, 3.0f, metaWood, metaLeaves);
    }
	 
	 public MarkSapling(String unlocalizedName, float hardness, float resistance, IBlockState metaWood, IBlockState metaLeaves) {
        this(unlocalizedName, Material.WOOD, hardness, resistance, metaWood, metaLeaves);
    }
	 
	public MarkSapling(String unlocalizedName, Material material, float hardness, float resistance, IBlockState metaWood, IBlockState metaLeaves) {
        super();	
		float f = 0.4F;
        this.setUnlocalizedName(unlocalizedName);
        this.setCreativeTab(MainRegistry.tabMark);
        this.setHardness(hardness);
        this.setResistance(resistance);
        this.setSoundType(SoundType.WOOD);
        this.setMeta(metaWood, metaLeaves);
        
		
	}
	
	public void setMeta(IBlockState metaWood, IBlockState metaLeaves){
		
		this.StateA = metaWood;
		this.StateB = metaLeaves;
		
	}
	
	 public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand)
	    {
	        if (!worldIn.isRemote)
	        {
	            super.updateTick(worldIn, pos, state, rand);
	            
	            if(this == MarkBlocks.LogNetherBranch_Sapling || this == MarkBlocks.LogCrystWood_Sapling){
	            	if(rand.nextInt(7) == 0){
	            	this.grow(worldIn, pos, state, rand);
	            	}
	            }
	            else{
	            if (worldIn.getLightFromNeighbors(pos.up()) >= 9 && rand.nextInt(7) == 0)
	            {
	                this.grow(worldIn, pos, state, rand);
	            }
	            }
	        }
	    }
	 
	 
	 protected boolean canPlaceBlockOn(Block ground)
	    {
	   if(this == MarkBlocks.LogCrystWood_Sapling){
	        return  ground == MarkBlocks.CrystSand;
	   }
	   else if (this == MarkBlocks.LogNetherBranch_Sapling){
		   
		   return ground == Blocks.SOUL_SAND || ground == MarkBlocks.NetherSand;
	   }
	   else if (this == MarkBlocks.LogYew_Sapling){
		   return ground == MarkBlocks.EnrichedGrass || ground == Blocks.DIRT || ground == Blocks.FARMLAND;
	   }
	   else{
	        return ground == Blocks.GRASS || ground == Blocks.DIRT || ground == Blocks.FARMLAND;
	    }
	    }
	 @Override
	 protected boolean canSustainBush(IBlockState state)
	    {
		 if(this == MarkBlocks.LogCrystWood_Sapling){
		        return  state.getBlock() == MarkBlocks.CrystSand;
		   }
		   else if (this == MarkBlocks.LogNetherBranch_Sapling){
			   
			   return state.getBlock() == Blocks.SOUL_SAND || state.getBlock() == MarkBlocks.NetherSand;
		   }
		   else if (this == MarkBlocks.LogYew_Sapling){
			   return state.getBlock() == MarkBlocks.EnrichedGrass;
		   }
		   else{
		        return state.getBlock() == Blocks.GRASS || state.getBlock() == Blocks.DIRT || state.getBlock() == Blocks.FARMLAND;
		    }
		     }

	    public void grow(World worldIn, BlockPos pos, IBlockState state, Random rand)
	    {
	        if (((Integer)state.getValue(STAGE)).intValue() == 0)
	        {
	            worldIn.setBlockState(pos, state.cycleProperty(STAGE), 4);
	        }
	        else
	        {
	            this.generateTree(worldIn, pos, state, rand);
	        }
	    }
	    
	    public void generateTree(World worldIn, BlockPos pos, IBlockState state, Random rand)
	    {
	        if (!net.minecraftforge.event.terraingen.TerrainGen.saplingGrowTree(worldIn, rand, pos)) return;
	        WorldGenerator worldgenerator = (WorldGenerator)(rand.nextInt(10) == 0 ? new WorldGenBigTree(true) : new WorldGenTrees(true));
	        int i = 0;
	        int j = 0;
	        boolean flag = false;
	        int BlockIDm = this == MarkBlocks.LogNetherBranch_Sapling ? 1 : (this == MarkBlocks.LogCrystWood_Sapling ? 2 : 0);
	        TileEntity tileentity = worldIn.getTileEntity(pos);
	    	if(tileentity instanceof TESapling){
	    		TESapling TE = (TESapling) tileentity;
	    	EntityPlayer player = this.getPlayerEntityByUUID(TE.getPlayer());
	    	MarkData p = player == null ? null : player.getCapability(MainRegistry.ModMark136Data, null);
	    	if (p != null){p.addXp(7, BlockIDm == 1 ? 120 : (BlockIDm == 2 ? 145 : 85));}
	    	

	    	}
	        
	        if(rand.nextInt(9) > 0){
	        worldgenerator = new WorldGenMarkTrees(true, false, this.StateA , this.StateB , false);
	        }
	        else{
	        worldgenerator = new WorldGenMarkTrees(true, true, this.StateA , this.StateB , false);
	        }
	        
	        
	        IBlockState iblockstate2 = Blocks.AIR.getDefaultState();

	        if (flag)
	        {
	            worldIn.setBlockState(pos.add(i, 0, j), iblockstate2, 4);
	            worldIn.setBlockState(pos.add(i + 1, 0, j), iblockstate2, 4);
	            worldIn.setBlockState(pos.add(i, 0, j + 1), iblockstate2, 4);
	            worldIn.setBlockState(pos.add(i + 1, 0, j + 1), iblockstate2, 4);
	        }
	        else
	        {
	            worldIn.setBlockState(pos, iblockstate2, 4);
	        }

	        if (!worldgenerator.generate(worldIn, rand, pos.add(i, 0, j)))
	        {
	            if (flag)
	            {
	                worldIn.setBlockState(pos.add(i, 0, j), state, 4);
	                worldIn.setBlockState(pos.add(i + 1, 0, j), state, 4);
	                worldIn.setBlockState(pos.add(i, 0, j + 1), state, 4);
	                worldIn.setBlockState(pos.add(i + 1, 0, j + 1), state, 4);
	            }
	            else
	            {
	                worldIn.setBlockState(pos, state, 4);
	            }
	        }
	    }
	    
	    @Nullable
	    public EntityPlayer getPlayerEntityByUUID(UUID uuid)
	    {
	    	List <EntityPlayerMP> players =  FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().getPlayerList();
	    	EntityPlayerMP[] playerEntities = new EntityPlayerMP[players.size()];
	    	playerEntities = players.toArray(playerEntities);
	        for (int i = 0; i < playerEntities.length; ++i)
	        {
	            EntityPlayer entityplayer = (EntityPlayer) playerEntities[i];

	            if (uuid.equals(entityplayer.getUniqueID()))
	            {
	                return entityplayer;
	            }
	        }

	        return null;
	    }
	    
	    public boolean canGrow(World worldIn, BlockPos pos, IBlockState state, boolean isClient)
	    {
	        return true;
	    }
	    
	    public void grow(World worldIn, Random rand, BlockPos pos, IBlockState state)
	    {
	        this.grow(worldIn, pos, state, rand);
	    }
	    
	    /**
	     * Convert the given metadata into a BlockState for this Block
	     */
	    public IBlockState getStateFromMeta(int meta)
	    {
	        return this.getDefaultState().withProperty(STAGE, Integer.valueOf((meta & 8) >> 3));
	    }

	    /**
	     * Convert the BlockState into the correct metadata value
	     */
	    public int getMetaFromState(IBlockState state)
	    {
	        int i = 0;
	        i = i | ((Integer)state.getValue(STAGE)).intValue() << 3;
	        return i;
	    }

	    protected BlockStateContainer createBlockState()
	    {
	        return new BlockStateContainer(this, new IProperty[] {STAGE});
	    }

		@Override
		public boolean canUseBonemeal(World worldIn, Random rand, BlockPos pos, IBlockState state) {
			
			return false;
		}
		
		 public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
		    {
		    	TileEntity tileentity = worldIn.getTileEntity(pos);
		    	if(tileentity instanceof TESapling){
		    		TESapling TE = (TESapling) tileentity;
		    		if (placer instanceof EntityPlayer){
		    		EntityPlayer player = (EntityPlayer) placer;
		    		
		    		TE.setPlayer(player.getUniqueID());
		    		
		    	}
		    	}
		    }
		    
		    @Override
			public TileEntity createNewTileEntity(World worldIn, int meta) {
				return new TESapling();
			}
	    
}
