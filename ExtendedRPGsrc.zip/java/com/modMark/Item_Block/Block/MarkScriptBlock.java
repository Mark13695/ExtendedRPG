package com.modMark.Item_Block.Block;

import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;

public class MarkScriptBlock extends Block {

	private Random rand;
	
	public MarkScriptBlock(String unlocalizedName) {
        this(unlocalizedName, 0.4f, 3.0f);
    }
	
	public MarkScriptBlock(String unlocalizedName, float hardness, float resistance) {
        this(unlocalizedName, Material.GROUND, hardness, resistance);
    }
	 
	public MarkScriptBlock(String unlocalizedName, Material material, float hardness, float resistance) {
       super(material);
       this.setUnlocalizedName(unlocalizedName);
       this.setCreativeTab(MainRegistry.tabMark);
       this.setHardness(hardness);
       this.setResistance(resistance);
       this.setSoundType(SoundType.STONE);
	}	
	public Item getItemDropped(IBlockState state, Random rand, int fortune)
   {
		return this == MarkBlocks.Script01 || this == MarkBlocks.Script05 || this == MarkBlocks.Script10 || this == MarkBlocks.Script15 || this == MarkBlocks.Script20 || this == MarkBlocks.Script30 || this == MarkBlocks.Script40 ? Item.getItemFromBlock(Blocks.COBBLESTONE)  
				:(this == MarkBlocks.Script50 || this == MarkBlocks.Script60 || this == MarkBlocks.Script65 ?  Item.getItemFromBlock(Blocks.NETHERRACK)
				:(this == MarkBlocks.Script75 || this == MarkBlocks.Script80 || this == MarkBlocks.Script85 ?  Item.getItemFromBlock(MarkBlocks.CrystRack)
				: Item.getItemFromBlock(this)));
   }
   
	
	
	
	
	
}
