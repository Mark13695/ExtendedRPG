package com.modMark.Item_Block.Block;

import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;

public class MarkStairs extends BlockStairs {

	public MarkStairs(String UnlocalizedName, IBlockState state) {
		super(state);
		this.setUnlocalizedName(UnlocalizedName);
		this.setCreativeTab(MainRegistry.tabMark);
	}

}
