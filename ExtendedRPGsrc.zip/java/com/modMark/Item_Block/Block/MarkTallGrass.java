package com.modMark.Item_Block.Block;

import java.util.List;
import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockDoublePlant;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.IGrowable;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.ColorizerGrass;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkTallGrass extends BlockBush implements IGrowable, net.minecraftforge.common.IShearable {

	public MarkTallGrass(String UnlocalizedName){
		 this(UnlocalizedName, 0.5f, 5.0f);
		
	}
	public MarkTallGrass(String unlocalizedName, float hardness, float resistance){
		this(unlocalizedName, Material.VINE, hardness, resistance);
		
	}
	
	public MarkTallGrass(String UnlocalizedName,Material material, float hardness, float resistance){
		
        this.setUnlocalizedName(UnlocalizedName);
        this.setCreativeTab(MainRegistry.tabMark);
        float f = 0.4F;
        
		
		
	}
	
	
	
	 public boolean canBlockStay(World worldIn, BlockPos pos, IBlockState state)
	 {
	        return super.canBlockStay(worldIn, pos, state);
	 }
	 
	 /**
	  * Whether this Block can be replaced directly by other blocks (true for e.g. tall grass)
	  */
	 public boolean isReplaceable(World worldIn, BlockPos pos)
	 {
	    return true;
	 }
	 
	 
	    public Item getItemDropped(IBlockState state, Random rand, int fortune)
	    {
	    	Block block = state.getBlock();
	    	Random random = new Random();
    		int ra = random.nextInt(49999);
	    	if (block == MarkBlocks.TallGrass40){
	    		
	    		if(ra == 0){
	    			return MarkItems.CrystliumBar;
	    		}
	    		else if(ra == 1 || ra == 2){
	    			return MarkItems.GemAquamarine;
	    		}
	    		else if(ra == 3 || ra == 4){
	    			return new ItemStack(MarkItems.Leather80, 2).getItem();
	    		}
	    		else if(ra >= 5 && ra < 10){
	    			return MarkItems.NetheriteBar;
	    		}
	    		else if(ra >= 10 && ra < 20){
	    			return MarkItems.GemSiam;
	    		}
	    		else if(ra >= 20 && ra < 30){
	    			return new ItemStack(MarkItems.Leather60, 2).getItem();
	    		}
	    		else if(ra >= 30 && ra < 40){
	    			return new ItemStack(Items.IRON_INGOT, 15).getItem();
	    		}
	    		else if(ra >= 40 && ra < 50){
	    			return new ItemStack(Items.GOLD_INGOT, 15).getItem();
	    		}
	    		else if(ra >= 50 && ra < 100){
	    			return Items.DIAMOND;
	    		}
	    		else if(ra >= 100 && ra < 200){
	    			return MarkItems.GemAmethyst;
	    		}
	    		else if(ra >= 200 && ra < 1200){
	    			return new ItemStack(MarkItems.Herb, 1, 8).getItem();
	    		}
	    		else if(ra >= 1200 && ra < 2200){
	    			return new ItemStack(MarkItems.Herb, 1, 10).getItem();
	    		}
	    		else if(ra >= 2200 && ra < 3200){
	    			return new ItemStack(MarkItems.Herb, 1, 12).getItem();
	    		}
	    		else if(ra >= 3200 && ra < 4200){
	    			return new ItemStack(MarkItems.Herb, 1, 14).getItem();
	    		}
	    		else if(ra >= 4200 && ra < 5200){
	    			return MarkItems.SarrietteSeed;
	    		}
	    		else if(ra >= 5200 && ra < 6200){
	    			return MarkItems.ArmoiseSeed;
	    		}
	    		else if(ra >= 6200 && ra < 7200){
	    			return MarkItems.CerfeuilSeed;
	    		}
	    		else if(ra >= 7200 && ra < 8200){
	    			return MarkItems.EstragonSeed;
	    		}
	    		else if(ra >= 8200 && ra < 11980){
	    			return MarkItems.OnionSeed;
	    		}
	    		else if(ra >= 11980 && ra < 12000){
	    			return MarkItems.TomatoSeed;
	    		}
	    		else if(ra >= 12000 && ra < 14980){
	    			return MarkItems.GreenCottonSeed;
	    		}
	    		else if(ra >= 14980 && ra < 15000){
	    			return MarkItems.RedCottonSeed;
	    		}
	    		else{return null;}
	    	}
	    	else if (block == MarkBlocks.TallGrass60){
	    		if (ra >= 0 && ra < 10){
	    			return MarkItems.CrystliumBar;
	    		}
	    		else if (ra >= 10 && ra < 30){
	    			return MarkItems.GemAquamarine;
	    		}
	    		else if (ra >= 30 && ra < 50){
	    			return new ItemStack(MarkItems.Leather80, 2).getItem();
	    		}
	    		else if (ra >= 50 && ra < 75){
	    			return MarkItems.NetheriteBar;
	    		}
	    		else if (ra >= 75 && ra < 125){
	    			return MarkItems.GemSiam;
	    		}
	    		else if (ra >= 125 && ra < 175){
	    			return new ItemStack(MarkItems.Leather60, 2).getItem();
	    		}
	    		else if (ra >= 175 && ra < 200){
	    			return MarkItems.BlueberrySeed;
	    		}
	    		else if (ra >= 200 && ra < 1700){
	    			return MarkItems.NetherweedSeed;
	    		}
	    		else if (ra >= 1700 && ra < 3200){
	    			return MarkItems.FlameweedSeed;
	    		}
	    		else if (ra >= 3200 && ra < 4700){
	    			return MarkItems.BrutalRedSeed;
	    		}
	    		else if (ra >= 4700 && ra < 6200){
	    			return new ItemStack(MarkItems.Herb, 1, 16).getItem();
	    		}
	    		else if (ra >= 6200 && ra < 7700){
	    			return new ItemStack(MarkItems.Herb, 1, 18).getItem();
	    		}
	    		else if (ra >= 7700 && ra < 9200){
	    			return new ItemStack(MarkItems.Herb, 1, 20).getItem();
	    		}
	    		else if (ra >= 9200 && ra < 12000){
	    			return MarkItems.TomatoSeed;
	    		}
	    		else if (ra >= 12000 && ra < 15000){
	    			return MarkItems.RedCottonSeed;
	    		}
	    		else{return null;}
	    	}
	    	else if(block == MarkBlocks.TallGrass80){
	    		if (ra >= 0 && ra < 25){
	    			return MarkItems.CrystliumBar;
	    		}
	    		else if (ra >= 25 && ra < 75){
	    			return MarkItems.GemAquamarine;
	    		}
	    		else if (ra >= 75 && ra < 125){
	    			return new ItemStack(MarkItems.Leather80, 2).getItem();
	    		}
	    		else if (ra >= 125 && ra < 3000){
	    			return MarkItems.BlueberrySeed;
	    		}
	    		else if (ra >= 3000 && ra < 4000){
	    			return new ItemStack(MarkItems.Herb, 1, 22).getItem();
	    		}
	    		else if (ra >= 4000 && ra < 5000){
	    			return new ItemStack(MarkItems.Herb, 1, 22).getItem();
	    		}
	    		else if (ra >= 5000 && ra < 6000){
	    			return new ItemStack(MarkItems.Herb, 1, 22).getItem();
	    		}
	    		else if (ra >= 6000 && ra < 7000){
	    			return MarkItems.CrystweedSeed;
	    		}
	    		else if (ra >= 7000 && ra < 8000){
	    			return MarkItems.DarkCrystalSeed;
	    		}
	    		else if (ra >= 8000 && ra < 9000){
	    			return MarkItems.BrutalBlueSeed;
	    		}
	    		else if (ra >= 9000 && ra < 12000){
	    			return MarkItems.BlueCottonSeed;
	    		}
	    		
	    		else{return null;}
	    	}
	    	
	    	else{return null;}
	        
	    }
	
	   
	    
	    public void harvestBlock(World worldIn, EntityPlayer player, BlockPos pos, IBlockState state, TileEntity te)
	    {
	        {
	            super.harvestBlock(worldIn, player, pos, state, te, null);
	        }
	    }
	    
	    
	    protected boolean canPlaceBlockOn(Block ground)
	    {
	    if(this == MarkBlocks.TallGrass40)
	    {
	        return ground == MarkBlocks.EnrichedGrass;
	    }
	    else if(this == MarkBlocks.TallGrass60){
	    	return ground == Blocks.SOUL_SAND || ground == MarkBlocks.NetherSand;
	    }
	    else{
	    	return ground == MarkBlocks.CrystSand;
	    }
	    
	    }
	    @Override
	    protected boolean canSustainBush(IBlockState state)
	    {
	    	if(this == MarkBlocks.TallGrass40)
		    {
		        return state.getBlock() == MarkBlocks.EnrichedGrass;
		    }
		    else if(this == MarkBlocks.TallGrass60){
		    	return state.getBlock() == Blocks.SOUL_SAND || state.getBlock() == MarkBlocks.NetherSand;
		    }
		    else{
		    	return state.getBlock() == MarkBlocks.CrystSand;
		    }
	    	
	    }
	    
	@Override
	public boolean isShearable(ItemStack item, IBlockAccess world, BlockPos pos) {
		
		return true;
	}

	@Override
	public List<ItemStack> onSheared(ItemStack item, IBlockAccess world, BlockPos pos, int fortune) {
		
		 List<ItemStack> ret = new java.util.ArrayList<ItemStack>();
	        ret.add(new ItemStack(this, 1));
	        return ret;
	}

	@Override
	public boolean canGrow(World worldIn, BlockPos pos, IBlockState state, boolean isClient) {
		
		return true;
	}

	@Override
	public boolean canUseBonemeal(World worldIn, Random rand, BlockPos pos, IBlockState state) {
		
		return true;
	}

	@Override
	public void grow(World worldIn, Random rand, BlockPos pos, IBlockState state) {
		
		
	}

}
