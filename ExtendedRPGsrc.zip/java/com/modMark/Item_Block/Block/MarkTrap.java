package com.modMark.Item_Block.Block;

import java.util.UUID;

import com.modMark.Combat.MarkDamageSrc;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.TileEntity.TETrap;
import com.modMark.Main.MainRegistry;
import com.modMark.Mob.EntitySalaBlue;
import com.modMark.Mob.EntitySalaCommon;
import com.modMark.Mob.EntitySalaDesert;
import com.modMark.Mob.EntitySalaGreen;
import com.modMark.Mob.EntitySalaRed;
import com.modMark.Skill.MarkData;

import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityRabbit;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkTrap extends Block implements ITileEntityProvider {
	
	protected static final AxisAlignedBB TRAP_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 0.9375D, 0.9375D);
    protected static final AxisAlignedBB TRAP_COLLISION_AABB = new AxisAlignedBB(0.0625D, 0.0D, 0.0625D, 0.9375D, 1.0D, 0.9375D);

	
	public MarkTrap(String unlocalizedName) {
        this(unlocalizedName, 0.5f, 5.0f);
    }
	 
	 public MarkTrap(String unlocalizedName, float hardness, float resistance) {
        this(unlocalizedName, MarkBlocks.Trap, hardness, resistance);
    }
	 
	public MarkTrap(String unlocalizedName, Material material, float hardness, float resistance) {
       super(material);
       this.setUnlocalizedName(unlocalizedName);
       this.setCreativeTab(MainRegistry.tabMark);
       this.setHardness(hardness);
       this.setResistance(resistance);
       this.setSoundType(SoundType.METAL);
       
	}
	
	public AxisAlignedBB getCollisionBoundingBox(IBlockState blockState, World worldIn, BlockPos pos)
    {
        return TRAP_AABB;
    }

    @SideOnly(Side.CLIENT)
    public AxisAlignedBB getSelectedBoundingBox(IBlockState state, World worldIn, BlockPos pos)
    {
        return TRAP_COLLISION_AABB.offset(pos);
    }

    public boolean isFullCube(IBlockState state)
    {
        return false;
    }

    /**
     * Used to determine ambient occlusion and culling when rebuilding chunks for render
     */
    public boolean isOpaqueCube(IBlockState state)
    {
        return false;
    }
    
	
	 public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn)
	    {
		 TileEntity tileentity = worldIn.getTileEntity(pos);
		 if (tileentity instanceof TETrap) {
		 TETrap TE = (TETrap) tileentity; 
	   
	    if(entityIn instanceof EntityRabbit){
	    	ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrap01, true, TE.getPlayer(), TE.getTrapLevel());
	        }
		 
	    
		else if(entityIn instanceof EntitySalaCommon && TE.getTrapLevel() >= 10){
			ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrap10, true, TE.getPlayer(), TE.getTrapLevel());
			}
		else if(entityIn instanceof EntitySalaCommon && TE.getTrapLevel() < 10){
			ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrapB, false, TE.getPlayer(), TE.getTrapLevel());
		}
		
	    
	    else if(entityIn instanceof EntitySalaDesert && TE.getTrapLevel() >= 20){
	    	ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrap20, true, TE.getPlayer(), TE.getTrapLevel());
			}
		else if(entityIn instanceof EntitySalaDesert && TE.getTrapLevel() < 20){
			ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrapB, false, TE.getPlayer(), TE.getTrapLevel());
		}
	    
	    
		else if(entityIn instanceof EntitySalaGreen && TE.getTrapLevel() >= 40){
			ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrap40, true, TE.getPlayer(), TE.getTrapLevel());
			}
		else if(entityIn instanceof EntitySalaGreen && TE.getTrapLevel() < 40){
			ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrapB, false, TE.getPlayer(), TE.getTrapLevel());
		}
	    
	    
		else if(entityIn instanceof EntitySalaRed && TE.getTrapLevel() >= 60){
			ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrap60, true, TE.getPlayer(), TE.getTrapLevel());
		}
		else if(entityIn instanceof EntitySalaRed && TE.getTrapLevel() < 60){
			ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrapB, false, TE.getPlayer(), TE.getTrapLevel());
		}
	    
	    
		else if(entityIn instanceof EntitySalaBlue && TE.getTrapLevel() >= 80){
			ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrap80, true, TE.getPlayer(), TE.getTrapLevel());
			}
		else if(entityIn instanceof EntitySalaBlue && TE.getTrapLevel() < 80){
			ChangeBlock(pos, worldIn, entityIn, MarkBlocks.MarkTrapB, false, TE.getPlayer(), TE.getTrapLevel());
		}
		else if(entityIn instanceof EntityPlayer){}
		else{}
		 }
		}
		
	 protected void ChangeBlock(BlockPos pos, World world, Entity entity, Block newBlock, Boolean isCaught, UUID player, int Level){
		 world.setBlockState(pos, newBlock.getDefaultState());
		 if(isCaught){
	     entity.attackEntityFrom(MarkDamageSrc.CapturedByTrap, 50000.0F);
		 }
		 
		 if(world.getBlockState(pos) == newBlock.getDefaultState()){
			 if(world.getTileEntity(pos) != null){
				 if(player != null && Level != 0){
					 TileEntity tileentity = world.getTileEntity(pos);
					 if (tileentity instanceof TETrap) {
					 TETrap TE = (TETrap) tileentity;
					 
					 TE.setPlayer(player);
					 TE.setTrapLevel(Level);
					 }
				 }
				 else{
					 System.err.println((player == null) + " / " + (Level == 0));
				 }
			 }
			 else{
				 System.err.println("TE = null!");
			 }
		 }
		 else{
			 System.err.println("Block = " + world.getBlockState(pos).getBlock().toString());
			 
		 }
	 }
	 
	 protected boolean canPlaceBlockOn(Block ground)
	    {
	        return ground == Blocks.SAND || ground == Blocks.HARDENED_CLAY || ground == Blocks.STAINED_HARDENED_CLAY || ground == Blocks.DIRT || ground == Blocks.SOUL_SAND || ground == Blocks.NETHERRACK || 
	        	   ground == MarkBlocks.CrystRack || ground == MarkBlocks.CrystSand || ground == MarkBlocks.EnrichedGrass || ground == Blocks.GRASS;
	    }
		
		
	
	
	
	public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack)
    {
		TileEntity tileentity = worldIn.getTileEntity(pos);
		 if (tileentity instanceof TETrap) {
		TETrap TE = (TETrap) tileentity;
		if (placer instanceof EntityPlayer){
		EntityPlayer player = (EntityPlayer) placer;
		MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
		
		
		TE.setPlayer(player.getUniqueID());
		TE.setTrapLevel(p.Level[9]);
		}
		

		 }
			
    }
	
	
	

    
    @SideOnly(Side.CLIENT)
    public BlockRenderLayer getBlockLayer()
    {
        return BlockRenderLayer.CUTOUT;
    }

	@Override
	public TileEntity createNewTileEntity(World worldIn, int meta) {
		return new TETrap();
	}
}
