package com.modMark.Item_Block.Fluid;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fluids.BlockFluidClassic;
import net.minecraftforge.fluids.Fluid;

public class BlockMarkLiquid extends BlockFluidClassic {

	public BlockMarkLiquid(String unlocalizedName, Fluid fluid, Material material) {
		super(fluid, material);
		this.setUnlocalizedName(unlocalizedName);
		this.setCreativeTab(MainRegistry.tabMark);
		
		
	}
	
	

	
	
	@Override
    public void neighborChanged(IBlockState state, World world, BlockPos pos, Block neighborBlock)
    {
		if(!world.isRemote){
			if(this.blockState == MarkFluids.BlueLava.getBlock().getBlockState()){
				
				if(neighborBlock == Blocks.WATER  || neighborBlock == Blocks.FLOWING_WATER){
				world.setBlockState(pos, MarkBlocks.CrystRack.getDefaultState());
				
			}
				else if(neighborBlock == Blocks.LAVA  || neighborBlock == Blocks.FLOWING_LAVA){
					
					world.setBlockState(pos, Blocks.NETHERRACK.getDefaultState());
				}
				else if(neighborBlock == MarkFluids.SandTurn.getBlock()){
					
					world.setBlockState(pos, MarkBlocks.Cyantinian.getDefaultState());
				}
			}
			else if(this.blockState == MarkFluids.SandTurn.getBlock().getBlockState()){
				if(neighborBlock == Blocks.LAVA  || neighborBlock == Blocks.FLOWING_LAVA){
						
						world.setBlockState(pos, Blocks.SOUL_SAND.getDefaultState());
					}
				else if(neighborBlock == Blocks.GLASS || neighborBlock == Blocks.AIR){
					world.setBlockState(pos, Blocks.GRAVEL.getDefaultState());
				}
				else{
					
					
					
				}
				}
				
				
			
    	
			
		}
		
        world.scheduleUpdate(pos, this, tickRate);
    }
	
	@Override	
	protected void flowIntoBlock(World world, BlockPos pos, int meta)
    {
		
		Block block = world.getBlockState(pos).getBlock();
        if (meta < 0) return;
        if(this.getFluid() == MarkFluids.BlueLava){
        if(block == Blocks.WATER || block == Blocks.FLOWING_WATER){
        	        	world.setBlockState(pos, MarkBlocks.CrystRack.getDefaultState());
        }
        else if	(block == Blocks.LAVA || block == Blocks.FLOWING_LAVA){
        	world.setBlockState(pos, Blocks.NETHERRACK.getDefaultState());
        }
        else if (displaceIfPossible(world, pos))
        {
            world.setBlockState(pos, this.getBlockState().getBaseState().withProperty(LEVEL, meta), 3);
        }
        }
        else if (this.getFluid() == MarkFluids.SandTurn){
        	if(block == MarkFluids.BlueLava.getBlock()){
	        	world.setBlockState(pos, MarkBlocks.CrystSand.getDefaultState());
        	}
        	else if	(block == Blocks.LAVA || block == Blocks.FLOWING_LAVA){
        		world.setBlockState(pos, MarkBlocks.NetherSand.getDefaultState());
        	}
        	else if (displaceIfPossible(world, pos))
            {
                world.setBlockState(pos, this.getBlockState().getBaseState().withProperty(LEVEL, meta), 3);
            }
        }
        	
    	
        
        else if (displaceIfPossible(world, pos))
        {
            world.setBlockState(pos, this.getBlockState().getBaseState().withProperty(LEVEL, meta), 3);
        }
    }
	
}
