package com.modMark.Item_Block.Fluid;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;

import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialLiquid;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fluids.BlockFluidClassic;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fluids.IFluidBlock;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class MarkFluids {

	
	
	public static Fluid BlueLava;
	public static Fluid SandTurn;
	
	public static final Set<Fluid> fluids = new HashSet<>();
	public static Set<IFluidBlock> fluidBlocks = new HashSet<IFluidBlock>();
	
	
	public static void init() {

		BlueLava = createFluid("bluelava", "mark13695:blocks/LavaBlue", Material.LAVA,
			fluid -> fluid.setViscosity(5500).setDensity(1100).setLuminosity(15),
			fluid -> new BlockMarkLiquid("LavaBlue", fluid, Material.LAVA));
		
		SandTurn = createFluid("sandturn", "mark13695:blocks/sandturn", Material.WATER,
				fluid -> fluid.setViscosity(1500).setDensity(1098),
				fluid -> new BlockMarkLiquid("sandturn", fluid, Material.WATER));
		
		
		
		
	}
	
	private static <T extends Block & IFluidBlock> Fluid createFluid(String name, String textureName, Material material, Consumer<Fluid> fluidPropertyApplier, Function<Fluid, T> blockFactory) {
		return createFluid(name, textureName, material, 0x0F44E4 , fluidPropertyApplier, blockFactory);
	}
	
	
	private static <T extends Block & IFluidBlock> Fluid createFluid(String name, String textureName, Material material, int color, Consumer<Fluid> fluidPropertyApplier, Function<Fluid, T> blockFactory) {
		
		if(material == Material.LAVA){
		
		Fluid fluid = new MarkLava(name, textureName + "_still", textureName + "_flow");
		boolean useOwnFluid = FluidRegistry.registerFluid(fluid);

		if (useOwnFluid) {
			fluidPropertyApplier.accept(fluid);
			String texturename2 = textureName.replace("mark13695:blocks/", "mark13695:fluid.");
			registerFluidBlock(blockFactory.apply(fluid), texturename2);
		} else {
			fluid = FluidRegistry.getFluid(name);
		}
		fluids.add(fluid);

		return fluid;
		}
		else{ 
			
		Fluid fluid = new MarkWater(name, textureName + "_still", textureName + "_flow");
		boolean useOwnFluid = FluidRegistry.registerFluid(fluid);

		if (useOwnFluid) {
			fluidPropertyApplier.accept(fluid);
			String texturename2 = textureName.replace("mark13695:blocks/", "mark13695:fluid.");
			registerFluidBlock(blockFactory.apply(fluid), texturename2);
		} else {
			fluid = FluidRegistry.getFluid(name);
		}
		fluids.add(fluid);

		return fluid;
			
		}

		
	}
	
	
	private static <T extends Block & IFluidBlock> T registerFluidBlock(T block, String Name) {
		
		GameRegistry.register(block, new ResourceLocation("" + Name));
		GameRegistry.register(new ItemBlock(block), new ResourceLocation("" + Name));

		fluidBlocks.add(block);

		return block;
	}
	
	
}
