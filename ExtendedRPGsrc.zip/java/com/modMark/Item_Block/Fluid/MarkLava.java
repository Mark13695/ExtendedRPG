package com.modMark.Item_Block.Fluid;

import com.modMark.Main.MainRegistry;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fluids.Fluid;

public class MarkLava extends Fluid{

	public MarkLava(String fluidName, String Static, String Dynamic) {
		super(fluidName, new ResourceLocation(Static), new ResourceLocation(Dynamic));
		
	}
	

}
