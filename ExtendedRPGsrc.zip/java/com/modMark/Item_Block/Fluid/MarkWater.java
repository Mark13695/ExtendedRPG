package com.modMark.Item_Block.Fluid;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fluids.Fluid;

public class MarkWater extends Fluid{
	

	public MarkWater(String fluidName, String Static, String Dynamic) {
		super(fluidName, new ResourceLocation(Static), new ResourceLocation(Dynamic));
	}
	
	
	
}
