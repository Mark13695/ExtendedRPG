package com.modMark.Item_Block.Item;

import net.minecraft.util.IStringSerializable;

public enum EnumHerb implements IStringSerializable{
	
	Aneth_D(0, 27, "Aneth_D", "Aneth_D"),
	Aneth_C(1, 26, "Aneth_C", "Aneth_C"),
	Romarin_D(2, 25, "Romarin_D", "Romarin_D"),
	Romarin_C(3, 24, "Romarin_C", "Romarin_C"),
	Raifort_D(4, 23, "Raifort_D", "Raifort_D"),
	Raifort_C(5, 22, "Raifort_C", "Raifort_C"),
	Celeri_D(6, 21, "Celeri_D", "Celeri_D"),
	Celeri_C(7, 20, "Celeri_C", "Celeri_C"),
	Sarriette_D(8, 19, "Sarriette_D", "Sarriette_D"),
	Sarriette_C(9, 18, "Sarriette_C", "Sarriette_C"),
	Armoise_D(10, 17, "Armoise_D", "Armoise_D"),
	Armoise_C(11, 16, "Armoise_C", "Armoise_C"),
	Cerfeuil_D(12, 15, "Cerfeuil_D", "Cerfeuil_D"),
	Cerfeuil_C(13, 14, "Cerfeuil_C", "Cerfeuil_C"),
	Estragon_D(14, 13, "Estragon_D", "Estragon_D"),
	Estragon_C(15, 12, "Estragon_C", "Estragon_C"),
	Netherweed_D(16, 11, "Netherweed_D", "Netherweed_D"),
	Netherweed_C(17, 10, "Netherweed_C", "Netherweed_C"),
	Flameweed_D(18, 9, "Flameweed_D", "Flameweed_D"),
	Flameweed_C(19, 8, "Flameweed_C", "Flameweed_C"),
	BrutalRed_D(20, 7, "BrutalRed_D", "BrutalRed_D"),
	BrutalRed_C(21, 6, "BrutalRed_C", "BrutalRed_C"),
	Crystweed_D(22, 5, "Crystweed_D", "Crystweed_D"),
	Crystweed_C(23, 4, "Crystweed_C", "Crystweed_C"),
	DarkCrystal_D(24, 3, "DarkCrystal_D", "DarkCrystal_D"),
	DarkCrystal_C(25, 2, "DarkCrystal_C", "DarkCrystal_C"),
	BrutalBlue_D(26, 1, "BrutalBlue_D", "BrutalBlue_D"),
	BrutalBlue_C(27, 0, "BrutalBlue_C", "BrutalBlue_C");
	
	private static final EnumHerb[] meta_Lookup = new EnumHerb[values().length];
	private static final EnumHerb[] dmg_Lookup = new EnumHerb[values().length];
	private final int meta;
	private final int dmgHerb;
	private final String Name;
	private final String unlocalizedName;
	
	
	
	
	
	private EnumHerb(int meta, int dmgHerb, String Name, String unlocalizedName){
		this.meta = meta;
		this.dmgHerb = dmgHerb;
		this.Name = Name;
		this.unlocalizedName = unlocalizedName;
		
		
	}
	
	public int getMetadata()
    {
        return this.meta;
    }

    public int getdmgHerb()
    {
        return this.dmgHerb;
    }

    public String getUnlocalizedName()
    {
        return this.unlocalizedName;
    }
    
    public static EnumHerb bydmg(int damage)
    {
        if (damage < 0 || damage >= dmg_Lookup.length)
        {
            damage = 0;
        }

        return dmg_Lookup[damage];
    }

    public static EnumHerb byMeta(int meta)
    {
        if (meta < 0 || meta >= meta_Lookup.length)
        {
            meta = 0;
        }

        return meta_Lookup[meta];
    }

    public String toString()
    {
        return this.unlocalizedName;
    }

    public String getName()
    {
        return this.Name;
    }

    static
    {
        for (EnumHerb enumherb : values())
        {
        	meta_Lookup[enumherb.getMetadata()] = enumherb;
        	dmg_Lookup[enumherb.getdmgHerb()] = enumherb;
        }
    }
}
