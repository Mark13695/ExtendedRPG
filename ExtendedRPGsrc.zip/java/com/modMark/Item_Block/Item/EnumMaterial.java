package com.modMark.Item_Block.Item;

public enum EnumMaterial {
	
	Tier1(0, 59, 2.0F, 0.0F),
	Tier5(0, 75, 0.0F, 0.5F),
	Tier10(1, 131, 4.0F, 1.0F),
	Tier15(0, 150, 0.0F, 1.5F),
	Tier20(2, 250, 6.0F, 2.0F),
	Tier25(0, 275, 0.0F, 2.25F),
	Tier30(0, 300, 0.0F, 2.5F),
	Tier35(0, 325, 0.0F, 2.75F),
	Tier40(3, 1561, 8.0F, 3.0F),
	Tier45(0, 1580, 0.0F, 3.25F),
	Tier50(0, 1600, 0.0F, 3.5F),
	Tier55(0, 1625, 0.0F, 3.75F),
	Tier60(4, 1650, 10.0F, 4.0F),
	Tier65(0, 1675, 0.0F, 4.25F),
	Tier70(0, 1700, 0.0F, 4.50F),
	Tier75(0, 1725, 0.0F, 4.75F),
	Tier80(5, 1750, 12.0F, 5.0F),
	Tier85(0, 1775, 0.0F, 5.25F),
	Tier90(0, 1800, 0.0F, 5.5F),
	Tier95(0, 1825, 0.0F, 5.75F);
	
	private int harvest;
	private int maxUses;
	private float Efficiency;
	private float AD;
	
	private EnumMaterial(int Harvestlevel, int maxuses, float efficiency, float damage){
		
		this.harvest = Harvestlevel;
		this.maxUses = maxuses;
		this.Efficiency = efficiency;
		this.AD = damage;
	}

	public int getHarvestLevel(){
		return this.harvest;
	}
	public int getMaxUses(){
		return this.maxUses;
	}
	public float getEfficiency(){
		return this.Efficiency;
	}
	public float getDamage(){
		return this.AD;
	}
}
