package com.modMark.Item_Block.Item;

import com.modMark.Combat.MarkArrow;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemMarkQuiver extends Item {

	private EnumMaterial material;
	
	public ItemMarkQuiver(EnumMaterial Material){
		super();
		this.material = Material;
		this.maxStackSize = 1;
		this.setMaxDamage(Material.getMaxUses());
	}
	
	 public MarkArrow createArrow(World worldIn, ItemStack stack, EntityLivingBase shooter)
	    {
	        MarkArrow arrow = new MarkArrow(worldIn, shooter, stack);
	        return arrow;
	    }
	
	
}
