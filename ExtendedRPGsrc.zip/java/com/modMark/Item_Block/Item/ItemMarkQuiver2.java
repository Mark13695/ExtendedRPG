package com.modMark.Item_Block.Item;

import net.minecraft.item.Item;

public class ItemMarkQuiver2 extends Item {

	private EnumMaterial material;
	
	public ItemMarkQuiver2(EnumMaterial Material){
		super();
		this.material = Material;
		this.maxStackSize = 1;
		this.setMaxDamage(Material.getMaxUses());
	}
	
	
}
