package com.modMark.Item_Block.Item;

import java.util.HashMap;
import java.util.Map;

import com.modMark.Item_Block.MarkItems;
import com.modMark.Mob.EntitySalaBlue;
import com.modMark.Mob.EntitySalaCommon;
import com.modMark.Mob.EntitySalaDesert;
import com.modMark.Mob.EntitySalaGreen;
import com.modMark.Mob.EntitySalaRed;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntityRabbit;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemTrap extends Item{

		public ItemTrap(){
			super();
				
		}
		
		@Override
		public EnumActionResult onItemUse(ItemStack stack, EntityPlayer playerIn, World worldIn, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
	    {
			
			Map<Item, Entity> trap = new HashMap<Item, Entity>();
			trap.put(MarkItems.Trap01, new EntityRabbit(worldIn));
			trap.put(MarkItems.Trap10, new EntitySalaCommon(worldIn));
			trap.put(MarkItems.Trap20, new EntitySalaDesert(worldIn));
			trap.put(MarkItems.Trap40, new EntitySalaGreen(worldIn));
			trap.put(MarkItems.Trap60, new EntitySalaRed(worldIn));
			trap.put(MarkItems.Trap80, new EntitySalaBlue(worldIn));
			
			Entity entity = trap.get(this) != null ? trap.get(this) : new EntityPig(worldIn);
			BlockPos p = playerIn.getPosition();
			entity.setPosition(p.getX(), p.getY(), p.getZ());
			if(!worldIn.isRemote){
			worldIn.spawnEntityInWorld(entity);
			}
			
			return EnumActionResult.PASS;
	    }
}
