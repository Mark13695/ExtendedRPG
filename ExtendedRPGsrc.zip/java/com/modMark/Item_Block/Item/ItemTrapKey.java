package com.modMark.Item_Block.Item;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemTrapKey extends Item {

	public ItemTrapKey(){
		super();
		
		
	}
	@Override
	public EnumActionResult onItemUse(ItemStack stack, EntityPlayer playerIn, World worldIn, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
    {
		Block block = worldIn.getBlockState(pos).getBlock();
		
		Map<Block, Item> trap = new HashMap<Block, Item>();
		trap.put(MarkBlocks.MarkTrap01, MarkItems.Trap01);
		trap.put(MarkBlocks.MarkTrap10, MarkItems.Trap10);
		trap.put(MarkBlocks.MarkTrap20, MarkItems.Trap20);
		trap.put(MarkBlocks.MarkTrap40, MarkItems.Trap40);
		trap.put(MarkBlocks.MarkTrap60, MarkItems.Trap60);
		trap.put(MarkBlocks.MarkTrap80, MarkItems.Trap80);
		Random r = new Random();
		
		if(trap.get(block) != null){
			if(!worldIn.isRemote){
			worldIn.spawnEntityInWorld(new EntityItem(worldIn, pos.getX() + (r.nextDouble() - 0.5D), pos.getY(), pos.getZ() + (r.nextDouble() - 0.5D), new ItemStack(trap.get(block), 1)));
			worldIn.spawnEntityInWorld(new EntityItem(worldIn, pos.getX() + (r.nextDouble() - 0.5D), pos.getY(), pos.getZ() + (r.nextDouble() - 0.5D), new ItemStack(MarkBlocks.MarkTrapE, 1)));
			}
			worldIn.setBlockToAir(pos);
		stack.stackSize--;
		}
		
		return trap.get(block) != null ? EnumActionResult.PASS : EnumActionResult.FAIL;
    }
    
}
