package com.modMark.Item_Block.Item;

import javax.annotation.Nullable;

import com.modMark.Combat.MarkArrow;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkBow extends Item {

	private EnumMaterial material;
	private float AttackDamage;
	private int Cooldown = 0;
	
	public MarkBow(EnumMaterial Material){
		this.material = Material;
		this.maxStackSize = 1;
		this.setMaxDamage(Material.getMaxUses());
		this.AttackDamage = 3.0F + Material.getDamage();
	}
	
	@SideOnly(Side.CLIENT)
    public boolean isFull3D()
    {
        return true;
    }
	public ItemStack availableAmmo(EntityPlayer player){
		
		  if (this.isQuiver(player.getHeldItem(EnumHand.OFF_HAND)))
	        {
	            return player.getHeldItem(EnumHand.OFF_HAND);
	        }
	        else if (this.isQuiver(player.getHeldItem(EnumHand.MAIN_HAND)))
	        {
	            return player.getHeldItem(EnumHand.MAIN_HAND);
	        }
	        else
	        {
	        	{
	                for (int i = 0; i < player.inventory.getSizeInventory(); ++i)
	                {
	                    ItemStack itemstack = player.inventory.getStackInSlot(i);

	                    if (this.isQuiver(itemstack))
	                    {
	                        return itemstack;
	                    }
	                }

	                return null;
	            }
	        }
	}
	
	protected boolean isQuiver(@Nullable ItemStack stack)
    {
        return stack != null && stack.getItem() instanceof ItemMarkQuiver;
    }
	
	@Override
	public ActionResult<ItemStack> onItemRightClick(ItemStack I, World W, EntityPlayer Player, EnumHand hand)
    {
		ItemStack itemstack = this.availableAmmo(Player);
		
		if (itemstack != null && Cooldown < 1)
        {
			float f = 1.0F;
			if (!W.isRemote)
            {
				ItemMarkQuiver quiver = (ItemMarkQuiver)itemstack.getItem();
				System.out.println(itemstack.getDisplayName());
				EntityArrow entityarrow = quiver.createArrow(W, itemstack, Player);
				entityarrow.setAim(Player, Player.rotationPitch, Player.rotationYaw, 0.0F, f * 3.0F, 1.0F);
				itemstack.damageItem(1, Player);
				I.damageItem(1, Player);
				W.spawnEntityInWorld(entityarrow);
				this.Cooldown = 30;
            }
        }
		return new ActionResult(EnumActionResult.PASS, I);
    }
    
	@Override
	public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean B) {
	if (this.Cooldown > 0){
		this.Cooldown--;
	}
	}
}
