package com.modMark.Item_Block.Item;

import java.util.List;
import java.util.Random;

import com.modMark.Generator.MarkBiome;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.world.storage.loot.LootTableList;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkFishHook extends EntityFishHook {
	
	private static final DataParameter<Integer> DATA_HOOKED_ENTITY = EntityDataManager.<Integer>createKey(MarkFishHook.class, DataSerializers.VARINT);
	private BlockPos field_189740_d;
	private int FishLvl;
	private Block inTile;
	private boolean inGround;
	private int ticksInGround;
	private int ticksInAir;
	private int ticksFishing;
	private boolean isFirstFish;
	private int ticksCatchable;
	private int ticksCaughtDelay;
	private int ticksCatchableDelay;
	private float fishApproachAngle;
	private int fishPosRotationIncrements;
	private double fishX;
	private double fishY;
	private double fishZ;
	private double fishYaw;
	private double fishPitch;
	@SideOnly(Side.CLIENT)
	private double clientMotionX;
	@SideOnly(Side.CLIENT)
	private double clientMotionY;
	@SideOnly(Side.CLIENT)
	private double clientMotionZ;

	public MarkFishHook(World worldIn) {
		super(worldIn);
		 this.field_189740_d = new BlockPos(-1, -1, -1);
	     this.setSize(0.25F, 0.25F);
	     this.ignoreFrustumCheck = true;
	}
	@SideOnly(Side.CLIENT)
    public MarkFishHook(World worldIn, double x, double y, double z, EntityPlayer anglerIn)
    {
        this(worldIn);
        this.setPosition(x, y, z);
        this.ignoreFrustumCheck = true;
        this.angler = anglerIn;
        anglerIn.fishEntity = this;
        MarkData p = anglerIn.getCapability(MainRegistry.ModMark136Data, null);
        this.FishLvl = p.Level[12];
    }
	
	 public MarkFishHook(World worldIn, EntityPlayer fishingPlayer)
	    {
	        super(worldIn);
	        this.field_189740_d = new BlockPos(-1, -1, -1);
	        this.ignoreFrustumCheck = true;
	        this.angler = fishingPlayer;
	        this.angler.fishEntity = this;
	        this.setSize(0.25F, 0.25F);
	        this.setLocationAndAngles(fishingPlayer.posX, fishingPlayer.posY + (double)fishingPlayer.getEyeHeight(), fishingPlayer.posZ, fishingPlayer.rotationYaw, fishingPlayer.rotationPitch);
	        this.posX -= (double)(MathHelper.cos(this.rotationYaw * 0.017453292F) * 0.16F);
	        this.posY -= 0.10000000149011612D;
	        this.posZ -= (double)(MathHelper.sin(this.rotationYaw * 0.017453292F) * 0.16F);
	        this.setPosition(this.posX, this.posY, this.posZ);
	        float f = 0.4F;
	        this.motionX = (double)(-MathHelper.sin(this.rotationYaw * 0.017453292F) * MathHelper.cos(this.rotationPitch * 0.017453292F) * 0.4F);
	        this.motionZ = (double)(MathHelper.cos(this.rotationYaw * 0.017453292F) * MathHelper.cos(this.rotationPitch * 0.017453292F) * 0.4F);
	        this.motionY = (double)(-MathHelper.sin(this.rotationPitch * 0.017453292F) * 0.4F);
	        this.handleHookCasting(this.motionX, this.motionY, this.motionZ, 1.5F, 1.0F);
	        MarkData p = fishingPlayer.getCapability(MainRegistry.ModMark136Data, null);
	        this.FishLvl = p.Level[12];
	        this.isFirstFish = true;
	        boolean a = this.angler.fishEntity != null;
	        
	    }
	 
	 protected void entityInit()
	    {
	        this.getDataManager().register(DATA_HOOKED_ENTITY, Integer.valueOf(0));
	    }

	    public void notifyDataManagerChange(DataParameter<?> key)
	    {
	        if (DATA_HOOKED_ENTITY.equals(key))
	        {
	            int i = ((Integer)this.getDataManager().get(DATA_HOOKED_ENTITY)).intValue();

	            if (i > 0 && this.caughtEntity != null)
	            {
	                this.caughtEntity = null;
	            }
	        }

	        super.notifyDataManagerChange(key);
	    }
	    
	 @Override
	 public void onUpdate()
	    {
		 if (!this.worldObj.isRemote)
	        {
	            this.setFlag(6, this.isGlowing());
	        }

	        this.onEntityUpdate();

	        if (this.worldObj.isRemote)
	        {
	            int i = ((Integer)this.getDataManager().get(DATA_HOOKED_ENTITY)).intValue();

	            if (i > 0 && this.caughtEntity == null)
	            {
	                this.caughtEntity = this.worldObj.getEntityByID(i - 1);
	            }
	        }
	        else
	        {
	            ItemStack itemstack = this.angler.getHeldItemMainhand();

	            if (this.angler.isDead || !this.angler.isEntityAlive() || itemstack == null || itemstack.getItem() != MarkItems.FishRod || this.getDistanceSqToEntity(this.angler) > 1024.0D)
	            {
	                this.setDead();
	                this.angler.fishEntity = null;
	                return;
	            }
	        }

	        if (this.caughtEntity != null)
	        {
	            if (!this.caughtEntity.isDead)
	            {
	                this.posX = this.caughtEntity.posX;
	                double d17 = (double)this.caughtEntity.height;
	                this.posY = this.caughtEntity.getEntityBoundingBox().minY + d17 * 0.8D;
	                this.posZ = this.caughtEntity.posZ;
	                return;
	            }

	            this.caughtEntity = null;
	        }

	        if (this.fishPosRotationIncrements > 0)
	        {
	            double d3 = this.posX + (this.fishX - this.posX) / (double)this.fishPosRotationIncrements;
	            double d4 = this.posY + (this.fishY - this.posY) / (double)this.fishPosRotationIncrements;
	            double d6 = this.posZ + (this.fishZ - this.posZ) / (double)this.fishPosRotationIncrements;
	            double d8 = MathHelper.wrapDegrees(this.fishYaw - (double)this.rotationYaw);
	            this.rotationYaw = (float)((double)this.rotationYaw + d8 / (double)this.fishPosRotationIncrements);
	            this.rotationPitch = (float)((double)this.rotationPitch + (this.fishPitch - (double)this.rotationPitch) / (double)this.fishPosRotationIncrements);
	            --this.fishPosRotationIncrements;
	            this.setPosition(d3, d4, d6);
	            this.setRotation(this.rotationYaw, this.rotationPitch);
	        }
	        else
	        {
	            if (this.inGround)
	            {
	                if (this.worldObj.getBlockState(this.field_189740_d).getBlock() == this.inTile)
	                {
	                    ++this.ticksInGround;

	                    if (this.ticksInGround == 1200)
	                    {
	                        this.setDead();
	                    }

	                    return;
	                }

	                this.inGround = false;
	                this.motionX *= (double)(this.rand.nextFloat() * 0.2F);
	                this.motionY *= (double)(this.rand.nextFloat() * 0.2F);
	                this.motionZ *= (double)(this.rand.nextFloat() * 0.2F);
	                this.ticksInGround = 0;
	                this.ticksInAir = 0;
	            }
	            else
	            {
	                ++this.ticksInAir;
	            }

	            if (!this.worldObj.isRemote)
	            {
	                Vec3d vec3d1 = new Vec3d(this.posX, this.posY, this.posZ);
	                Vec3d vec3d = new Vec3d(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
	                RayTraceResult raytraceresult = this.worldObj.rayTraceBlocks(vec3d1, vec3d);
	                vec3d1 = new Vec3d(this.posX, this.posY, this.posZ);
	                vec3d = new Vec3d(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);

	                if (raytraceresult != null)
	                {
	                    vec3d = new Vec3d(raytraceresult.hitVec.xCoord, raytraceresult.hitVec.yCoord, raytraceresult.hitVec.zCoord);
	                }

	                Entity entity = null;
	                List<Entity> list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().addCoord(this.motionX, this.motionY, this.motionZ).expandXyz(1.0D));
	                double d0 = 0.0D;

	                for (int j = 0; j < list.size(); ++j)
	                {
	                    Entity entity1 = (Entity)list.get(j);

	                    if (this.func_189739_a(entity1) && (entity1 != this.angler || this.ticksInAir >= 5))
	                    {
	                        AxisAlignedBB axisalignedbb1 = entity1.getEntityBoundingBox().expandXyz(0.30000001192092896D);
	                        RayTraceResult raytraceresult1 = axisalignedbb1.calculateIntercept(vec3d1, vec3d);

	                        if (raytraceresult1 != null)
	                        {
	                            double d1 = vec3d1.squareDistanceTo(raytraceresult1.hitVec);

	                            if (d1 < d0 || d0 == 0.0D)
	                            {
	                                entity = entity1;
	                                d0 = d1;
	                            }
	                        }
	                    }
	                }

	                if (entity != null)
	                {
	                    raytraceresult = new RayTraceResult(entity);
	                }

	                if (raytraceresult != null)
	                {
	                    if (raytraceresult.entityHit != null)
	                    {
	                        this.caughtEntity = raytraceresult.entityHit;
	                        this.getDataManager().set(DATA_HOOKED_ENTITY, Integer.valueOf(this.caughtEntity.getEntityId() + 1));
	                    }
	                    else
	                    {
	                        this.inGround = true;
	                    }
	                }
	            }

	            if (!this.inGround)
	            {
	                this.moveEntity(this.motionX, this.motionY, this.motionZ);
	                float f2 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
	                this.rotationYaw = (float)(MathHelper.atan2(this.motionX, this.motionZ) * (180D / Math.PI));

	                for (this.rotationPitch = (float)(MathHelper.atan2(this.motionY, (double)f2) * (180D / Math.PI)); this.rotationPitch - this.prevRotationPitch < -180.0F; this.prevRotationPitch -= 360.0F)
	                {
	                    ;
	                }

	                while (this.rotationPitch - this.prevRotationPitch >= 180.0F)
	                {
	                    this.prevRotationPitch += 360.0F;
	                }

	                while (this.rotationYaw - this.prevRotationYaw < -180.0F)
	                {
	                    this.prevRotationYaw -= 360.0F;
	                }

	                while (this.rotationYaw - this.prevRotationYaw >= 180.0F)
	                {
	                    this.prevRotationYaw += 360.0F;
	                }

	                this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2F;
	                this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2F;
	                float f3 = 0.92F;

	                if (this.onGround || this.isCollidedHorizontally)
	                {
	                    f3 = 0.5F;
	                }

	                int k = 5;
	                double d5 = 0.0D;

	                for (int l = 0; l < 5; ++l)
	                {
	                    AxisAlignedBB axisalignedbb = this.getEntityBoundingBox();
	                    double d9 = axisalignedbb.maxY - axisalignedbb.minY;
	                    double d10 = axisalignedbb.minY + d9 * (double)l / 5.0D;
	                    double d11 = axisalignedbb.minY + d9 * (double)(l + 1) / 5.0D;
	                    AxisAlignedBB axisalignedbb2 = new AxisAlignedBB(axisalignedbb.minX, d10, axisalignedbb.minZ, axisalignedbb.maxX, d11, axisalignedbb.maxZ);

	                    if (this.worldObj.isAABBInMaterial(axisalignedbb2, Material.WATER))
	                    {
	                        d5 += 0.2D;
	                    }
	                }

	                if (!this.worldObj.isRemote && d5 > 0.0D)
	                	//EDIT!
	                {
	                    WorldServer worldserver = (WorldServer)this.worldObj;
	                    int i1 = 1000;
	                    BlockPos blockpos = (new BlockPos(this)).up();

	                    if (this.rand.nextFloat() < 0.25F && this.worldObj.isRainingAt(blockpos))
	                    {
	                        i1 = 900;
	                    }

	                    if (this.rand.nextFloat() < 0.5F && !this.worldObj.canSeeSky(blockpos))
	                    {
	                        i1 = 1100;
	                    }
	                    
	                    if (this.ticksFishing > 0)
	                    {
	                    	--this.ticksFishing;
	                    }
	                    
	                    MarkData p = this.angler.getCapability(MainRegistry.ModMark136Data, null);
	                    this.FishLvl = p.Level[12];
	                    Biome biome = this.worldObj.getBiomeForCoordsBody(this.getPosition());
                    	if(biome == Biomes.RIVER){
                    		if(!p.requireLvl(12, 10, 7)){
                    			this.setDead();
                    			this.angler.fishEntity = null;	
                    		}
                    	}
                    	else if(biome == Biomes.OCEAN){
                    		if(!p.requireLvl(12, 20, 7)){
                    			this.setDead();
                    			this.angler.fishEntity = null;	
                    		}
                    	}
                    	else if(biome == Biomes.DEEP_OCEAN){
                    		if(!p.requireLvl(12, 50, 7)){
                    			this.setDead();
                    			this.angler.fishEntity = null;	
                    		}
                    	}
                    	else if(biome == MarkBiome.Biome_1_Enriched || biome == MarkBiome.Biome_1_EnrichedM){
                    		if(!p.requireLvl(12, 70, 7)){
                    			this.setDead();
                    			this.angler.fishEntity = null;	
                    		}
                    	}
                    	
                    	if (this.ticksFishing <= 0){
	                    	if(!this.isFirstFish){	
	                    	
	                    	
	                    	int f = this.rand.nextInt(1000);
	                    	ItemStack stackhand = this.angler.getHeldItemMainhand();
	                    	
	                    	if(f < (50 - (this.FishLvl / 7))){
	                    		
	                    		if (stackhand.getItem() == MarkItems.FishRod){ 
	                    		stackhand.damageItem(1, this.angler);
	                    		}
	                    		this.setDead();
                    			this.angler.fishEntity = null;
                    			
	                    	}
	                    	else{
	                    		int l = this.rand.nextInt(i1);
	                    		int l2 = 0;
	                    		
	                    		if(biome == Biomes.RIVER){
	                    			
	                    			l2 = 280 + (((this.FishLvl - 10) * 13) / 2);
	                    			if (l2 > 990){
	                    				l2 = 990;
	                    			}
	                    			
	                    		}
	                    		else if(biome == Biomes.OCEAN){
	                    			
	                    			l2 = 270 + (((this.FishLvl - 20) * 50) / 6);
	                    			if (l2 > 990){
	                    				l2 = 990;
	                    			}
	                    			
	                    		}
	                    		else if(biome == Biomes.DEEP_OCEAN){
	                    			
	                    			l2 = 200 + (((this.FishLvl - 50) * 15) / 2);
	                    			if (l2 > 990){
	                    				l2 = 990;
	                    			}
	                    			
	                    		}
	                    		else if(biome == MarkBiome.Biome_1_Enriched || biome == MarkBiome.Biome_1_EnrichedM){
	                    			
	                    			l2 = 175 + (((this.FishLvl - 70) * 19) / 2);
	                    			if (l2 > 990){
	                    				l2 = 990;
	                    			}
	                    			
	                    		}
	                    		else {
	                    			
	                    			l2 = 300 + (((this.FishLvl - 1) * 17) / 2);
	                    			if (l2 > 990){
	                    				l2 = 990;
	                    			}
	                    			
	                    		}
	                    		if (l < l2 && l2 != 0){
	                            this.motionY -= 0.20000000298023224D;
	                            this.playSound(SoundEvents.ENTITY_BOBBER_SPLASH, 0.25F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
	                            float f6 = (float)MathHelper.floor_double(this.getEntityBoundingBox().minY);
	                            worldserver.spawnParticle(EnumParticleTypes.WATER_BUBBLE, this.posX, (double)(f6 + 1.0F), this.posZ, (int)(1.0F + this.width * 20.0F), (double)this.width, 0.0D, (double)this.width, 0.20000000298023224D, new int[0]);
	                            worldserver.spawnParticle(EnumParticleTypes.WATER_WAKE, this.posX, (double)(f6 + 1.0F), this.posZ, (int)(1.0F + this.width * 20.0F), (double)this.width, 0.0D, (double)this.width, 0.20000000298023224D, new int[0]);
	                            ItemStack coughtstack = this.MarkFishingLooter();
	                            this.angler.inventory.addItemStackToInventory(coughtstack);
	                            if (stackhand.getItem() == MarkItems.FishRod && this.rand.nextInt(2) == 0){
	                            	if(stackhand.getMaxDamage() == stackhand.getItemDamage()){
	                            		this.setDead();
	                    	            this.angler.fishEntity = null;
	                            	}
		                    		stackhand.damageItem(1, this.angler);
	                            }
	                            
	                    		
	                    	}
	                    	this.ticksFishing = MathHelper.getRandomIntegerInRange(this.rand, 48, 60);
                            
	                    	}}
	                    	
	                    	else{
	                    		this.isFirstFish = false;
	                    		this.ticksFishing = MathHelper.getRandomIntegerInRange(this.rand, 90, 110);
	                    	}
	                    	
	                    }
	                  
	                }
	                double d7 = d5 * 2.0D - 1.0D;
	                this.motionY += 0.03999999910593033D * d7;

	                if (d5 > 0.0D)
	                {
	                    f3 = (float)((double)f3 * 0.9D);
	                    this.motionY *= 0.8D;
	                }

	                this.motionX *= (double)f3;
	                this.motionY *= (double)f3;
	                this.motionZ *= (double)f3;
	                this.setPosition(this.posX, this.posY, this.posZ);
	            }
	        }
	    }

	 public int handleHookRetraction()
	    {
	        if (this.worldObj.isRemote)
	        {
	            return 0;
	        }
	        else
	        {
	            int i = 0;

	            if (this.caughtEntity != null)
	            {
	                this.bringInHookedEntity();
	                this.worldObj.setEntityState(this, (byte)31);
	                i = this.caughtEntity instanceof EntityItem ? 3 : 5;
	            }
	            else if (this.ticksCatchable > 0)
	            {
	                LootContext.Builder lootcontext$builder = new LootContext.Builder((WorldServer)this.worldObj);
	                lootcontext$builder.withLuck((float)EnchantmentHelper.getLuckOfSeaModifier(this.angler) + this.angler.getLuck());

	                for (ItemStack itemstack : this.worldObj.getLootTableManager().getLootTableFromLocation(LootTableList.GAMEPLAY_FISHING).generateLootForPools(this.rand, lootcontext$builder.build()))
	                {
	                    EntityItem entityitem = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, itemstack);
	                    double d0 = this.angler.posX - this.posX;
	                    double d1 = this.angler.posY - this.posY;
	                    double d2 = this.angler.posZ - this.posZ;
	                    double d3 = (double)MathHelper.sqrt_double(d0 * d0 + d1 * d1 + d2 * d2);
	                    double d4 = 0.1D;
	                    entityitem.motionX = d0 * 0.1D;
	                    entityitem.motionY = d1 * 0.1D + (double)MathHelper.sqrt_double(d3) * 0.08D;
	                    entityitem.motionZ = d2 * 0.1D;
	                    this.worldObj.spawnEntityInWorld(entityitem);
	                    this.angler.worldObj.spawnEntityInWorld(new EntityXPOrb(this.angler.worldObj, this.angler.posX, this.angler.posY + 0.5D, this.angler.posZ + 0.5D, this.rand.nextInt(6) + 1));
	                }

	                i = 1;
	            }

	            if (this.inGround)
	            {
	                i = 2;
	            }

	            this.setDead();
	            this.angler.fishEntity = null;
	            return i;
	        }
	    }
	 
	 public ItemStack MarkFishingLooter(){
		 Random random = new Random();
		 Biome biome = worldObj.getBiomeForCoordsBody(this.getPosition());
		 int LootRandom = random.nextInt(1000);
		 MarkData p = this.angler.getCapability(MainRegistry.ModMark136Data, null);
		 this.FishLvl = p.Level[12];
		 ItemStack stack = new ItemStack(MarkItems.Cod_Raw, 1);
		 if(biome == Biomes.BEACH || biome == Biomes.STONE_BEACH){
			 if (this.FishLvl < 5){
				 p.addXp(12, 25);
				 stack = new ItemStack(MarkItems.Cod_Raw, 1);
				 
			 }
			 else if(this.FishLvl >= 5 && this.FishLvl < 15){
				 int a = (this.FishLvl * 5) + 25;
				 
				 if (a > LootRandom){ 
					 p.addXp(12, 3);
					 stack = new ItemStack(Items.FISH, 1, 3);
					 
					 }
				 else{
					 p.addXp(12, 25);
					 stack = new ItemStack(MarkItems.Cod_Raw, 1);
				 }
			 }
			 else if(this.FishLvl >= 15 && this.FishLvl < 30){
				 int a = (this.FishLvl * 5) + 25;
				 int b = (this.FishLvl * 5) - 25 + a;
				 if(a > LootRandom){
					 p.addXp(12, 3);
					stack = new ItemStack(Items.FISH, 1, 3);
				 }
				 else if (b > LootRandom){
					 p.addXp(12, 5);
					 stack = new ItemStack(Items.FISH, 1, 2);
				 }
				 else{
					 p.addXp(12, 25);
					stack = new ItemStack(MarkItems.Cod_Raw, 1); 
				 }
			 }
			 else if(this.FishLvl >=30 && this.FishLvl < 55){
				 int a = (this.FishLvl * 5) + 25;
				 int b = (this.FishLvl * 5) - 25 + a;
				 int c = (this.FishLvl * 5) - 100 + a + b;
				 
				 if(a > LootRandom){
					 p.addXp(12, 3);
					 new ItemStack(Items.FISH, 1, 3);
				 }
				 else if(b > LootRandom){
					 p.addXp(12, 5);
					 new ItemStack(Items.FISH, 1, 2);
				 }
				 else if (c > LootRandom){
					 p.addXp(12, 50);
					 new ItemStack(Items.FISH, 1, 1);
				 }
				 else{
					 p.addXp(12, 25);
					 new ItemStack(MarkItems.Cod_Raw, 1);
				 } 
			 }
			 else if(this.FishLvl >=55 && this.FishLvl < 65){
				 int a = 300;
				 int b = (this.FishLvl * 5) - 25 + a;
				 int c = (this.FishLvl * 5) - 100 + a + b;
				 
				 if(a > LootRandom){
					 p.addXp(12, 3);
					 new ItemStack(Items.FISH, 1, 3);
				 }
				 else if(b > LootRandom){
					 p.addXp(12, 5);
					 new ItemStack(Items.FISH, 1, 2);
				 }
				 else if (c > LootRandom){
					 p.addXp(12, 50);
					 new ItemStack(Items.FISH, 1, 1);
				 }
				 else{
					 p.addXp(12, 25);
					 new ItemStack(MarkItems.Cod_Raw, 1);
				 } 
				 
			 }
			 else if(this.FishLvl >=65 && this.FishLvl < 80){
				 int a = 300;
				 int b = 300 + a;
				 int c = (this.FishLvl * 5) - 100 + a + b;
				 
				 if(a > LootRandom){
					 p.addXp(12, 3);
					 new ItemStack(Items.FISH, 1, 3);
				 }
				 else if(b > LootRandom){
					 p.addXp(12, 5);
					 new ItemStack(Items.FISH, 1, 2);
				 }
				 else if (c > LootRandom){
					 p.addXp(12, 50);
					 new ItemStack(Items.FISH, 1, 1);
				 }
				 else{
					 p.addXp(12, 25);
					 new ItemStack(MarkItems.Cod_Raw, 1);
				 } 
			 }
			 else{
				 int a = 300;
				 int b = 300 + a;
				 int c = 300 + a + b;
				 
				 if(a > LootRandom){
					 p.addXp(12, 3);
					 new ItemStack(Items.FISH, 1, 3);
				 }
				 else if(b > LootRandom){
					 p.addXp(12, 5);
					 new ItemStack(Items.FISH, 1, 2);
				 }
				 else if (c > LootRandom){
					 p.addXp(12, 50);
					 new ItemStack(Items.FISH, 1, 1);
				 }
				 else{
					 p.addXp(12, 25);
					 new ItemStack(MarkItems.Cod_Raw, 1);
				 } 
			 }
		 }
		 else if(biome == Biomes.RIVER){
			 if (this.FishLvl < 30){
				 p.addXp(12, 32);
				 stack = new ItemStack(MarkItems.Trout_Raw, 1);
			 }
			 else if(this.FishLvl >= 30 && this.FishLvl < 60){
				 int a = ((this.FishLvl - 30) * 13) + ((this.FishLvl - 30) / 4) * 3 + 50;
				 
				 if(a > LootRandom){
					 p.addXp(12, 40);
					stack = new ItemStack(Items.FISH, 1, 1);
				 }
				 else{
					 p.addXp(12, 32);
					 stack = new ItemStack(MarkItems.Trout_Raw, 1);
				 }
				 
				 
					 
			 }
			 else if(this.FishLvl >= 60 && this.FishLvl < 70){
				 int a = ((this.FishLvl - 30) * 13) + ((this.FishLvl - 30) / 4) * 3 + 50;
				 int b = ((this.FishLvl - 60) * 10) + 50 + a;
				 
				 if(a > LootRandom){
					 p.addXp(12, 40);
					 stack = new ItemStack(Items.FISH, 1, 1);
				 }
				 else if(a > LootRandom){
					 p.addXp(12, 90);
					 stack = new ItemStack(MarkItems.Bass_Raw, 1);
				 }
				 else{
					 p.addXp(12, 32);
					 stack = new ItemStack(MarkItems.Trout_Raw, 1);
				 }
			 }
			 else if(this.FishLvl >= 70 && this.FishLvl < 75){
				 int a = 600;
				 int b = ((this.FishLvl - 60) * 10) + 50 + a;
				 
				 if(a > LootRandom){
					 p.addXp(12, 40);
					 stack = new ItemStack(Items.FISH, 1, 1);
				 }
				 else if(a > LootRandom){
					 p.addXp(12, 90);
					 stack = new ItemStack(MarkItems.Bass_Raw, 1);
				 }
				 else{
					 p.addXp(12, 32);
					 stack = new ItemStack(MarkItems.Trout_Raw, 1);
				 }
			 }
			 else if(this.FishLvl >= 75 && this.FishLvl < 115){
				 int a = 600 - ((this.FishLvl - 75) * 10);
				 int b = ((this.FishLvl - 60) * 10) + 50 + a;
				 
				 if(a > LootRandom){
					 p.addXp(12, 40);
					 stack = new ItemStack(Items.FISH, 1, 1);
				 }
				 else if(a > LootRandom){
					 p.addXp(12, 90);
					 stack = new ItemStack(MarkItems.Bass_Raw, 1);
				 }
				 else{
					 p.addXp(12, 32);
					 stack = new ItemStack(MarkItems.Trout_Raw, 1);
				 }
			 }
			 else{
				 int a = 200;
				 int b = 600;
				 
				 if(a > LootRandom){
					 p.addXp(12, 40);
					 stack = new ItemStack(Items.FISH, 1, 1);
				 }
				 else if(a > LootRandom){
					 p.addXp(12, 90);
					 stack = new ItemStack(MarkItems.Bass_Raw, 1);
				 }
				 else{
					 p.addXp(12, 32);
					 stack = new ItemStack(MarkItems.Trout_Raw, 1);
				 }
			 }
			 
		 }
		 else if(biome == Biomes.OCEAN){
			 if (this.FishLvl < 40){
				 p.addXp(12, 40);
				 stack = new ItemStack(MarkItems.Sardine_Raw, 1);
			 } 
			 else if(this.FishLvl >= 40 && this.FishLvl < 105){
				 
				 int a = ((this.FishLvl - 40) * 10) + 50;
				 
				 if(a > LootRandom){
					 p.addXp(12, 60);
					 stack = new ItemStack(MarkItems.Tuna_Raw, 1);
				 }
				 else{
					 p.addXp(12, 40);
					stack = new ItemStack(MarkItems.Sardine_Raw, 1);
				 }
				
			 }
			 else{
				 int a = 700;
				 if(a > LootRandom){
					 p.addXp(12, 60);
					 stack = new ItemStack(MarkItems.Tuna_Raw, 1);
				 }
				 else{
					 p.addXp(12, 40);
					 stack = new ItemStack(MarkItems.Sardine_Raw, 1);
				 }
			 }
			 
			 
		 }
		 else if(biome == Biomes.DEEP_OCEAN){
			 if (this.FishLvl < 90){
				 p.addXp(12, 75);
				 stack = new ItemStack(MarkItems.Herring_Raw, 1);
			 } 
			 else if(this.FishLvl >= 90 && this.FishLvl < 145){
				 
				 int a = ((this.FishLvl - 90) * 10) + 50;
				 
				 if(a > LootRandom){
					 p.addXp(12, 135);
					 stack = new ItemStack(MarkItems.Shark_Raw, 1);
				 }
				 else{
					 p.addXp(12, 75);
					 stack = new ItemStack(MarkItems.Herring_Raw, 1);
				 }
				 
			 }
			 else{
				 int a = 700;
				 if(a > LootRandom){
					 p.addXp(12, 135);
					 stack = new ItemStack(MarkItems.Shark_Raw, 1);
				 }
				 else{
					 p.addXp(12, 75);
					 stack = new ItemStack(MarkItems.Herring_Raw, 1);
				 }
			 } 
		 }
		 else if(biome == MarkBiome.Biome_1_Enriched || biome == MarkBiome.Biome_1_EnrichedM){
			 if (this.FishLvl < 80){
				 p.addXp(12, 105);
				 stack = new ItemStack(MarkItems.Eel_Raw, 1);
			 } 
			 else if(this.FishLvl >= 80 && this.FishLvl < 135){
				 
				 int a = ((this.FishLvl - 80) * 10) + 50;
				 
				 if(a > LootRandom){
					 p.addXp(12, 120);
					stack = new ItemStack(MarkItems.Batiod_Raw, 1);
				 }
				 else{
					 p.addXp(12, 105);
					stack = new ItemStack(MarkItems.Eel_Raw, 1);
				 }
			 }
			 else{
				 int a = 700;
				 if(a > LootRandom){
					 p.addXp(12, 120);
					stack = new ItemStack(MarkItems.Batiod_Raw, 1);
				 }
				 else{
					 p.addXp(12, 105);
					stack = new ItemStack(MarkItems.Eel_Raw, 1);
				 }
			 }  
		 }
		 
		 else{
			 if (this.FishLvl < 30){
				 p.addXp(12, 25);
				 stack = new ItemStack(MarkItems.Cod_Raw, 1);
			 } 
			 else if(this.FishLvl >= 30 && this.FishLvl < 95){
				 
				 int a = (this.FishLvl * 10) - 250 ;
				 
				 if(a > LootRandom){
					 p.addXp(12, 50);
					stack = new ItemStack(Items.FISH, 1, 1);
				 }
				 else{
					 p.addXp(12, 25);
					stack = new ItemStack(MarkItems.Cod_Raw, 1);
				 }
			 }
			 else{
				 int a = 700;
				 if(a > LootRandom){
					 p.addXp(12, 50);
					stack = new ItemStack(Items.FISH, 1, 1);
				 }
				 else{
					 p.addXp(12, 25);
					stack = new ItemStack(MarkItems.Cod_Raw, 1);
				 }
			 }
			 
		 }
		 p.syncSkill();
		 return stack;
	 }
	 
	 
	 /**
	     * Will get destroyed next tick.
	     */
	    public void setDead()
	    {
	        super.setDead();
	        
	        if (this.angler != null)
	        {
	            this.angler.fishEntity = null;
	        }
	        
	    }
	 
}
