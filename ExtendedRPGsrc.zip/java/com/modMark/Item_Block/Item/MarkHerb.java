package com.modMark.Item_Block.Item;

import java.util.List;

import com.modMark.Item_Block.MarkItems;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkHerb extends Item {

	public MarkHerb(){
		super();
		this.setHasSubtypes(true);
		
		
	}
	
	public String getUnlocalizedName(ItemStack stack)
    {
	        int i = stack.getMetadata();
	        return super.getUnlocalizedName()+ "." + EnumHerb.byMeta(i).getUnlocalizedName();
	    
    }
	
	
	/**
     * returns a list of items with the same ID, but different meta (eg: dye returns 16 items)
     */
    @SideOnly(Side.CLIENT)
    public void getSubItems(Item itemIn, CreativeTabs tab, List<ItemStack> subItems)
    {
        for (int i = 0; i < 28; ++i)
        {
            subItems.add(new ItemStack(itemIn, 1, i));
        }
    }
    
    @Override
	 public ActionResult<ItemStack> onItemRightClick(ItemStack I, World W, EntityPlayer Player, EnumHand hand){
    	
    	Item item = I.getItem();
    	MarkData p = Player.getCapability(MainRegistry.ModMark136Data, null);
    	EnumHerb eHerb = EnumHerb.byMeta(I.getMetadata());
    	
    	if(eHerb == EnumHerb.Aneth_D){if(p.requireLvl(20, 1, 4)){p.addXp(20, 1); 	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 1));}}
    	else if(eHerb == EnumHerb.Romarin_D){if(p.requireLvl(20, 5, 4)){p.addXp(20, 1); 	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 3));}}
    	else if(eHerb == EnumHerb.Raifort_D){if(p.requireLvl(20, 12, 4)){p.addXp(20, 2); 	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 5));}}
    	else if(eHerb == EnumHerb.Celeri_D){if(p.requireLvl(20, 19, 4)){p.addXp(20, 2);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 7));}}
    	else if(eHerb == EnumHerb.Sarriette_D){if(p.requireLvl(20, 26, 4)){p.addXp(20, 3);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 9));}}
    	else if(eHerb == EnumHerb.Armoise_D){if(p.requireLvl(20, 33, 4)){p.addXp(20, 3);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 11));}}
    	else if(eHerb == EnumHerb.Cerfeuil_D){if(p.requireLvl(20, 40, 4)){p.addXp(20, 4);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 13));}}
    	else if(eHerb == EnumHerb.Estragon_D){if(p.requireLvl(20, 47, 4)){p.addXp(20, 4); 	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 15));}}
    	else if(eHerb == EnumHerb.Netherweed_D){if(p.requireLvl(20, 54, 4)){p.addXp(20, 5);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 17));}}
    	else if(eHerb == EnumHerb.Flameweed_D){if(p.requireLvl(20, 61, 4)){p.addXp(20, 5);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 19));}}
    	else if(eHerb == EnumHerb.BrutalRed_D){if(p.requireLvl(20, 68, 4)){p.addXp(20, 6);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 21));}}
    	else if(eHerb == EnumHerb.Crystweed_D){if(p.requireLvl(20, 75, 4)){p.addXp(20, 6);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 23));}}
    	else if(eHerb == EnumHerb.DarkCrystal_D){if(p.requireLvl(20, 82, 4)){p.addXp(20, 7);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 25));}}
    	else if(eHerb == EnumHerb.BrutalBlue_D){if(p.requireLvl(20, 89, 4)){p.addXp(20, 7);  	I.stackSize--;	Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.Herb, 1, 27));}}
    	
    	
    	return new ActionResult(EnumActionResult.PASS, I);
    }
    
}
