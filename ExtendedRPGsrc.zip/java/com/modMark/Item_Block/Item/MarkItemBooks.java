package com.modMark.Item_Block.Item;

import java.util.Random;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class MarkItemBooks extends Item {
	
	

	public MarkItemBooks(){
		super();
		
		
	}
	
	
	@Override
	public EnumActionResult onItemUse(ItemStack I, EntityPlayer Player, World W, BlockPos pos, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ)
    {	
		Item item = I.getItem();
		MarkData p = Player.getCapability(MainRegistry.ModMark136Data, null);
		Block block = W.getBlockState(pos).getBlock();
		Random ran = new Random();
		
		if (item == MarkItems.Book20){
			if (block == MarkBlocks.Script20){if(p.requireLvl(13, 20, 2)){
				p.addXp(13, 20); 
				I.stackSize--;
				Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW20, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				p.syncSkill();
				if(R < 18){W.setBlockState(pos, Blocks.STONE.getDefaultState());}}}
			
			else if (block == MarkBlocks.Script30){if(p.requireLvl(13, 30, 2)){
				p.addXp(13, 25); 
				I.stackSize--;
				Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW30, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				p.syncSkill();
				if(R < 20){W.setBlockState(pos, Blocks.STONE.getDefaultState());}}}
		}
		else if (item == MarkItems.Book40){
		
			if (block == MarkBlocks.Script40){if(p.requireLvl(13, 40, 2)){
				p.addXp(13, 30); 
				I.stackSize--;
				Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW40, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				p.syncSkill();
				if(R < 23){W.setBlockState(pos, Blocks.STONE.getDefaultState());}}}
			
			else if (block == MarkBlocks.Script50){if(p.requireLvl(13, 50, 2)){
				p.addXp(13, 35); 
				I.stackSize--;
				Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW50, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				p.syncSkill();
				if(R < 24){W.setBlockState(pos, Blocks.NETHERRACK.getDefaultState());}}}
		}
		else if (item == MarkItems.Book60){
			
			if (block == MarkBlocks.Script60){if(p.requireLvl(13, 60, 2)){
				p.addXp(13, 40); 
				I.stackSize--;
				Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW60, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				p.syncSkill();
				if(R < 25){W.setBlockState(pos, Blocks.NETHERRACK.getDefaultState());}}}
			
			else if (block == MarkBlocks.Script65){if(p.requireLvl(13, 65, 2)){
				p.addXp(13, 50); 
				I.stackSize--;
				Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW65, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				p.syncSkill();
				if(R < 26){W.setBlockState(pos, Blocks.NETHERRACK.getDefaultState());}}}
			
			else if (block == MarkBlocks.Script75){if(p.requireLvl(13, 75, 2)){
				p.addXp(13, 60); 
				I.stackSize--;
				Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW75, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				p.syncSkill();
				if(R < 26){W.setBlockState(pos, MarkBlocks.CrystRack.getDefaultState());}}}
		}
			else if (item == MarkItems.Book80){
			
			if (block == MarkBlocks.Script80){if(p.requireLvl(13, 80, 2)){
				p.addXp(13, 70); 
				I.stackSize--;
				Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW80, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				p.syncSkill();
				if(R < 27){W.setBlockState(pos, MarkBlocks.CrystRack.getDefaultState());}}}
			
			else if (block == MarkBlocks.Script85){if(p.requireLvl(13, 85, 2)){
				p.addXp(13, 80); 
				I.stackSize--;
				Player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW85, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				p.syncSkill();
				if(R < 27){W.setBlockState(pos, MarkBlocks.CrystRack.getDefaultState());}}}
			
		}
		
		return EnumActionResult.PASS;
		
		
		
	}
}

