package com.modMark.Item_Block.Item;

import com.modMark.Item_Block.MarkItems;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class MarkItemBooksWritten extends Item {
	
	public MarkItemBooksWritten(){
		super();
		
		
	}

	@Override
	public ActionResult<ItemStack> onItemRightClick(ItemStack I, World worldIn, EntityPlayer Player, EnumHand hand)
    {	
		Item item = I.getItem();
		MarkData p = Player.getCapability(MainRegistry.ModMark136Data, null);
		
		if (item == MarkItems.BookW1){if (p.requireLvl(27, 1, 3)){p.addXp(27, 5); I.stackSize--;}}
		else if (item == MarkItems.BookW5){if (p.requireLvl(27, 5, 3)){p.addXp(27, 8); I.stackSize--;}}		
		else if (item == MarkItems.BookW10){if (p.requireLvl(27, 10, 3)){p.addXp(27, 12); I.stackSize--;}}
		else if (item == MarkItems.BookW15){if (p.requireLvl(27, 15, 3)){p.addXp(27, 15); I.stackSize--;}}
		else if (item == MarkItems.BookW20){if (p.requireLvl(27, 20, 3)){p.addXp(27, 20); I.stackSize--;}}
		else if (item == MarkItems.BookW30){if (p.requireLvl(27, 30, 3)){p.addXp(27, 25); I.stackSize--;}}
		else if (item == MarkItems.BookW40){if (p.requireLvl(27, 40, 3)){p.addXp(27, 30); I.stackSize--;}}
		else if (item == MarkItems.BookW50){if (p.requireLvl(27, 50, 3)){p.addXp(27, 35); I.stackSize--;}}
		else if (item == MarkItems.BookW60){if (p.requireLvl(27, 60, 3)){p.addXp(27, 40); I.stackSize--;}}
		else if (item == MarkItems.BookW65){if (p.requireLvl(27, 65, 3)){p.addXp(27, 50); I.stackSize--;}}
		else if (item == MarkItems.BookW75){if (p.requireLvl(27, 75, 3)){p.addXp(27, 60); I.stackSize--;}}
		else if (item == MarkItems.BookW80){if (p.requireLvl(27, 80, 3)){p.addXp(27, 70); I.stackSize--;}}
		else if (item == MarkItems.BookW85){if (p.requireLvl(27, 85, 3)){p.addXp(27, 80); I.stackSize--;}}
		
		p.syncSkill();
		return new ActionResult(EnumActionResult.PASS, I);
		
	}
}
