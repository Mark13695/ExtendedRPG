package com.modMark.Item_Block.Item;

import com.modMark.Combat.EntityOpalShot;
import com.modMark.Item_Block.MarkItems;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkWand extends Item {
	
	private EnumMaterial material;
	private float AttackDamage;
	private int Cooldown = 0;
	
	public MarkWand(EnumMaterial Material){
		this.material = Material;
		this.maxStackSize = 1;
		this.setMaxDamage(Material.getMaxUses());
		this.AttackDamage = 3.0F + Material.getDamage();
	}

	@SideOnly(Side.CLIENT)
    public boolean isFull3D()
    {
        return true;
    }
	
	@Override
	public ActionResult<ItemStack> onItemRightClick(ItemStack I, World W, EntityPlayer Player, EnumHand hand)
    {
		if(this.Cooldown < 1){
		this.Cooldown = 30;
		
		Entity GemBall;
		
		if(this == MarkItems.Wand1){
			GemBall = new EntityOpalShot(W, Player, 0);
			
			
			((EntityOpalShot) GemBall).setHeadingFromThrower(Player, Player.rotationPitch, Player.rotationYaw, 0.0F, 1.5F, 1.0F);
            W.spawnEntityInWorld(GemBall);
			I.damageItem(1, Player);
		}
		else{
		
		Vec3d aim = Player.getLookVec();
		
		GemBall = new EntitySmallFireball(W, Player, 1, 1, 1);
		
		((EntitySmallFireball)GemBall).setPosition(
				Player.posX + aim.xCoord * 1.5D,
				Player.posY + aim.yCoord * 1.5D,
				Player.posZ + aim.zCoord * 1.5D);
		((EntitySmallFireball)GemBall).accelerationX = aim.xCoord * 0.1;
		((EntitySmallFireball)GemBall).accelerationY = aim.yCoord * 0.1;
		((EntitySmallFireball)GemBall).accelerationZ = aim.zCoord * 0.1;
		}
		 
		W.spawnEntityInWorld(GemBall);
		
		
		
    }
		return new ActionResult(EnumActionResult.PASS, I);
    }
	
	@Override
	public void onUpdate(ItemStack itemstack, World world, Entity entity, int i, boolean B) {
	if (this.Cooldown > 0){
		this.Cooldown--;
	}
	}
}
