package com.modMark.Item_Block;

import java.util.HashSet;
import java.util.Set;

import com.modMark.Item_Block.Block.BlockGemOres;
import com.modMark.Item_Block.Block.MarkCraftingTable;
import com.modMark.Item_Block.Block.MarkCrops;
import com.modMark.Item_Block.Block.MarkCrystalBush;
import com.modMark.Item_Block.Block.MarkDoor;
import com.modMark.Item_Block.Block.MarkFullTrap;
import com.modMark.Item_Block.Block.MarkGlass;
import com.modMark.Item_Block.Block.MarkGrass;
import com.modMark.Item_Block.Block.MarkHerbCrops;
import com.modMark.Item_Block.Block.MarkLeaf;
import com.modMark.Item_Block.Block.MarkLog;
import com.modMark.Item_Block.Block.MarkOre;
import com.modMark.Item_Block.Block.MarkPlanks;
import com.modMark.Item_Block.Block.MarkRack;
import com.modMark.Item_Block.Block.MarkSand;
import com.modMark.Item_Block.Block.MarkSand2;
import com.modMark.Item_Block.Block.MarkSapling;
import com.modMark.Item_Block.Block.MarkSaplingVanilla;
import com.modMark.Item_Block.Block.MarkScriptBlock;
import com.modMark.Item_Block.Block.MarkStairs;
import com.modMark.Item_Block.Block.MarkTallGrass;
import com.modMark.Item_Block.Block.MarkTrap;
import com.modMark.Item_Block.Fluid.BlockMarkLiquid;
import com.modMark.Item_Block.Fluid.MarkLava;
import com.modMark.Main.MainRegistry;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockNetherrack;
import net.minecraft.block.BlockOldLog;
import net.minecraft.block.BlockOre;
import net.minecraft.block.BlockPlanks;
import net.minecraft.block.BlockSoulSand;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class MarkBlocks {

	public static final Set<Block> Markblocks = new HashSet<>();
	
	public static final Material Trap = new Material(MapColor.IRON);
	
	public static Block GemOpalOre = new BlockGemOres("GemOpalOre");
	public static Block GemSapphireOre = new BlockGemOres("GemSapphireOre");
	public static Block GemOlivineOre = new BlockGemOres("GemOlivineOre");
	public static Block GemHyacinthOre = new BlockGemOres("GemHyacinthOre");
	public static Block GemTopazOre = new BlockGemOres("GemTopazOre");
	public static Block GemAmethystOre = new BlockGemOres("GemAmethystOre");
	public static Block GemSiamOre = new BlockGemOres("GemSiamOre");
	public static Block GemAquamarineOre = new BlockGemOres("GemAquamarineOre");
	
	public static Block EnrichedGrass = new MarkGrass("EnrichedGrass", 2);
	public static Block NetherSand = new MarkSand2("NetherSand", 2);
	public static Block CrystSand = new MarkSand2("CrystSand", 3);
	public static Block OreIron = new MarkOre("OreIron");
	public static Block OreGold = new MarkOre("OreGold");
	public static Block OreNetherite = new MarkOre("OreNetherite");
	public static Block OreCrystlium = new MarkOre("OreCrystlium");
	public static Block CrystRack = new MarkRack("CrystRack");
	public static Block Cyantinian = new MarkSand("Cyantinian");
	
	public static Block CrystBricks = new MarkRack("CrystBricks");
	public static Block LogYew = new MarkLog("LogYew");
	public static Block LogNetherBranch = new MarkLog("LogNetherBranch");
	public static Block LogCrystWood = new MarkLog("LogCrystWood");
	public static Block LogYew_Leaf = new MarkLeaf("LogYew_Leaf");
	public static Block LogNetherBranch_Leaf = new MarkLeaf("LogNetherBranch_Leaf");
	public static Block LogCrystWood_Leaf = new MarkLeaf("LogCrystWood_Leaf");
	
	public static Block LogOak_Sapling = new MarkSaplingVanilla("LogOak_Sapling");
	public static Block LogBirch_Sapling = new MarkSaplingVanilla("LogBirch_Sapling");
	public static Block LogSpruce_Sapling = new MarkSaplingVanilla("LogSpruce_Sapling");
	public static Block LogJungle_Sapling = new MarkSaplingVanilla("LogJungle_Sapling");
	public static Block LogAcacia_Sapling = new MarkSaplingVanilla("LogAcacia_Sapling");
	public static Block LogDarkOak_Sapling = new MarkSaplingVanilla("LogDarkOak_Sapling");
	public static Block LogYew_Sapling = new MarkSapling("LogYew_Sapling", MarkBlocks.LogYew.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogYew_Leaf.getDefaultState());
	public static Block LogNetherBranch_Sapling = new MarkSapling("LogNetherBranch_Sapling", MarkBlocks.LogNetherBranch.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogNetherBranch_Leaf.getDefaultState());
	public static Block LogCrystWood_Sapling = new MarkSapling("LogCrystWood_Sapling", MarkBlocks.LogCrystWood.getDefaultState().withProperty(MarkLog.LOG_AXIS, BlockLog.EnumAxis.Y), MarkBlocks.LogCrystWood_Leaf.getDefaultState());
	
	public static Block LogYew_Planks = new MarkPlanks("LogYew_Planks");
	public static Block LogNetherBranch_Planks = new MarkPlanks("LogNetherBranch_Planks");
	public static Block LogCrystWood_Planks = new MarkPlanks("LogCrystWood_Planks");
	
	public static Block LogYew_Door = new MarkDoor("LogYew_Door");
	public static Block LogNetherBranch_Door = new MarkDoor("LogNetherBranch_Door");
	public static Block LogCrystWood_Door = new MarkDoor("LogCrystWood_Door");
	
	public static Block LogYew_stairs = new MarkStairs("LogYew_stairs", MarkBlocks.LogYew_Planks.getDefaultState());
	
	public static Block Script01 = new MarkScriptBlock("Script01");
	public static Block Script05 = new MarkScriptBlock("Script05");
	public static Block Script10 = new MarkScriptBlock("Script10");
	public static Block Script15 = new MarkScriptBlock("Script15");
	public static Block Script20 = new MarkScriptBlock("Script20");
	public static Block Script30 = new MarkScriptBlock("Script30");
	public static Block Script40 = new MarkScriptBlock("Script40");
	public static Block Script50 = new MarkScriptBlock("Script50");
	public static Block Script60 = new MarkScriptBlock("Script60");
	public static Block Script65 = new MarkScriptBlock("Script65");
	public static Block Script75 = new MarkScriptBlock("Script75");
	public static Block Script80 = new MarkScriptBlock("Script80");
	public static Block Script85 = new MarkScriptBlock("Script85");
	
	public static Block MarkTrapE = new MarkTrap("MarkTrapE");
	public static Block MarkTrapB = new MarkFullTrap("MarkTrapB");
	public static Block MarkTrap01 = new MarkFullTrap("MarkTrap01");
	public static Block MarkTrap10 = new MarkFullTrap("MarkTrap10");
	public static Block MarkTrap20 = new MarkFullTrap("MarkTrap20");
	public static Block MarkTrap40 = new MarkFullTrap("MarkTrap40");
	public static Block MarkTrap60 = new MarkFullTrap("MarkTrap60");
	public static Block MarkTrap80 = new MarkFullTrap("MarkTrap80");
	
	public static Block DiamondBush = new MarkCrystalBush("DiamondBush",Material.ROCK);
	public static Block AmethystBush = new MarkCrystalBush("AmethystBush", Material.GROUND);
	
	public static Block TallGrass40 = new MarkTallGrass("TallGrass40");
	public static Block TallGrass60 = new MarkTallGrass("TallGrass60");
	public static Block TallGrass80 = new MarkTallGrass("TallGrass80");
	
	public static Block AnethCrop = new MarkHerbCrops("AnethCrop", Blocks.FARMLAND);
	public static Block RomarinCrop = new MarkHerbCrops("RomarinCrop", Blocks.FARMLAND);
	public static Block RaifortCrop = new MarkHerbCrops("RaifortCrop", Blocks.FARMLAND);
	public static Block CeleriCrop = new MarkHerbCrops("CeleriCrop", Blocks.FARMLAND);
	public static Block SarrietteCrop = new MarkHerbCrops("SarrietteCrop", Blocks.FARMLAND);
	public static Block ArmoiseCrop = new MarkHerbCrops("ArmoiseCrop", Blocks.FARMLAND);
	public static Block CerfeuilCrop = new MarkHerbCrops("CerfeuilCrop", Blocks.FARMLAND);
	public static Block EstragonCrop = new MarkHerbCrops("EstragonCrop", Blocks.FARMLAND);
	public static Block NetherweedCrop = new MarkHerbCrops("NetherweedCrop", MarkBlocks.NetherSand);
	public static Block FlameweedCrop = new MarkHerbCrops("FlameweedCrop", MarkBlocks.NetherSand);
	public static Block BrutalRedCrop = new MarkHerbCrops("BrutalRedCrop", MarkBlocks.NetherSand);
	public static Block CrystweedCrop = new MarkHerbCrops("CrystweedCrop", MarkBlocks.CrystSand);
	public static Block DarkCrystalCrop = new MarkHerbCrops("DarkCrystalCrop", MarkBlocks.CrystSand);
	public static Block BrutalBlueCrop = new MarkHerbCrops("BrutalBlueCrop", MarkBlocks.CrystSand);
	
	public static Block OnionCrop = new MarkCrops("OnionCrop", Blocks.FARMLAND);
	public static Block TomatoCrop = new MarkCrops("TomatoCrop", MarkBlocks.NetherSand);
	public static Block BlueberryCrop = new MarkCrops("BlueberryCrop", MarkBlocks.CrystSand);
	
	public static Block CommonCottonCrop = new MarkCrops("CommonCottonCrop", Blocks.FARMLAND);
	public static Block GreenCottonCrop = new MarkCrops("GreenCottonCrop", Blocks.FARMLAND);
	public static Block RedCottonCrop = new MarkCrops("RedCottonCrop", Blocks.FARMLAND);
	public static Block BlueCottonCrop = new MarkCrops("BlueCottonCrop", Blocks.FARMLAND);
	
	public static Block BasicTable = new MarkCraftingTable("BasicTable", Material.WOOD, 0);
	public static Block TailoryBench_I = new MarkCraftingTable("TailoryBench_I", Material.WOOD, 2);
	public static Block TailoryBench_II = new MarkCraftingTable("TailoryBench_II", Material.WOOD, 2);
	public static Block Anvil_I = new MarkCraftingTable("Anvil_I", Material.ROCK, 3);
	public static Block Anvil_II = new MarkCraftingTable("Anvil_II", Material.ROCK, 3);
	public static Block Furnace_I = new MarkCraftingTable("Furnace_I", Material.ROCK, 3);
	public static Block Furnace_II = new MarkCraftingTable("Furnace_II", Material.ROCK, 3);
	public static Block TanningBench_I = new MarkCraftingTable("TanningBench_I", Material.WOOD, 4);
	public static Block TanningBench_II = new MarkCraftingTable("TanningBench_II", Material.WOOD, 4);
	public static Block JewelryTable_I = new MarkCraftingTable("JewelryTable_I", Material.WOOD, 5);
	public static Block JewelryTable_II = new MarkCraftingTable("JewelryTable_II", Material.WOOD, 5);
	public static Block GlassOven_I = new MarkCraftingTable("GlassOven_I", Material.ROCK, 5);
	public static Block GlassOven_II = new MarkCraftingTable("GlassOven_II", Material.ROCK, 5);
	public static Block FletchingTable_I = new MarkCraftingTable("FletchingTable_I", Material.WOOD, 6);
	public static Block FletchingTable_II = new MarkCraftingTable("FletchingTable_II", Material.WOOD, 6);
	public static Block Range_I = new MarkCraftingTable("Range_I", Material.ROCK, 7);
	public static Block Range_II = new MarkCraftingTable("Range_II", Material.ROCK, 7);
	public static Block Cauldron_I = new MarkCraftingTable("Cauldron_I", Material.ROCK, 8);
	public static Block Cauldron_II = new MarkCraftingTable("Cauldron_II", Material.ROCK, 8);
	public static Block WorkBench_I = new MarkCraftingTable("WorkBench_I", Material.WOOD, 10);
	public static Block WorkBench_II = new MarkCraftingTable("WorkBench_II", Material.WOOD, 10);
	public static Block TechBench_I = new MarkCraftingTable("TechBench_I", Material.ROCK, 11);
	public static Block DirtGlass = new MarkGlass("DirtGlass"); //TODO
	public static Block GravelGlass = new MarkGlass("GravelGlass");
	public static Block NetherGlass = new MarkGlass("NetherGlass");
	public static Block SoulGlass = new MarkGlass("SoulGlass");
	public static Block CrystGlass = new MarkGlass("CrystGlass");
	public static Block CyantinianGlass = new MarkGlass("CyantinianGlass");
	
	public static ItemBlock[] ItemBlockArray = new ItemBlock[350];
	public static int a = 0;
	
	
	public static final void init(){
		
		RegisterTheBlock(GemOpalOre, new ResourceLocation("mark13695:GemOpalOre")).setHardness(0.6F);
		RegisterTheBlock(GemSapphireOre, new ResourceLocation("mark13695:GemSapphireOre")).setHardness(2.7F);
		RegisterTheBlock(GemOlivineOre, new ResourceLocation("mark13695:GemOlivineOre")).setHardness(3.2F);
		RegisterTheBlock(GemHyacinthOre, new ResourceLocation("mark13695:GemHyacinthOre")).setHardness(4.0F);
		RegisterTheBlock(GemTopazOre, new ResourceLocation("mark13695:GemTopazOre")).setHardness(4.8F);
		RegisterTheBlock(GemAmethystOre, new ResourceLocation("mark13695:GemAmethystOre")).setHardness(5.9F);
		RegisterTheBlock(GemSiamOre, new ResourceLocation("mark13695:GemSiamOre")).setHardness(7.0F);
		RegisterTheBlock(GemAquamarineOre, new ResourceLocation("mark13695:GemAquamarineOre")).setLightLevel(0.5F).setHardness(8.0F);
		RegisterTheBlock(EnrichedGrass , new ResourceLocation("mark13695:EnrichedGrass"));
		RegisterTheBlock(NetherSand, new ResourceLocation("mark13695:NetherSand")).setHardness(1.1F);
		RegisterTheBlock(CrystSand, new ResourceLocation("mark13695:CrystSand")).setHardness(1.4F).setLightLevel(0.5F);
		RegisterTheBlock(OreIron, new ResourceLocation("mark13695:OreIron")).setHardness(5.1F).setHarvestLevel("pickaxe", 1);
		RegisterTheBlock(OreGold, new ResourceLocation("mark13695:OreGold")).setHardness(7.3F).setLightLevel(0.5F).setHarvestLevel("pickaxe", 2);
		RegisterTheBlock(OreNetherite, new ResourceLocation("mark13695:OreNetherite")).setHardness(5.1F).setHarvestLevel("pickaxe", 3);
		RegisterTheBlock(OreCrystlium, new ResourceLocation("mark13695:OreCrystlium")).setHardness(7.3F).setLightLevel(0.5F).setHarvestLevel("pickaxe", 3);
		RegisterTheBlock(CrystRack, new ResourceLocation("mark13695:CrystRack")).setHardness(1.8F).setLightLevel(0.5F).setHarvestLevel("pickaxe", 3);
		RegisterTheBlock(Cyantinian, new ResourceLocation("mark13695:Cyantinian")).setHardness(70.0F).setResistance(2200.0F).setLightLevel(0.5F);
		
		RegisterTheBlock(CrystBricks , new ResourceLocation("mark13695:CrystBricks")).setCreativeTab(MainRegistry.tabMark).setLightLevel(0.5f).setHarvestLevel("pickaxe", 3);
		RegisterTheBlock(LogYew , new ResourceLocation("mark13695:LogYew")).setHarvestLevel("axe", 2);
		RegisterTheBlock(LogNetherBranch , new ResourceLocation("mark13695:LogNetherBranch")).setHarvestLevel("axe", 3);
		RegisterTheBlock(LogCrystWood , new ResourceLocation("mark13695:LogCrystWood")).setHarvestLevel("axe", 3);
		RegisterTheBlock(LogYew_Leaf , new ResourceLocation("mark13695:LogYew_Leaf"));
		RegisterTheBlock(LogNetherBranch_Leaf , new ResourceLocation("mark13695:LogNetherBranch_Leaf"));
		RegisterTheBlock(LogCrystWood_Leaf , new ResourceLocation("mark13695:LogCrystWood_Leaf"));
		
		RegisterTheBlock(LogOak_Sapling, new ResourceLocation("mark13695:LogOak_Sapling"));
		RegisterTheBlock(LogBirch_Sapling, new ResourceLocation("mark13695:LogBirch_Sapling"));
		RegisterTheBlock(LogSpruce_Sapling, new ResourceLocation("mark13695:LogSpruce_Sapling"));
		RegisterTheBlock(LogJungle_Sapling, new ResourceLocation("mark13695:LogJungle_Sapling"));
		RegisterTheBlock(LogAcacia_Sapling, new ResourceLocation("mark13695:LogAcacia_Sapling"));
		RegisterTheBlock(LogDarkOak_Sapling, new ResourceLocation("mark13695:LogDarkOak_Sapling"));
		
		RegisterTheBlock(LogYew_Sapling , new ResourceLocation("mark13695:LogYew_Sapling"));
		RegisterTheBlock(LogNetherBranch_Sapling , new ResourceLocation("mark13695:LogNetherBranch_Sapling"));
		RegisterTheBlock(LogCrystWood_Sapling , new ResourceLocation("mark13695:LogCrystWood_Sapling"));
		
		RegisterTheBlock(LogYew_Planks , new ResourceLocation("mark13695:LogYew_Planks")).setHarvestLevel("axe", 2);
		RegisterTheBlock(LogNetherBranch_Planks , new ResourceLocation("mark13695:LogNetherBranch_Planks")).setHarvestLevel("axe", 3);
		RegisterTheBlock(LogCrystWood_Planks , new ResourceLocation("mark13695:LogCrystWood_Planks")).setHarvestLevel("axe", 3);

		RegisterTheBlock2(LogYew_Door , new ResourceLocation("mark13695:LogYew_Door")).setHarvestLevel("axe", 2);
		RegisterTheBlock2(LogNetherBranch_Door , new ResourceLocation("mark13695:LogNetherBranch_Door")).setHarvestLevel("axe", 3);
		RegisterTheBlock2(LogCrystWood_Door , new ResourceLocation("mark13695:LogCrystWood_Door")).setHarvestLevel("axe", 3);

		RegisterTheBlock(LogYew_stairs , new ResourceLocation("mark13695:LogYew_stairs")).setHarvestLevel("axe", 2);
		
		
		RegisterTheBlock(TallGrass40 , new ResourceLocation("mark13695:TallGrass40"));
		RegisterTheBlock(TallGrass60 , new ResourceLocation("mark13695:TallGrass60"));
		RegisterTheBlock(TallGrass80 , new ResourceLocation("mark13695:TallGrass80"));
		
		RegisterTheBlock(Script01, new ResourceLocation("mark13695:Script01"));
		RegisterTheBlock(Script05, new ResourceLocation("mark13695:Script05"));
		RegisterTheBlock(Script10, new ResourceLocation("mark13695:Script10"));
		RegisterTheBlock(Script15, new ResourceLocation("mark13695:Script15"));
		RegisterTheBlock(Script20, new ResourceLocation("mark13695:Script20"));
		RegisterTheBlock(Script30, new ResourceLocation("mark13695:Script30"));
		RegisterTheBlock(Script40, new ResourceLocation("mark13695:Script40"));
		RegisterTheBlock(Script50, new ResourceLocation("mark13695:Script50"));
		RegisterTheBlock(Script60, new ResourceLocation("mark13695:Script60"));
		RegisterTheBlock(Script65, new ResourceLocation("mark13695:Script65"));
		RegisterTheBlock(Script75, new ResourceLocation("mark13695:Script75")).setLightLevel(0.5f);
		RegisterTheBlock(Script80, new ResourceLocation("mark13695:Script80")).setLightLevel(0.5f);
		RegisterTheBlock(Script85, new ResourceLocation("mark13695:Script85")).setLightLevel(0.5f);
		RegisterTheBlock(MarkTrapE, new ResourceLocation("mark13695:MarkTrapE"));
		RegisterTheBlock(MarkTrapB, new ResourceLocation("mark13695:MarkTrapB"));
		RegisterTheBlock(MarkTrap01, new ResourceLocation("mark13695:MarkTrap01"));
		RegisterTheBlock(MarkTrap10, new ResourceLocation("mark13695:MarkTrap10"));
		RegisterTheBlock(MarkTrap20, new ResourceLocation("mark13695:MarkTrap20"));
		RegisterTheBlock(MarkTrap40, new ResourceLocation("mark13695:MarkTrap40"));
		RegisterTheBlock(MarkTrap60, new ResourceLocation("mark13695:MarkTrap60"));
		RegisterTheBlock(MarkTrap80, new ResourceLocation("mark13695:MarkTrap80"));
		RegisterTheBlock(DiamondBush, new ResourceLocation("mark13695:DiamondBush"));
		RegisterTheBlock(AmethystBush, new ResourceLocation("mark13695:AmethystBush"));
		
		RegisterTheBlock(AnethCrop, new ResourceLocation("mark13695:AnethCrop"));
		RegisterTheBlock(RomarinCrop, new ResourceLocation("mark13695:RomarinCrop"));
		RegisterTheBlock(RaifortCrop, new ResourceLocation("mark13695:RaifortCrop"));
		RegisterTheBlock(CeleriCrop, new ResourceLocation("mark13695:CeleriCrop"));
		RegisterTheBlock(SarrietteCrop, new ResourceLocation("mark13695:SarrietteCrop"));
		RegisterTheBlock(ArmoiseCrop, new ResourceLocation("mark13695:ArmoiseCrop"));
		RegisterTheBlock(CerfeuilCrop, new ResourceLocation("mark13695:CerfeuilCrop"));
		RegisterTheBlock(EstragonCrop, new ResourceLocation("mark13695:EstragonCrop"));
		RegisterTheBlock(NetherweedCrop, new ResourceLocation("mark13695:NetherweedCrop"));
		RegisterTheBlock(FlameweedCrop, new ResourceLocation("mark13695:FlameweedCrop"));
		RegisterTheBlock(BrutalRedCrop, new ResourceLocation("mark13695:BrutalRedCrop"));
		RegisterTheBlock(CrystweedCrop, new ResourceLocation("mark13695:CrystweedCrop"));
		RegisterTheBlock(DarkCrystalCrop, new ResourceLocation("mark13695:DarkCrystalCrop"));
		RegisterTheBlock(BrutalBlueCrop, new ResourceLocation("mark13695:BrutalBlueCrop"));
		
		RegisterTheBlock(OnionCrop, new ResourceLocation("mark13695:OnionCrop"));
		RegisterTheBlock(TomatoCrop, new ResourceLocation("mark13695:TomatoCrop"));
		RegisterTheBlock(BlueberryCrop, new ResourceLocation("mark13695:BlueberryCrop"));
		RegisterTheBlock(CommonCottonCrop, new ResourceLocation("mark13695:CommonCottonCrop"));
		RegisterTheBlock(GreenCottonCrop, new ResourceLocation("mark13695:GreenCottonCrop"));
		RegisterTheBlock(RedCottonCrop, new ResourceLocation("mark13695:RedCottonCrop"));
		RegisterTheBlock(BlueCottonCrop, new ResourceLocation("mark13695:BlueCottonCrop"));
		
		RegisterTheBlock(BasicTable, new ResourceLocation("mark13695:BasicTable"));
		RegisterTheBlock(TailoryBench_I, new ResourceLocation("mark13695:TailoryBench_I"));
		RegisterTheBlock(TailoryBench_II, new ResourceLocation("mark13695:TailoryBench_II"));
		RegisterTheBlock(Anvil_I, new ResourceLocation("mark13695:Anvil_I"));
		RegisterTheBlock(Anvil_II, new ResourceLocation("mark13695:Anvil_II"));
		RegisterTheBlock(Furnace_I, new ResourceLocation("mark13695:Furnace_I"));
		RegisterTheBlock(Furnace_II, new ResourceLocation("mark13695:Furnace_II"));
		RegisterTheBlock(TanningBench_I, new ResourceLocation("mark13695:TanningBench_I"));
		RegisterTheBlock(TanningBench_II, new ResourceLocation("mark13695:TanningBench_II"));
		RegisterTheBlock(JewelryTable_I, new ResourceLocation("mark13695:JewelryTable_I"));
		RegisterTheBlock(JewelryTable_II, new ResourceLocation("mark13695:JewelryTable_II"));
		RegisterTheBlock(GlassOven_I,  new ResourceLocation("mark13695:GlassOven_I"));
		RegisterTheBlock(GlassOven_II,  new ResourceLocation("mark13695:GlassOven_II"));
		RegisterTheBlock(FletchingTable_I,  new ResourceLocation("mark13695:FletchingTable_I"));
		RegisterTheBlock(FletchingTable_II,  new ResourceLocation("mark13695:FletchingTable_II"));
		RegisterTheBlock(Range_I,  new ResourceLocation("mark13695:Range_I"));
		RegisterTheBlock(Range_II,  new ResourceLocation("mark13695:Range_II"));
		RegisterTheBlock(Cauldron_I,  new ResourceLocation("mark13695:Cauldron_I"));
		RegisterTheBlock(Cauldron_II,  new ResourceLocation("mark13695:Cauldron_II"));
		RegisterTheBlock(WorkBench_I, new ResourceLocation("mark13695:WorkBench_I"));
		RegisterTheBlock(WorkBench_II, new ResourceLocation("mark13695:WorkBench_II"));
		RegisterTheBlock(TechBench_I,  new ResourceLocation("mark13695:TechBench_I"));
		RegisterTheBlock(DirtGlass,  new ResourceLocation("mark13695:DirtGlass"));
		RegisterTheBlock(GravelGlass,  new ResourceLocation("mark13695:GravelGlass"));
		RegisterTheBlock(NetherGlass,  new ResourceLocation("mark13695:NetherGlass"));
		RegisterTheBlock(SoulGlass,  new ResourceLocation("mark13695:SoulGlass"));
		RegisterTheBlock(CrystGlass,  new ResourceLocation("mark13695:CrystGlass"));
		RegisterTheBlock(CyantinianGlass,  new ResourceLocation("mark13695:CyantinianGlass"));
	}
	
	public static Block RegisterTheBlock(Block block, ResourceLocation name){
		GameRegistry.register(block, name);
		ItemBlockArray[a] = new ItemBlock(block);
		GameRegistry.register(ItemBlockArray[a], name);
		a++;
		Markblocks.add(block);
		
		return block;
	}
	public static Block RegisterTheBlock2(Block block, ResourceLocation name){
		GameRegistry.register(block, name);
		Markblocks.add(block);
		
		return block;
	}
}
