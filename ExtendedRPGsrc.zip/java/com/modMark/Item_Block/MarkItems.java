package com.modMark.Item_Block;

import java.util.HashSet;
import java.util.Set;

import com.modMark.Item_Block.Item.EnumMaterial;
import com.modMark.Item_Block.Item.ItemMarkQuiver;
import com.modMark.Item_Block.Item.ItemMarkQuiver2;
import com.modMark.Item_Block.Item.ItemTrap;
import com.modMark.Item_Block.Item.ItemTrapKey;
import com.modMark.Item_Block.Item.MarkBow;
import com.modMark.Item_Block.Item.MarkHerb;
import com.modMark.Item_Block.Item.MarkItemBooks;
import com.modMark.Item_Block.Item.MarkItemBooksWritten;
import com.modMark.Item_Block.Item.MarkItemDoor;
import com.modMark.Item_Block.Item.MarkRod;
import com.modMark.Item_Block.Item.MarkSword;
import com.modMark.Item_Block.Item.MarkWand;
import com.modMark.Main.MainRegistry;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSeeds;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class MarkItems {

	public static final Set<Item> items = new HashSet<>();
	
	public static Item GemOpal;
	public static Item GemSapphire;
	public static Item GemOlivine;
	public static Item GemHyacinth;
	public static Item GemTopaz;
	public static Item GemAmethyst;
	public static Item GemSiam;
	public static Item GemAquamarine;
	
	public static Item NetheriteBar;
	public static Item CrystliumBar;
	
	public static Item BookW1;
	public static Item BookW5;
	public static Item BookW10;
	public static Item BookW15;
	public static Item Book20;
	public static Item BookW20;
	public static Item BookW30;
	public static Item Book40;
	public static Item BookW40;
	public static Item BookW50;
	public static Item Book60;
	public static Item BookW60;
	public static Item BookW65;
	public static Item BookW75;
	public static Item Book80;
	public static Item BookW80;
	public static Item BookW85;
	
	
	public static Item Hide10;
	public static Item Hide20;
	public static Item Hide40;
	public static Item Hide60;
	public static Item Hide80;
	public static Item Leather20;
	public static Item Leather40;
	public static Item Leather60;
	public static Item Leather80;
	public static Item Herb = new MarkHerb();
	public static Item Trap01;
	public static Item Trap10;
	public static Item Trap20;
	public static Item Trap40;
	public static Item Trap60;
	public static Item Trap80;
	public static Item TrapKey;
	
	public static Item AnethSeed;
	public static Item RomarinSeed;
	public static Item RaifortSeed;
	public static Item CeleriSeed;
	public static Item SarrietteSeed;
	public static Item ArmoiseSeed;
	public static Item CerfeuilSeed;
	public static Item EstragonSeed;
	public static Item NetherweedSeed;
	public static Item FlameweedSeed;
	public static Item BrutalRedSeed;
	public static Item CrystweedSeed;
	public static Item DarkCrystalSeed;
	public static Item BrutalBlueSeed;
	
	public static Item OnionSeed;
	public static Item TomatoSeed;
	public static Item BlueberrySeed;
	public static Item Onion;
	public static Item Tomato;
	public static Item Blueberry;
	
	public static Item CommonCottonSeed;
	public static Item GreenCottonSeed;
	public static Item RedCottonSeed;
	public static Item BlueCottonSeed;
	
	public static Item Cotton20;
	public static Item Cotton40;
	public static Item Cotton60;
	public static Item Cotton80;
	
	public static Item Silk20;
	public static Item Silk40;
	public static Item Silk60;
	public static Item Silk80;
	
	public static Item Cod_Raw;
	public static Item Trout_Raw;
	public static Item Sardine_Raw;
	public static Item Tuna_Raw;
	public static Item Herring_Raw;
	public static Item Bass_Raw;
	public static Item Eel_Raw;
	public static Item Batiod_Raw;
	public static Item Shark_Raw;
	
	public static Item Cod_Cooked;
	public static Item Trout_Cooked;
	public static Item Sardine_Cooked;
	public static Item Tuna_Cooked;
	public static Item Herring_Cooked;
	public static Item Bass_Cooked;
	public static Item Eel_Cooked;
	public static Item Batiod_Cooked;
	public static Item Shark_Cooked;
	public static Item FishRod;
	
	public static Item CakeUnf;
	
	public static Item Stick10;
	public static Item Stick20;
	public static Item Stick40;
	public static Item Stick60;
	public static Item Stick80;
	public static Item LogYew_Door;
	public static Item LogNetherBranch_Door;
	public static Item LogCrystWood_Door;
	
	public static Item Wand1unf;
	public static Item Wand20unf;
	public static Item Wand40unf;
	public static Item Wand60unf;
	public static Item Wand80unf;
	public static Item OpalShotIcon;
	public static Item SapphireShotIcon;
	public static Item OlivineShotIcon;
	public static Item HyacinthShotIcon;
	public static Item DefensiveShotIcon;
	
	public static Item Bow1;
	public static Item Bow10;
	public static Item Bow20;
	public static Item Bow40;
	public static Item Bow60;
	public static Item Bow80;
	
	public static Item Quiver1;
	public static Item Quiver1D;
	public static Item Quiver10X;
	public static Item Quiver20;
	public static Item Quiver20D;
	public static Item Quiver20X;
	public static Item Quiver40;
	public static Item Quiver40D;
	public static Item Quiver40X;
	public static Item Quiver60;
	public static Item Quiver60D;
	public static Item Quiver60X;
	public static Item Quiver80;
	public static Item Quiver80D;
	public static Item Quiver80X;
	
	public static Item Quiver1I;
	public static Item Quiver1DI;
	public static Item Quiver10XI;
	public static Item Quiver20I;
	public static Item Quiver20DI;
	public static Item Quiver20XI;
	public static Item Quiver40I;
	public static Item Quiver40DI;
	public static Item Quiver40XI;
	public static Item Quiver60I;
	public static Item Quiver60DI;
	public static Item Quiver60XI;
	public static Item Quiver80I;
	public static Item Quiver80DI;
	public static Item Quiver80XI;
	
	public static Item Sword1D;
	public static Item Sword20D;
	public static Item Sword40D;
	public static Item Sword60;
	public static Item Sword60D;
	public static Item Sword80;
	public static Item Sword80D;
	
	public static Item Wand1;
	public static Item Wand1D;
	public static Item Wand5;
	public static Item Wand10;
	public static Item Wand15;
	public static Item Wand20;
	public static Item Wand20D;
	public static Item Wand25;
	public static Item Wand30;
	public static Item Wand35;
	public static Item Wand40;
	public static Item Wand40D;
	public static Item Wand45;
	public static Item Wand50;
	public static Item Wand55;
	public static Item Wand60;
	public static Item Wand60D;
	public static Item Wand65;
	public static Item Wand70;
	public static Item Wand75;
	public static Item Wand80;
	public static Item Wand80D;
	public static Item Wand85;
	public static Item Wand90;
	public static Item Wand95;
	
	
	
	
	
	public static final void init() {

		GemOpal = registerItem(new Item(), "GemOpal").setCreativeTab(MainRegistry.tabMark);															
		GemSapphire = registerItem(new Item(), "GemSapphire").setCreativeTab(MainRegistry.tabMark);	
		GemOlivine = registerItem(new Item(), "GemOlivine").setCreativeTab(MainRegistry.tabMark);
		GemHyacinth = registerItem(new Item(), "GemHyacinth").setCreativeTab(MainRegistry.tabMark);	
		GemTopaz = registerItem(new Item(), "GemTopaz").setCreativeTab(MainRegistry.tabMark);	
		GemAmethyst = registerItem(new Item(), "GemAmethyst").setCreativeTab(MainRegistry.tabMark);
		GemSiam = registerItem(new Item(), "GemSiam").setCreativeTab(MainRegistry.tabMark);	
		GemAquamarine = registerItem(new Item(), "GemAquamarine").setCreativeTab(MainRegistry.tabMark);
		NetheriteBar = registerItem(new Item(), "NetheriteBar").setCreativeTab(MainRegistry.tabMark);
		CrystliumBar = registerItem(new Item(), "CrystliumBar").setCreativeTab(MainRegistry.tabMark);
														
		BookW1 = registerItem(new MarkItemBooksWritten(), "BookW1").setCreativeTab(MainRegistry.tabMark);
		BookW5 = registerItem(new MarkItemBooksWritten(),"BookW5").setCreativeTab(MainRegistry.tabMark);	
		BookW10 = registerItem(new MarkItemBooksWritten(),"BookW10").setCreativeTab(MainRegistry.tabMark);
		BookW15 = registerItem(new MarkItemBooksWritten(),"BookW15").setCreativeTab(MainRegistry.tabMark);
		Book20 = registerItem(new MarkItemBooks(),"Book20").setCreativeTab(MainRegistry.tabMark);		
		BookW20 = registerItem(new MarkItemBooksWritten(),"BookW20").setCreativeTab(MainRegistry.tabMark);	
		BookW30 = registerItem(new MarkItemBooksWritten(),"BookW30").setCreativeTab(MainRegistry.tabMark);
		Book40 = registerItem(new MarkItemBooks(),"Book40").setCreativeTab(MainRegistry.tabMark);		
		BookW40 = registerItem(new MarkItemBooksWritten(),"BookW40").setCreativeTab(MainRegistry.tabMark);
		BookW50 = registerItem(new MarkItemBooksWritten(),"BookW50").setCreativeTab(MainRegistry.tabMark);
		Book60 = registerItem(new MarkItemBooks(),"Book60").setCreativeTab(MainRegistry.tabMark);		
		BookW60 = registerItem(new MarkItemBooksWritten(),"BookW60").setCreativeTab(MainRegistry.tabMark);
		BookW65 = registerItem(new MarkItemBooksWritten(),"BookW65").setCreativeTab(MainRegistry.tabMark);
		BookW75 = registerItem(new MarkItemBooksWritten(),"BookW75").setCreativeTab(MainRegistry.tabMark);
		Book80 = registerItem(new MarkItemBooks(),"Book80").setCreativeTab(MainRegistry.tabMark);		
		BookW80 = registerItem(new MarkItemBooksWritten(),"BookW80").setCreativeTab(MainRegistry.tabMark);
		BookW85 = registerItem(new MarkItemBooksWritten(),"BookW85").setCreativeTab(MainRegistry.tabMark);
		
		Hide10 = registerItem(new Item(), "Hide10").setCreativeTab(MainRegistry.tabMark);
		Hide20 = registerItem(new Item(), "Hide20").setCreativeTab(MainRegistry.tabMark);
		Hide40 = registerItem(new Item(), "Hide40").setCreativeTab(MainRegistry.tabMark);
		Hide60 = registerItem(new Item(), "Hide60").setCreativeTab(MainRegistry.tabMark);
		Hide80 = registerItem(new Item(), "Hide80").setCreativeTab(MainRegistry.tabMark);
		Leather20 = registerItem(new Item(), "Leather20").setCreativeTab(MainRegistry.tabMark);
		Leather40 = registerItem(new Item(), "Leather40").setCreativeTab(MainRegistry.tabMark);
		Leather60 = registerItem(new Item(), "Leather60").setCreativeTab(MainRegistry.tabMark);
		Leather80 = registerItem(new Item(), "Leather80").setCreativeTab(MainRegistry.tabMark);
		Trap01 = registerItem(new ItemTrap(), "Trap01").setCreativeTab(MainRegistry.tabMark);
		Trap10 = registerItem(new ItemTrap(), "Trap10").setCreativeTab(MainRegistry.tabMark);
		Trap20 = registerItem(new ItemTrap(), "Trap20").setCreativeTab(MainRegistry.tabMark);
		Trap40 = registerItem(new ItemTrap(), "Trap40").setCreativeTab(MainRegistry.tabMark);
		Trap60 = registerItem(new ItemTrap(), "Trap60").setCreativeTab(MainRegistry.tabMark);
		Trap80 = registerItem(new ItemTrap(), "Trap80").setCreativeTab(MainRegistry.tabMark);
		TrapKey = registerItem(new ItemTrapKey(), "TrapKey").setCreativeTab(MainRegistry.tabMark);
		
		RegisterItem2(Herb, "Herb").setCreativeTab(MainRegistry.tabMark);	
		
		AnethSeed = registerItem(new ItemSeeds(MarkBlocks.AnethCrop, Blocks.FARMLAND), "AnethSeed").setCreativeTab(MainRegistry.tabMark);
		RomarinSeed = registerItem(new ItemSeeds(MarkBlocks.RomarinCrop, Blocks.FARMLAND), "RomarinSeed").setCreativeTab(MainRegistry.tabMark);	
		RaifortSeed = registerItem(new ItemSeeds(MarkBlocks.RaifortCrop, Blocks.FARMLAND), "RaifortSeed").setCreativeTab(MainRegistry.tabMark);	
		CeleriSeed = registerItem(new ItemSeeds(MarkBlocks.CeleriCrop, Blocks.FARMLAND), "CeleriSeed").setCreativeTab(MainRegistry.tabMark);
		SarrietteSeed = registerItem(new ItemSeeds(MarkBlocks.SarrietteCrop, Blocks.FARMLAND), "SarrietteSeed").setCreativeTab(MainRegistry.tabMark);		
		ArmoiseSeed = registerItem(new ItemSeeds(MarkBlocks.ArmoiseCrop, Blocks.FARMLAND), "ArmoiseSeed").setCreativeTab(MainRegistry.tabMark);		
		CerfeuilSeed = registerItem(new ItemSeeds(MarkBlocks.CerfeuilCrop, Blocks.FARMLAND), "CerfeuilSeed").setCreativeTab(MainRegistry.tabMark);
		EstragonSeed = registerItem(new ItemSeeds(MarkBlocks.EstragonCrop, Blocks.FARMLAND), "EstragonSeed").setCreativeTab(MainRegistry.tabMark);		
		NetherweedSeed = registerItem(new ItemSeeds(MarkBlocks.NetherweedCrop, MarkBlocks.NetherSand), "NetherweedSeed").setCreativeTab(MainRegistry.tabMark);
		FlameweedSeed = registerItem(new ItemSeeds(MarkBlocks.FlameweedCrop, MarkBlocks.NetherSand), "FlameweedSeed").setCreativeTab(MainRegistry.tabMark);	
		BrutalRedSeed = registerItem(new ItemSeeds(MarkBlocks.BrutalRedCrop, MarkBlocks.NetherSand), "BrutalRedSeed").setCreativeTab(MainRegistry.tabMark);	
		CrystweedSeed = registerItem(new ItemSeeds(MarkBlocks.CrystweedCrop, MarkBlocks.CrystSand), "CrystweedSeed").setCreativeTab(MainRegistry.tabMark);
		DarkCrystalSeed = registerItem(new ItemSeeds(MarkBlocks.DarkCrystalCrop, MarkBlocks.CrystSand), "DarkCrystalSeed").setCreativeTab(MainRegistry.tabMark);
		BrutalBlueSeed = registerItem(new ItemSeeds(MarkBlocks.BrutalBlueCrop, MarkBlocks.CrystSand), "BrutalBlueSeed").setCreativeTab(MainRegistry.tabMark);	
		OnionSeed = registerItem(new ItemSeeds(MarkBlocks.OnionCrop, Blocks.FARMLAND), "OnionSeed").setCreativeTab(MainRegistry.tabMark);					
		TomatoSeed = registerItem(new ItemSeeds(MarkBlocks.TomatoCrop, MarkBlocks.NetherSand), "TomatoSeed").setCreativeTab(MainRegistry.tabMark);		
		BlueberrySeed = registerItem(new ItemSeeds(MarkBlocks.BlueberryCrop, MarkBlocks.CrystSand), "BlueberrySeed").setCreativeTab(MainRegistry.tabMark);	
		CommonCottonSeed = registerItem(new ItemSeeds(MarkBlocks.CommonCottonCrop, Blocks.FARMLAND), "CommonCottonSeed").setCreativeTab(MainRegistry.tabMark);
		GreenCottonSeed = registerItem(new ItemSeeds(MarkBlocks.GreenCottonCrop, Blocks.FARMLAND), "GreenCottonSeed").setCreativeTab(MainRegistry.tabMark);	
		RedCottonSeed = registerItem(new ItemSeeds(MarkBlocks.RedCottonCrop, MarkBlocks.NetherSand), "RedCottonSeed").setCreativeTab(MainRegistry.tabMark);			
		BlueCottonSeed = registerItem(new ItemSeeds(MarkBlocks.BlueCottonCrop, MarkBlocks.CrystSand), "BlueCottonSeed").setCreativeTab(MainRegistry.tabMark);			
		
		Onion = registerItem(new Item(), "Onion").setCreativeTab(MainRegistry.tabMark);											
		Tomato = registerItem(new Item(), "Tomato").setCreativeTab(MainRegistry.tabMark);									
		Blueberry = registerItem(new Item(), "Blueberry").setCreativeTab(MainRegistry.tabMark);								
		Cotton20 = registerItem(new Item(), "Cotton20").setCreativeTab(MainRegistry.tabMark);								
		Cotton40 = registerItem(new Item(), "Cotton40").setCreativeTab(MainRegistry.tabMark);							
		Cotton60 = registerItem(new Item(), "Cotton60").setCreativeTab(MainRegistry.tabMark);							
		Cotton80 = registerItem(new Item(), "Cotton80").setCreativeTab(MainRegistry.tabMark);							
		Silk20 = registerItem(new Item(), "Silk20").setCreativeTab(MainRegistry.tabMark);								
		Silk40 = registerItem(new Item(), "Silk40").setCreativeTab(MainRegistry.tabMark);							
		Silk60 = registerItem(new Item(), "Silk60").setCreativeTab(MainRegistry.tabMark);					
		Silk80 = registerItem(new Item(), "Silk80").setCreativeTab(MainRegistry.tabMark);					
		
		Stick10 = registerItem(new Item(), "Stick10").setCreativeTab(MainRegistry.tabMark);								
		Stick20 = registerItem(new Item(), "Stick20").setCreativeTab(MainRegistry.tabMark);								
		Stick40 = registerItem(new Item(), "Stick40").setCreativeTab(MainRegistry.tabMark);							
		Stick60 = registerItem(new Item(), "Stick60").setCreativeTab(MainRegistry.tabMark);					
		Stick80 = registerItem(new Item(), "Stick80").setCreativeTab(MainRegistry.tabMark);					
		
		Cod_Raw = registerItem(new Item(), "Cod_Raw").setCreativeTab(MainRegistry.tabMark);					
		Trout_Raw = registerItem(new Item(), "Trout_Raw").setCreativeTab(MainRegistry.tabMark);
		Sardine_Raw = registerItem(new Item(), "Sardine_Raw").setCreativeTab(MainRegistry.tabMark);
		Tuna_Raw = registerItem(new Item(), "Tuna_Raw").setCreativeTab(MainRegistry.tabMark);
		Herring_Raw = registerItem(new Item(), "Herring_Raw").setCreativeTab(MainRegistry.tabMark);
		Bass_Raw = registerItem(new Item(), "Bass_Raw").setCreativeTab(MainRegistry.tabMark);
		Eel_Raw = registerItem(new Item(), "Eel_Raw").setCreativeTab(MainRegistry.tabMark);
		Batiod_Raw = registerItem(new Item(), "Batiod_Raw").setCreativeTab(MainRegistry.tabMark);
		Shark_Raw = registerItem(new Item(), "Shark_Raw").setCreativeTab(MainRegistry.tabMark);
		
		Cod_Cooked = registerItem(new Item(), "Cod_Cooked").setCreativeTab(MainRegistry.tabMark);
		Trout_Cooked = registerItem(new Item(), "Trout_Cooked").setCreativeTab(MainRegistry.tabMark);
		Sardine_Cooked = registerItem(new Item(), "Sardine_Cooked").setCreativeTab(MainRegistry.tabMark);
		Tuna_Cooked = registerItem(new Item(), "Tuna_Cooked").setCreativeTab(MainRegistry.tabMark);
		Herring_Cooked = registerItem(new Item(), "Herring_Cooked").setCreativeTab(MainRegistry.tabMark);
		Bass_Cooked = registerItem(new Item(), "Bass_Cooked").setCreativeTab(MainRegistry.tabMark);
		Eel_Cooked = registerItem(new Item(), "Eel_Cooked").setCreativeTab(MainRegistry.tabMark);
		Batiod_Cooked = registerItem(new Item(), "Batiod_Cooked").setCreativeTab(MainRegistry.tabMark);
		Shark_Cooked = registerItem(new Item(), "Shark_Cooked").setCreativeTab(MainRegistry.tabMark);
		FishRod = registerItem(new MarkRod(), "FishRod").setCreativeTab(MainRegistry.tabMark);
		
		CakeUnf = registerItem(new Item(), "CakeUnf").setCreativeTab(MainRegistry.tabMark);
		
		
		LogYew_Door = registerItem(new MarkItemDoor(MarkBlocks.LogYew_Door), "LogYew_Door").setCreativeTab(MainRegistry.tabMark);
		LogNetherBranch_Door = registerItem(new MarkItemDoor(MarkBlocks.LogNetherBranch_Door), "LogNetherBranch_Door").setCreativeTab(MainRegistry.tabMark);
		LogCrystWood_Door = registerItem(new MarkItemDoor(MarkBlocks.LogCrystWood_Door), "LogCrystWood_Door").setCreativeTab(MainRegistry.tabMark);
		
		Wand1unf = registerItem(new Item(), "Wand1unf").setCreativeTab(MainRegistry.tabMark);
		Wand20unf = registerItem(new Item(), "Wand20unf").setCreativeTab(MainRegistry.tabMark);
		Wand40unf = registerItem(new Item(), "Wand40unf").setCreativeTab(MainRegistry.tabMark);
		Wand60unf = registerItem(new Item(), "Wand60unf").setCreativeTab(MainRegistry.tabMark);
		Wand80unf = registerItem(new Item(), "Wand80unf").setCreativeTab(MainRegistry.tabMark);
		
		OpalShotIcon = registerItem(new Item(), "OpalShot");
		SapphireShotIcon = registerItem(new Item(), "SapphireShot");
		OlivineShotIcon = registerItem(new Item(), "OlivineShot");
		HyacinthShotIcon = registerItem(new Item(), "HyacinthShot");
		DefensiveShotIcon = registerItem(new Item(), "DefensiveShot");
		
		Bow1 = registerItem(new MarkBow(EnumMaterial.Tier1), "Bow1").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Bow10 = registerItem(new MarkBow(EnumMaterial.Tier10), "Bow10").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Bow20 = registerItem(new MarkBow(EnumMaterial.Tier20), "Bow20").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Bow40 = registerItem(new MarkBow(EnumMaterial.Tier40), "Bow40").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Bow60 = registerItem(new MarkBow(EnumMaterial.Tier60), "Bow60").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Bow80 = registerItem(new MarkBow(EnumMaterial.Tier80), "Bow80").setCreativeTab(MainRegistry.tabMark).setFull3D();

		Quiver1 = registerItem(new ItemMarkQuiver(EnumMaterial.Tier1), "Quiver1").setCreativeTab(MainRegistry.tabMark);
		Quiver1D = registerItem(new ItemMarkQuiver(EnumMaterial.Tier1), "Quiver1D").setCreativeTab(MainRegistry.tabMark);
		Quiver10X = registerItem(new ItemMarkQuiver(EnumMaterial.Tier10), "Quiver10X").setCreativeTab(MainRegistry.tabMark);
		Quiver20 = registerItem(new ItemMarkQuiver(EnumMaterial.Tier20), "Quiver20").setCreativeTab(MainRegistry.tabMark);
		Quiver20D = registerItem(new ItemMarkQuiver(EnumMaterial.Tier20), "Quiver20D").setCreativeTab(MainRegistry.tabMark);
		Quiver20X = registerItem(new ItemMarkQuiver(EnumMaterial.Tier20), "Quiver20X").setCreativeTab(MainRegistry.tabMark);
		Quiver40 = registerItem(new ItemMarkQuiver(EnumMaterial.Tier40), "Quiver40").setCreativeTab(MainRegistry.tabMark);
		Quiver40D = registerItem(new ItemMarkQuiver(EnumMaterial.Tier40), "Quiver40D").setCreativeTab(MainRegistry.tabMark);
		Quiver40X = registerItem(new ItemMarkQuiver(EnumMaterial.Tier40), "Quiver40X").setCreativeTab(MainRegistry.tabMark);
		Quiver60 = registerItem(new ItemMarkQuiver(EnumMaterial.Tier60), "Quiver60").setCreativeTab(MainRegistry.tabMark);
		Quiver60D = registerItem(new ItemMarkQuiver(EnumMaterial.Tier60), "Quiver60D").setCreativeTab(MainRegistry.tabMark);
		Quiver60X = registerItem(new ItemMarkQuiver(EnumMaterial.Tier60), "Quiver60X").setCreativeTab(MainRegistry.tabMark);
		Quiver80 = registerItem(new ItemMarkQuiver(EnumMaterial.Tier80), "Quiver80").setCreativeTab(MainRegistry.tabMark);
		Quiver80D = registerItem(new ItemMarkQuiver(EnumMaterial.Tier80), "Quiver80D").setCreativeTab(MainRegistry.tabMark);
		Quiver80X = registerItem(new ItemMarkQuiver(EnumMaterial.Tier80), "Quiver80X").setCreativeTab(MainRegistry.tabMark);

		Quiver1I = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier1), "Quiver1I").setCreativeTab(MainRegistry.tabMark);
		Quiver1DI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier1), "Quiver1DI").setCreativeTab(MainRegistry.tabMark);
		Quiver10XI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier10), "Quiver10XI").setCreativeTab(MainRegistry.tabMark);
		Quiver20I = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier20), "Quiver20I").setCreativeTab(MainRegistry.tabMark);
		Quiver20DI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier20), "Quiver20DI").setCreativeTab(MainRegistry.tabMark);
		Quiver20XI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier20), "Quiver20XI").setCreativeTab(MainRegistry.tabMark);
		Quiver40I = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier40), "Quiver40I").setCreativeTab(MainRegistry.tabMark);
		Quiver40DI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier40), "Quiver40DI").setCreativeTab(MainRegistry.tabMark);
		Quiver40XI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier40), "Quiver40XI").setCreativeTab(MainRegistry.tabMark);
		Quiver60I = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier60), "Quiver60I").setCreativeTab(MainRegistry.tabMark);
		Quiver60DI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier60), "Quiver60DI").setCreativeTab(MainRegistry.tabMark);
		Quiver60XI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier60), "Quiver60XI").setCreativeTab(MainRegistry.tabMark);
		Quiver80I = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier80), "Quiver80I").setCreativeTab(MainRegistry.tabMark);
		Quiver80DI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier80), "Quiver80DI").setCreativeTab(MainRegistry.tabMark);
		Quiver80XI = registerItem(new ItemMarkQuiver2(EnumMaterial.Tier80), "Quiver80XI").setCreativeTab(MainRegistry.tabMark);

		Sword1D = registerItem(new MarkSword(EnumMaterial.Tier1), "Sword1D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Sword20D = registerItem(new MarkSword(EnumMaterial.Tier20), "Sword20D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Sword40D = registerItem(new MarkSword(EnumMaterial.Tier40), "Sword40D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Sword60 = registerItem(new MarkSword(EnumMaterial.Tier60), "Sword60").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Sword60D = registerItem(new MarkSword(EnumMaterial.Tier60), "Sword60D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Sword80 = registerItem(new MarkSword(EnumMaterial.Tier80), "Sword80").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Sword80D = registerItem(new MarkSword(EnumMaterial.Tier80), "Sword80D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		
		Wand1 = registerItem(new MarkWand(EnumMaterial.Tier1), "Wand1").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand1D = registerItem(new MarkWand(EnumMaterial.Tier1), "Wand1D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand5 = registerItem(new MarkWand(EnumMaterial.Tier5), "Wand5").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand10 = registerItem(new MarkWand(EnumMaterial.Tier10), "Wand10").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand15 = registerItem(new MarkWand(EnumMaterial.Tier15), "Wand15").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand20 = registerItem(new MarkWand(EnumMaterial.Tier20), "Wand20").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand20D = registerItem(new MarkWand(EnumMaterial.Tier20), "Wand20D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand25 = registerItem(new MarkWand(EnumMaterial.Tier25), "Wand25").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand30 = registerItem(new MarkWand(EnumMaterial.Tier30), "Wand30").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand35 = registerItem(new MarkWand(EnumMaterial.Tier35), "Wand35").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand40 = registerItem(new MarkWand(EnumMaterial.Tier40), "Wand40").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand40D = registerItem(new MarkWand(EnumMaterial.Tier40), "Wand40D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand45 = registerItem(new MarkWand(EnumMaterial.Tier45), "Wand45").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand50 = registerItem(new MarkWand(EnumMaterial.Tier50), "Wand50").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand55 = registerItem(new MarkWand(EnumMaterial.Tier55), "Wand55").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand60 = registerItem(new MarkWand(EnumMaterial.Tier60), "Wand60").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand60D = registerItem(new MarkWand(EnumMaterial.Tier60), "Wand60D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand65 = registerItem(new MarkWand(EnumMaterial.Tier65), "Wand65").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand70 = registerItem(new MarkWand(EnumMaterial.Tier70), "Wand70").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand75 = registerItem(new MarkWand(EnumMaterial.Tier75), "Wand75").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand80 = registerItem(new MarkWand(EnumMaterial.Tier80), "Wand80").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand80D = registerItem(new MarkWand(EnumMaterial.Tier80), "Wand80D").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand85 = registerItem(new MarkWand(EnumMaterial.Tier85), "Wand85").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand90 = registerItem(new MarkWand(EnumMaterial.Tier90), "Wand90").setCreativeTab(MainRegistry.tabMark).setFull3D();
		Wand95 = registerItem(new MarkWand(EnumMaterial.Tier95), "Wand95").setCreativeTab(MainRegistry.tabMark).setFull3D();
		
	   }
	
	private static <T extends Item> T registerItem(T item, String name) {
		item.setUnlocalizedName(name);
		return registerItem(item, new ResourceLocation("mark13695:" + name));
	}
	
	private static <T extends Item> T registerItem(T item, ResourceLocation name) {
		GameRegistry.register(item, name);
		items.add(item);
		return item;
	}
	/**this is used for items with meta **/
	private static Item RegisterItem2(Item item, String name){
		item.setUnlocalizedName(name);
		return registerItem(item, new ResourceLocation("mark13695:" + name));
	}
	
	private static Item RegisterItem2(Item item, ResourceLocation name){
		
		GameRegistry.register(item, name);
		return item;
	}
}
