package com.modMark.Item_Block;

import com.modMark.Item_Block.Fluid.MarkFluids;
import com.modMark.Item_Block.Fluid.MeshDefinitionFix;
import com.modMark.Main.MainRegistry;
import com.modMark.Refer.ReferenceStrings;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelBakery;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.block.statemap.StateMapperBase;
import net.minecraft.item.Item;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fluids.IFluidBlock;

public class MarkModelRender{
	
	public static final MarkModelRender INSTANCE = new MarkModelRender();
	public static String modid = ReferenceStrings.MODID;
	public static String [] HerbRef = new String[28];
	
	
	
	public void init(){
		//Items!! ---------------------
		
		//gems, staff
		RegistryItem(MarkItems.GemOpal);
		RegistryItem(MarkItems.GemSapphire);
		RegistryItem(MarkItems.GemOlivine);
		RegistryItem(MarkItems.GemHyacinth);
		RegistryItem(MarkItems.GemTopaz);
		RegistryItem(MarkItems.GemAmethyst);
		RegistryItem(MarkItems.GemSiam);
		RegistryItem(MarkItems.GemAquamarine);
		RegistryItem(MarkItems.NetheriteBar);
		RegistryItem(MarkItems.CrystliumBar);
		
		//Books
		
		RegistryItem(MarkItems.Book20);
		RegistryItem(MarkItems.Book40);
		RegistryItem(MarkItems.Book60);
		RegistryItem(MarkItems.Book80);
		RegistryItem(MarkItems.BookW1);
		RegistryItem(MarkItems.BookW5);
		RegistryItem(MarkItems.BookW10);
		RegistryItem(MarkItems.BookW15);
		RegistryItem(MarkItems.BookW20);
		RegistryItem(MarkItems.BookW30);
		RegistryItem(MarkItems.BookW40);
		RegistryItem(MarkItems.BookW50);
		RegistryItem(MarkItems.BookW60);
		RegistryItem(MarkItems.BookW65);
		RegistryItem(MarkItems.BookW75);
		RegistryItem(MarkItems.BookW80);
		RegistryItem(MarkItems.BookW85);
		//Melee Defences, Weapons, Tools: Ingot, Armours 
		
		//Ranged Defences: Hides, Leathers, Armours
		RegistryItem(MarkItems.Hide10);
		RegistryItem(MarkItems.Hide20);
		RegistryItem(MarkItems.Hide40);
		RegistryItem(MarkItems.Hide60);
		RegistryItem(MarkItems.Hide80);
		RegistryItem(MarkItems.Leather20);
		RegistryItem(MarkItems.Leather40);
		RegistryItem(MarkItems.Leather60);
		RegistryItem(MarkItems.Leather80);
		RegistryItem(MarkItems.Trap01);
		RegistryItem(MarkItems.Trap10);
		RegistryItem(MarkItems.Trap20);
		RegistryItem(MarkItems.Trap40);
		RegistryItem(MarkItems.Trap60);
		RegistryItem(MarkItems.Trap80);
		RegistryItem(MarkItems.TrapKey);
		
		
		//Magic Defences: Cottons plants, Cloths, Armour
		RegistryItem(MarkItems.CommonCottonSeed);
		RegistryItem(MarkItems.GreenCottonSeed);
		RegistryItem(MarkItems.RedCottonSeed);
		RegistryItem(MarkItems.BlueCottonSeed);
		RegistryItem(MarkItems.Cotton20);
		RegistryItem(MarkItems.Cotton40);
		RegistryItem(MarkItems.Cotton60);
		RegistryItem(MarkItems.Cotton80);
		RegistryItem(MarkItems.Silk20);
		RegistryItem(MarkItems.Silk40);
		RegistryItem(MarkItems.Silk60);
		RegistryItem(MarkItems.Silk80);
		
		//herbs & crops
		RegistryItem(MarkItems.AnethSeed);
		RegistryItem(MarkItems.RomarinSeed);
		RegistryItem(MarkItems.RaifortSeed);
		RegistryItem(MarkItems.CeleriSeed);
		RegistryItem(MarkItems.SarrietteSeed);
		RegistryItem(MarkItems.ArmoiseSeed);
		RegistryItem(MarkItems.CerfeuilSeed);
		RegistryItem(MarkItems.EstragonSeed);
		RegistryItem(MarkItems.NetherweedSeed);
		RegistryItem(MarkItems.FlameweedSeed);
		RegistryItem(MarkItems.BrutalRedSeed);
		RegistryItem(MarkItems.CrystweedSeed);
		RegistryItem(MarkItems.DarkCrystalSeed);
		RegistryItem(MarkItems.BrutalBlueSeed);
		RegistryItemWithMeta(MarkItems.Herb, 0 , "HerbAneth_D");
		RegistryItemWithMeta(MarkItems.Herb, 1 , "HerbAneth_C");
		RegistryItemWithMeta(MarkItems.Herb, 2 , "HerbRomarin_D");
		RegistryItemWithMeta(MarkItems.Herb, 3 , "HerbRomarin_C");
		RegistryItemWithMeta(MarkItems.Herb, 4 , "HerbRaifort_D");
		RegistryItemWithMeta(MarkItems.Herb, 5 , "HerbRaifort_C");
		RegistryItemWithMeta(MarkItems.Herb, 6 , "HerbCeleri_D");
		RegistryItemWithMeta(MarkItems.Herb, 7 , "HerbCeleri_C");
		RegistryItemWithMeta(MarkItems.Herb, 8 , "HerbSarriette_D");
		RegistryItemWithMeta(MarkItems.Herb, 9 , "HerbSarriette_C");
		RegistryItemWithMeta(MarkItems.Herb, 10 , "HerbArmoise_D");
		RegistryItemWithMeta(MarkItems.Herb, 11 , "HerbArmoise_C");
		RegistryItemWithMeta(MarkItems.Herb, 12 , "HerbCerfeuil_D");
		RegistryItemWithMeta(MarkItems.Herb, 13 , "HerbCerfeuil_C");
		RegistryItemWithMeta(MarkItems.Herb, 14 , "HerbEstragon_D");
		RegistryItemWithMeta(MarkItems.Herb, 15 , "HerbEstragon_C");
		RegistryItemWithMeta(MarkItems.Herb, 16 , "HerbNetherweed_D");
		RegistryItemWithMeta(MarkItems.Herb, 17 , "HerbNetherweed_C");
		RegistryItemWithMeta(MarkItems.Herb, 18 , "HerbFlameweed_D");
		RegistryItemWithMeta(MarkItems.Herb, 19 , "HerbFlameweed_C");
		RegistryItemWithMeta(MarkItems.Herb, 20 , "HerbBrutalRed_D");
		RegistryItemWithMeta(MarkItems.Herb, 21 , "HerbBrutalRed_C");
		RegistryItemWithMeta(MarkItems.Herb, 22 , "HerbCrystweed_D");
		RegistryItemWithMeta(MarkItems.Herb, 23 , "HerbCrystweed_C");
		RegistryItemWithMeta(MarkItems.Herb, 24 , "HerbDarkCrystal_D");
		RegistryItemWithMeta(MarkItems.Herb, 25 , "HerbDarkCrystal_C");
		RegistryItemWithMeta(MarkItems.Herb, 26 , "HerbBrutalBlue_D");
		RegistryItemWithMeta(MarkItems.Herb, 27 , "HerbBrutalBlue_C");
		
		RegistryItem(MarkItems.OnionSeed);
		RegistryItem(MarkItems.TomatoSeed);
		RegistryItem(MarkItems.BlueberrySeed);
		
		RegistryItem(MarkItems.Onion);
		RegistryItem(MarkItems.Tomato);
		RegistryItem(MarkItems.Blueberry);
		
		RegistryItem(MarkItems.Cod_Raw);
		RegistryItem(MarkItems.Trout_Raw);
		RegistryItem(MarkItems.Sardine_Raw);
		RegistryItem(MarkItems.Tuna_Raw);
		RegistryItem(MarkItems.Herring_Raw);
		RegistryItem(MarkItems.Bass_Raw);
		RegistryItem(MarkItems.Eel_Raw);
		RegistryItem(MarkItems.Batiod_Raw);
		RegistryItem(MarkItems.Shark_Raw);
		
		RegistryItem(MarkItems.Cod_Cooked);
		RegistryItem(MarkItems.Trout_Cooked);
		RegistryItem(MarkItems.Sardine_Cooked);
		RegistryItem(MarkItems.Tuna_Cooked);
		RegistryItem(MarkItems.Herring_Cooked);
		RegistryItem(MarkItems.Bass_Cooked);
		RegistryItem(MarkItems.Eel_Cooked);
		RegistryItem(MarkItems.Batiod_Cooked);
		RegistryItem(MarkItems.Shark_Cooked);
		
		RegistryItem(MarkItems.FishRod);
		
		RegistryItem(MarkItems.Stick10);
		RegistryItem(MarkItems.Stick20);
		RegistryItem(MarkItems.Stick40);
		RegistryItem(MarkItems.Stick60);
		RegistryItem(MarkItems.Stick80);
		
		RegistryItem(MarkItems.CakeUnf);
		
		RegistryItem(MarkItems.LogYew_Door);
		RegistryItem(MarkItems.LogNetherBranch_Door);
		RegistryItem(MarkItems.LogCrystWood_Door);
		
		RegistryItem(MarkItems.Wand1unf);
		RegistryItem(MarkItems.Wand20unf);
		RegistryItem(MarkItems.Wand40unf);
		RegistryItem(MarkItems.Wand60unf);
		RegistryItem(MarkItems.Wand80unf);
		
		RegistryItem(MarkItems.OpalShotIcon);
		RegistryItem(MarkItems.SapphireShotIcon);
		RegistryItem(MarkItems.OlivineShotIcon);
		RegistryItem(MarkItems.HyacinthShotIcon);
		RegistryItem(MarkItems.DefensiveShotIcon);
		
		RegistryItem(MarkItems.Bow1);
		RegistryItem(MarkItems.Bow10);
		RegistryItem(MarkItems.Bow20);
		RegistryItem(MarkItems.Bow40);
		RegistryItem(MarkItems.Bow60);
		RegistryItem(MarkItems.Bow80);
		
		RegistryItem(MarkItems.Quiver1);
		RegistryItem(MarkItems.Quiver1I);
		RegistryItem(MarkItems.Quiver1D);
		RegistryItem(MarkItems.Quiver1DI);
		RegistryItem(MarkItems.Quiver10X);
		RegistryItem(MarkItems.Quiver10XI);
		RegistryItem(MarkItems.Quiver20);
		RegistryItem(MarkItems.Quiver20I);
		RegistryItem(MarkItems.Quiver20D);
		RegistryItem(MarkItems.Quiver20DI);
		RegistryItem(MarkItems.Quiver20X);
		RegistryItem(MarkItems.Quiver20XI);
		RegistryItem(MarkItems.Quiver40);
		RegistryItem(MarkItems.Quiver40I);
		RegistryItem(MarkItems.Quiver40D);
		RegistryItem(MarkItems.Quiver40DI);
		RegistryItem(MarkItems.Quiver40X);
		RegistryItem(MarkItems.Quiver40XI);
		RegistryItem(MarkItems.Quiver60);
		RegistryItem(MarkItems.Quiver60I);
		RegistryItem(MarkItems.Quiver60D);
		RegistryItem(MarkItems.Quiver60DI);
		RegistryItem(MarkItems.Quiver60X);
		RegistryItem(MarkItems.Quiver60XI);
		RegistryItem(MarkItems.Quiver80);
		RegistryItem(MarkItems.Quiver80I);
		RegistryItem(MarkItems.Quiver80D);
		RegistryItem(MarkItems.Quiver80DI);
		RegistryItem(MarkItems.Quiver80X);
		RegistryItem(MarkItems.Quiver80XI);
		
		RegistryItem(MarkItems.Sword1D);
		RegistryItem(MarkItems.Sword20D);
		RegistryItem(MarkItems.Sword40D);
		RegistryItem(MarkItems.Sword60);
		RegistryItem(MarkItems.Sword60D);
		RegistryItem(MarkItems.Sword80);
		RegistryItem(MarkItems.Sword80D);
		
		RegistryItem(MarkItems.Wand1);
		RegistryItem(MarkItems.Wand1D);
		RegistryItem(MarkItems.Wand5);
		RegistryItem(MarkItems.Wand10);
		RegistryItem(MarkItems.Wand15);
		RegistryItem(MarkItems.Wand20);
		RegistryItem(MarkItems.Wand20D);
		RegistryItem(MarkItems.Wand25);
		RegistryItem(MarkItems.Wand30);
		RegistryItem(MarkItems.Wand35);
		RegistryItem(MarkItems.Wand40);
		RegistryItem(MarkItems.Wand40D);
		RegistryItem(MarkItems.Wand45);
		RegistryItem(MarkItems.Wand50);
		RegistryItem(MarkItems.Wand55);
		RegistryItem(MarkItems.Wand60);
		RegistryItem(MarkItems.Wand60D);
		RegistryItem(MarkItems.Wand65);
		RegistryItem(MarkItems.Wand70);
		RegistryItem(MarkItems.Wand75);
		RegistryItem(MarkItems.Wand80);
		RegistryItem(MarkItems.Wand80D);
		RegistryItem(MarkItems.Wand85);
		RegistryItem(MarkItems.Wand90);
		RegistryItem(MarkItems.Wand95);
		
		
		//Blocks!! ----------------
		
		RegistryBlock(MarkBlocks.GemOpalOre);
		RegistryBlock(MarkBlocks.GemSapphireOre);
		RegistryBlock(MarkBlocks.GemOlivineOre);
		RegistryBlock(MarkBlocks.GemHyacinthOre);
		RegistryBlock(MarkBlocks.GemTopazOre);
		RegistryBlock(MarkBlocks.GemAmethystOre);
		RegistryBlock(MarkBlocks.GemSiamOre);
		RegistryBlock(MarkBlocks.GemAquamarineOre);
		RegistryBlock(MarkBlocks.OreNetherite);
		
		RegistryBlock(MarkBlocks.EnrichedGrass);
		RegistryBlock(MarkBlocks.NetherSand);
		RegistryBlock(MarkBlocks.CrystSand);
		
		RegistryBlock(MarkBlocks.OreIron);
		RegistryBlock(MarkBlocks.OreGold);
		RegistryBlock(MarkBlocks.OreCrystlium);
		RegistryBlock(MarkBlocks.CrystRack);
		RegistryBlock(MarkBlocks.Cyantinian);
		
		RegistryBlock(MarkBlocks.CrystBricks);
		RegistryBlock(MarkBlocks.LogYew);
		RegistryBlock(MarkBlocks.LogNetherBranch);
		RegistryBlock(MarkBlocks.LogCrystWood);
		RegistryBlock(MarkBlocks.LogYew_Leaf);
		RegistryBlock(MarkBlocks.LogNetherBranch_Leaf);
		RegistryBlock(MarkBlocks.LogCrystWood_Leaf);
		RegistryBlock(MarkBlocks.LogOak_Sapling);
		RegistryBlock(MarkBlocks.LogBirch_Sapling);
		RegistryBlock(MarkBlocks.LogSpruce_Sapling);
		RegistryBlock(MarkBlocks.LogJungle_Sapling);
		RegistryBlock(MarkBlocks.LogAcacia_Sapling);
		RegistryBlock(MarkBlocks.LogDarkOak_Sapling);
		RegistryBlock(MarkBlocks.LogYew_Sapling);
		RegistryBlock(MarkBlocks.LogNetherBranch_Sapling);
		RegistryBlock(MarkBlocks.LogCrystWood_Sapling);
		RegistryBlock(MarkBlocks.LogYew_Planks);
		RegistryBlock(MarkBlocks.LogNetherBranch_Planks);
		RegistryBlock(MarkBlocks.LogCrystWood_Planks);
		RegistryBlock(MarkBlocks.LogYew_Door);
		RegistryBlock(MarkBlocks.LogNetherBranch_Door);
		RegistryBlock(MarkBlocks.LogCrystWood_Door);
		
		RegistryBlock(MarkBlocks.LogYew_stairs);
		
		//Script Blocks
		RegistryBlock(MarkBlocks.Script01);
		RegistryBlock(MarkBlocks.Script05);
		RegistryBlock(MarkBlocks.Script10);
		RegistryBlock(MarkBlocks.Script15);
		RegistryBlock(MarkBlocks.Script20);
		RegistryBlock(MarkBlocks.Script30);
		RegistryBlock(MarkBlocks.Script40);
		RegistryBlock(MarkBlocks.Script50);
		RegistryBlock(MarkBlocks.Script60);
		RegistryBlock(MarkBlocks.Script65);
		RegistryBlock(MarkBlocks.Script75);
		RegistryBlock(MarkBlocks.Script80);
		RegistryBlock(MarkBlocks.Script85);
		
		RegistryBlock(MarkBlocks.MarkTrapE);
		RegistryBlock(MarkBlocks.MarkTrapB);
		RegistryBlock(MarkBlocks.MarkTrap01);
		RegistryBlock(MarkBlocks.MarkTrap10);
		RegistryBlock(MarkBlocks.MarkTrap20);
		RegistryBlock(MarkBlocks.MarkTrap40);
		RegistryBlock(MarkBlocks.MarkTrap60);
		RegistryBlock(MarkBlocks.MarkTrap80);
		
		RegistryBlock(MarkBlocks.DiamondBush);
		RegistryBlock(MarkBlocks.AmethystBush);
		
		RegistryBlock(MarkBlocks.AnethCrop);
		RegistryBlock(MarkBlocks.RomarinCrop);
		RegistryBlock(MarkBlocks.RaifortCrop);
		RegistryBlock(MarkBlocks.CeleriCrop);
		RegistryBlock(MarkBlocks.SarrietteCrop);
		RegistryBlock(MarkBlocks.ArmoiseCrop);
		RegistryBlock(MarkBlocks.CerfeuilCrop);
		RegistryBlock(MarkBlocks.EstragonCrop);
		RegistryBlock(MarkBlocks.NetherweedCrop);
		RegistryBlock(MarkBlocks.FlameweedCrop);
		RegistryBlock(MarkBlocks.BrutalRedCrop);
		RegistryBlock(MarkBlocks.CrystweedCrop);
		RegistryBlock(MarkBlocks.DarkCrystalCrop);
		RegistryBlock(MarkBlocks.BrutalBlueCrop);
		
		RegistryBlock(MarkBlocks.OnionCrop);
		RegistryBlock(MarkBlocks.TomatoCrop);
		RegistryBlock(MarkBlocks.BlueberryCrop);
		RegistryBlock(MarkBlocks.CommonCottonCrop);
		RegistryBlock(MarkBlocks.GreenCottonCrop);
		RegistryBlock(MarkBlocks.RedCottonCrop);
		RegistryBlock(MarkBlocks.BlueCottonCrop);
		
		RegistryBlock(MarkBlocks.TallGrass40);
		RegistryBlock(MarkBlocks.TallGrass60);
		RegistryBlock(MarkBlocks.TallGrass80);
		
		RegistryBlock(MarkBlocks.BasicTable);
		RegistryBlock(MarkBlocks.TailoryBench_I);
		RegistryBlock(MarkBlocks.TailoryBench_II);
		RegistryBlock(MarkBlocks.Anvil_I);
		RegistryBlock(MarkBlocks.Anvil_II);
		RegistryBlock(MarkBlocks.Furnace_I);
		RegistryBlock(MarkBlocks.Furnace_II);
		RegistryBlock(MarkBlocks.TanningBench_I);
		RegistryBlock(MarkBlocks.TanningBench_II);
		RegistryBlock(MarkBlocks.JewelryTable_I);
		RegistryBlock(MarkBlocks.JewelryTable_II);
		RegistryBlock(MarkBlocks.GlassOven_I);
		RegistryBlock(MarkBlocks.GlassOven_II);
		RegistryBlock(MarkBlocks.FletchingTable_I);
		RegistryBlock(MarkBlocks.FletchingTable_II);
		RegistryBlock(MarkBlocks.Range_I);
		RegistryBlock(MarkBlocks.Range_II);
		RegistryBlock(MarkBlocks.Cauldron_I);
		RegistryBlock(MarkBlocks.Cauldron_II);
		RegistryBlock(MarkBlocks.WorkBench_I);
		RegistryBlock(MarkBlocks.WorkBench_II);
		RegistryBlock(MarkBlocks.TechBench_I);
		
		RegistryBlock(MarkBlocks.DirtGlass);
		RegistryBlock(MarkBlocks.GravelGlass);
		RegistryBlock(MarkBlocks.NetherGlass);
		RegistryBlock(MarkBlocks.SoulGlass);
		RegistryBlock(MarkBlocks.CrystGlass);
		RegistryBlock(MarkBlocks.CyantinianGlass);
		
		
		
		ModelResourceLocation HerbAneth_D = new ModelResourceLocation(modid + ":HerbAneth_D", "inventory");
		ModelResourceLocation HerbAneth_C = new ModelResourceLocation(modid + ":HerbAneth_C", "inventory");
		ModelResourceLocation HerbRomarin_D = new ModelResourceLocation(modid + ":HerbRomarin_D", "inventory");
		ModelResourceLocation HerbRomarin_C = new ModelResourceLocation(modid + ":HerbRomarin_C", "inventory");
		ModelResourceLocation HerbRaifort_D = new ModelResourceLocation(modid + ":HerbRaifort_D", "inventory");
		ModelResourceLocation HerbRaifort_C = new ModelResourceLocation(modid + ":HerbRaifort_C", "inventory");
		ModelResourceLocation HerbCeleri_D = new ModelResourceLocation(modid + ":HerbCeleri_D", "inventory");
		ModelResourceLocation HerbCeleri_C = new ModelResourceLocation(modid + ":HerbCeleri_C", "inventory");
		ModelResourceLocation HerbSarriette_D = new ModelResourceLocation(modid + ":HerbSarriette_D", "inventory");
		ModelResourceLocation HerbSarriette_C = new ModelResourceLocation(modid + ":HerbSarriette_C", "inventory");
		ModelResourceLocation HerbArmoise_D = new ModelResourceLocation(modid + ":HerbArmoise_D", "inventory");
		ModelResourceLocation HerbArmoise_C = new ModelResourceLocation(modid + ":HerbArmoise_C", "inventory");
		ModelResourceLocation HerbCerfeuil_D = new ModelResourceLocation(modid + ":HerbCerfeuil_D", "inventory");
		ModelResourceLocation HerbCerfeuil_C = new ModelResourceLocation(modid + ":HerbCerfeuil_C", "inventory");
		ModelResourceLocation HerbEstragon_D = new ModelResourceLocation(modid + ":HerbEstragon_D", "inventory");
		ModelResourceLocation HerbEstragon_C = new ModelResourceLocation(modid + ":HerbEstragon_C", "inventory");
		ModelResourceLocation HerbNetherweed_D = new ModelResourceLocation(modid + ":HerbNetherweed_D", "inventory");
		ModelResourceLocation HerbNetherweed_C = new ModelResourceLocation(modid + ":HerbNetherweed_C", "inventory");
		ModelResourceLocation HerbFlameweed_D = new ModelResourceLocation(modid + ":HerbFlameweed_D", "inventory");
		ModelResourceLocation HerbFlameweed_C = new ModelResourceLocation(modid + ":HerbFlameweed_C", "inventory");
		ModelResourceLocation HerbBrutalRed_D = new ModelResourceLocation(modid + ":HerbBrutalRed_D", "inventory");
		ModelResourceLocation HerbBrutalRed_C = new ModelResourceLocation(modid + ":HerbBrutalRed_C", "inventory");
		ModelResourceLocation HerbCrystweed_D = new ModelResourceLocation(modid + ":HerbCrystweed_D", "inventory");
		ModelResourceLocation HerbCrystweed_C = new ModelResourceLocation(modid + ":HerbCrystweed_C", "inventory");
		ModelResourceLocation HerbDarkCrystal_D = new ModelResourceLocation(modid + ":HerbDarkCrystal_D", "inventory");
		ModelResourceLocation HerbDarkCrystal_C = new ModelResourceLocation(modid + ":HerbDarkCrystal_C", "inventory");
		ModelResourceLocation HerbBrutalBlue_D = new ModelResourceLocation(modid + ":HerbBrutalBlue_D", "inventory");
		ModelResourceLocation HerbBrutalBlue_C = new ModelResourceLocation(modid + ":HerbBrutalBlue_C", "inventory");
		
		ModelBakery.registerItemVariants(MarkItems.Herb, HerbAneth_D, HerbAneth_C
				, HerbRomarin_D, HerbRomarin_C, HerbRaifort_D, HerbRaifort_C, HerbCeleri_D, HerbCeleri_C,
				HerbSarriette_D, HerbSarriette_C, HerbArmoise_D, HerbArmoise_C, HerbCerfeuil_D, HerbCerfeuil_C,
				HerbEstragon_D, HerbEstragon_C, HerbNetherweed_D, HerbNetherweed_C, HerbFlameweed_D, HerbFlameweed_C,
				HerbBrutalRed_D, HerbBrutalRed_C, HerbCrystweed_D, HerbCrystweed_C, HerbDarkCrystal_D, HerbDarkCrystal_C,
				HerbBrutalBlue_D, HerbBrutalBlue_C);
	}
	
	public static void RegistryItem(Item item) {
	 Minecraft.getMinecraft().getRenderItem().getItemModelMesher()
	    .register(item, 0, new ModelResourceLocation(modid + ":" + item.getUnlocalizedName().substring(5), "inventory"));
	}
	
	public static void RegistryItemWithMeta(Item item, int meta, String file) {
	    Minecraft.getMinecraft().getRenderItem().getItemModelMesher()
	    .register(item, meta, new ModelResourceLocation(modid + ":" + file, "inventory"));
	}
	
	
	public static void RegistryBlock(Block block) {
	    Minecraft.getMinecraft().getRenderItem().getItemModelMesher()
	    .register(Item.getItemFromBlock(block), 0, new ModelResourceLocation(modid + ":" + block.getUnlocalizedName().substring(5), "inventory"));
	}
	
	
	public void RegistryFluid(){
		MarkFluids.fluidBlocks.forEach(this::RegistryFluids);
	}
	public void RegistryFluids(IFluidBlock fluidBlock) {
		
		Item item = Item.getItemFromBlock((Block) fluidBlock);
		ModelBakery.registerItemVariants(item);
		
		ModelResourceLocation modelR = new ModelResourceLocation(modid + ":fluid" , fluidBlock.getFluid().getName());

		ModelLoader.setCustomMeshDefinition(item, MeshDefinitionFix.create(stack -> modelR));
			
		ModelLoader.setCustomStateMapper((Block) fluidBlock, new StateMapperBase() {
			@Override
			protected ModelResourceLocation getModelResourceLocation(IBlockState state) {
				return modelR;
			}
		});
		
	}
	
		
	
		
		
		
	
	
	
}