package com.modMark.Item_Block;

import com.modMark.Item_Block.TileEntity.TECraftingTable;
import com.modMark.Item_Block.TileEntity.TESapling;
import com.modMark.Item_Block.TileEntity.TETrap;

import net.minecraftforge.fml.common.registry.GameRegistry;

public class MarkTE {

	public static void init(){	
		GameRegistry.registerTileEntity(TETrap.class, "mark13695trap");	
		GameRegistry.registerTileEntity(TESapling.class, "mark13695Sapling");
		GameRegistry.registerTileEntity(TECraftingTable.class, "mark13695CraftTable");
		// I know I gonna make more TEs later
	}
	
}
