package com.modMark.Item_Block.TileEntity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Item_Block.Block.MarkCraftingTable;
import com.modMark.Main.MainRegistry;
import com.modMark.Packets.CraftingPacketA;
import com.modMark.Packets.CraftingPacketB;
import com.modMark.Packets.CraftingPacketC;
import com.modMark.Packets.CraftingPacketD;
import com.modMark.Packets.SkillPacket;
import com.modMark.Skill.MarkData;

import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class TECraftingTable extends TileEntity implements IInventory, ITickable{

	private ItemStack[] stack = new ItemStack[46];
	private UUID uuid;
	private int isCrafting;
	private int CraftVal;
	private int CurrentCraftProgness;
	private int MaxCraftProgness;
	private float CurrentEnergy;
	private int MaxEnergy;
	private boolean isbeingUsed;
	private boolean isActive;
	private ItemStack[] IngrList = new ItemStack[3];
	private boolean addremIngr;
	private boolean NeedsEnergy = this.blockType != MarkBlocks.BasicTable && this.blockType != MarkBlocks.TailoryBench_I && this.blockType != MarkBlocks.Anvil_I && this.blockType != MarkBlocks.TailoryBench_I && this.blockType != MarkBlocks.JewelryTable_I && this.blockType != MarkBlocks.Cauldron_I && this.blockType != MarkBlocks.WorkBench_I;
	public int GainedXP;
	private int LdirtyMarker = 0;
	
	
	public void resetGainedXP(){
		this.GainedXP = 0;
	}
	public void addGainedXP(int gain){
		this.GainedXP += gain;
	}
	
	@Override
	public String getName() {
		
		return "container.markcraft.name";
	}

	@Override
	public boolean hasCustomName() {
	
		return false;
	}
	
	public ItemStack[] getInventory(){
		ItemStack[] stack2 = new ItemStack[12];
		int[] stackSize = new int[12];
		for (int i = 0; i < 12; i++){
			stack2[i] = stack[i];
			stackSize[i] = stack[i] != null ? stackSize[i] = stack[i].stackSize : 0;
		
		}
		
		for(int i1 = 0; i1 < 12; i1++){
			for(int i2 = 0; i2 < 12; i2++){
			if (i1 != i2){
				if(stack2[i1] != null && stack2[i2] != null){
				if(stack2[i1].getItem() == stack2[i2].getItem()){
					if(stack2[i1].getMetadata() == stack2[i2].getMetadata()){
					stackSize[i1] += stackSize[i2];
					stack2[i1] = new ItemStack(stack2[i2].getItem(), stackSize[i1], stack2[i2].getMetadata());
					stack2[i2] = null; stackSize[i2] = 0;
					
				}}
				}
			}
			}
		}
		return stack2;
		
	}

	@Override
	public int getSizeInventory() {
		
		return stack.length;
	}

	@Override
	public ItemStack getStackInSlot(int index) {
		
		return stack[index];
	}
	
	public ItemStack[] getCurInventory(){
		ItemStack[] stackInv = new ItemStack[25];
		for (int i = 0; i < 25; i++){
			if(this.stack[i] == null){
				stackInv[i] = null;
			}
			else{
			stackInv[i] = this.stack[i];
			}
		}
		
		return stackInv;
	}
	
	public boolean GetisActive(){
		
		return this.isActive;
	}
	public void setaddRemIng(boolean b){this.addremIngr = b; }
	public void setIsActive(boolean b){
		
		this.isActive = b;
		
		this.CurrentCraftProgness = 0;
		this.resetGainedXP();
		
		this.markDirty();
		this.addremIngr = false;
	}
	
	public boolean isUsed(){
		
		return this.isbeingUsed;
	}
	
	public void setUsing(boolean b){
		
		this.isbeingUsed = b;
	}
	
	public void setPlayerUUID(UUID u){
		this.uuid = u;
	}
	public void setCurEnergy(float u){
		this.CurrentEnergy = u;
	}
	public void setMaxEnergy(float u){
		this.MaxEnergy = (int)u;
	}
	public void setCurInventory(ItemStack[] s){
		for (int i = 0; i < 25; i++){
			this.setInventorySlotContents(i, s[i]);
		}
	}
	
	
	public UUID getPlayerUUID(){
		return this.uuid;
	}
	
	public int getCurrentCrProg(){
		return this.CurrentCraftProgness;
	}
	public void setCurrentCrProg(int i){
		this.CurrentCraftProgness = i;
	}
	public int getMaxCrProg(){
		return this.MaxCraftProgness;
	}
	
	public void setCraftStackValue(int i){
		this.CraftVal = i;
	}
	public void addRemCraftStackValue(int i){
		 this.CraftVal += i;
		
	}
	
	public float getCurEnergy(){
		return this.CurrentEnergy;
	}
	public float getMaxEnergy(){
		return this.MaxEnergy;
	}
	
	public int getCraftStackValue(){
		return this.CraftVal;
	}

	public boolean CraftSlotContainsStack(){
		
		return stack[25] != null;// slot 25 Crafting
	}
	
	public int MaxCraft(){
		 
		 int MaxFurnace = 0;
		 int MaxInvSpace = 0;
		 int MaxIngr = 0;
		 
		 if(this.NeedsEnergy){
			 if(this.getStackInSlot(24) == null){
				 MaxFurnace = ((int)this.getCurEnergy()) / this.getCraftTime(this.getStackInSlot(25).getItem());
			 }
			 else{
			 MaxFurnace = ((this.burnEnergy(this.getStackInSlot(24).getItem()) * 20) + (int)this.getCurEnergy()) / this.getCraftTime(this.getStackInSlot(25).getItem());		
			 }
		 }
		 //get free inventory space
		 for (int i = 0; i < 12; i++){
			 if(this.getStackInSlot(i + 12) == null){
				 MaxInvSpace += (64 / this.getCorStackSize(this.getStackInSlot(25).getItem()));
			 }
			 else if(this.getStackInSlot(i + 12).getItem() == this.getStackInSlot(25).getItem()){
				 MaxInvSpace += ((64 - this.getStackInSlot(i + 12).stackSize) / this.getCorStackSize(this.getStackInSlot(25).getItem()));
			 } 
		 }
		 
		 //how much ingredients you have for how many items
		 if(this.IngrList != null){
			 int[] stk = new int[3];
			 for (int i = 0; i < 3; i++){
				 stk[i] = 0;
				 for (int i2 = 0; i2 < 12; i2++){
					 if(this.getStackInSlot(i2) != null && this.IngrList[i] != null){
					 if(this.IngrList[i].getItem() == this.getStackInSlot(i2).getItem()){
						stk[i] += (this.getStackInSlot(i2).stackSize / this.IngrList[i].stackSize);
					 }
					 }
				 }
			 }
			 for (int i = 0; i < stk.length; i++){
				 int temp = i == 0 ? 0 : MaxIngr;
				 MaxIngr = i == 0 ? stk[0] : (stk[i] < MaxIngr ? (stk[i] != 0 ? stk[i] : temp) : temp);
			 }
		 }
		 if(this.NeedsEnergy){
			 System.out.println("Values: " + MaxFurnace + " : " + MaxInvSpace + " : " + MaxIngr + " : " + (this.worldObj.isRemote ? "Client" : "Server"));
			 if(MaxFurnace > 64 && MaxInvSpace > 64 && (MaxIngr + 1) > 64){
				 return 64;
			 }
			 else if(MaxFurnace <= MaxInvSpace && MaxFurnace <= MaxIngr + 1){
				 return MaxFurnace;
			 } 
			 else if(MaxInvSpace <= (MaxIngr + 1)){
				 return MaxInvSpace;
			 }
			 else{
				 return MaxIngr + 1;
			 }
		 }
		 else if(MaxInvSpace <= (MaxIngr + 1)){
			 return MaxInvSpace;
		 }
		 else{
			 return MaxIngr + 1;
		 } 
	}
	
	public void setIngredientList(ItemStack s1, ItemStack s2, ItemStack s3){
		
		ItemStack[] s = {s1, s2, s3};
		this.IngrList = s;
	}
	 @Override
     public NBTTagCompound getUpdateTag()
     {
       NBTTagCompound nbtTagCompound = new NBTTagCompound();
       writeToNBT(nbtTagCompound);
       return nbtTagCompound;
     }

     /* Populates this TileEntity with information from the tag, used by vanilla to transmit from server to client
    */
     @Override
     public void handleUpdateTag(NBTTagCompound tag)
     {
       this.readFromNBT(tag);
     }
	
	@Override
	public ItemStack decrStackSize(int index, int count) {
		ItemStack slotStack = getStackInSlot(index);
		if (slotStack == null) {
			return null;
		}
		
		ItemStack RemovedStack;
		
		if (slotStack.stackSize <= count) {
			RemovedStack = slotStack;
			setInventorySlotContents(index, null);	
		}
		else{
			RemovedStack = slotStack.splitStack(count);
			if (slotStack.stackSize == 0) {
				setInventorySlotContents(index, null);
			}
		}
		markDirty();
		return RemovedStack;
	}
	public int getCorStackSize(Item item){
		Map<Item, Integer> size = new HashMap<Item, Integer>();
		size.put(Items.STICK, 4);
		size.put(Item.getItemFromBlock(Blocks.TORCH), 4);
		size.put(MarkItems.Stick10, 4);
		size.put(MarkItems.Stick20, 4);
		size.put(MarkItems.Stick40, 4);
		size.put(MarkItems.Stick60, 4);
		size.put(MarkItems.Stick80, 4);
		size.put(Item.getItemFromBlock(Blocks.PLANKS), 4);
		size.put(Item.getItemFromBlock(MarkBlocks.LogYew_Planks), 4);
		size.put(Item.getItemFromBlock(MarkBlocks.LogNetherBranch_Planks), 4);
		size.put(Item.getItemFromBlock(MarkBlocks.LogCrystWood_Planks), 4);
		size.put(Item.getItemFromBlock(Blocks.OAK_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.SPRUCE_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.BIRCH_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.JUNGLE_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.ACACIA_FENCE), 3);
		size.put(Item.getItemFromBlock(Blocks.DARK_OAK_FENCE), 3);
		size.put(Items.OAK_DOOR, 3);
		size.put(Items.SPRUCE_DOOR, 3);
		size.put(Items.BIRCH_DOOR, 3);
		size.put(Items.JUNGLE_DOOR, 3);
		size.put(Items.ACACIA_DOOR, 3);
		size.put(Items.DARK_OAK_DOOR, 3);
		size.put(MarkItems.LogYew_Door, 3);
		size.put(MarkItems.LogNetherBranch_Door, 3);
		size.put(MarkItems.LogCrystWood_Door, 3);
		size.put(Item.getItemFromBlock(Blocks.OAK_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.SPRUCE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.BIRCH_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.JUNGLE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.ACACIA_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.DARK_OAK_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.SANDSTONE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.RED_SANDSTONE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.STONE_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.BRICK_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.STONE_BRICK_STAIRS), 4);
		size.put(Item.getItemFromBlock(Blocks.NETHER_BRICK_FENCE), 6);
		size.put(Item.getItemFromBlock(Blocks.NETHER_BRICK_STAIRS), 4);
		size.put(Item.getItemFromBlock(MarkBlocks.LogYew_stairs), 4);
		size.put(Item.getItemFromBlock(Blocks.STONE_SLAB), 6);
		size.put(Item.getItemFromBlock(Blocks.STONE_SLAB2), 6);
		size.put(Item.getItemFromBlock(Blocks.WOODEN_SLAB), 6);
		size.put(Item.getItemFromBlock(Blocks.GLASS_PANE), 16);
		
		
		if(item == Item.getItemFromBlock(Blocks.STONEBRICK)){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.STONE)){
					return 4;
				}
				else {
					return 1;
				}
			}
		}
		
		return size.get(item) != null ? size.get(item) : 1;
	}
	private int getCorMetaData(Item item){
		Map<Item, Integer> meta = new HashMap<Item, Integer>();
		meta.put(Items.COOKED_FISH, 1);
		meta.put(Items.COAL, 1);
		
		if(item == Item.getItemFromBlock(Blocks.WOOL)){
			if(this.IngrList[1] != null){
			if (this.IngrList[1].getItem() == Items.DYE){
				return (15 - this.IngrList[1].getMetadata());
			}
			else{
				return 0;
			}
			}
		}
		else if(item == Item.getItemFromBlock(Blocks.PLANKS)){
			if(this.IngrList[0] != null){
			return this.IngrList[0].getMetadata();
			}
		}
		else if(item == Item.getItemFromBlock(Blocks.GLASS_PANE)){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getItem() == Item.getItemFromBlock(MarkBlocks.DirtGlass)){
					return 5;
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(MarkBlocks.GravelGlass)){
					return 10;
				}
				else{
					return 16;
				}
			
			}
		}
		else if(item == Item.getItemFromBlock(MarkBlocks.MarkTrapE)){
			if(this.IngrList[0] != null && this.IngrList[1] != null){
			if(this.IngrList[0].getItem() == Item.getItemFromBlock(MarkBlocks.LogYew_Planks) && this.IngrList[1].getItem() == MarkItems.Stick40){
				return 2;
			}
			}
		}
		else if(item == Item.getItemFromBlock(Blocks.SANDSTONE)){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.SAND)){
				return 0;	
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.SANDSTONE)){
					return 1;
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.STONE_SLAB)){{
					if(this.IngrList[0].getMetadata() == 1){
						return 2;
					}
				}
					
				}
			}
		}
		else if(item == Item.getItemFromBlock(Blocks.RED_SANDSTONE)){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.SAND)){
					return 0;	
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.RED_SANDSTONE)){
					return 1;
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.STONE_SLAB2)){{
					return 2;
				}
					
				}
			}
		}
		else if(item == Item.getItemFromBlock(Blocks.STONEBRICK)){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.STONE)){
					return 0;
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.STONEBRICK)){
					if(this.IngrList[1] != null){
						if(this.IngrList[1] == null){
							return 2;
						}
						else{
							return 1;
						}
					
					}
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.STONE_SLAB)){
					return 3;
				}
				
			}
		}
		else if(item == Items.DYE){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.RED_FLOWER)){
					if(this.IngrList[0].getMetadata() == 0 || this.IngrList[0].getMetadata() == 4){
					return 1;
					}
					else if(this.IngrList[0].getMetadata() == 1){
					return 12;
					}
					else if(this.IngrList[0].getMetadata() == 2){
					return 13;
					}
					else if(this.IngrList[0].getMetadata() == 3 || this.IngrList[0].getMetadata() == 6 ||this.IngrList[0].getMetadata() == 8){
					return 7;
					}
					else if(this.IngrList[0].getMetadata() == 5){
					return 14;
					}
					else if(this.IngrList[0].getMetadata() == 7){
					return 9;
					}
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.YELLOW_FLOWER)){
					return 11;
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.DOUBLE_PLANT)){
					if(this.IngrList[0].getMetadata() == 0){
						return 11;
					}
					else if(this.IngrList[0].getMetadata() == 1){
						return 13;
					}
					else if(this.IngrList[0].getMetadata() == 4){
						return 1;
					}
					else if(this.IngrList[0].getMetadata() == 5){
						return 9;
					}
				}
				else if(this.IngrList[0].getItem() == Items.BEETROOT){
					return 1;
				}
				else if(this.IngrList[0].getItem() == Items.BONE){
					return 15;
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.CACTUS)){
					return 2;
				}
				else if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.LAPIS_ORE)){
					return 4;
				}
			}
		}
		
		
		return meta.get(item) != null ? meta.get(item) : 0;
		
	}
	
	public void remIngrInv(){
		if(this.stack[25] != null && this.ContainItems(this.stack[25].getItem())){
			
			for (int i = 0; i < 3; i++){
				int g = 0;
				for (int j = 0; j < 12; j++){
					if(this.stack[j] != null && this.IngrList[i] != null)
					if(this.stack[j].getItem() == this.IngrList[i].getItem()){
						if(this.bucketItem() != 1){
						if(this.stack[j].getMetadata() == this.IngrList[i].getMetadata()){
					int a =	this.stack[j].stackSize;
					int b =	g == 0 ? this.IngrList[i].stackSize : g;
						if(a > b){
							int c = a - b;
							
							this.stack[j] = new ItemStack(this.IngrList[i].getItem(),c , this.IngrList[i].getMetadata());
							break;
						}	
						else if (a == b){
							this.removeStackFromSlot(j);
							break;
						}
						else{
							g = b - a;
							this.removeStackFromSlot(j);
							
						}
						}
					}
						else if(this.bucketItem() == 1){
							g = this.IngrList[i].stackSize;
							this.stack[j] = new ItemStack(Items.BUCKET, 1);
							g--;
						}
					}
				}
			}
			this.completeRecipe();
		}else{
			if(!worldObj.isRemote){
		this.isActive = false;
		if(this.uuid != null){
		 MainRegistry.network.sendTo(new CraftingPacketB(this.isActive, worldObj.getPlayerEntityByUUID(this.uuid), this.getPos().getX(), this.getPos().getY(), this.getPos().getZ()), (EntityPlayerMP) worldObj.getPlayerEntityByUUID(this.uuid));
		}
		System.out.println("does not contain Items so isActive is set to false");
			}
		}
	}
	private void addIngrInv(){
		for (int i = 0; i < 3; i++){
			int g = 0;
			for (int j = 0; j < 12; j++){
				if(this.stack[j] != null && this.IngrList[i] != null)
				if(this.stack[j].getItem() == this.IngrList[i].getItem()){
					if(this.stack[j].getMetadata() == this.IngrList[i].getMetadata()){
				int a =	this.stack[j].stackSize;
				int b =	g == 0 ? this.IngrList[i].stackSize : g;
					if((a + b) <= 64){
						int c = a + b;
						
						this.stack[j] = new ItemStack(this.IngrList[i].getItem(), c, this.IngrList[i].getMetadata());
						break;
					}	
					else{
						g = (b + a) - 64;
						this.stack[j] = new ItemStack(this.IngrList[i].getItem(), 64, this.IngrList[i].getMetadata());
						
					}
					}
				}
			}
		}
	}
	
	private Item CheckItem(Item item){
		
		if(item == Items.OAK_DOOR){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getMetadata() == 1){
					return Items.SPRUCE_DOOR;
				}
				else if(this.IngrList[0].getMetadata() == 2){
					return Items.BIRCH_DOOR;
				}
				else if(this.IngrList[0].getMetadata() == 3){
					return Items.JUNGLE_DOOR;
				}
				
				
			}
			
		}
		else if(item == Items.ACACIA_DOOR){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getMetadata() == 5){
					return Items.DARK_OAK_DOOR;
				}
				
			}
			
		}
		else if(item == Item.getItemFromBlock(Blocks.OAK_FENCE)){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getMetadata() == 1){
					return Item.getItemFromBlock(Blocks.SPRUCE_FENCE);
				}
				else if(this.IngrList[0].getMetadata() == 2){
					return Item.getItemFromBlock(Blocks.BIRCH_FENCE);
				}
				else if(this.IngrList[0].getMetadata() == 3){
					return Item.getItemFromBlock(Blocks.JUNGLE_FENCE);
				}
				
			}
			
		}
		else if(item == Item.getItemFromBlock(Blocks.ACACIA_FENCE)){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getMetadata() == 5){
					return Item.getItemFromBlock(Blocks.DARK_OAK_FENCE);
				}
				
			}
			
		}
		else if(item == Item.getItemFromBlock(Blocks.OAK_FENCE_GATE)){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getMetadata() == 1){
					return Item.getItemFromBlock(Blocks.SPRUCE_FENCE_GATE);
				}
				else if(this.IngrList[0].getMetadata() == 2){
					return Item.getItemFromBlock(Blocks.BIRCH_FENCE_GATE);
				}
				else if(this.IngrList[0].getMetadata() == 3){
					return Item.getItemFromBlock(Blocks.JUNGLE_FENCE_GATE);
				}
				
			}
			
		}
		else if(item == Item.getItemFromBlock(Blocks.ACACIA_FENCE_GATE)){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getMetadata() == 5){
					return Item.getItemFromBlock(Blocks.DARK_OAK_FENCE_GATE);
				}
				
			}
			
		}
		else if(item == Items.BOAT){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getMetadata() == 1){
					return Items.SPRUCE_BOAT;
				}
				else if(this.IngrList[0].getMetadata() == 2){
					return Items.BIRCH_BOAT;
				}
				else if(this.IngrList[0].getMetadata() == 3){
					return Items.JUNGLE_BOAT;
				}
				
			}
			
		}
		else if(item == Items.ACACIA_BOAT){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getMetadata() == 5){
					return Items.DARK_OAK_BOAT;
				}
				
			}
			
		}
		
		
		return item;
	}
	
	private void PutCrItemInv(Item item){
		int g = 0;
		
		for(int i = 0; i < 12; i++){
			if(this.getStackInSlot(i + 12) != null){
			if(this.getStackInSlot(i + 12).getItem() == item){
				int a =  this.getStackInSlot(i + 12).stackSize;
				int b = g == 0 ? this.getCorStackSize(item) : g;
				int c = this.getStackInSlot(i + 12).getMaxStackSize();
				
				if((a + b) <= c){
					this.setInventorySlotContents(i + 12,  new ItemStack(item, (a + b),this.getCorMetaData(item)));
					return;
				}
				else{
					g = (a + b) - c;
					this.setInventorySlotContents(i + 12,  new ItemStack(item, c,this.getCorMetaData(item)));
				}
				
			}
			
		}
		}
		
		for(int i = 0; i < 12; i++){

			if(this.getStackInSlot(i + 12) == null){
				this.setInventorySlotContents(i + 12, new ItemStack(item, this.getCorStackSize(item),this.getCorMetaData(item)));
				return;
			}
			
			
		}
		
		this.addremIngr = true;
		this.setIsActive(false);
		this.addremIngr = false;
		if(this.worldObj != null){
		if(this.worldObj.getPlayerEntityByUUID(this.uuid) != null){
		TextComponentString component = new TextComponentString(TextFormatting.RED + "Your Inventory is too full to craft this Item");
		this.worldObj.getPlayerEntityByUUID(this.uuid).addChatComponentMessage(component);
		}}
	}

	

	@Override
	public ItemStack removeStackFromSlot(int index) {
		
		ItemStack itemStack = getStackInSlot(index);
		if (itemStack != null) setInventorySlotContents(index, null);
		return itemStack;
	}

	@Override
	public void setInventorySlotContents(int index, ItemStack stackIn) {
		this.stack[index] = stackIn;
		if(stackIn != null && stackIn.stackSize > getInventoryStackLimit()){
			stackIn.stackSize = getInventoryStackLimit();
		}
		markDirty();
	}

	@Override
	public int getInventoryStackLimit() {
		
		return 64;
	}
	
	@Override
	public boolean isUseableByPlayer(EntityPlayer player) {
		
		return player.getDistanceSq(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) < (8.0D * 8.0D);
	}

	@Override
	public void openInventory(EntityPlayer player) {}

	@Override
	public void closeInventory(EntityPlayer player) {
		markDirty();
		if(!this.isActive && !this.worldObj.isRemote){
			System.out.println("Check:" + (this.worldObj.isRemote ? "Client" : "Server"));
			if(this.getStackInSlot(25) == null){
				this.setPlayerUUID((UUID)null);
				if(this.getBlockType() instanceof MarkCraftingTable){
					((MarkCraftingTable)this.getBlockType()).MigrateTEToNewState(this.worldObj, this, false, this.getPos(), this.worldObj.getBlockState(this.getPos()), (UUID)null);
				}
			}
		}
	}

	@Override
	public boolean isItemValidForSlot(int index, ItemStack stack) {
		
		return true;
	}

	@Override
	public int getField(int id) {
		
		return 0;
	}

	@Override
	public void setField(int id, int value) {}

	@Override
	public int getFieldCount() {
		return 0;
	}

	@Override
	public void clear() {
		Arrays.fill(this.stack, null);
		
	}
	
 public Boolean ContainItems(Item item){
		 
		 if(this.IngrList != null){
		 boolean[] b = new boolean[this.IngrList.length];
		 for(int i = 0; i < this.IngrList.length; i++){
			 b[i] = false;
		 }
		
		 for (int j = 0; j < this.getInventory().length; j++){
			
				
				
				 
		 for(int i = 0; i < 3; i++){
			if(!b[i]){
				if(this.IngrList[i] != null){
				if(this.getInventory()[j] != null){
					if(this.getInventory()[j].getItem() == this.IngrList[i].getItem()){
					
					
					if(this.getInventory()[j].stackSize >= this.IngrList[i].stackSize){
						 Item it = this.IngrList[i].getItem();
						 if(it == Item.getItemFromBlock(Blocks.PLANKS) || it == Item.getItemFromBlock(Blocks.LOG) || it == Items.DYE || it == Item.getItemFromBlock(Blocks.WOOL) || it == Items.FISH){
						if(this.getInventory()[j].getMetadata() == this.IngrList[i].getMetadata()){
								b[i] = true; 
								
							}}
							else{
								b[i] = true;
								
							
					}
				}
				}
				
			}
		 }
				else{
					if (i != 0){
					b[i] = true;
					}
				}
		 }
		 }
		 
		 } 
			
		 
		 for(int i = 0; i < b.length; i++){
			 if (b[i] == false)return false; 
		 }
		 return true;
		 
		 }
		 return false;
	 }
 /**1 if Bucket, 2 if glass bottle, 0 if nothing  */
 public int bucketItem(){
	 Map<Item, Integer> bucket = new HashMap<Item, Integer>();
	 
	 bucket.put(Items.LAVA_BUCKET, 1);
	 bucket.put(Items.WATER_BUCKET, 1);
	 bucket.put(Items.MILK_BUCKET, 1);
	 
	 return bucket.get(this.stack[25].getItem()) != null ? bucket.get(this.stack[25].getItem()) : 0;
 }
 
 public int TimeRemaining(){
	 
	 int a = this.MaxCraftProgness - this.CurrentCraftProgness;
	 if(this.stack[25] != null){
	 return ((this.CraftVal - 1) * this.getCraftTime(this.stack[25].getItem())) + a;
	 }
	 else return 0;
 }
	
	//update TE, Crafting Mechanism!! -------------------------------------------------------------------------------------------------------
	@Override
	public void update() {
		
			if (this.isActive){
				
			
			this.NeedsEnergy = this.blockType != MarkBlocks.BasicTable && this.blockType != MarkBlocks.TailoryBench_I && this.blockType != MarkBlocks.Anvil_I && this.blockType != MarkBlocks.TailoryBench_I && this.blockType != MarkBlocks.JewelryTable_I && this.blockType != MarkBlocks.FletchingTable_I && this.blockType != MarkBlocks.Cauldron_I && this.blockType != MarkBlocks.WorkBench_I;
			
			if(this.NeedsEnergy){
				
				if(this.stack[25] != null && this.CraftEnergy(this.stack[25].getItem()) != 0.0F){
					if(this.CurrentEnergy <= 0.0F){
						if(this.stack[24] != null){	
							if(this.burnEnergy(this.stack[24].getItem()) != 0){
						this.MaxEnergy = this.burnEnergy(this.stack[24].getItem());
						this.CurrentEnergy = (float)this.burnEnergy(this.stack[24].getItem());
					
				
					this.decrStackSize(24, 1);
					System.out.println("removed Fuel");
				}
				else{
					this.addremIngr = true;
					this.setIsActive(false);
					this.addremIngr = false;
					this.resetGainedXP();
					if(this.worldObj != null){
					if(this.worldObj.getPlayerEntityByUUID(this.uuid) != null){
					TextComponentString component = new TextComponentString(TextFormatting.RED + "You need fuel to craft this Item");
					this.worldObj.getPlayerEntityByUUID(this.uuid).addChatComponentMessage(component);
					}}
				}
			}
					else{
						this.addremIngr = true;
						this.setIsActive(false);
						this.addremIngr = false;
						this.resetGainedXP();
						if(this.worldObj != null){
						if(this.worldObj.getPlayerEntityByUUID(this.uuid) != null){
						TextComponentString component = new TextComponentString(TextFormatting.RED + "You need fuel to craft this Item");
						this.worldObj.getPlayerEntityByUUID(this.uuid).addChatComponentMessage(component);
						}}
					
				}}
				else{
					
				this.CurrentEnergy -= this.CraftEnergy(this.stack[25].getItem());
				
				}
					
					
				
				
			}
			}
			if(this.CraftSlotContainsStack()){
		if(this.MaxCraftProgness != this.getCraftTime(this.getStackInSlot(25).getItem())){
			this.MaxCraftProgness = this.getCraftTime(this.getStackInSlot(25).getItem());
			this.CurrentCraftProgness = 0;
		}
			if(this.CurrentCraftProgness < this.MaxCraftProgness){
				System.out.println("Test: " + this.CurrentCraftProgness + " / " + this.MaxCraftProgness + " : " + (this.worldObj.isRemote ? "Client" : "Server") + " : " +(this.stack[25] != null ? this.stack[25].getDisplayName() : null));
				this.CurrentCraftProgness++;
				if(this.MaxCraftProgness > 1199){
					this.LdirtyMarker++;
					if(this.LdirtyMarker <= 600){
						if((this.MaxCraftProgness - this.CurrentCraftProgness) < 599){
							this.markDirty();
						}
						this.LdirtyMarker = 0;
					}
				}
			}
			else{
				if(this.getCraftStackValue() > 1){
					this.LdirtyMarker = 0;
					this.markDirty();
					if(this.worldObj != null){
						if(!this.worldObj.isRemote){
							EntityPlayer pla = this.uuid != null ? worldObj.getPlayerEntityByUUID(this.uuid) : null;
							this.remIngrInv();
							if(pla != null){
							MainRegistry.network.sendTo(new CraftingPacketD(0, this.getCraftStackValue(), pla,this.getPos().getX(),this.getPos().getY(),this.getPos().getZ()), (EntityPlayerMP) pla);
							}
						}else{
							this.addGainedXP(this.GetCraftXP(this.stack[25].getItem()));
							this.worldObj.spawnParticle(EnumParticleTypes.EXPLOSION_NORMAL, (double)this.getPos().getX() + 0.5D, (double)this.getPos().getY() + 1.1D, (double)this.getPos().getZ() + 0.5D, 0.0D, 0.0D, 0.0D, new int[0]);
						}
						}
					
						}
				else{
					if(this.worldObj != null){
						if(!this.worldObj.isRemote){
							
							TextComponentString component = new TextComponentString(TextFormatting.RED + "your Order in the " + new ItemStack(this.blockType).getDisplayName() + " is Completed at pos: (" + this.getPos().getX() + "," + this.getPos().getY() + "," + this.getPos().getZ() + ").");
							this.worldObj.getPlayerEntityByUUID(this.uuid).addChatComponentMessage(component);
				
							EntityPlayer pla = worldObj.getPlayerEntityByUUID(this.uuid);
					this.remIngrInv();
					MainRegistry.network.sendTo(new CraftingPacketD(0, this.getCraftStackValue(), pla,this.getPos().getX(),this.getPos().getY(),this.getPos().getZ()), (EntityPlayerMP) pla);
					
						}}
				
					this.addGainedXP(this.GetCraftXP(this.stack[25].getItem()));
					this.CurrentCraftProgness = 0;
					this.MaxCraftProgness = 0;
					this.setCraftStackValue(0);
					System.out.println("Called!");
					this.removeStackFromSlot(25);
					this.isActive = false;
					this.resetGainedXP();
				}
			}
			
			}
		}
	}
	
	public void completeRecipe(){
		
		
	this.PutCrItemInv(this.stack[25].getItem());
			if(worldObj.getPlayerEntityByUUID(this.uuid) != null){
				EntityPlayer pla = worldObj.getPlayerEntityByUUID(this.uuid);
				System.out.println("Player name is:" + pla.getName());
			MarkData p = pla.getCapability(MainRegistry.ModMark136Data, null);
			if(this.blockType == MarkBlocks.BasicTable){
			p.addXp(this.BasicTableSkill(this.stack[25].getItem()), this.GetCraftXP(this.stack[25].getItem()));
			p.syncSkill();
			MainRegistry.network.sendTo(new CraftingPacketC(p.XP[this.BasicTableSkill(this.stack[25].getItem())], 0, pla), (EntityPlayerMP) pla);
			}
			else{
				p.addXp(this.ContainerSkill(), this.GetCraftXP(this.stack[25].getItem()));
				p.syncSkill();
				MainRegistry.network.sendTo(new CraftingPacketC(p.XP[this.ContainerSkill()],this.ContainerSkill2(), pla), (EntityPlayerMP) pla);
			}
		}
	
	
	
	
	this.addRemCraftStackValue(-1);
	this.CurrentCraftProgness = 0;
	
	
		this.markDirty();
	}
	
	
	private int getSlotEnergy(){
		
		if(this.stack[24] == null) return (int)(this.CurrentEnergy + 0.5F);
		
		return (int)(((float)this.burnEnergy(this.stack[24].getItem()) * (float)this.stack[24].stackSize) + this.CurrentEnergy + 0.5F);
		
	}
	private boolean isEnoughFuel(){
		
		if(!this.NeedsEnergy) return true;
		else{
		
		float a = (this.CraftEnergy(this.stack[25].getItem())) * (float)this.getCraftTime(this.stack[25].getItem());
		if(!(this.getSlotEnergy() >= (int)a)){
			System.out.println(this.getSlotEnergy() + " vs " + (int)a);
		}
		return this.getSlotEnergy() >= (int)a;
		}
	}

	
	/** gives the Time in ticks(1 sec = 20 ticks) duration an Item is crafted */
	public int getCraftTime(Item item){
		
		Map<Item, Integer> ItemTime = new HashMap<Item, Integer>();
		ItemTime.put(Item.getItemFromBlock(Blocks.STONE), 200);
		ItemTime.put(Items.IRON_INGOT, 200);
		ItemTime.put(Items.COAL, 200);
		ItemTime.put(Items.GOLD_INGOT, 200);
		
		ItemTime.put(Item.getItemFromBlock(MarkBlocks.DirtGlass), 200);
		ItemTime.put(Item.getItemFromBlock(MarkBlocks.GravelGlass), 200);
		ItemTime.put(Item.getItemFromBlock(Blocks.GLASS), 200);
		ItemTime.put(Item.getItemFromBlock(MarkBlocks.NetherGlass), 200);
		ItemTime.put(Item.getItemFromBlock(MarkBlocks.SoulGlass), 200);
		ItemTime.put(Item.getItemFromBlock(MarkBlocks.CrystGlass), 200);
		ItemTime.put(Item.getItemFromBlock(MarkBlocks.CyantinianGlass), 200);
		
		ItemTime.put(MarkItems.GemOpal, 200);
		ItemTime.put(MarkItems.GemSapphire, 200);
		ItemTime.put(MarkItems.GemOlivine, 200);
		ItemTime.put(MarkItems.GemHyacinth, 200);
		ItemTime.put(MarkItems.GemTopaz, 250);
		ItemTime.put(MarkItems.GemAmethyst, 300);
		ItemTime.put(MarkItems.GemSiam, 400);
		ItemTime.put(MarkItems.GemAquamarine, 500);
		
		ItemTime.put(Items.COOKED_BEEF, 200);
		ItemTime.put(Items.COOKED_CHICKEN, 200);
		ItemTime.put(Items.COOKED_FISH, 230);
		ItemTime.put(Items.COOKED_MUTTON, 200);
		ItemTime.put(Items.COOKED_PORKCHOP, 200);
		ItemTime.put(Items.COOKED_RABBIT, 200);
		ItemTime.put(Items.CAKE, 100);
		ItemTime.put(MarkItems.Cod_Cooked, 200);
		ItemTime.put(MarkItems.Trout_Cooked, 210);
		ItemTime.put(MarkItems.Sardine_Cooked, 220);
		ItemTime.put(MarkItems.Tuna_Cooked, 250);
		ItemTime.put(MarkItems.Herring_Cooked, 300);
		ItemTime.put(MarkItems.Bass_Cooked, 350);
		ItemTime.put(MarkItems.Eel_Cooked, 400);
		ItemTime.put(MarkItems.Batiod_Cooked, 500);
		ItemTime.put(MarkItems.Shark_Cooked, 600);
		
		if(item == Items.DYE){
			if(this.IngrList[0] != null){
				if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.CACTUS)){
					return 200;
				}
				if(this.IngrList[0].getItem() == Item.getItemFromBlock(Blocks.LAPIS_ORE)){
					return 200;
				}
			}
		}
		
		return ItemTime.get(item) != null ? ItemTime.get(item) : 10;
	}
	private int GetIngrCraftXP(){
		int TotalXP = 0;
		Map<Item, Integer> IngrXP = new HashMap<Item, Integer>();
		IngrXP.put(Items.STRING, 1);
		IngrXP.put(Items.STICK, 2);
		IngrXP.put(Items.BONE, 2);
		IngrXP.put(Items.COAL, 4);
		IngrXP.put(Items.IRON_INGOT, 12);
		IngrXP.put(MarkItems.Leather20, 12);
		IngrXP.put(MarkItems.Leather40, 25);
		IngrXP.put(MarkItems.Hide10, 4);
		IngrXP.put(Items.RABBIT_HIDE, 1);
		IngrXP.put(MarkItems.Hide20, 5);
		IngrXP.put(MarkItems.Hide40, 10);
		IngrXP.put(MarkItems.Silk20, 12);
		IngrXP.put(MarkItems.Silk40, 25);
		IngrXP.put(MarkItems.Cotton20, 5);
		IngrXP.put(MarkItems.Cotton40, 10);
		IngrXP.put(Item.getItemFromBlock(Blocks.COBBLESTONE), 2);
		IngrXP.put(Item.getItemFromBlock(Blocks.STONE), 3);
		IngrXP.put(Item.getItemFromBlock(Blocks.LOG), 5);
		IngrXP.put(Item.getItemFromBlock(Blocks.LOG2), 10);
		IngrXP.put(Item.getItemFromBlock(MarkBlocks.LogYew), 18);
		IngrXP.put(Items.GOLD_INGOT, 17);
		IngrXP.put(Items.DIAMOND, 25);
		IngrXP.put(MarkItems.Stick10, 3);
		IngrXP.put(MarkItems.Stick20, 6);
		IngrXP.put(MarkItems.Stick40, 9);
		
		
		
		for (int i = 0; i < 3; i++){
			if(this.IngrList[i] != null){
			if(this.IngrList[i].getItem() == Item.getItemFromBlock(Blocks.PLANKS)){
				if(this.IngrList[i].getMetadata() > 3){
					if(TotalXP != 0){
						int g = TotalXP;
						TotalXP = (g + 7);
					}
					else{
						int g = 0;
						TotalXP = (g + 7);
					}
					
				}
				else{
					if(TotalXP != 0){
						int g = TotalXP;
						TotalXP = (g + 3);
					}
					else{
					int g = 0;
					TotalXP = (g + 3);
				}
				}
			}
			else{
				int g2 = TotalXP;
				TotalXP = g2 + (IngrXP.get(this.IngrList[i].getItem()) != null ? IngrXP.get(this.IngrList[i].getItem()) * this.IngrList[i].stackSize : 0);
				
			}
			
			
			}
			
		}
		if(TotalXP == 0){
			return 0;
		}
		return TotalXP;
	}
	
	private int GetCraftXP(Item item){
		Map<Item, Integer> ItemXP = new HashMap<Item, Integer>();
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.BasicTable), 7);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.TailoryBench_I), 10);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.Anvil_I), 10);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.Furnace_I), 10);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.TanningBench_I), 10);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.JewelryTable_I), 10);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.GlassOven_I), 10);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.FletchingTable_I), 10);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.Range_I), 10);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.Cauldron_I), 10);
		ItemXP.put(Item.getItemFromBlock(Blocks.PLANKS), 5);
		ItemXP.put(Item.getItemFromBlock(Blocks.WOOL), 5);
		ItemXP.put(Item.getItemFromBlock(Blocks.STONE), 10);
		ItemXP.put(Item.getItemFromBlock(Blocks.GLASS_PANE), 9);
		ItemXP.put(Items.STICK, 10);
		ItemXP.put(MarkItems.Stick10, 15);
		ItemXP.put(MarkItems.Stick20, 20);
		ItemXP.put(MarkItems.Stick40, 25);
		ItemXP.put(MarkItems.Stick60, 50);
		ItemXP.put(MarkItems.Stick80, 65);
		ItemXP.put(Items.STICK, 10);
		ItemXP.put(Items.PAPER, 5);
		ItemXP.put(Items.BREAD, 25);
		ItemXP.put(Items.SUGAR, 3);
		ItemXP.put(MarkItems.CakeUnf, 10);
		ItemXP.put(Items.CAKE, 100);
		ItemXP.put(MarkItems.Cod_Cooked, 15);
		ItemXP.put(Items.COOKED_BEEF, 15);
		ItemXP.put(Items.COOKED_CHICKEN, 15);
		ItemXP.put(Items.COOKED_MUTTON, 15);
		ItemXP.put(Items.COOKED_PORKCHOP, 15);
		ItemXP.put(Items.COOKED_RABBIT, 15);
		ItemXP.put(MarkItems.Trout_Cooked, 22);
		ItemXP.put(MarkItems.Sardine_Cooked, 28);
		ItemXP.put(Items.COOKED_FISH, 36);
		ItemXP.put(MarkItems.Tuna_Cooked, 45);
		ItemXP.put(MarkItems.Herring_Cooked, 57);
		ItemXP.put(MarkItems.Bass_Cooked, 75);
		ItemXP.put(MarkItems.Eel_Cooked, 88);
		ItemXP.put(MarkItems.Batiod_Cooked, 100);
		ItemXP.put(MarkItems.Shark_Cooked, 110);
		ItemXP.put(Items.IRON_INGOT, 6);
		ItemXP.put(Items.GOLD_INGOT, 15);
		ItemXP.put(Items.DYE, 2);
		
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.DirtGlass) , 17);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.GravelGlass) , 18);
		ItemXP.put(Item.getItemFromBlock(Blocks.GLASS) , 20);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.NetherGlass) , 40);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.SoulGlass) , 45);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.CrystGlass) , 50);
		ItemXP.put(Item.getItemFromBlock(MarkBlocks.CyantinianGlass) , 70);
		
		ItemXP.put(MarkItems.GemOpal, 5);
		ItemXP.put(MarkItems.GemSapphire, 7);
		ItemXP.put(MarkItems.GemOlivine, 8);
		ItemXP.put(MarkItems.GemOlivine, 10);
		ItemXP.put(MarkItems.GemTopaz, 12);
		ItemXP.put(MarkItems.GemAmethyst, 15);
		ItemXP.put(MarkItems.GemSiam, 17);
		ItemXP.put(MarkItems.GemAquamarine, 20);
		
		
		
		
		
		return ItemXP.get(item) != null ? ItemXP.get(item) : this.GetIngrCraftXP();
	}
	public int BasicTableSkill(Item item){
		int ARCHEOLOGY = 13;
		int TAILORY = 14;
		int SMITHING = 15;
		int TANNING = 16;
		int JEWELRY = 17;
		int FLETCHING = 18;
		int COOKING = 19;
		int HERBLORE = 20;
		int HONOUR = 21;
		int TECHNOLOGY = 28;
			
		Map<Item, Integer> BTSkill = new HashMap<Item, Integer>();
		
		BTSkill.put(Items.STICK, FLETCHING);
		BTSkill.put(MarkItems.FishRod, FLETCHING);
		BTSkill.put(Items.WOODEN_AXE, SMITHING);
		BTSkill.put(Items.WOODEN_HOE, SMITHING);
		BTSkill.put(Items.WOODEN_PICKAXE, SMITHING);
		BTSkill.put(Items.WOODEN_SHOVEL, SMITHING);
		BTSkill.put(Items.WOODEN_SWORD, SMITHING);
		BTSkill.put(Items.BOW, FLETCHING);
		BTSkill.put(Item.getItemFromBlock(Blocks.WOOL), TAILORY);
		BTSkill.put(Items.PAPER, TANNING);
		BTSkill.put(Items.SUGAR, COOKING);
		
		return BTSkill.get(item) != null ? BTSkill.get(item) : 22; // returns CONSTRUCTION skill if hashmap results null
	}
	public int ContainerSkill(){
		Map<Block, Integer> CSkill = new HashMap<Block, Integer>();
		CSkill.put(MarkBlocks.TailoryBench_I, 14);
		CSkill.put(MarkBlocks.TailoryBench_II, 14);
		
		CSkill.put(MarkBlocks.Anvil_I, 15);
		CSkill.put(MarkBlocks.Anvil_II, 15);
		
		CSkill.put(MarkBlocks.Furnace_I, 15);
		CSkill.put(MarkBlocks.Furnace_II, 15);
		
		CSkill.put(MarkBlocks.TanningBench_I, 16);
		CSkill.put(MarkBlocks.TanningBench_II, 16);
		
		CSkill.put(MarkBlocks.JewelryTable_I, 17);
		CSkill.put(MarkBlocks.JewelryTable_II, 17);
		
		CSkill.put(MarkBlocks.GlassOven_I, 17);
		CSkill.put(MarkBlocks.GlassOven_II, 17);
		
		CSkill.put(MarkBlocks.FletchingTable_I, 18);
		CSkill.put(MarkBlocks.FletchingTable_II, 18);
		
		CSkill.put(MarkBlocks.Range_I, 19);
		CSkill.put(MarkBlocks.Range_II, 19);
		
		CSkill.put(MarkBlocks.Cauldron_I, 20);
		CSkill.put(MarkBlocks.Cauldron_II, 20);
		
		CSkill.put(MarkBlocks.WorkBench_I, 22);
		CSkill.put(MarkBlocks.WorkBench_II, 22);
		
		CSkill.put(MarkBlocks.TechBench_I, 28);
		
		
		return CSkill.get(this.blockType) != null ? CSkill.get(this.blockType) : 8;
	}
	public int ContainerSkill2(){
		Map<Block, Integer> CSkill = new HashMap<Block, Integer>();
		
		CSkill.put(MarkBlocks.TailoryBench_I, 2);
		CSkill.put(MarkBlocks.TailoryBench_II, 2);
		
		CSkill.put(MarkBlocks.Anvil_I, 3);
		CSkill.put(MarkBlocks.Anvil_II, 3);
		
		CSkill.put(MarkBlocks.Furnace_I, 3);
		CSkill.put(MarkBlocks.Furnace_II, 3);
		
		CSkill.put(MarkBlocks.TanningBench_I, 4);
		CSkill.put(MarkBlocks.TanningBench_II, 4);
		
		CSkill.put(MarkBlocks.JewelryTable_I, 5);
		CSkill.put(MarkBlocks.JewelryTable_II, 5);
		
		CSkill.put(MarkBlocks.GlassOven_I, 5);
		CSkill.put(MarkBlocks.GlassOven_II, 5);
		
		CSkill.put(MarkBlocks.FletchingTable_I, 6);
		CSkill.put(MarkBlocks.FletchingTable_II, 6);
		
		CSkill.put(MarkBlocks.Range_I, 7);
		CSkill.put(MarkBlocks.Range_II, 7);
		
		CSkill.put(MarkBlocks.Cauldron_I, 8);
		CSkill.put(MarkBlocks.Cauldron_II, 8);
		
		CSkill.put(MarkBlocks.WorkBench_I, 10);
		CSkill.put(MarkBlocks.WorkBench_II, 10);
		
		CSkill.put(MarkBlocks.TechBench_I, 11);
		
		return CSkill.get(this.blockType) != null ? CSkill.get(this.blockType) : 0;
	}
	
	/** gives how long an Item Can burn in TE#CraftEnergy & TE#BurnEnergy. 
	 * 100 & 10 has a duration of 10 seconds*/
	public int burnEnergy(Item item){
		Map<Item, Integer> Energy = new HashMap<Item, Integer>();
		
		
		Energy.put(Items.STICK, 5);
		Energy.put(Items.WOODEN_AXE, 10);
		Energy.put(Items.WOODEN_HOE, 10);
		Energy.put(Items.WOODEN_PICKAXE, 10);
		Energy.put(Items.WOODEN_SHOVEL, 10);
		Energy.put(Items.WOODEN_SWORD, 10);
		Energy.put(Items.BOW, 10);
		Energy.put(Items.SIGN, 10);
		Energy.put(Items.BOWL, 10);
		Energy.put(Item.getItemFromBlock(Blocks.OAK_DOOR), 10);
		Energy.put(Item.getItemFromBlock(Blocks.BIRCH_DOOR), 10);
		Energy.put(Item.getItemFromBlock(Blocks.SPRUCE_DOOR), 10);
		Energy.put(Item.getItemFromBlock(Blocks.JUNGLE_DOOR), 10);
		Energy.put(Item.getItemFromBlock(Blocks.ACACIA_DOOR), 10);
		Energy.put(Item.getItemFromBlock(Blocks.DARK_OAK_DOOR), 10);
		Energy.put(MarkItems.FishRod, 15);
		Energy.put(Item.getItemFromBlock(Blocks.LOG), 15);
		Energy.put(Item.getItemFromBlock(Blocks.PLANKS), 15);
		Energy.put(Items.COAL, 80);
		Energy.put(Items.BLAZE_ROD, 120);
		
		
		
		
		
		return Energy.get(item) != null ? (Energy.get(item) * 20) : 0;
	}
	/** gives how fast energy will be drained per tick*/
	public float CraftEnergy(Item item){
		Map<Item, Float> Energy = new HashMap<Item, Float>();
		
		Energy.put(Items.COOKED_FISH, 1.0F);
		Energy.put(Items.COOKED_BEEF, 1.0F);
		Energy.put(Items.COOKED_CHICKEN, 1.0F);
		Energy.put(Items.COOKED_MUTTON, 1.0F);
		Energy.put(Items.COOKED_PORKCHOP, 1.0F);
		Energy.put(Items.COOKED_RABBIT, 1.0F);
		Energy.put(Items.BAKED_POTATO, 1.0F);
		Energy.put(Items.COAL, 1.0F);
		Energy.put(Items.BREAD, 0.5F);
		Energy.put(MarkItems.Cod_Cooked, 1.0F);
		Energy.put(MarkItems.Trout_Cooked, 1.0F);
		Energy.put(MarkItems.Sardine_Cooked, 1.0F);
		Energy.put(MarkItems.Tuna_Cooked, 1.0F);
		Energy.put(MarkItems.Herring_Cooked, 1.2F);
		Energy.put(MarkItems.Bass_Cooked, 1.3F);
		Energy.put(MarkItems.Eel_Cooked, 1.5F);
		Energy.put(MarkItems.Batiod_Cooked, 2.0F);
		Energy.put(MarkItems.Shark_Cooked, 2.5F);
		Energy.put(MarkItems.GemOpal, 1.0F);
		Energy.put(MarkItems.GemSapphire, 1.0F);
		Energy.put(MarkItems.GemOlivine, 1.0F);
		Energy.put(MarkItems.GemHyacinth, 1.0F);
		Energy.put(MarkItems.GemTopaz, 1.0F);
		Energy.put(MarkItems.GemAmethyst, 1.0F);
		Energy.put(MarkItems.GemSiam, 1.2F);
		Energy.put(MarkItems.GemAquamarine, 1.5F);
		Energy.put(Item.getItemFromBlock(MarkBlocks.DirtGlass), 1.0F);
		Energy.put(Item.getItemFromBlock(MarkBlocks.GravelGlass), 1.0F);
		Energy.put(Item.getItemFromBlock(Blocks.GLASS), 1.0F);
		Energy.put(Item.getItemFromBlock(MarkBlocks.NetherGlass), 1.1F);
		Energy.put(Item.getItemFromBlock(MarkBlocks.SoulGlass), 1.2F);
		Energy.put(Item.getItemFromBlock(MarkBlocks.CrystGlass), 1.5F);
		Energy.put(Item.getItemFromBlock(MarkBlocks.SoulGlass), 3.0F);
		Energy.put(Item.getItemFromBlock(Blocks.STONE), 1.0F);
		Energy.put(Items.CAKE, 0.5F);
		Energy.put(Items.IRON_INGOT, 1.0F);
		Energy.put(Items.IRON_INGOT, 1.0F);
		Energy.put(Items.GOLD_INGOT, 1.0F);
		Energy.put(Items.NETHERBRICK, 1.0F);
		Energy.put(MarkItems.NetheriteBar, 1.7F);
		Energy.put(MarkItems.CrystliumBar, 2.5F);
		if(this.getBlockType() == MarkBlocks.Furnace_I || this.getBlockType() == MarkBlocks.Furnace_II ){
			if(item == Items.DYE){
				return 1.0F;
			}
		}
		
		
		
		
		return Energy.get(item) != null ? Energy.get(item) : 0.0F;
	}
	
	//Saving & Loading!! --------------------------------------------------------------------------------------------------------------------
	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound Compound)
	{
		super.writeToNBT(Compound);
		int act = this.GetisActive() ? 1 : 0;
		String WritePlayer = this.getPlayerUUID() != null ? this.getPlayerUUID().toString() : "null";
		System.out.println("Check1: " + this.CraftVal);
		
		Compound.setInteger("craftval13695", this.CraftVal);
		Compound.setFloat("curenergy13695", this.CurrentEnergy);
		Compound.setInteger("maxenergy13695", this.MaxEnergy);
		Compound.setInteger("curcraft13695", this.CurrentCraftProgness);
		Compound.setInteger("maxcraft13695", this.MaxCraftProgness);
		Compound.setInteger("isactive13695", act);
		Compound.setString("CraftPlayer13695", WritePlayer);
		
		
		
		
		//Inventory
		NBTTagList dataForAllSlots = new NBTTagList();
		for (int i = 0; i < 26; ++i) {
			if (this.stack[i] != null)	{
				NBTTagCompound dataForThisSlot = new NBTTagCompound();
				dataForThisSlot.setByte("mark13569Slotbyte", (byte) i);
				this.stack[i].writeToNBT(dataForThisSlot);
				dataForAllSlots.appendTag(dataForThisSlot);
			}
		}
		// the array of hashmaps is then inserted into the parent hashmap for the container
		Compound.setTag("mark135695slots", dataForAllSlots);
		// return the NBT Tag Compound
		
		return Compound;
		
		
	}
	@Override
	public void readFromNBT(NBTTagCompound Compound)
	{
		super.readFromNBT(Compound); 
		
		int ReadCrVal = 0;
		float ReadCurEng = 0.0F;
		int ReadMaxEng = 0;
		int ReadCurCrft = 0;
		int ReadMaxCrft = 0;
		int ReadisActive = 0;
		String ReadPlayer = "null";
		
		if(Compound.hasKey("craftval13695", 3)){
			System.out.println("Check1: " + this.CraftVal);
			ReadCrVal = Compound.getInteger("craftval13695");	
		}
		if(Compound.hasKey("curenergy13695", 5)){
			ReadCurEng = Compound.getFloat("curenergy13695");	
		}
		if(Compound.hasKey("maxenergy13695", 3)){
			ReadMaxEng = Compound.getInteger("maxenergy13695");	
		}
		if(Compound.hasKey("curcraft13695", 3)){
			ReadCurCrft = Compound.getInteger("curcraft13695");	
		}
		if(Compound.hasKey("maxcraft13695", 3)){
			ReadMaxCrft = Compound.getInteger("maxcraft13695");	
		}
		if(Compound.hasKey("isactive13695", 3)){
			ReadisActive = Compound.getInteger("isactive13695");	
		}
		if(Compound.hasKey("CraftPlayer13695", 8)){
			ReadPlayer = Compound.getString("CraftPlayer13695");	
		}
		
		
	this.CraftVal = ReadCrVal;
	this.CurrentEnergy = ReadCurEng;
	this.MaxEnergy = ReadMaxEng;
	this.CurrentCraftProgness = ReadCurCrft;
	this.MaxCraftProgness = ReadMaxCrft;
	this.isActive = ReadisActive == 1 ? true : false;
	this.setPlayerUUID(ReadPlayer == null || ReadPlayer.equals("null") ? (UUID) null : UUID.fromString(ReadPlayer));
		
		//Inventory
		NBTTagList ReadSlots = Compound.getTagList("mark135695slots", 10);

		Arrays.fill(this.stack, null);           // set all slots to empty
		for (int i = 0; i < ReadSlots.tagCount(); ++i) {
			NBTTagCompound dataForOneSlot = ReadSlots.getCompoundTagAt(i);
			int Index = dataForOneSlot.getByte("mark13569Slotbyte") & 255;

			if (Index >= 0 && Index < 26) {
				this.stack[Index] = ItemStack.loadItemStackFromNBT(dataForOneSlot);
			}
		}
	}
}
