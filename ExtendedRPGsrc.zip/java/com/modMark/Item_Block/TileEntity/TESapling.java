package com.modMark.Item_Block.TileEntity;

import java.util.UUID;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;

public class TESapling extends TileEntity {
	
	private UUID playerUUID;
	
	
	public void setPlayer(UUID playerIn){
		this.playerUUID = playerIn;
		markDirty();
	}
	public UUID getPlayer(){
		return this.playerUUID;
	}
	

    
    /* Creates a tag containing the TileEntity information, used by vanilla to transmit from server to client
     */
      @Override
      public NBTTagCompound getUpdateTag()
      {
        NBTTagCompound nbtTagCompound = new NBTTagCompound();
        writeToNBT(nbtTagCompound);
        return nbtTagCompound;
      }

      /* Populates this TileEntity with information from the tag, used by vanilla to transmit from server to client
     */
      @Override
      public void handleUpdateTag(NBTTagCompound tag)
      {
        this.readFromNBT(tag);
      }
	
      @Override
  	public NBTTagCompound writeToNBT(NBTTagCompound Compound)
  	{
  		
  		super.writeToNBT(Compound);
  		String uuid = "null";
      
  		if(this.playerUUID != null){
  			uuid = this.playerUUID.toString();
  			}
  			Compound.setString("player13695Sapling", uuid);
  			return Compound;
  			
  	}
      
      @Override
  	public void readFromNBT(NBTTagCompound Compound)
  	{
  		super.readFromNBT(Compound);
  		
  		String a = "null";
  		UUID ReadPlayerUUID = null;
  		
  		if(Compound.hasKey("player13695Sapling", 8)){
			a = Compound.getString("player13695Sapling");
			if(!a.equals("null")){
				
			ReadPlayerUUID = UUID.fromString(a);
				}
		
			}
  		this.playerUUID = ReadPlayerUUID;
  		}
  		
}
