package com.modMark.Item_Block.TileEntity;

import java.util.List;
import java.util.UUID;

import javax.annotation.Nullable;
import javax.xml.ws.spi.Provider;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class TETrap extends TileEntity {

	private int HuntLvl = 0;
	private UUID playerUUID = null;
	
	public TETrap(){};
	
	public void setTrapLevel(int Lvl){
		HuntLvl = Lvl;
		markDirty();
	}
	public int getTrapLevel(){
		return HuntLvl;
	}
	public void setPlayer(UUID playerIn){
		this.playerUUID = playerIn;
		markDirty();
	}
	public UUID getPlayer(){
		return this.playerUUID;
	}
	
	private boolean isVanilla = getClass().getName().startsWith("net.minecraft.");
    /**
     * Called from Chunk.setBlockIDWithMetadata and Chunk.fillChunk, determines if this tile entity should be re-created when the ID, or Metadata changes.
     * Use with caution as this will leave straggler TileEntities, or create conflicts with other TileEntities if not used properly.
     *
     * @param world Current world
     * @param pos Tile's world position
     * @param oldState The old ID of the block
     * @param newState The new ID of the block (May be the same)
     * @return true forcing the invalidation of the existing TE, false not to invalidate the existing TE
     */
    public boolean shouldRefresh(World world, BlockPos pos, IBlockState oldState, IBlockState newState)
    {
        return isVanilla ? (oldState.getBlock() != newState.getBlock()) : oldState != newState;
    }
    
	
    
    
    /* Creates a tag containing the TileEntity information, used by vanilla to transmit from server to client
     */
      @Override
      public NBTTagCompound getUpdateTag()
      {
        NBTTagCompound nbtTagCompound = new NBTTagCompound();
        writeToNBT(nbtTagCompound);
        return nbtTagCompound;
      }

      /* Populates this TileEntity with information from the tag, used by vanilla to transmit from server to client
     */
      @Override
      public void handleUpdateTag(NBTTagCompound tag)
      {
        this.readFromNBT(tag);
      }
	
	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound Compound)
	{
		
		super.writeToNBT(Compound);
		String uuid = "null";
		
		Compound.setInteger("hunter13695", this.HuntLvl);
		if(this.playerUUID != null){
		uuid = this.playerUUID.toString();
		}
		Compound.setString("player13695Trap", uuid);

		return Compound;
	}
	@Override
	public void readFromNBT(NBTTagCompound Compound)
	{
		super.readFromNBT(Compound);
		
		
		int ReadLvl = 1;
		
		String a = "null";
		UUID ReadPlayerUUID = null;
		
		
		
		if(Compound.hasKey("hunter13695", 3)){
			ReadLvl = Compound.getInteger("hunter13695");
		}
		if(Compound.hasKey("player13695Trap", 8)){
			a = Compound.getString("player13695Trap");
			if(!a.equals("null")){
				
			ReadPlayerUUID = UUID.fromString(a);
				}
		
			}
		
		this.HuntLvl = ReadLvl;
		this.playerUUID = ReadPlayerUUID;
		
	}
		
	
	
	
	
	
}
