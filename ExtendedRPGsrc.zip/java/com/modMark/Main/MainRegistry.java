package com.modMark.Main;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.modMark.Combat.LivingEventHandler;
import com.modMark.Combat.MobData;
import com.modMark.Generator.MarkBiome;
import com.modMark.Generator.MarkGen;
import com.modMark.Gui.IGuiHandlerMark;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Item_Block.MarkModelRender;
import com.modMark.Item_Block.MarkTE;
import com.modMark.Item_Block.Fluid.MarkFluids;
import com.modMark.Mob.MobRegistry;
import com.modMark.Packets.CombatLvlPacket;
import com.modMark.Packets.CombatLvlPacket2;
import com.modMark.Packets.CombatLvlPacket3;
import com.modMark.Packets.CombatLvlPacket4;
import com.modMark.Packets.CombatLvlPacket4S;
import com.modMark.Packets.CombatLvlPacketHP;
import com.modMark.Packets.CraftingPacketA;
import com.modMark.Packets.CraftingPacketB;
import com.modMark.Packets.CraftingPacketC;
import com.modMark.Packets.CraftingPacketD;
import com.modMark.Packets.CraftingPacketS;
import com.modMark.Packets.HiscorePacketA;
import com.modMark.Packets.HiscorePacketB;
import com.modMark.Packets.HiscorePacketC;
import com.modMark.Packets.InventoryPacketA;
import com.modMark.Packets.InventoryPacketB;
import com.modMark.Packets.InventoryPacketS;
import com.modMark.Packets.InventoryPacketS2;
import com.modMark.Packets.PacketHUD;
import com.modMark.Packets.SkillPacket;
import com.modMark.Proxy.ClientProxy;
import com.modMark.Proxy.CommonProxy;
import com.modMark.Refer.ReferenceStrings;
import com.modMark.Skill.EventHandlerMark;
import com.modMark.Skill.MarkData;


import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLInterModComms;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = ReferenceStrings.MODID, name = ReferenceStrings.NAME, version = ReferenceStrings.VERSION)
public class MainRegistry {
	
	@Mod.Instance("mark13695")
	public static MainRegistry instance;
	
	@SidedProxy(clientSide = "com.modMark.Proxy.ClientProxy", serverSide = "com.modMark.Proxy.ServerProxy" )
	public static CommonProxy proxy;
	
	public static SimpleNetworkWrapper network;
	
	
	public static CreativeTabs tabMark = new MarkCrTab(CreativeTabs.getNextID(), "MarksModTab");
	
	@CapabilityInject(MarkData.class)
    public static final Capability<MarkData> ModMark136Data = null;

	@CapabilityInject(MobData.class)
    public static final Capability<MobData> ModMark136MobData = null;

	
	@EventHandler
	public void PreInit(FMLPreInitializationEvent Event){
		
		network = NetworkRegistry.INSTANCE.newSimpleChannel("mark13695");
		network.registerMessage(SkillPacket.MarkHandler.class , SkillPacket.class, 0, Side.CLIENT);
		network.registerMessage(HiscorePacketA.MarkHandler2.class , HiscorePacketA.class, 1, Side.SERVER);
		network.registerMessage(HiscorePacketB.MarkHandler3.class , HiscorePacketB.class, 2, Side.CLIENT);
		network.registerMessage(HiscorePacketC.MarkHandler4.class , HiscorePacketC.class, 3, Side.CLIENT);
		network.registerMessage(CraftingPacketA.MarkHandler5.class , CraftingPacketA.class, 4, Side.CLIENT);
		network.registerMessage(CraftingPacketS.MarkHandler6.class , CraftingPacketS.class, 5, Side.SERVER);
		network.registerMessage(CraftingPacketB.MarkHandler7.class , CraftingPacketB.class, 6, Side.CLIENT);
		network.registerMessage(CraftingPacketC.MarkHandler8.class , CraftingPacketC.class, 7, Side.CLIENT);
		network.registerMessage(InventoryPacketA.MarkHandler9.class , InventoryPacketA.class, 8, Side.SERVER);
		network.registerMessage(InventoryPacketB.MarkHandler10.class , InventoryPacketB.class, 9, Side.CLIENT);
		network.registerMessage(InventoryPacketS.MarkHandler11.class , InventoryPacketS.class, 10, Side.SERVER);
		network.registerMessage(InventoryPacketS2.MarkHandler12.class , InventoryPacketS2.class, 11, Side.SERVER);
		network.registerMessage(CraftingPacketD.MarkHandler13.class , CraftingPacketD.class, 12, Side.CLIENT);
		network.registerMessage(PacketHUD.MarkHandler14.class , PacketHUD.class, 13, Side.CLIENT);
		network.registerMessage(CombatLvlPacket.MarkHandler15.class , CombatLvlPacket.class, 14, Side.SERVER);
		network.registerMessage(CombatLvlPacket2.MarkHandler16.class , CombatLvlPacket2.class, 15, Side.CLIENT);
		network.registerMessage(CombatLvlPacket3.MarkHandler17.class , CombatLvlPacket3.class, 16, Side.CLIENT);
		network.registerMessage(CombatLvlPacket4.MarkHandler18.class , CombatLvlPacket4.class, 17, Side.CLIENT);
		network.registerMessage(CombatLvlPacket4S.MarkHandler19.class , CombatLvlPacket4S.class, 18, Side.SERVER);
		network.registerMessage(CombatLvlPacketHP.MarkHandler20.class , CombatLvlPacketHP.class, 19, Side.CLIENT);
		
		MarkFluids.init();
		MarkBlocks.init();
		MarkItems.init();
		MarkTE.init();
		
		
		
		proxy.preInit(Event);
	}
	@EventHandler
	public void init(FMLInitializationEvent Event){
		
		NetworkRegistry.INSTANCE.registerGuiHandler(instance, new IGuiHandlerMark());
		MinecraftForge.EVENT_BUS.register(new EventHandlerMark());
		MinecraftForge.EVENT_BUS.register(new LivingEventHandler());
		
		MarkData.register();
		MobData.register();
		
		MarkAchievements.Init();
        
        MobRegistry.init();
        
        
        GameRegistry.registerWorldGenerator(new MarkGen(), 0);
        MarkBiome.init();
        proxy.init(Event);
	}
	
	
	@EventHandler
	public void PostInit(FMLPostInitializationEvent Event){
		proxy.postInit(Event);
		
	}
}
