package com.modMark.Main;

import com.modMark.Item_Block.MarkItems;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.stats.Achievement;
import net.minecraftforge.common.AchievementPage;

public class MarkAchievements {

	
	public static Achievement Total200 = new Achievement("Achievement.Total200", "Total200", 0, -7, Items.CAKE, (Achievement) null);
	public static Achievement Total500 = new Achievement("Achievement.Total500", "Total500", 6, -7, Items.CAKE, Total200);
	public static Achievement Total1000 = new Achievement("Achievement.Total1000", "Total1000", 12, -7, Items.CAKE, Total500);
	public static Achievement Total1500 = new Achievement("Achievement.Total1500", "Total1500", 18, -7, Items.CAKE, Total1000);
	public static Achievement Total2000 = new Achievement("Achievement.Total2000", "Total2000", 24, -7, Items.CAKE, Total1500);
	public static Achievement Total2500 = new Achievement("Achievement.Total2500", "Total2500", 30, -7, Items.CAKE, Total2000);
	public static Achievement Total3000 = new Achievement("Achievement.Total3000", "Total3000", 36, -7, Items.CAKE, Total2500);
	public static Achievement Total3500 = new Achievement("Achievement.Total3500", "Total3500", 42, -7, Items.CAKE, Total3000);
	public static Achievement Total4000 = new Achievement("Achievement.Total4000", "Total4000", 48, -7, Items.CAKE, Total3500);
	public static Achievement Total4500 = new Achievement("Achievement.Total4500", "Total4500", 54, -7, Items.CAKE, Total4000);
	public static Achievement Total5000 = new Achievement("Achievement.Total5000", "Total5000", 60, -7, Items.CAKE, Total4500);
	public static Achievement Total5500 = new Achievement("Achievement.Total5500", "Total5500", 66, -7, Items.CAKE, Total5000);
	public static Achievement Total6000 = new Achievement("Achievement.Total6000", "Total6000", 72, -7, Items.CAKE, Total5500);
	public static Achievement Total6500 = new Achievement("Achievement.Total6500", "Total6500", 78, -7, Items.CAKE, Total6000);
	public static Achievement Total7000 = new Achievement("Achievement.Total7000", "Total7000", 84, -7, Items.CAKE, Total6500);
	public static Achievement Total7500 = new Achievement("Achievement.Total7500", "Total7500", 90, -7, Items.CAKE, Total7000);
	public static Achievement Total8000 = new Achievement("Achievement.Total8000", "Total8000", 96, -7, Items.CAKE, Total7500);
	public static Achievement Total8200 = new Achievement("Achievement.Total8200", "Total8200", 102, -7, Items.CAKE, Total8000);
	public static Achievement Total8400 = new Achievement("Achievement.Total8400", "Total8400", 118, -7, Items.CAKE, Total8200);
	public static Achievement Total8500 = new Achievement("Achievement.Total8500", "Total8500", 114, -7, Items.CAKE, Total8400);
	public static Achievement Total8600 = new Achievement("Achievement.Total8600", "Total8600", 120, -7, Items.CAKE, Total8500);
	public static Achievement Total8700 = new Achievement("Achievement.Total8700", "Total8700", 126, -7, Items.CAKE, Total8600);
	public static Achievement Total8800 = new Achievement("Achievement.Total8800", "Total8800", 132, -7, Items.CAKE, Total8700);
	public static Achievement Total8900 = new Achievement("Achievement.Total8900", "Total8900", 136, -7, Items.CAKE, Total8800);
	//total level 8925!!
	public static Achievement GrandMaster = new Achievement("Achievement.GrandMaster", "Total200", 138, -7, Items.CAKE, Total8900);
	
	//0_HP
	public static Achievement HP2 = new Achievement("Achievement.HP2", "HP2", 0, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement HP25 = new Achievement("Achievement.HP25", "HP25", 2, -5, Items.GLASS_BOTTLE, HP2);
	public static Achievement HP50 = new Achievement("Achievement.HP50", "HP50", 2, -3, Items.GLASS_BOTTLE, HP25);
	public static Achievement HP75 = new Achievement("Achievement.HP75", "HP75", 0, -3, Items.GLASS_BOTTLE, HP50);
	public static Achievement HP99 = new Achievement("Achievement.HP99", "HP99", 0, -1, Items.GLASS_BOTTLE, HP75);
	public static Achievement HP100 = new Achievement("Achievement.HP100", "HP100", 2, -1, Items.GLASS_BOTTLE, HP99);
	public static Achievement HP125 = new Achievement("Achievement.HP125", "HP125", 2, 1, Items.GLASS_BOTTLE, HP100);
	public static Achievement HP150 = new Achievement("Achievement.HP150", "HP150", 0, 1, Items.GLASS_BOTTLE, HP125);
	public static Achievement HP175 = new Achievement("Achievement.HP175", "HP175", 0, 3, Items.GLASS_BOTTLE, HP150);
	public static Achievement HP200 = new Achievement("Achievement.HP200", "HP200", 2, 3, Items.GLASS_BOTTLE, HP175);
	public static Achievement HP201 = new Achievement("Achievement.HP201", "HP201", 2, 5, Items.GLASS_BOTTLE, HP200);
	public static Achievement HP220 = new Achievement("Achievement.HP220", "HP220", 0, 5, Items.GLASS_BOTTLE, HP201);
	public static Achievement HP240 = new Achievement("Achievement.HP240", "HP240", 0, 7, Items.GLASS_BOTTLE, HP220);
	public static Achievement HP250 = new Achievement("Achievement.HP250", "HP250", 2, 7, Items.GLASS_BOTTLE, HP240);
	public static Achievement HPMAX = new Achievement("Achievement.HPMAX", "HPMAX", 1, 9, Items.GLASS_BOTTLE, HP250);
	
	//1_MELEE
	public static Achievement ML2 = new Achievement("Achievement.ML2", "ML2", 4, -5, Items.WOODEN_SWORD, (Achievement) null);
	public static Achievement ML25 = new Achievement("Achievement.ML25", "ML25", 6, -5, Items.STONE_SWORD, ML2);
	public static Achievement ML50 = new Achievement("Achievement.ML50", "ML50", 6, -3, Items.IRON_SWORD, ML25);
	public static Achievement ML75 = new Achievement("Achievement.ML75", "ML75", 4, -3, Items.DIAMOND_SWORD, ML50);
	public static Achievement ML99 = new Achievement("Achievement.ML99", "ML99", 4, -1, Items.DIAMOND_SWORD, ML75); //netherite
	public static Achievement ML100 = new Achievement("Achievement.ML100", "ML100", 6, -1, Items.DIAMOND_SWORD, ML99); //crystlium
	public static Achievement ML125 = new Achievement("Achievement.ML125", "ML125", 6, 1, Items.DIAMOND_SWORD, ML100); //ammitdh 105
	public static Achievement ML150 = new Achievement("Achievement.ML150", "ML150", 4, 1, Items.GLASS_BOTTLE, ML125); //120
	public static Achievement ML175 = new Achievement("Achievement.ML175", "ML175", 4, 3, Items.GLASS_BOTTLE, ML150); //135
	public static Achievement ML200 = new Achievement("Achievement.ML200", "ML200", 6, 3, Items.GLASS_BOTTLE, ML175); //150
	public static Achievement ML201 = new Achievement("Achievement.ML201", "ML201", 6, 5, Items.GLASS_BOTTLE, ML200); //160
	public static Achievement ML220 = new Achievement("Achievement.ML220", "ML220", 4, 5, Items.GLASS_BOTTLE, ML201); //170
	public static Achievement ML240 = new Achievement("Achievement.ML240", "ML240", 4, 7, Items.GLASS_BOTTLE, ML220); //180
	public static Achievement ML250 = new Achievement("Achievement.ML250", "ML250", 6, 7, Items.GLASS_BOTTLE, ML240); //krenite 190
	public static Achievement MLMAX = new Achievement("Achievement.MLMAX", "MLMAX", 5, 9, Items.GLASS_BOTTLE, ML250); //ammaritdh 200
	
	//2_Ranged
	public static Achievement RN2 = new Achievement("Achievement.RN2", "RN2", 8, -5, Items.BOW, (Achievement) null);
	public static Achievement RN25 = new Achievement("Achievement.RN25", "RN25", 10, -5, Items.BOW, RN2);
	public static Achievement RN50 = new Achievement("Achievement.RN50", "RN50", 10, -3, Items.BOW, RN25);
	public static Achievement RN75 = new Achievement("Achievement.RN75", "RN75", 8, -3, Items.BOW, RN50);
	public static Achievement RN99 = new Achievement("Achievement.RN99", "RN99", 8, -1, Items.BOW, RN75);
	public static Achievement RN100 = new Achievement("Achievement.RN100", "RN100", 10, -1, Items.BOW, RN99);
	public static Achievement RN125 = new Achievement("Achievement.RN125", "RN125", 10, 1, Items.BOW, RN100);
	public static Achievement RN150 = new Achievement("Achievement.RN150", "RN150", 8, 1, Items.BOW, RN125);
	public static Achievement RN175 = new Achievement("Achievement.RN175", "RN175", 8, 3, Items.BOW, RN150);
	public static Achievement RN200 = new Achievement("Achievement.RN200", "RN200", 10, 3, Items.BOW, RN175);
	public static Achievement RN201 = new Achievement("Achievement.RN201", "RN201", 10, 5, Items.BOW, RN200);
	public static Achievement RN220 = new Achievement("Achievement.RN220", "RN220", 8, 5, Items.BOW, RN201);
	public static Achievement RN240 = new Achievement("Achievement.RN240", "RN240", 8, 7, Items.BOW, RN220);
	public static Achievement RN250 = new Achievement("Achievement.RN250", "RN250", 10, 7, Items.BOW, RN240);
	public static Achievement RNMAX = new Achievement("Achievement.RNMAX", "RNMAX", 9, 9, Items.BOW, RN250);
	
	//3_MAGIC
	public static Achievement MG2 = new Achievement("Achievement.MG2", "MG2", 12, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement MG25 = new Achievement("Achievement.MG25", "MG25", 14, -5, Items.GLASS_BOTTLE, MG2);
	public static Achievement MG50 = new Achievement("Achievement.MG50", "MG50", 14, -3, Items.GLASS_BOTTLE, MG25);
	public static Achievement MG75 = new Achievement("Achievement.MG75", "MG75", 12, -3, Items.GLASS_BOTTLE, MG50);
	public static Achievement MG99 = new Achievement("Achievement.MG99", "MG99", 12, -1, Items.GLASS_BOTTLE, MG75);
	public static Achievement MG100 = new Achievement("Achievement.MG100", "MG100", 14, -1, Items.GLASS_BOTTLE, MG99);
	public static Achievement MG125 = new Achievement("Achievement.MG125", "MG125", 14, 1, Items.GLASS_BOTTLE, MG100);
	public static Achievement MG150 = new Achievement("Achievement.MG150", "MG150", 12, 1, Items.GLASS_BOTTLE, MG125);
	public static Achievement MG175 = new Achievement("Achievement.MG175", "MG175", 12, 3, Items.GLASS_BOTTLE, MG150);
	public static Achievement MG200 = new Achievement("Achievement.MG200", "MG200", 14, 3, Items.GLASS_BOTTLE, MG175);
	public static Achievement MG201 = new Achievement("Achievement.MG201", "MG201", 14, 5, Items.GLASS_BOTTLE, MG200);
	public static Achievement MG220 = new Achievement("Achievement.MG220", "MG220", 12, 5, Items.GLASS_BOTTLE, MG201);
	public static Achievement MG240 = new Achievement("Achievement.MG240", "MG240", 12, 7, Items.GLASS_BOTTLE, MG220);
	public static Achievement MG250 = new Achievement("Achievement.MG250", "MG250", 14, 7, Items.GLASS_BOTTLE, MG240);
	public static Achievement MGMAX = new Achievement("Achievement.MGMAX", "MGMAX", 13, 9, Items.GLASS_BOTTLE, MG250);
	
	//4_DEFENCE
	public static Achievement DF2 = new Achievement("Achievement.DF2", "DF2", 16, -5, Items.LEATHER_CHESTPLATE, (Achievement) null);
	public static Achievement DF25 = new Achievement("Achievement.DF25", "DF25", 18, -5, Items.CHAINMAIL_CHESTPLATE, DF2);
	public static Achievement DF50 = new Achievement("Achievement.DF50", "DF50", 18, -3, Items.IRON_CHESTPLATE, DF25);
	public static Achievement DF75 = new Achievement("Achievement.DF75", "DF75", 16, -3, Items.DIAMOND_CHESTPLATE, DF50);
	public static Achievement DF99 = new Achievement("Achievement.DF99", "DF99", 16, -1, Items.DIAMOND_CHESTPLATE, DF75);
	public static Achievement DF100 = new Achievement("Achievement.DF100", "DF100", 18, -1, Items.DIAMOND_CHESTPLATE, DF99);
	public static Achievement DF125 = new Achievement("Achievement.DF125", "DF125", 18, 1, Items.DIAMOND_CHESTPLATE, DF100);
	public static Achievement DF150 = new Achievement("Achievement.DF150", "DF150", 16, 1, Items.GLASS_BOTTLE, DF125);
	public static Achievement DF175 = new Achievement("Achievement.DF175", "DF175", 16, 3, Items.GLASS_BOTTLE, DF150);
	public static Achievement DF200 = new Achievement("Achievement.DF200", "DF200", 18, 3, Items.GLASS_BOTTLE, DF175);
	public static Achievement DF201 = new Achievement("Achievement.DF201", "DF201", 18, 5, Items.GLASS_BOTTLE, DF200);
	public static Achievement DF220 = new Achievement("Achievement.DF220", "DF220", 16, 5, Items.GLASS_BOTTLE, DF201);
	public static Achievement DF240 = new Achievement("Achievement.DF240", "DF240", 16, 7, Items.GLASS_BOTTLE, DF220);
	public static Achievement DF250 = new Achievement("Achievement.DF250", "DF250", 18, 7, Items.GLASS_BOTTLE, DF240);
	public static Achievement DFMAX = new Achievement("Achievement.DFMAX", "DFMAX", 17, 9, Items.GLASS_BOTTLE, DF250);
	
	//5_ENDURANCE
	public static Achievement EN2 = new Achievement("Achievement.EN2", "EN2", 20, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement EN25 = new Achievement("Achievement.EN25", "EN25", 22, -5, Items.GLASS_BOTTLE, EN2);
	public static Achievement EN50 = new Achievement("Achievement.EN50", "EN50", 22, -3, Items.GLASS_BOTTLE, EN25);
	public static Achievement EN75 = new Achievement("Achievement.EN75", "EN75", 20, -3, Items.GLASS_BOTTLE, EN50);
	public static Achievement EN99 = new Achievement("Achievement.EN99", "EN99", 20, -1, Items.GLASS_BOTTLE, EN75);
	public static Achievement EN100 = new Achievement("Achievement.EN100", "EN100", 22, -1, Items.GLASS_BOTTLE, EN99);
	public static Achievement EN125 = new Achievement("Achievement.EN125", "EN125", 22, 1, Items.GLASS_BOTTLE, EN100);
	public static Achievement EN150 = new Achievement("Achievement.EN150", "EN150", 20, 1, Items.GLASS_BOTTLE, EN125);
	public static Achievement EN175 = new Achievement("Achievement.EN175", "EN175", 20, 3, Items.GLASS_BOTTLE, EN150);
	public static Achievement EN200 = new Achievement("Achievement.EN200", "EN200", 22, 3, Items.GLASS_BOTTLE, EN175);
	public static Achievement EN201 = new Achievement("Achievement.EN201", "EN201", 22, 5, Items.GLASS_BOTTLE, EN200);
	public static Achievement EN220 = new Achievement("Achievement.EN220", "EN220", 20, 5, Items.GLASS_BOTTLE, EN201);
	public static Achievement EN240 = new Achievement("Achievement.EN240", "EN240", 20, 7, Items.GLASS_BOTTLE, EN220);
	public static Achievement EN250 = new Achievement("Achievement.EN250", "EN250", 22, 7, Items.GLASS_BOTTLE, EN240);
	public static Achievement ENMAX = new Achievement("Achievement.ENMAX", "ENMAX", 21, 9, Items.GLASS_BOTTLE, EN250);
	
	//6_SLAYER
	public static Achievement SL2 = new Achievement("Achievement.SL2", "SL2", 24, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement SL25 = new Achievement("Achievement.SL25", "SL25", 26, -5, Items.GLASS_BOTTLE, SL2);
	public static Achievement SL50 = new Achievement("Achievement.SL50", "SL50", 26, -3, Items.GLASS_BOTTLE, SL25);
	public static Achievement SL75 = new Achievement("Achievement.SL75", "SL75", 24, -3, Items.GLASS_BOTTLE, SL50);
	public static Achievement SL99 = new Achievement("Achievement.SL99", "SL99", 24, -1, Items.GLASS_BOTTLE, SL75);
	public static Achievement SL100 = new Achievement("Achievement.SL100", "SL100", 26, -1, Items.GLASS_BOTTLE, SL99);
	public static Achievement SL125 = new Achievement("Achievement.SL125", "SL125", 26, 1, Items.GLASS_BOTTLE, SL100);
	public static Achievement SL150 = new Achievement("Achievement.SL150", "SL150", 24, 1, Items.GLASS_BOTTLE, SL125);
	public static Achievement SL175 = new Achievement("Achievement.SL175", "SL175", 24, 3, Items.GLASS_BOTTLE, SL150);
	public static Achievement SL200 = new Achievement("Achievement.SL200", "SL200", 26, 3, Items.GLASS_BOTTLE, SL175);
	public static Achievement SL201 = new Achievement("Achievement.SL201", "SL201", 26, 5, Items.GLASS_BOTTLE, SL200);
	public static Achievement SL220 = new Achievement("Achievement.SL220", "SL220", 24, 5, Items.GLASS_BOTTLE, SL201);
	public static Achievement SL240 = new Achievement("Achievement.SL240", "SL240", 24, 7, Items.GLASS_BOTTLE, SL220);
	public static Achievement SL250 = new Achievement("Achievement.SL250", "SL250", 26, 7, Items.GLASS_BOTTLE, SL240);
	public static Achievement SLMAX = new Achievement("Achievement.SLMAX", "SLMAX", 25, 9, Items.GLASS_BOTTLE, SL250);
	
	//7_FARMING
	public static Achievement FA2 = new Achievement("Achievement.FA2", "FA2", 28, -5, Items.WOODEN_HOE, (Achievement) null);
	public static Achievement FA25 = new Achievement("Achievement.FA25", "FA25", 30, -5, Items.STONE_HOE, FA2);
	public static Achievement FA50 = new Achievement("Achievement.FA50", "FA50", 30, -3, Items.IRON_HOE, FA25);
	public static Achievement FA75 = new Achievement("Achievement.FA75", "FA75", 28, -3, Items.DIAMOND_HOE, FA50);
	public static Achievement FA99 = new Achievement("Achievement.FA99", "FA99", 28, -1, Items.DIAMOND_HOE, FA75);
	public static Achievement FA100 = new Achievement("Achievement.FA100", "FA100", 30, -1, Items.DIAMOND_HOE, FA99);
	public static Achievement FA125 = new Achievement("Achievement.FA125", "FA125", 30, 1, Items.GLASS_BOTTLE, FA100);
	public static Achievement FA150 = new Achievement("Achievement.FA150", "FA150", 28, 1, Items.GLASS_BOTTLE, FA125);
	public static Achievement FA175 = new Achievement("Achievement.FA175", "FA175", 28, 3, Items.GLASS_BOTTLE, FA150);
	public static Achievement FA200 = new Achievement("Achievement.FA200", "FA200", 30, 3, Items.GLASS_BOTTLE, FA175);
	public static Achievement FA201 = new Achievement("Achievement.FA201", "FA201", 30, 5, Items.GLASS_BOTTLE, FA200);
	public static Achievement FA220 = new Achievement("Achievement.FA220", "FA220", 28, 5, Items.GLASS_BOTTLE, FA201);
	public static Achievement FA240 = new Achievement("Achievement.FA240", "FA240", 28, 7, Items.GLASS_BOTTLE, FA220);
	public static Achievement FA250 = new Achievement("Achievement.FA250", "FA250", 30, 7, Items.GLASS_BOTTLE, FA240);
	public static Achievement FAMAX = new Achievement("Achievement.FAMAX", "FAMAX", 29, 9, Items.GLASS_BOTTLE, FA250);
	
	//8_MINING
	public static Achievement MI2 = new Achievement("Achievement.MI2", "MI2", 32, -5, Items.WOODEN_PICKAXE, (Achievement) null);
	public static Achievement MI25 = new Achievement("Achievement.MI25", "MI25", 34, -5, Items.STONE_PICKAXE, MI2);
	public static Achievement MI50 = new Achievement("Achievement.MI50", "MI50", 34, -3, Items.IRON_PICKAXE, MI25);
	public static Achievement MI75 = new Achievement("Achievement.MI75", "MI75", 32, -3, Items.DIAMOND_PICKAXE, MI50);
	public static Achievement MI99 = new Achievement("Achievement.MI99", "MI99", 32, -1, Items.DIAMOND_PICKAXE, MI75);
	public static Achievement MI100 = new Achievement("Achievement.MI100", "MI100", 34, -1, Items.DIAMOND_PICKAXE, MI99);
	public static Achievement MI125 = new Achievement("Achievement.MI125", "MI125", 34, 1, Items.GLASS_BOTTLE, MI100);
	public static Achievement MI150 = new Achievement("Achievement.MI150", "MI150", 32, 1, Items.GLASS_BOTTLE, MI125);
	public static Achievement MI175 = new Achievement("Achievement.MI175", "MI175", 32, 3, Items.GLASS_BOTTLE, MI150);
	public static Achievement MI200 = new Achievement("Achievement.MI200", "MI200", 34, 3, Items.GLASS_BOTTLE, MI175);
	public static Achievement MI201 = new Achievement("Achievement.MI201", "MI201", 34, 5, Items.GLASS_BOTTLE, MI200);
	public static Achievement MI220 = new Achievement("Achievement.MI220", "MI220", 32, 5, Items.GLASS_BOTTLE, MI201);
	public static Achievement MI240 = new Achievement("Achievement.MI240", "MI240", 32, 7, Items.GLASS_BOTTLE, MI220);
	public static Achievement MI250 = new Achievement("Achievement.MI250", "MI250", 34, 7, Items.GLASS_BOTTLE, MI240);
	public static Achievement MIMAX = new Achievement("Achievement.MIMAX", "MIMAX", 33, 9, Items.GLASS_BOTTLE, MI250);
	
	//9_HUNTER
	public static Achievement HU2 = new Achievement("Achievement.HU2", "HU2", 36, -5, Items.RABBIT_HIDE, (Achievement) null);
	public static Achievement HU25 = new Achievement("Achievement.HU25", "HU25", 38, -5, MarkItems.Hide10, HU2);
	public static Achievement HU50 = new Achievement("Achievement.HU50", "HU50", 38, -3, MarkItems.Hide20, HU25);
	public static Achievement HU75 = new Achievement("Achievement.HU75", "HU75", 36, -3, MarkItems.Hide40, HU50);
	public static Achievement HU99 = new Achievement("Achievement.HU99", "HU99", 36, -1, MarkItems.Hide60, HU75);
	public static Achievement HU100 = new Achievement("Achievement.HU100", "HU100", 38, -1, MarkItems.Hide80, HU99);
	public static Achievement HU125 = new Achievement("Achievement.HU125", "HU125", 38, 1, MarkItems.Hide80, HU100);
	public static Achievement HU150 = new Achievement("Achievement.HU150", "HU150", 36, 1, Items.GLASS_BOTTLE, HU125);
	public static Achievement HU175 = new Achievement("Achievement.HU175", "HU175", 36, 3, Items.GLASS_BOTTLE, HU150);
	public static Achievement HU200 = new Achievement("Achievement.HU200", "HU200", 38, 3, Items.GLASS_BOTTLE, HU175);
	public static Achievement HU201 = new Achievement("Achievement.HU201", "HU201", 38, 5, Items.GLASS_BOTTLE, HU200);
	public static Achievement HU220 = new Achievement("Achievement.HU220", "HU220", 36, 5, Items.GLASS_BOTTLE, HU201);
	public static Achievement HU240 = new Achievement("Achievement.HU240", "HU240", 36, 7, Items.GLASS_BOTTLE, HU220);
	public static Achievement HU250 = new Achievement("Achievement.HU250", "HU250", 38, 7, Items.GLASS_BOTTLE, HU240);
	public static Achievement HUMAX = new Achievement("Achievement.HUMAX", "HUMAX", 37, 9, Items.GLASS_BOTTLE, HU250);
	
	//10_EXCAVATION
	public static Achievement EX2 = new Achievement("Achievement.EX2", "EX2", 40, -5, Items.WOODEN_SHOVEL, (Achievement) null);
	public static Achievement EX25 = new Achievement("Achievement.EX25", "EX25", 42, -5, Items.STONE_SHOVEL, EX2);
	public static Achievement EX50 = new Achievement("Achievement.EX50", "EX50", 42, -3, Items.IRON_SHOVEL, EX25);
	public static Achievement EX75 = new Achievement("Achievement.EX75", "EX75", 40, -3, Items.DIAMOND_SHOVEL, EX50);
	public static Achievement EX99 = new Achievement("Achievement.EX99", "EX99", 40, -1, Items.DIAMOND_SHOVEL, EX75);
	public static Achievement EX100 = new Achievement("Achievement.EX100", "EX100", 42, -1, Items.DIAMOND_SHOVEL, EX99);
	public static Achievement EX125 = new Achievement("Achievement.EX125", "EX125", 42, 1, Items.GLASS_BOTTLE, EX100);
	public static Achievement EX150 = new Achievement("Achievement.EX150", "EX150", 40, 1, Items.GLASS_BOTTLE, EX125);
	public static Achievement EX175 = new Achievement("Achievement.EX175", "EX175", 40, 3, Items.GLASS_BOTTLE, EX150);
	public static Achievement EX200 = new Achievement("Achievement.EX200", "EX200", 42, 3, Items.GLASS_BOTTLE, EX175);
	public static Achievement EX201 = new Achievement("Achievement.EX201", "EX201", 42, 5, Items.GLASS_BOTTLE, EX200);
	public static Achievement EX220 = new Achievement("Achievement.EX220", "EX220", 40, 5, Items.GLASS_BOTTLE, EX201);
	public static Achievement EX240 = new Achievement("Achievement.EX240", "EX240", 40, 7, Items.GLASS_BOTTLE, EX220);
	public static Achievement EX250 = new Achievement("Achievement.EX250", "EX250", 42, 7, Items.GLASS_BOTTLE, EX240);
	public static Achievement EXMAX = new Achievement("Achievement.EXMAX", "EXMAX", 41, 9, Items.GLASS_BOTTLE, EX250);
	
	//11_WOODCUTTING
	public static Achievement WC2 = new Achievement("Achievement.WC2", "WC2", 44, -5, Items.WOODEN_AXE, (Achievement) null);
	public static Achievement WC25 = new Achievement("Achievement.WC25", "WC25", 46, -5, Items.STONE_AXE, WC2);
	public static Achievement WC50 = new Achievement("Achievement.WC50", "WC50", 46, -3, Items.IRON_AXE, WC25);
	public static Achievement WC75 = new Achievement("Achievement.WC75", "WC75", 44, -3, Items.DIAMOND_AXE, WC50);
	public static Achievement WC99 = new Achievement("Achievement.WC99", "WC99", 44, -1, Items.DIAMOND_AXE, WC75);
	public static Achievement WC100 = new Achievement("Achievement.WC100", "WC100", 46, -1, Items.DIAMOND_AXE, WC99);
	public static Achievement WC125 = new Achievement("Achievement.WC125", "WC125", 46, 1, Items.GLASS_BOTTLE, WC100);
	public static Achievement WC150 = new Achievement("Achievement.WC150", "WC150", 44, 1, Items.GLASS_BOTTLE, WC125);
	public static Achievement WC175 = new Achievement("Achievement.WC175", "WC175", 44, 3, Items.GLASS_BOTTLE, WC150);
	public static Achievement WC200 = new Achievement("Achievement.WC200", "WC200", 46, 3, Items.GLASS_BOTTLE, WC175);
	public static Achievement WC201 = new Achievement("Achievement.WC201", "WC201", 46, 5, Items.GLASS_BOTTLE, WC200);
	public static Achievement WC220 = new Achievement("Achievement.WC220", "WC220", 44, 5, Items.GLASS_BOTTLE, WC201);
	public static Achievement WC240 = new Achievement("Achievement.WC240", "WC240", 44, 7, Items.GLASS_BOTTLE, WC220);
	public static Achievement WC250 = new Achievement("Achievement.WC250", "WC250", 46, 7, Items.GLASS_BOTTLE, WC240);
	public static Achievement WCMAX = new Achievement("Achievement.WCMAX", "WCMAX", 45, 9, Items.GLASS_BOTTLE, WC250);
	
	//12_FISHING
	public static Achievement FS2 = new Achievement("Achievement.FS2", "FS2", 48, -5, Items.FISHING_ROD, (Achievement) null);
	public static Achievement FS25 = new Achievement("Achievement.FS25", "FS25", 50, -5, Items.FISHING_ROD, FS2);
	public static Achievement FS50 = new Achievement("Achievement.FS50", "FS50", 50, -3, Items.FISHING_ROD, FS25);
	public static Achievement FS75 = new Achievement("Achievement.FS75", "FS75", 48, -3, Items.FISHING_ROD, FS50);
	public static Achievement FS99 = new Achievement("Achievement.FS99", "FS99", 48, -1, Items.FISHING_ROD, FS75);
	public static Achievement FS100 = new Achievement("Achievement.FS100", "FS100", 50, -1, Items.FISHING_ROD, FS99);
	public static Achievement FS125 = new Achievement("Achievement.FS125", "FS125", 50, 1, Items.FISHING_ROD, FS100);
	public static Achievement FS150 = new Achievement("Achievement.FS150", "FS150", 48, 1, Items.GLASS_BOTTLE, FS125);
	public static Achievement FS175 = new Achievement("Achievement.FS175", "FS175", 48, 3, Items.GLASS_BOTTLE, FS150);
	public static Achievement FS200 = new Achievement("Achievement.FS200", "FS200", 50, 3, Items.GLASS_BOTTLE, FS175);
	public static Achievement FS201 = new Achievement("Achievement.FS201", "FS201", 50, 5, Items.GLASS_BOTTLE, FS200);
	public static Achievement FS220 = new Achievement("Achievement.FS220", "FS220", 48, 5, Items.GLASS_BOTTLE, FS201);
	public static Achievement FS240 = new Achievement("Achievement.FS240", "FS240", 48, 7, Items.GLASS_BOTTLE, FS220);
	public static Achievement FS250 = new Achievement("Achievement.FS250", "FS250", 50, 7, Items.GLASS_BOTTLE, FS240);
	public static Achievement FSMAX = new Achievement("Achievement.FSMAX", "FSMAX", 49, 9, Items.GLASS_BOTTLE, FS250);
	
	//13_ARCHEOLOGY
	public static Achievement AR2 = new Achievement("Achievement.AR2", "AR2", 52, -5, Items.BONE, (Achievement) null);
	public static Achievement AR25 = new Achievement("Achievement.AR25", "AR25", 54, -5, Items.BONE, AR2);
	public static Achievement AR50 = new Achievement("Achievement.AR50", "AR50", 54, -3, Items.BONE, AR25);
	public static Achievement AR75 = new Achievement("Achievement.AR75", "AR75", 52, -3, Items.BONE, AR50);
	public static Achievement AR99 = new Achievement("Achievement.AR99", "AR99", 52, -1, Items.BONE, AR75);
	public static Achievement AR100 = new Achievement("Achievement.AR100", "AR100", 54, -1, Items.BONE, AR99);
	public static Achievement AR125 = new Achievement("Achievement.AR125", "AR125", 54, 1, Items.BONE, AR100);
	public static Achievement AR150 = new Achievement("Achievement.AR150", "AR150", 52, 1, Items.GLASS_BOTTLE, AR125);
	public static Achievement AR175 = new Achievement("Achievement.AR175", "AR175", 52, 3, Items.GLASS_BOTTLE, AR150);
	public static Achievement AR200 = new Achievement("Achievement.AR200", "AR200", 54, 3, Items.GLASS_BOTTLE, AR175);
	public static Achievement AR201 = new Achievement("Achievement.AR201", "AR201", 54, 5, Items.GLASS_BOTTLE, AR200);
	public static Achievement AR220 = new Achievement("Achievement.AR220", "AR220", 52, 5, Items.GLASS_BOTTLE, AR201);
	public static Achievement AR240 = new Achievement("Achievement.AR240", "AR240", 52, 7, Items.GLASS_BOTTLE, AR220);
	public static Achievement AR250 = new Achievement("Achievement.AR250", "AR250", 54, 7, Items.GLASS_BOTTLE, AR240);
	public static Achievement ARMAX = new Achievement("Achievement.ARMAX", "ARMAX", 53, 9, Items.GLASS_BOTTLE, AR250);
	
	//14_TAILORY
	public static Achievement TA2 = new Achievement("Achievement.TA2", "TA2", 56, -5, Items.STRING, (Achievement) null);
	public static Achievement TA25 = new Achievement("Achievement.TA25", "TA25", 58, -5, Items.STRING, TA2);
	public static Achievement TA50 = new Achievement("Achievement.TA50", "TA50", 58, -3, MarkItems.Silk20, TA25);
	public static Achievement TA75 = new Achievement("Achievement.TA75", "TA75", 56, -3, MarkItems.Silk40, TA50);
	public static Achievement TA99 = new Achievement("Achievement.TA99", "TA99", 56, -1, MarkItems.Silk60, TA75);
	public static Achievement TA100 = new Achievement("Achievement.TA100", "TA100", 58, -1, MarkItems.Silk80, TA99);
	public static Achievement TA125 = new Achievement("Achievement.TA125", "TA125", 58, 1, MarkItems.Silk80, TA100);
	public static Achievement TA150 = new Achievement("Achievement.TA150", "TA150", 56, 1, Items.GLASS_BOTTLE, TA125);
	public static Achievement TA175 = new Achievement("Achievement.TA175", "TA175", 56, 3, Items.GLASS_BOTTLE, TA150);
	public static Achievement TA200 = new Achievement("Achievement.TA200", "TA200", 58, 3, Items.GLASS_BOTTLE, TA175);
	public static Achievement TA201 = new Achievement("Achievement.TA201", "TA201", 58, 5, Items.GLASS_BOTTLE, TA200);
	public static Achievement TA220 = new Achievement("Achievement.TA220", "TA220", 56, 5, Items.GLASS_BOTTLE, TA201);
	public static Achievement TA240 = new Achievement("Achievement.TA240", "TA240", 56, 7, Items.GLASS_BOTTLE, TA220);
	public static Achievement TA250 = new Achievement("Achievement.TA250", "TA250", 58, 7, Items.GLASS_BOTTLE, TA240);
	public static Achievement TAMAX = new Achievement("Achievement.TAMAX", "TAMAX", 57, 9, Items.GLASS_BOTTLE, TA250);
	
	//15_SMITHING
	public static Achievement SM2 = new Achievement("Achievement.SM2", "SM2", 60, -5, Blocks.ANVIL, (Achievement) null);
	public static Achievement SM25 = new Achievement("Achievement.SM25", "SM25", 62, -5, Blocks.ANVIL, SM2);
	public static Achievement SM50 = new Achievement("Achievement.SM50", "SM50", 62, -3, Items.IRON_INGOT, SM25);
	public static Achievement SM75 = new Achievement("Achievement.SM75", "SM75", 60, -3, Items.DIAMOND, SM50);
	public static Achievement SM99 = new Achievement("Achievement.SM99", "SM99", 60, -1, MarkItems.NetheriteBar, SM75);
	public static Achievement SM100 = new Achievement("Achievement.SM100", "SM100", 62, -1, MarkItems.CrystliumBar, SM99);
	public static Achievement SM125 = new Achievement("Achievement.SM125", "SM125", 62, 1, MarkItems.CrystliumBar, SM100);
	public static Achievement SM150 = new Achievement("Achievement.SM150", "SM150", 60, 1, Items.GLASS_BOTTLE, SM125);
	public static Achievement SM175 = new Achievement("Achievement.SM175", "SM175", 60, 3, Items.GLASS_BOTTLE, SM150);
	public static Achievement SM200 = new Achievement("Achievement.SM200", "SM200", 62, 3, Items.GLASS_BOTTLE, SM175);
	public static Achievement SM201 = new Achievement("Achievement.SM201", "SM201", 62, 5, Items.GLASS_BOTTLE, SM200);
	public static Achievement SM220 = new Achievement("Achievement.SM220", "SM220", 60, 5, Items.GLASS_BOTTLE, SM201);
	public static Achievement SM240 = new Achievement("Achievement.SM240", "SM240", 60, 7, Items.GLASS_BOTTLE, SM220);
	public static Achievement SM250 = new Achievement("Achievement.SM250", "SM250", 62, 7, Items.GLASS_BOTTLE, SM240);
	public static Achievement SMMAX = new Achievement("Achievement.SMMAX", "SMMAX", 61, 9, Items.GLASS_BOTTLE, SM250);
	
	//16_TANNING
	public static Achievement TN2 = new Achievement("Achievement.TN2", "TN2", 64, -5, Items.RABBIT_HIDE, (Achievement) null);
	public static Achievement TN25 = new Achievement("Achievement.TN25", "TN25", 66, -5, Items.LEATHER, TN2);
	public static Achievement TN50 = new Achievement("Achievement.TN50", "TN50", 66, -3, MarkItems.Leather20, TN25);
	public static Achievement TN75 = new Achievement("Achievement.TN75", "TN75", 64, -3, MarkItems.Leather40, TN50);
	public static Achievement TN99 = new Achievement("Achievement.TN99", "TN99", 64, -1, MarkItems.Leather60, TN75);
	public static Achievement TN100 = new Achievement("Achievement.TN100", "TN100", 66, -1, MarkItems.Leather80, TN99);
	public static Achievement TN125 = new Achievement("Achievement.TN125", "TN125", 66, 1, MarkItems.Leather80, TN100);
	public static Achievement TN150 = new Achievement("Achievement.TN150", "TN150", 64, 1, Items.GLASS_BOTTLE, TN125);
	public static Achievement TN175 = new Achievement("Achievement.TN175", "TN175", 64, 3, Items.GLASS_BOTTLE, TN150);
	public static Achievement TN200 = new Achievement("Achievement.TN200", "TN200", 66, 3, Items.GLASS_BOTTLE, TN175);
	public static Achievement TN201 = new Achievement("Achievement.TN201", "TN201", 66, 5, Items.GLASS_BOTTLE, TN200);
	public static Achievement TN220 = new Achievement("Achievement.TN220", "TN220", 64, 5, Items.GLASS_BOTTLE, TN201);
	public static Achievement TN240 = new Achievement("Achievement.TN240", "TN240", 64, 7, Items.GLASS_BOTTLE, TN220);
	public static Achievement TN250 = new Achievement("Achievement.TN250", "TN250", 66, 7, Items.GLASS_BOTTLE, TN240);
	public static Achievement TNMAX = new Achievement("Achievement.TNMAX", "TNMAX", 65, 9, Items.GLASS_BOTTLE, TN250);
	
	//17_JEWELRY
	public static Achievement JE2 = new Achievement("Achievement.JE2", "JE2", 68, -5, MarkItems.GemOpal, (Achievement) null);
	public static Achievement JE25 = new Achievement("Achievement.JE25", "JE25", 70, -5, MarkItems.GemOlivine, JE2);
	public static Achievement JE50 = new Achievement("Achievement.JE50", "JE50", 70, -3, MarkItems.GemTopaz, JE25);
	public static Achievement JE75 = new Achievement("Achievement.JE75", "JE75", 68, -3, MarkItems.GemAmethyst, JE50);
	public static Achievement JE99 = new Achievement("Achievement.JE99", "JE99", 68, -1, MarkItems.GemSiam, JE75);
	public static Achievement JE100 = new Achievement("Achievement.JE100", "JE100", 70, -1, MarkItems.GemAquamarine, JE99);
	public static Achievement JE125 = new Achievement("Achievement.JE125", "JE125", 70, 1, MarkItems.GemAquamarine, JE100);
	public static Achievement JE150 = new Achievement("Achievement.JE150", "JE150", 68, 1, Items.GLASS_BOTTLE, JE125);
	public static Achievement JE175 = new Achievement("Achievement.JE175", "JE175", 68, 3, Items.GLASS_BOTTLE, JE150);
	public static Achievement JE200 = new Achievement("Achievement.JE200", "JE200", 70, 3, Items.GLASS_BOTTLE, JE175);
	public static Achievement JE201 = new Achievement("Achievement.JE201", "JE201", 70, 5, Items.GLASS_BOTTLE, JE200);
	public static Achievement JE220 = new Achievement("Achievement.JE220", "JE220", 68, 5, Items.GLASS_BOTTLE, JE201);
	public static Achievement JE240 = new Achievement("Achievement.JE240", "JE240", 68, 7, Items.GLASS_BOTTLE, JE220);
	public static Achievement JE250 = new Achievement("Achievement.JE250", "JE250", 70, 7, Items.GLASS_BOTTLE, JE240);
	public static Achievement JEMAX = new Achievement("Achievement.JEMAX", "JEMAX", 69, 9, Items.GLASS_BOTTLE, JE250);
	
	//18_FLETCHING
	public static Achievement FL2 = new Achievement("Achievement.FL2", "FL2", 72, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement FL25 = new Achievement("Achievement.FL25", "FL25", 74, -5, Items.GLASS_BOTTLE, FL2);
	public static Achievement FL50 = new Achievement("Achievement.FL50", "FL50", 74, -3, Items.GLASS_BOTTLE, FL25);
	public static Achievement FL75 = new Achievement("Achievement.FL75", "FL75", 72, -3, Items.GLASS_BOTTLE, FL50);
	public static Achievement FL99 = new Achievement("Achievement.FL99", "FL99", 72, -1, Items.GLASS_BOTTLE, FL75);
	public static Achievement FL100 = new Achievement("Achievement.FL100", "FL100", 74, -1, Items.GLASS_BOTTLE, FL99);
	public static Achievement FL125 = new Achievement("Achievement.FL125", "FL125", 74, 1, Items.GLASS_BOTTLE, FL100);
	public static Achievement FL150 = new Achievement("Achievement.FL150", "FL150", 72, 1, Items.GLASS_BOTTLE, FL125);
	public static Achievement FL175 = new Achievement("Achievement.FL175", "FL175", 72, 3, Items.GLASS_BOTTLE, FL150);
	public static Achievement FL200 = new Achievement("Achievement.FL200", "FL200", 74, 3, Items.GLASS_BOTTLE, FL175);
	public static Achievement FL201 = new Achievement("Achievement.FL201", "FL201", 74, 5, Items.GLASS_BOTTLE, FL200);
	public static Achievement FL220 = new Achievement("Achievement.FL220", "FL220", 72, 5, Items.GLASS_BOTTLE, FL201);
	public static Achievement FL240 = new Achievement("Achievement.FL240", "FL240", 72, 7, Items.GLASS_BOTTLE, FL220);
	public static Achievement FL250 = new Achievement("Achievement.FL250", "FL250", 74, 7, Items.GLASS_BOTTLE, FL240);
	public static Achievement FLMAX = new Achievement("Achievement.FLMAX", "FLMAX", 73, 9, Items.GLASS_BOTTLE, FL250);
	
	//19_COOKING
	public static Achievement CO2 = new Achievement("Achievement.CO2", "CO2", 76, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement CO25 = new Achievement("Achievement.CO25", "CO25", 78, -5, Items.GLASS_BOTTLE, CO2);
	public static Achievement CO50 = new Achievement("Achievement.CO50", "CO50", 78, -3, Items.GLASS_BOTTLE, CO25);
	public static Achievement CO75 = new Achievement("Achievement.CO75", "CO75", 76, -3, Items.GLASS_BOTTLE, CO50);
	public static Achievement CO99 = new Achievement("Achievement.CO99", "CO99", 76, -1, Items.GLASS_BOTTLE, CO75);
	public static Achievement CO100 = new Achievement("Achievement.CO100", "CO100", 78, -1, Items.GLASS_BOTTLE, CO99);
	public static Achievement CO125 = new Achievement("Achievement.CO125", "CO125", 78, 1, Items.GLASS_BOTTLE, CO100);
	public static Achievement CO150 = new Achievement("Achievement.CO150", "CO150", 76, 1, Items.GLASS_BOTTLE, CO125);
	public static Achievement CO175 = new Achievement("Achievement.CO175", "CO175", 76, 3, Items.GLASS_BOTTLE, CO150);
	public static Achievement CO200 = new Achievement("Achievement.CO200", "CO200", 78, 3, Items.GLASS_BOTTLE, CO175);
	public static Achievement CO201 = new Achievement("Achievement.CO201", "CO201", 78, 5, Items.GLASS_BOTTLE, CO200);
	public static Achievement CO220 = new Achievement("Achievement.CO220", "CO220", 76, 5, Items.GLASS_BOTTLE, CO201);
	public static Achievement CO240 = new Achievement("Achievement.CO240", "CO240", 76, 7, Items.GLASS_BOTTLE, CO220);
	public static Achievement CO250 = new Achievement("Achievement.CO250", "CO250", 78, 7, Items.GLASS_BOTTLE, CO240);
	public static Achievement COMAX = new Achievement("Achievement.COMAX", "COMAX", 77, 9, Items.GLASS_BOTTLE, CO250);
	
	//20_HERBLORE
	public static Achievement HE2 = new Achievement("Achievement.HE2", "HE2", 80, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement HE25 = new Achievement("Achievement.HE25", "HE25", 82, -5, Items.GLASS_BOTTLE, HE2);
	public static Achievement HE50 = new Achievement("Achievement.HE50", "HE50", 82, -3, Items.GLASS_BOTTLE, HE25);
	public static Achievement HE75 = new Achievement("Achievement.HE75", "HE75", 80, -3, Items.GLASS_BOTTLE, HE50);
	public static Achievement HE99 = new Achievement("Achievement.HE99", "HE99", 80, -1, Items.GLASS_BOTTLE, HE75);
	public static Achievement HE100 = new Achievement("Achievement.HE100", "HE100", 82, -1, Items.GLASS_BOTTLE, HE99);
	public static Achievement HE125 = new Achievement("Achievement.HE125", "HE125", 82, 1, Items.GLASS_BOTTLE, HE100);
	public static Achievement HE150 = new Achievement("Achievement.HE150", "HE150", 80, 1, Items.GLASS_BOTTLE, HE125);
	public static Achievement HE175 = new Achievement("Achievement.HE175", "HE175", 80, 3, Items.GLASS_BOTTLE, HE150);
	public static Achievement HE200 = new Achievement("Achievement.HE200", "HE200", 82, 3, Items.GLASS_BOTTLE, HE175);
	public static Achievement HE201 = new Achievement("Achievement.HE201", "HE201", 82, 5, Items.GLASS_BOTTLE, HE200);
	public static Achievement HE220 = new Achievement("Achievement.HE220", "HE220", 80, 5, Items.GLASS_BOTTLE, HE201);
	public static Achievement HE240 = new Achievement("Achievement.HE240", "HE240", 80, 7, Items.GLASS_BOTTLE, HE220);
	public static Achievement HE250 = new Achievement("Achievement.HE250", "HE250", 82, 7, Items.GLASS_BOTTLE, HE240);
	public static Achievement HEMAX = new Achievement("Achievement.HEMAX", "HEMAX", 81, 9, Items.GLASS_BOTTLE, HE250);
	
	//21_HONOUR
	public static Achievement HO2 = new Achievement("Achievement.HO2", "HO2", 84, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement HO25 = new Achievement("Achievement.HO25", "HO25", 86, -5, Items.GLASS_BOTTLE, HO2);
	public static Achievement HO50 = new Achievement("Achievement.HO50", "HO50", 86, -3, Items.GLASS_BOTTLE, HO25);
	public static Achievement HO75 = new Achievement("Achievement.HO75", "HO75", 84, -3, Items.GLASS_BOTTLE, HO50);
	public static Achievement HO99 = new Achievement("Achievement.HO99", "HO99", 84, -1, Items.GLASS_BOTTLE, HO75);
	public static Achievement HO100 = new Achievement("Achievement.HO100", "HO100", 86, -1, Items.GLASS_BOTTLE, HO99);
	public static Achievement HO125 = new Achievement("Achievement.HO125", "HO125", 86, 1, Items.GLASS_BOTTLE, HO100);
	public static Achievement HO150 = new Achievement("Achievement.HO150", "HO150", 84, 1, Items.GLASS_BOTTLE, HO125);
	public static Achievement HO175 = new Achievement("Achievement.HO175", "HO175", 84, 3, Items.GLASS_BOTTLE, HO150);
	public static Achievement HO200 = new Achievement("Achievement.HO200", "HO200", 86, 3, Items.GLASS_BOTTLE, HO175);
	public static Achievement HO201 = new Achievement("Achievement.HO201", "HO201", 86, 5, Items.GLASS_BOTTLE, HO200);
	public static Achievement HO220 = new Achievement("Achievement.HO220", "HO220", 84, 5, Items.GLASS_BOTTLE, HO201);
	public static Achievement HO240 = new Achievement("Achievement.HO240", "HO240", 84, 7, Items.GLASS_BOTTLE, HO220);
	public static Achievement HO250 = new Achievement("Achievement.HO250", "HO250", 86, 7, Items.GLASS_BOTTLE, HO240);
	public static Achievement HOMAX = new Achievement("Achievement.HOMAX", "HOMAX", 85, 9, Items.GLASS_BOTTLE, HO250);
	
	//22_CONSTRUCTION
	public static Achievement CN2 = new Achievement("Achievement.CN2", "CN2", 88, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement CN25 = new Achievement("Achievement.CN25", "CN25", 90, -5, Items.GLASS_BOTTLE, CN2);
	public static Achievement CN50 = new Achievement("Achievement.CN50", "CN50", 90, -3, Items.GLASS_BOTTLE, CN25);
	public static Achievement CN75 = new Achievement("Achievement.CN75", "CN75", 88, -3, Items.GLASS_BOTTLE, CN50);
	public static Achievement CN99 = new Achievement("Achievement.CN99", "CN99", 88, -1, Items.GLASS_BOTTLE, CN75);
	public static Achievement CN100 = new Achievement("Achievement.CN100", "CN100", 90, -1, Items.GLASS_BOTTLE, CN99);
	public static Achievement CN125 = new Achievement("Achievement.CN125", "CN125", 90, 1, Items.GLASS_BOTTLE, CN100);
	public static Achievement CN150 = new Achievement("Achievement.CN150", "CN150", 88, 1, Items.GLASS_BOTTLE, CN125);
	public static Achievement CN175 = new Achievement("Achievement.CN175", "CN175", 88, 3, Items.GLASS_BOTTLE, CN150);
	public static Achievement CN200 = new Achievement("Achievement.CN200", "CN200", 90, 3, Items.GLASS_BOTTLE, CN175);
	public static Achievement CN201 = new Achievement("Achievement.CN201", "CN201", 90, 5, Items.GLASS_BOTTLE, CN200);
	public static Achievement CN220 = new Achievement("Achievement.CN220", "CN220", 88, 5, Items.GLASS_BOTTLE, CN201);
	public static Achievement CN240 = new Achievement("Achievement.CN240", "CN240", 88, 7, Items.GLASS_BOTTLE, CN220);
	public static Achievement CN250 = new Achievement("Achievement.CN250", "CN250", 90, 7, Items.GLASS_BOTTLE, CN240);
	public static Achievement CNMAX = new Achievement("Achievement.CNMAX", "CNMAX", 89, 9, Items.GLASS_BOTTLE, CN250);
	
	//23_AGILITY
	public static Achievement AG2 = new Achievement("Achievement.AG2", "AG2", 92, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement AG25 = new Achievement("Achievement.AG25", "AG25", 94, -5, Items.GLASS_BOTTLE, AG2);
	public static Achievement AG50 = new Achievement("Achievement.AG50", "AG50", 94, -3, Items.GLASS_BOTTLE, AG25);
	public static Achievement AG75 = new Achievement("Achievement.AG75", "AG75", 92, -3, Items.GLASS_BOTTLE, AG50);
	public static Achievement AG99 = new Achievement("Achievement.AG99", "AG99", 92, -1, Items.GLASS_BOTTLE, AG75);
	public static Achievement AG100 = new Achievement("Achievement.AG100", "AG100", 94, -1, Items.GLASS_BOTTLE, AG99);
	public static Achievement AG125 = new Achievement("Achievement.AG125", "AG125", 94, 1, Items.GLASS_BOTTLE, AG100);
	public static Achievement AG150 = new Achievement("Achievement.AG150", "AG150", 92, 1, Items.GLASS_BOTTLE, AG125);
	public static Achievement AG175 = new Achievement("Achievement.AG175", "AG175", 92, 3, Items.GLASS_BOTTLE, AG150);
	public static Achievement AG200 = new Achievement("Achievement.AG200", "AG200", 94, 3, Items.GLASS_BOTTLE, AG175);
	public static Achievement AG201 = new Achievement("Achievement.AG201", "AG201", 94, 5, Items.GLASS_BOTTLE, AG200);
	public static Achievement AG220 = new Achievement("Achievement.AG220", "AG220", 92, 5, Items.GLASS_BOTTLE, AG201);
	public static Achievement AG240 = new Achievement("Achievement.AG240", "AG240", 92, 7, Items.GLASS_BOTTLE, AG220);
	public static Achievement AG250 = new Achievement("Achievement.AG250", "AG250", 94, 7, Items.GLASS_BOTTLE, AG240);
	public static Achievement AGMAX = new Achievement("Achievement.AGMAX", "AGMAX", 93, 9, Items.GLASS_BOTTLE, AG250);
	
	//24_DUNGEONEERING
	public static Achievement DN2 = new Achievement("Achievement.DN2", "DN2", 96, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement DN25 = new Achievement("Achievement.DN25", "DN25", 98, -5, Items.GLASS_BOTTLE, DN2);
	public static Achievement DN50 = new Achievement("Achievement.DN50", "DN50", 98, -3, Items.GLASS_BOTTLE, DN25);
	public static Achievement DN75 = new Achievement("Achievement.DN75", "DN75", 96, -3, Items.GLASS_BOTTLE, DN50);
	public static Achievement DN99 = new Achievement("Achievement.DN99", "DN99", 96, -1, Items.GLASS_BOTTLE, DN75);
	public static Achievement DN100 = new Achievement("Achievement.DN100", "DN100", 98, -1, Items.GLASS_BOTTLE, DN99);
	public static Achievement DN125 = new Achievement("Achievement.DN125", "DN125", 98, 1, Items.GLASS_BOTTLE, DN100);
	public static Achievement DN150 = new Achievement("Achievement.DN150", "DN150", 96, 1, Items.GLASS_BOTTLE, DN125);
	public static Achievement DN175 = new Achievement("Achievement.DN175", "DN175", 96, 3, Items.GLASS_BOTTLE, DN150);
	public static Achievement DN200 = new Achievement("Achievement.DN200", "DN200", 98, 3, Items.GLASS_BOTTLE, DN175);
	public static Achievement DN201 = new Achievement("Achievement.DN201", "DN201", 98, 5, Items.GLASS_BOTTLE, DN200);
	public static Achievement DN220 = new Achievement("Achievement.DN220", "DN220", 96, 5, Items.GLASS_BOTTLE, DN201);
	public static Achievement DN240 = new Achievement("Achievement.DN240", "DN240", 96, 7, Items.GLASS_BOTTLE, DN220);
	public static Achievement DN250 = new Achievement("Achievement.DN250", "DN250", 98, 7, Items.GLASS_BOTTLE, DN240);
	public static Achievement DNMAX = new Achievement("Achievement.DNMAX", "DNMAX", 97, 9, Items.GLASS_BOTTLE, DN250);
	
	//25_PET CARING
	public static Achievement PC2 = new Achievement("Achievement.PC2", "PC2", 100, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement PC25 = new Achievement("Achievement.PC25", "PC25", 102, -5, Items.GLASS_BOTTLE, PC2);
	public static Achievement PC50 = new Achievement("Achievement.PC50", "PC50", 102, -3, Items.GLASS_BOTTLE, PC25);
	public static Achievement PC75 = new Achievement("Achievement.PC75", "PC75", 100, -3, Items.GLASS_BOTTLE, PC50);
	public static Achievement PC99 = new Achievement("Achievement.PC99", "PC99", 100, -1, Items.GLASS_BOTTLE, PC75);
	public static Achievement PC100 = new Achievement("Achievement.PC100", "PC100", 102, -1, Items.GLASS_BOTTLE, PC99);
	public static Achievement PC125 = new Achievement("Achievement.PC125", "PC125", 102, 1, Items.GLASS_BOTTLE, PC100);
	public static Achievement PC150 = new Achievement("Achievement.PC150", "PC150", 100, 1, Items.GLASS_BOTTLE, PC125);
	public static Achievement PC175 = new Achievement("Achievement.PC175", "PC175", 100, 3, Items.GLASS_BOTTLE, PC150);
	public static Achievement PC200 = new Achievement("Achievement.PC200", "PC200", 102, 3, Items.GLASS_BOTTLE, PC175);
	public static Achievement PC201 = new Achievement("Achievement.PC201", "PC201", 102, 5, Items.GLASS_BOTTLE, PC200);
	public static Achievement PC220 = new Achievement("Achievement.PC220", "PC220", 100, 5, Items.GLASS_BOTTLE, PC201);
	public static Achievement PC240 = new Achievement("Achievement.PC240", "PC240", 100, 7, Items.GLASS_BOTTLE, PC220);
	public static Achievement PC250 = new Achievement("Achievement.PC250", "PC250", 102, 7, Items.GLASS_BOTTLE, PC240);
	public static Achievement PCMAX = new Achievement("Achievement.PCMAX", "PCMAX", 101, 9, Items.GLASS_BOTTLE, PC250);
	
	//26_LIFESTOCK
	public static Achievement LS2 = new Achievement("Achievement.LS2", "LS2", 104, -5, Items.WHEAT, (Achievement) null);
	public static Achievement LS25 = new Achievement("Achievement.LS25", "LS25", 106, -5, Items.WHEAT, LS2);
	public static Achievement LS50 = new Achievement("Achievement.LS50", "LS50", 106, -3, Items.WHEAT, LS25);
	public static Achievement LS75 = new Achievement("Achievement.LS75", "LS75", 104, -3, Items.WHEAT, LS50);
	public static Achievement LS99 = new Achievement("Achievement.LS99", "LS99", 104, -1, Items.WHEAT, LS75);
	public static Achievement LS100 = new Achievement("Achievement.LS100", "LS100", 106, -1, Items.WHEAT, LS99);
	public static Achievement LS125 = new Achievement("Achievement.LS125", "LS125", 106, 1, Items.WHEAT, LS100);
	public static Achievement LS150 = new Achievement("Achievement.LS150", "LS150", 104, 1, Items.WHEAT, LS125);
	public static Achievement LS175 = new Achievement("Achievement.LS175", "LS175", 104, 3, Items.WHEAT, LS150);
	public static Achievement LS200 = new Achievement("Achievement.LS200", "LS200", 106, 3, Items.WHEAT, LS175);
	public static Achievement LS201 = new Achievement("Achievement.LS201", "LS201", 106, 5, Items.GLASS_BOTTLE, LS200);
	public static Achievement LS220 = new Achievement("Achievement.LS220", "LS220", 104, 5, Items.GLASS_BOTTLE, LS201);
	public static Achievement LS240 = new Achievement("Achievement.LS240", "LS240", 104, 7, Items.GLASS_BOTTLE, LS220);
	public static Achievement LS250 = new Achievement("Achievement.LS250", "LS250", 106, 7, Items.GLASS_BOTTLE, LS240);
	public static Achievement LSMAX = new Achievement("Achievement.LSMAX", "LSMAX", 105, 9, Items.GLASS_BOTTLE, LS250);
	
	//27_KNOWLEDGE
	public static Achievement KW2 = new Achievement("Achievement.KW2", "KW2", 108, -5, Items.BOOK, (Achievement) null);
	public static Achievement KW25 = new Achievement("Achievement.KW25", "KW25", 110, -5, MarkItems.BookW1, KW2);
	public static Achievement KW50 = new Achievement("Achievement.KW50", "KW50", 110, -3, MarkItems.Book20, KW25);
	public static Achievement KW75 = new Achievement("Achievement.KW75", "KW75", 108, -3, MarkItems.Book40, KW50);
	public static Achievement KW99 = new Achievement("Achievement.KW99", "KW99", 108, -1, MarkItems.Book60, KW75);
	public static Achievement KW100 = new Achievement("Achievement.KW100", "KW100", 110, -1, MarkItems.Book80, KW99);
	public static Achievement KW125 = new Achievement("Achievement.KW125", "KW125", 110, 1, MarkItems.Book80, KW100);
	public static Achievement KW150 = new Achievement("Achievement.KW150", "KW150", 108, 1, Items.GLASS_BOTTLE, KW125);
	public static Achievement KW175 = new Achievement("Achievement.KW175", "KW175", 108, 3, Items.GLASS_BOTTLE, KW150);
	public static Achievement KW200 = new Achievement("Achievement.KW200", "KW200", 110, 3, Items.GLASS_BOTTLE, KW175);
	public static Achievement KW201 = new Achievement("Achievement.KW201", "KW201", 110, 5, Items.GLASS_BOTTLE, KW200);
	public static Achievement KW220 = new Achievement("Achievement.KW220", "KW220", 108, 5, Items.GLASS_BOTTLE, KW201);
	public static Achievement KW240 = new Achievement("Achievement.KW240", "KW240", 108, 7, Items.GLASS_BOTTLE, KW220);
	public static Achievement KW250 = new Achievement("Achievement.KW250", "KW250", 110, 7, Items.GLASS_BOTTLE, KW240);
	public static Achievement KWMAX = new Achievement("Achievement.KWMAX", "KWMAX", 109, 9, Items.GLASS_BOTTLE, KW250);
	
	//28_TECHNOLOGY
	public static Achievement TC2 = new Achievement("Achievement.TC2", "TC2", 112, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement TC25 = new Achievement("Achievement.TC25", "TC25", 114, -5, Items.GLASS_BOTTLE, TC2);
	public static Achievement TC50 = new Achievement("Achievement.TC50", "TC50", 114, -3, Items.GLASS_BOTTLE, TC25);
	public static Achievement TC75 = new Achievement("Achievement.TC75", "TC75", 112, -3, Items.GLASS_BOTTLE, TC50);
	public static Achievement TC99 = new Achievement("Achievement.TC99", "TC99", 112, -1, Items.GLASS_BOTTLE, TC75);
	public static Achievement TC100 = new Achievement("Achievement.TC100", "TC100", 114, -1, Items.GLASS_BOTTLE, TC99);
	public static Achievement TC125 = new Achievement("Achievement.TC125", "TC125", 114, 1, Items.GLASS_BOTTLE, TC100);
	public static Achievement TC150 = new Achievement("Achievement.TC150", "TC150", 112, 1, Items.GLASS_BOTTLE, TC125);
	public static Achievement TC175 = new Achievement("Achievement.TC175", "TC175", 112, 3, Items.GLASS_BOTTLE, TC150);
	public static Achievement TC200 = new Achievement("Achievement.TC200", "TC200", 114, 3, Items.GLASS_BOTTLE, TC175);
	public static Achievement TC201 = new Achievement("Achievement.TC201", "TC201", 114, 5, Items.GLASS_BOTTLE, TC200);
	public static Achievement TC220 = new Achievement("Achievement.TC220", "TC220", 112, 5, Items.GLASS_BOTTLE, TC201);
	public static Achievement TC240 = new Achievement("Achievement.TC240", "TC240", 112, 7, Items.GLASS_BOTTLE, TC220);
	public static Achievement TC250 = new Achievement("Achievement.TC250", "TC250", 114, 7, Items.GLASS_BOTTLE, TC240);
	public static Achievement TCMAX = new Achievement("Achievement.TCMAX", "TCMAX", 113, 9, Items.GLASS_BOTTLE, TC250);
	
	//29_ENERGIZING
	public static Achievement EG2 = new Achievement("Achievement.EG2", "EG2", 116, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement EG25 = new Achievement("Achievement.EG25", "EG25", 118, -5, Items.GLASS_BOTTLE, EG2);
	public static Achievement EG50 = new Achievement("Achievement.EG50", "EG50", 118, -3, Items.GLASS_BOTTLE, EG25);
	public static Achievement EG75 = new Achievement("Achievement.EG75", "EG75", 116, -3, Items.GLASS_BOTTLE, EG50);
	public static Achievement EG99 = new Achievement("Achievement.EG99", "EG99", 116, -1, Items.GLASS_BOTTLE, EG75);
	public static Achievement EG100 = new Achievement("Achievement.EG100", "EG100",118, -1, Items.GLASS_BOTTLE, EG99);
	public static Achievement EG125 = new Achievement("Achievement.EG125", "EG125", 118, 1, Items.GLASS_BOTTLE, EG100);
	public static Achievement EG150 = new Achievement("Achievement.EG150", "EG150", 116, 1, Items.GLASS_BOTTLE, EG125);
	public static Achievement EG175 = new Achievement("Achievement.EG175", "EG175", 116, 3, Items.GLASS_BOTTLE, EG150);
	public static Achievement EG200 = new Achievement("Achievement.EG200", "EG200", 118, 3, Items.GLASS_BOTTLE, EG175);
	public static Achievement EG201 = new Achievement("Achievement.EG201", "EG201", 118, 5, Items.GLASS_BOTTLE, EG200);
	public static Achievement EG220 = new Achievement("Achievement.EG220", "EG220", 116, 5, Items.GLASS_BOTTLE, EG201);
	public static Achievement EG240 = new Achievement("Achievement.EG240", "EG240", 116, 7, Items.GLASS_BOTTLE, EG220);
	public static Achievement EG250 = new Achievement("Achievement.EG250", "EG250", 118, 7, Items.GLASS_BOTTLE, EG240);
	public static Achievement EGMAX = new Achievement("Achievement.EGMAX", "EGMAX", 117, 9, Items.GLASS_BOTTLE, EG250);
	
	//30_CHEMISTRY
	public static Achievement CH2 = new Achievement("Achievement.CH2", "CH2", 120, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement CH25 = new Achievement("Achievement.CH25", "CH25", 122, -5, Items.GLASS_BOTTLE, CH2);
	public static Achievement CH50 = new Achievement("Achievement.CH50", "CH50", 122, -3, Items.GLASS_BOTTLE, CH25);
	public static Achievement CH75 = new Achievement("Achievement.CH75", "CH75", 120, -3, Items.GLASS_BOTTLE, CH50);
	public static Achievement CH99 = new Achievement("Achievement.CH99", "CH99", 120, -1, Items.GLASS_BOTTLE, CH75);
	public static Achievement CH100 = new Achievement("Achievement.CH100", "CH100", 122, -1, Items.GLASS_BOTTLE, CH99);
	public static Achievement CH125 = new Achievement("Achievement.CH125", "CH125", 122, 1, Items.GLASS_BOTTLE, CH100);
	public static Achievement CH150 = new Achievement("Achievement.CH150", "CH150", 120, 1, Items.GLASS_BOTTLE, CH125);
	public static Achievement CH175 = new Achievement("Achievement.CH175", "CH175", 120, 3, Items.GLASS_BOTTLE, CH150);
	public static Achievement CH200 = new Achievement("Achievement.CH200", "CH200", 122, 3, Items.GLASS_BOTTLE, CH175);
	public static Achievement CH201 = new Achievement("Achievement.CH201", "CH201", 122, 5, Items.GLASS_BOTTLE, CH200);
	public static Achievement CH220 = new Achievement("Achievement.CH220", "CH220", 120, 5, Items.GLASS_BOTTLE, CH201);
	public static Achievement CH240 = new Achievement("Achievement.CH240", "CH240", 120, 7, Items.GLASS_BOTTLE, CH220);
	public static Achievement CH250 = new Achievement("Achievement.CH250", "CH250", 122, 7, Items.GLASS_BOTTLE, CH240);
	public static Achievement CHMAX = new Achievement("Achievement.CHMAX", "CHMAX", 121, 9, Items.GLASS_BOTTLE, CH250);
	
	//31_SPECILITY
	public static Achievement SP2 = new Achievement("Achievement.SP2", "SP2", 124, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement SP25 = new Achievement("Achievement.SP25", "SP25", 126, -5, Items.GLASS_BOTTLE, SP2);
	public static Achievement SP50 = new Achievement("Achievement.SP50", "SP50", 126, -3, Items.GLASS_BOTTLE, SP25);
	public static Achievement SP75 = new Achievement("Achievement.SP75", "SP75", 124, -3, Items.GLASS_BOTTLE, SP50);
	public static Achievement SP99 = new Achievement("Achievement.SP99", "SP99", 124, -1, Items.GLASS_BOTTLE, SP75);
	public static Achievement SP100 = new Achievement("Achievement.SP100", "SP100", 126, -1, Items.GLASS_BOTTLE, SP99);
	public static Achievement SP125 = new Achievement("Achievement.SP125", "SP125", 126, 1, Items.GLASS_BOTTLE, SP100);
	public static Achievement SP150 = new Achievement("Achievement.SP150", "SP150", 124, 1, Items.GLASS_BOTTLE, SP125);
	public static Achievement SP175 = new Achievement("Achievement.SP175", "SP175", 124, 3, Items.GLASS_BOTTLE, SP150);
	public static Achievement SP200 = new Achievement("Achievement.SP200", "SP200", 126, 3, Items.GLASS_BOTTLE, SP175);
	public static Achievement SP201 = new Achievement("Achievement.SP201", "SP201", 126, 5, Items.GLASS_BOTTLE, SP200);
	public static Achievement SP220 = new Achievement("Achievement.SP220", "SP220", 124, 5, Items.GLASS_BOTTLE, SP201);
	public static Achievement SP240 = new Achievement("Achievement.SP240", "SP240", 124, 7, Items.GLASS_BOTTLE, SP220);
	public static Achievement SP250 = new Achievement("Achievement.SP250", "SP250", 126, 7, Items.GLASS_BOTTLE, SP240);
	public static Achievement SPMAX = new Achievement("Achievement.SPMAX", "SPMAX", 125, 9, Items.GLASS_BOTTLE, SP250);
	
	//32_MUTATION
	public static Achievement MU2 = new Achievement("Achievement.MU2", "MU2", 128, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement MU25 = new Achievement("Achievement.MU25", "MU25", 130, -5, Items.GLASS_BOTTLE, MU2);
	public static Achievement MU50 = new Achievement("Achievement.MU50", "MU50", 130, -3, Items.GLASS_BOTTLE, MU25);
	public static Achievement MU75 = new Achievement("Achievement.MU75", "MU75", 128, -3, Items.GLASS_BOTTLE, MU50);
	public static Achievement MU99 = new Achievement("Achievement.MU99", "MU99", 128, -1, Items.GLASS_BOTTLE, MU75);
	public static Achievement MU100 = new Achievement("Achievement.MU100", "MU100", 130, -1, Items.GLASS_BOTTLE, MU99);
	public static Achievement MU125 = new Achievement("Achievement.MU125", "MU125", 130, 1, Items.GLASS_BOTTLE, MU100);
	public static Achievement MU150 = new Achievement("Achievement.MU150", "MU150", 128, 1, Items.GLASS_BOTTLE, MU125);
	public static Achievement MU175 = new Achievement("Achievement.MU175", "MU175", 128, 3, Items.GLASS_BOTTLE, MU150);
	public static Achievement MU200 = new Achievement("Achievement.MU200", "MU200", 130, 3, Items.GLASS_BOTTLE, MU175);
	public static Achievement MU201 = new Achievement("Achievement.MU201", "MU201", 130, 5, Items.GLASS_BOTTLE, MU200);
	public static Achievement MU220 = new Achievement("Achievement.MU220", "MU220", 128, 5, Items.GLASS_BOTTLE, MU201);
	public static Achievement MU240 = new Achievement("Achievement.MU240", "MU240", 128, 7, Items.GLASS_BOTTLE, MU220);
	public static Achievement MU250 = new Achievement("Achievement.MU250", "MU250", 130, 7, Items.GLASS_BOTTLE, MU240);
	public static Achievement MUMAX = new Achievement("Achievement.MUMAX", "MUMAX", 129, 9, Items.GLASS_BOTTLE, MU250);
	
	//33_FISSIONING
	public static Achievement FI2 = new Achievement("Achievement.FI2", "FI2", 132, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement FI25 = new Achievement("Achievement.FI25", "FI25", 134, -5, Items.GLASS_BOTTLE, FI2);
	public static Achievement FI50 = new Achievement("Achievement.FI50", "FI50", 134, -3, Items.GLASS_BOTTLE, FI25);
	public static Achievement FI75 = new Achievement("Achievement.FI75", "FI75", 132, -3, Items.GLASS_BOTTLE, FI50);
	public static Achievement FI99 = new Achievement("Achievement.FI99", "FI99", 132, -1, Items.GLASS_BOTTLE, FI75);
	public static Achievement FI100 = new Achievement("Achievement.FI100", "FI100", 134, -1, Items.GLASS_BOTTLE, FI99);
	public static Achievement FI125 = new Achievement("Achievement.FI125", "FI125", 134, 1, Items.GLASS_BOTTLE, FI100);
	public static Achievement FI150 = new Achievement("Achievement.FI150", "FI150", 132, 1, Items.GLASS_BOTTLE, FI125);
	public static Achievement FI175 = new Achievement("Achievement.FI175", "FI175", 132, 3, Items.GLASS_BOTTLE, FI150);
	public static Achievement FI200 = new Achievement("Achievement.FI200", "FI200", 134, 3, Items.GLASS_BOTTLE, FI175);
	public static Achievement FI201 = new Achievement("Achievement.FI201", "FI201", 134, 5, Items.GLASS_BOTTLE, FI200);
	public static Achievement FI220 = new Achievement("Achievement.FI220", "FI220", 132, 5, Items.GLASS_BOTTLE, FI201);
	public static Achievement FI240 = new Achievement("Achievement.FI240", "FI240", 132, 7, Items.GLASS_BOTTLE, FI220);
	public static Achievement FI250 = new Achievement("Achievement.FI250", "FI250", 134, 7, Items.GLASS_BOTTLE, FI240);
	public static Achievement FIMAX = new Achievement("Achievement.FIMAX", "FIMAX", 133, 9, Items.GLASS_BOTTLE, FI250);
	
	//34_FUSSIONING
	public static Achievement FU2 = new Achievement("Achievement.FU2", "FU2", 136, -5, Items.GLASS_BOTTLE, (Achievement) null);
	public static Achievement FU25 = new Achievement("Achievement.FU25", "FU25", 138, -5, Items.GLASS_BOTTLE, FU2);
	public static Achievement FU50 = new Achievement("Achievement.FU50", "FU50", 138, -3, Items.GLASS_BOTTLE, FU25);
	public static Achievement FU75 = new Achievement("Achievement.FU75", "FU75", 136, -3, Items.GLASS_BOTTLE, FU50);
	public static Achievement FU99 = new Achievement("Achievement.FU99", "FU99", 136, -1, Items.GLASS_BOTTLE, FU75);
	public static Achievement FU100 = new Achievement("Achievement.FU100", "FU100", 138, -1, Items.GLASS_BOTTLE, FU99);
	public static Achievement FU125 = new Achievement("Achievement.FU125", "FU125", 138, 1, Items.GLASS_BOTTLE, FU100);
	public static Achievement FU150 = new Achievement("Achievement.FU150", "FU150", 136, 1, Items.GLASS_BOTTLE, FU125);
	public static Achievement FU175 = new Achievement("Achievement.FU175", "FU175", 136, 3, Items.GLASS_BOTTLE, FU150);
	public static Achievement FU200 = new Achievement("Achievement.FU200", "FU200", 138, 3, Items.GLASS_BOTTLE, FU175);
	public static Achievement FU201 = new Achievement("Achievement.FU201", "FU201", 138, 5, Items.GLASS_BOTTLE, FU200);
	public static Achievement FU220 = new Achievement("Achievement.FU220", "FU220", 136, 5, Items.GLASS_BOTTLE, FU201);
	public static Achievement FU240 = new Achievement("Achievement.FU240", "FU240", 136, 7, Items.GLASS_BOTTLE, FU220);
	public static Achievement FU250 = new Achievement("Achievement.FU250", "FU250", 138, 7, Items.GLASS_BOTTLE, FU240);
	public static Achievement FUMAX = new Achievement("Achievement.FUMAX", "FUMAX", 137, 9, Items.GLASS_BOTTLE, FU250);
	
	
	public static void Init(){
		
		
		
		
		
		Achievement[] achievementArray = new Achievement [550];
		achievementArray[0] = Total200;
		achievementArray[1] = Total500;
		achievementArray[2] = Total1000;
		achievementArray[3] = Total1500;
		achievementArray[4] = Total2000;
		achievementArray[5] = Total2500;
		achievementArray[6] = Total3000;
		achievementArray[7] = Total3500;
		achievementArray[8] = Total4000;
		achievementArray[9] = Total4500;
		achievementArray[10] = Total5000;
		achievementArray[11] = Total5500;
		achievementArray[12] = Total6000;
		achievementArray[13] = Total6500;
		achievementArray[14] = Total7000;
		achievementArray[15] = Total7500;
		achievementArray[16] = Total8000;
		achievementArray[17] = Total8200;
		achievementArray[18] = Total8400;
		achievementArray[19] = Total8500;
		achievementArray[20] = Total8600;
		achievementArray[21] = Total8700;
		achievementArray[22] = Total8800;
		achievementArray[23] = Total8900;
		achievementArray[24] = GrandMaster;
		
		achievementArray[25] = HP2;
		achievementArray[26] = HP25;
		achievementArray[27] = HP50;
		achievementArray[28] = HP75;
		achievementArray[29] = HP99;
		achievementArray[30] = HP100;
		achievementArray[31] = HP125;
		achievementArray[32] = HP150;
		achievementArray[33] = HP175;
		achievementArray[34] = HP200;
		achievementArray[35] = HP201;
		achievementArray[36] = HP220;
		achievementArray[37] = HP240;
		achievementArray[38] = HP250;
		achievementArray[39] = HPMAX;

		achievementArray[40] = ML2;
		achievementArray[41] = ML25;
		achievementArray[42] = ML50;
		achievementArray[43] = ML75;
		achievementArray[44] = ML99;
		achievementArray[45] = ML100;
		achievementArray[46] = ML125;
		achievementArray[47] = ML150;
		achievementArray[48] = ML175;
		achievementArray[49] = ML200;
		achievementArray[50] = ML201;
		achievementArray[51] = ML220;
		achievementArray[52] = ML240;
		achievementArray[53] = ML250;
		achievementArray[54] = MLMAX;

		achievementArray[55] = RN2;
		achievementArray[56] = RN25;
		achievementArray[57] = RN50;
		achievementArray[58] = RN75;
		achievementArray[59] = RN99;
		achievementArray[60] = RN100;
		achievementArray[61] = RN125;
		achievementArray[62] = RN150;
		achievementArray[63] = RN175;
		achievementArray[64] = RN200;
		achievementArray[65] = RN201;
		achievementArray[66] = RN220;
		achievementArray[67] = RN240;
		achievementArray[68] = RN250;
		achievementArray[69] = RNMAX;

		achievementArray[70] = MG2;
		achievementArray[71] = MG25;
		achievementArray[72] = MG50;
		achievementArray[73] = MG75;
		achievementArray[74] = MG99;
		achievementArray[75] = MG100;
		achievementArray[76] = MG125;
		achievementArray[77] = MG150;
		achievementArray[78] = MG175;
		achievementArray[79] = MG200;
		achievementArray[80] = MG201;
		achievementArray[81] = MG220;
		achievementArray[82] = MG240;
		achievementArray[83] = MG250;
		achievementArray[84] = MGMAX;

		achievementArray[85] = DF2;
		achievementArray[86] = DF25;
		achievementArray[87] = DF50;
		achievementArray[88] = DF75;
		achievementArray[89] = DF99;
		achievementArray[90] = DF100;
		achievementArray[91] = DF125;
		achievementArray[92] = DF150;
		achievementArray[93] = DF175;
		achievementArray[94] = DF200;
		achievementArray[95] = DF201;
		achievementArray[96] = DF220;
		achievementArray[97] = DF240;
		achievementArray[98] = DF250;
		achievementArray[99] = DFMAX;

		achievementArray[100] = EN2;
		achievementArray[101] = EN25;
		achievementArray[102] = EN50;
		achievementArray[103] = EN75;
		achievementArray[104] = EN99;
		achievementArray[105] = EN100;
		achievementArray[106] = EN125;
		achievementArray[107] = EN150;
		achievementArray[108] = EN175;
		achievementArray[109] = EN200;
		achievementArray[110] = EN201;
		achievementArray[111] = EN220;
		achievementArray[112] = EN240;
		achievementArray[113] = EN250;
		achievementArray[114] = ENMAX;

		achievementArray[115] = SL2;
		achievementArray[116] = SL25;
		achievementArray[117] = SL50;
		achievementArray[118] = SL75;
		achievementArray[119] = SL99;
		achievementArray[120] = SL100;
		achievementArray[121] = SL125;
		achievementArray[122] = SL150;
		achievementArray[123] = SL175;
		achievementArray[124] = SL200;
		achievementArray[125] = SL201;
		achievementArray[126] = SL220;
		achievementArray[127] = SL240;
		achievementArray[128] = SL250;
		achievementArray[129] = SLMAX;

		achievementArray[130] = FA2;
		achievementArray[131] = FA25;
		achievementArray[132] = FA50;
		achievementArray[133] = FA75;
		achievementArray[134] = FA99;
		achievementArray[135] = FA100;
		achievementArray[136] = FA125;
		achievementArray[137] = FA150;
		achievementArray[138] = FA175;
		achievementArray[139] = FA200;
		achievementArray[140] = FA201;
		achievementArray[141] = FA220;
		achievementArray[142] = FA240;
		achievementArray[143] = FA250;
		achievementArray[144] = FAMAX;

		achievementArray[145] = MI2;
		achievementArray[146] = MI25;
		achievementArray[147] = MI50;
		achievementArray[148] = MI75;
		achievementArray[149] = MI99;
		achievementArray[150] = MI100;
		achievementArray[151] = MI125;
		achievementArray[152] = MI150;
		achievementArray[153] = MI175;
		achievementArray[154] = MI200;
		achievementArray[155] = MI201;
		achievementArray[156] = MI220;
		achievementArray[157] = MI240;
		achievementArray[158] = MI250;
		achievementArray[159] = MIMAX;

		achievementArray[160] = HU2;
		achievementArray[161] = HU25;
		achievementArray[162] = HU50;
		achievementArray[163] = HU75;
		achievementArray[164] = HU99;
		achievementArray[165] = HU100;
		achievementArray[166] = HU125;
		achievementArray[167] = HU150;
		achievementArray[168] = HU175;
		achievementArray[169] = HU200;
		achievementArray[170] = HU201;
		achievementArray[171] = HU220;
		achievementArray[172] = HU240;
		achievementArray[173] = HU250;
		achievementArray[174] = HUMAX;

		achievementArray[175] = EX2;
		achievementArray[176] = EX25;
		achievementArray[177] = EX50;
		achievementArray[178] = EX75;
		achievementArray[179] = EX99;
		achievementArray[180] = EX100;
		achievementArray[181] = EX125;
		achievementArray[182] = EX150;
		achievementArray[183] = EX175;
		achievementArray[184] = EX200;
		achievementArray[185] = EX201;
		achievementArray[186] = EX220;
		achievementArray[187] = EX240;
		achievementArray[188] = EX250;
		achievementArray[189] = EXMAX;

		achievementArray[190] = WC2;
		achievementArray[191] = WC25;
		achievementArray[192] = WC50;
		achievementArray[193] = WC75;
		achievementArray[194] = WC99;
		achievementArray[195] = WC100;
		achievementArray[196] = WC125;
		achievementArray[197] = WC150;
		achievementArray[198] = WC175;
		achievementArray[199] = WC200;
		achievementArray[200] = WC201;
		achievementArray[201] = WC220;
		achievementArray[202] = WC240;
		achievementArray[203] = WC250;
		achievementArray[204] = WCMAX;

		achievementArray[205] = FS2;
		achievementArray[206] = FS25;
		achievementArray[207] = FS50;
		achievementArray[208] = FS75;
		achievementArray[209] = FS99;
		achievementArray[210] = FS100;
		achievementArray[211] = FS125;
		achievementArray[212] = FS150;
		achievementArray[213] = FS175;
		achievementArray[214] = FS200;
		achievementArray[215] = FS201;
		achievementArray[216] = FS220;
		achievementArray[217] = FS240;
		achievementArray[218] = FS250;
		achievementArray[219] = FSMAX;

		achievementArray[220] = AR2;
		achievementArray[221] = AR25;
		achievementArray[222] = AR50;
		achievementArray[223] = AR75;
		achievementArray[224] = AR99;
		achievementArray[225] = AR100;
		achievementArray[226] = AR125;
		achievementArray[227] = AR150;
		achievementArray[228] = AR175;
		achievementArray[229] = AR200;
		achievementArray[230] = AR201;
		achievementArray[231] = AR220;
		achievementArray[232] = AR240;
		achievementArray[233] = AR250;
		achievementArray[234] = ARMAX;

		achievementArray[235] = TA2;
		achievementArray[236] = TA25;
		achievementArray[237] = TA50;
		achievementArray[238] = TA75;
		achievementArray[239] = TA99;
		achievementArray[240] = TA100;
		achievementArray[241] = TA125;
		achievementArray[242] = TA150;
		achievementArray[243] = TA175;
		achievementArray[244] = TA200;
		achievementArray[245] = TA201;
		achievementArray[246] = TA220;
		achievementArray[247] = TA240;
		achievementArray[248] = TA250;
		achievementArray[249] = TAMAX;

		achievementArray[250] = SM2;
		achievementArray[251] = SM25;
		achievementArray[252] = SM50;
		achievementArray[253] = SM75;
		achievementArray[254] = SM99;
		achievementArray[255] = SM100;
		achievementArray[256] = SM125;
		achievementArray[257] = SM150;
		achievementArray[258] = SM175;
		achievementArray[259] = SM200;
		achievementArray[260] = SM201;
		achievementArray[261] = SM220;
		achievementArray[262] = SM240;
		achievementArray[263] = SM250;
		achievementArray[264] = SMMAX;

		achievementArray[265] = TN2;
		achievementArray[266] = TN25;
		achievementArray[267] = TN50;
		achievementArray[268] = TN75;
		achievementArray[269] = TN99;
		achievementArray[270] = TN100;
		achievementArray[271] = TN125;
		achievementArray[272] = TN150;
		achievementArray[273] = TN175;
		achievementArray[274] = TN200;
		achievementArray[275] = TN201;
		achievementArray[276] = TN220;
		achievementArray[277] = TN240;
		achievementArray[278] = TN250;
		achievementArray[279] = TNMAX;

		achievementArray[280] = JE2;
		achievementArray[281] = JE25;
		achievementArray[282] = JE50;
		achievementArray[283] = JE75;
		achievementArray[284] = JE99;
		achievementArray[285] = JE100;
		achievementArray[286] = JE125;
		achievementArray[287] = JE150;
		achievementArray[288] = JE175;
		achievementArray[289] = JE200;
		achievementArray[290] = JE201;
		achievementArray[291] = JE220;
		achievementArray[292] = JE240;
		achievementArray[293] = JE250;
		achievementArray[294] = JEMAX;

		achievementArray[295] = FL2;
		achievementArray[296] = FL25;
		achievementArray[297] = FL50;
		achievementArray[298] = FL75;
		achievementArray[299] = FL99;
		achievementArray[300] = FL100;
		achievementArray[301] = FL125;
		achievementArray[302] = FL150;
		achievementArray[303] = FL175;
		achievementArray[304] = FL200;
		achievementArray[305] = FL201;
		achievementArray[306] = FL220;
		achievementArray[307] = FL240;
		achievementArray[308] = FL250;
		achievementArray[309] = FLMAX;

		achievementArray[310] = CO2;
		achievementArray[311] = CO25;
		achievementArray[312] = CO50;
		achievementArray[313] = CO75;
		achievementArray[314] = CO99;
		achievementArray[315] = CO100;
		achievementArray[316] = CO125;
		achievementArray[317] = CO150;
		achievementArray[318] = CO175;
		achievementArray[319] = CO200;
		achievementArray[320] = CO201;
		achievementArray[321] = CO220;
		achievementArray[322] = CO240;
		achievementArray[323] = CO250;
		achievementArray[324] = COMAX;

		achievementArray[325] = HE2;
		achievementArray[326] = HE25;
		achievementArray[327] = HE50;
		achievementArray[328] = HE75;
		achievementArray[329] = HE99;
		achievementArray[330] = HE100;
		achievementArray[331] = HE125;
		achievementArray[332] = HE150;
		achievementArray[333] = HE175;
		achievementArray[334] = HE200;
		achievementArray[335] = HE201;
		achievementArray[336] = HE220;
		achievementArray[337] = HE240;
		achievementArray[338] = HE250;
		achievementArray[339] = HEMAX;

		achievementArray[340] = HO2;
		achievementArray[341] = HO25;
		achievementArray[342] = HO50;
		achievementArray[343] = HO75;
		achievementArray[344] = HO99;
		achievementArray[345] = HO100;
		achievementArray[346] = HO125;
		achievementArray[347] = HO150;
		achievementArray[348] = HO175;
		achievementArray[349] = HO200;
		achievementArray[350] = HO201;
		achievementArray[351] = HO220;
		achievementArray[352] = HO240;
		achievementArray[353] = HO250;
		achievementArray[354] = HOMAX;

		achievementArray[355] = CN2;
		achievementArray[356] = CN25;
		achievementArray[357] = CN50;
		achievementArray[358] = CN75;
		achievementArray[359] = CN99;
		achievementArray[360] = CN100;
		achievementArray[361] = CN125;
		achievementArray[362] = CN150;
		achievementArray[363] = CN175;
		achievementArray[364] = CN200;
		achievementArray[365] = CN201;
		achievementArray[366] = CN220;
		achievementArray[367] = CN240;
		achievementArray[368] = CN250;
		achievementArray[369] = CNMAX;

		achievementArray[370] = AG2;
		achievementArray[371] = AG25;
		achievementArray[372] = AG50;
		achievementArray[373] = AG75;
		achievementArray[374] = AG99;
		achievementArray[375] = AG100;
		achievementArray[376] = AG125;
		achievementArray[377] = AG150;
		achievementArray[378] = AG175;
		achievementArray[379] = AG200;
		achievementArray[380] = AG201;
		achievementArray[381] = AG220;
		achievementArray[382] = AG240;
		achievementArray[383] = AG250;
		achievementArray[384] = AGMAX;

		achievementArray[385] = DN2;
		achievementArray[386] = DN25;
		achievementArray[387] = DN50;
		achievementArray[388] = DN75;
		achievementArray[389] = DN99;
		achievementArray[390] = DN100;
		achievementArray[391] = DN125;
		achievementArray[392] = DN150;
		achievementArray[393] = DN175;
		achievementArray[394] = DN200;
		achievementArray[395] = DN201;
		achievementArray[396] = DN220;
		achievementArray[397] = DN240;
		achievementArray[398] = DN250;
		achievementArray[399] = DNMAX;

		achievementArray[400] = PC2;
		achievementArray[401] = PC25;
		achievementArray[402] = PC50;
		achievementArray[403] = PC75;
		achievementArray[404] = PC99;
		achievementArray[405] = PC100;
		achievementArray[406] = PC125;
		achievementArray[407] = PC150;
		achievementArray[408] = PC175;
		achievementArray[409] = PC200;
		achievementArray[410] = PC201;
		achievementArray[411] = PC220;
		achievementArray[412] = PC240;
		achievementArray[413] = PC250;
		achievementArray[414] = PCMAX;

		achievementArray[415] = LS2;
		achievementArray[416] = LS25;
		achievementArray[417] = LS50;
		achievementArray[418] = LS75;
		achievementArray[419] = LS99;
		achievementArray[420] = LS100;
		achievementArray[421] = LS125;
		achievementArray[422] = LS150;
		achievementArray[423] = LS175;
		achievementArray[424] = LS200;
		achievementArray[425] = LS201;
		achievementArray[426] = LS220;
		achievementArray[427] = LS240;
		achievementArray[428] = LS250;
		achievementArray[429] = LSMAX;

		achievementArray[430] = KW2;
		achievementArray[431] = KW25;
		achievementArray[432] = KW50;
		achievementArray[433] = KW75;
		achievementArray[434] = KW99;
		achievementArray[435] = KW100;
		achievementArray[436] = KW125;
		achievementArray[437] = KW150;
		achievementArray[438] = KW175;
		achievementArray[439] = KW200;
		achievementArray[440] = KW201;
		achievementArray[441] = KW220;
		achievementArray[442] = KW240;
		achievementArray[443] = KW250;
		achievementArray[444] = KWMAX;

		achievementArray[445] = TC2;
		achievementArray[446] = TC25;
		achievementArray[447] = TC50;
		achievementArray[448] = TC75;
		achievementArray[449] = TC99;
		achievementArray[450] = TC100;
		achievementArray[451] = TC125;
		achievementArray[452] = TC150;
		achievementArray[453] = TC175;
		achievementArray[454] = TC200;
		achievementArray[455] = TC201;
		achievementArray[456] = TC220;
		achievementArray[457] = TC240;
		achievementArray[458] = TC250;
		achievementArray[459] = TCMAX;

		achievementArray[460] = EG2;
		achievementArray[461] = EG25;
		achievementArray[462] = EG50;
		achievementArray[463] = EG75;
		achievementArray[464] = EG99;
		achievementArray[465] = EG100;
		achievementArray[466] = EG125;
		achievementArray[467] = EG150;
		achievementArray[468] = EG175;
		achievementArray[469] = EG200;
		achievementArray[470] = EG201;
		achievementArray[471] = EG220;
		achievementArray[472] = EG240;
		achievementArray[473] = EG250;
		achievementArray[474] = EGMAX;

		achievementArray[475] = CH2;
		achievementArray[476] = CH25;
		achievementArray[477] = CH50;
		achievementArray[478] = CH75;
		achievementArray[479] = CH99;
		achievementArray[480] = CH100;
		achievementArray[481] = CH125;
		achievementArray[482] = CH150;
		achievementArray[483] = CH175;
		achievementArray[484] = CH200;
		achievementArray[485] = CH201;
		achievementArray[486] = CH220;
		achievementArray[487] = CH240;
		achievementArray[488] = CH250;
		achievementArray[489] = CHMAX;

		achievementArray[490] = SP2;
		achievementArray[491] = SP25;
		achievementArray[492] = SP50;
		achievementArray[493] = SP75;
		achievementArray[494] = SP99;
		achievementArray[495] = SP100;
		achievementArray[496] = SP125;
		achievementArray[497] = SP150;
		achievementArray[498] = SP175;
		achievementArray[499] = SP200;
		achievementArray[500] = SP201;
		achievementArray[501] = SP220;
		achievementArray[502] = SP240;
		achievementArray[503] = SP250;
		achievementArray[504] = SPMAX;

		achievementArray[505] = MU2;
		achievementArray[506] = MU25;
		achievementArray[507] = MU50;
		achievementArray[508] = MU75;
		achievementArray[509] = MU99;
		achievementArray[510] = MU100;
		achievementArray[511] = MU125;
		achievementArray[512] = MU150;
		achievementArray[513] = MU175;
		achievementArray[514] = MU200;
		achievementArray[515] = MU201;
		achievementArray[516] = MU220;
		achievementArray[517] = MU240;
		achievementArray[518] = MU250;
		achievementArray[519] = MUMAX;

		achievementArray[520] = FI2;
		achievementArray[521] = FI25;
		achievementArray[522] = FI50;
		achievementArray[523] = FI75;
		achievementArray[524] = FI99;
		achievementArray[525] = FI100;
		achievementArray[526] = FI125;
		achievementArray[527] = FI150;
		achievementArray[528] = FI175;
		achievementArray[529] = FI200;
		achievementArray[530] = FI201;
		achievementArray[531] = FI220;
		achievementArray[532] = FI240;
		achievementArray[533] = FI250;
		achievementArray[534] = FIMAX;
		
		achievementArray[535] = FU2;
		achievementArray[536] = FU25;
		achievementArray[537] = FU50;
		achievementArray[538] = FU75;
		achievementArray[539] = FU99;
		achievementArray[540] = FU100;
		achievementArray[541] = FU125;
		achievementArray[542] = FU150;
		achievementArray[543] = FU175;
		achievementArray[544] = FU200;
		achievementArray[545] = FU201;
		achievementArray[546] = FU220;
		achievementArray[547] = FU240;
		achievementArray[548] = FU250;
		achievementArray[549] = FUMAX;
		
		for(int i = 0; i < 550; i++){
			achievementArray[i].registerStat();
		}
		
		AchievementPage.registerAchievementPage(new AchievementPage("Mark's Mod", achievementArray));
		
		
		
	}
	
	
	

	
	
	
	
	
	
}
