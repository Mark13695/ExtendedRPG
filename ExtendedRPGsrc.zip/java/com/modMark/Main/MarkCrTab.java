package com.modMark.Main;

import com.modMark.Item_Block.MarkItems;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class MarkCrTab extends CreativeTabs {

	public MarkCrTab(int index, String unlocalizedName) {
		super(index, unlocalizedName);
		
	}
	
	@SideOnly(Side.CLIENT)
	public Item getTabIconItem(){
		
		return MarkItems.GemOpal;
	}

}
