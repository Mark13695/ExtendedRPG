package com.modMark.Main;

import org.lwjgl.input.Keyboard;

import com.modMark.Gui.IGuiHandlerMark;
import com.modMark.Packets.CraftingPacketS;
import com.modMark.Packets.HiscorePacketA;
import com.modMark.Packets.InventoryPacketA;
import com.modMark.Skill.MarkData;

import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.common.network.internal.FMLNetworkHandler;
import net.minecraft.entity.player.EntityPlayer;

public class MarkKeyBindings {
	
	public static KeyBinding StatsR;
	public static KeyBinding HiscoreY;
	public static KeyBinding InvE;
	
	public static void init() {
		
		StatsR = new KeyBinding("key.StatsR", Keyboard.KEY_R,"key.categories.inventory" );
		HiscoreY = new KeyBinding("key.HiscoreY", Keyboard.KEY_Y,"key.categories.inventory" );
		InvE = new KeyBinding("key.InvE", Keyboard.KEY_U,"key.categories.inventory" );
		
		ClientRegistry.registerKeyBinding(StatsR);
		ClientRegistry.registerKeyBinding(HiscoreY);
		ClientRegistry.registerKeyBinding(InvE);
		// TODO: Register The Keybinding further and find something to open the gui
	}
	
	@SubscribeEvent
	public void onKeyInput(KeyInputEvent event) {
		EntityPlayer player = FMLClientHandler.instance().getClient().thePlayer;
		if (!FMLClientHandler.instance().isGUIOpen(GuiChat.class)) {
		if (MarkKeyBindings.StatsR.isPressed()) {
			player.openGui( MainRegistry.instance, IGuiHandlerMark.SkillsGui , player.worldObj , (int) player.posX , (int) player.posY , (int) player.posZ  );
			
		}
		if (MarkKeyBindings.HiscoreY.isPressed()) {
			
			 MainRegistry.network.sendToServer(new HiscorePacketA(35, player));
			
			player.openGui( MainRegistry.instance, IGuiHandlerMark.HiscoreGui , player.worldObj , (int) player.posX , (int) player.posY , (int) player.posZ  );
				
		}
		if (MarkKeyBindings.InvE.isPressed()) {
			
			player.openGui( MainRegistry.instance, IGuiHandlerMark.Inventory , player.worldObj , (int) player.posX , (int) player.posY , (int) player.posZ  );
			MainRegistry.network.sendToServer(new InventoryPacketA(player));
			 
			
		}
}
}
}