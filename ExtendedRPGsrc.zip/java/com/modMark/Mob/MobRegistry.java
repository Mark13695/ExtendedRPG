package com.modMark.Mob;

import com.modMark.Combat.EntityOpalShot;
import com.modMark.Main.MainRegistry;

import net.minecraft.entity.EnumCreatureType;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.common.BiomeDictionary.Type;
import net.minecraftforge.fml.common.registry.EntityRegistry;

public class MobRegistry {
	
	public static int EntityID = 0;
	
	public static void init(){

	registerModEntityWithEgg(EntitySalaCommon.class, "CommonSala" , 0x996600, 0x774400);
	registerModEntityWithEgg(EntitySalaDesert.class, "DesertSala" , 0xCCCC66, 0xCCCC99);
	registerModEntityWithEgg(EntitySalaGreen.class, "GreenSala" , 0x00CC00, 0x009900);
	registerModEntityWithEgg(EntitySalaRed.class, "RedSala" , 0xCC0000, 0x990000);
	registerModEntityWithEgg(EntitySalaBlue.class, "BlueSala" , 0x0000CC, 0x000099);
	
	EntityRegistry.addSpawn(EntitySalaCommon.class, 4, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.FOREST)); //
	EntityRegistry.addSpawn(EntitySalaCommon.class, 4, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.PLAINS));
	EntityRegistry.addSpawn(EntitySalaCommon.class, 4, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.HILLS));
	EntityRegistry.addSpawn(EntitySalaCommon.class, 4, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.SPARSE));
	
	EntityRegistry.addSpawn(EntitySalaDesert.class, 3, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.BEACH));
	EntityRegistry.addSpawn(EntitySalaDesert.class, 3, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.HOT));
	EntityRegistry.addSpawn(EntitySalaDesert.class, 3, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.MESA));
	EntityRegistry.addSpawn(EntitySalaDesert.class, 3, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.WASTELAND));
	
	EntityRegistry.addSpawn(EntitySalaGreen.class, 1, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.JUNGLE));
	EntityRegistry.addSpawn(EntitySalaGreen.class, 1, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.SAVANNA));
	EntityRegistry.addSpawn(EntitySalaGreen.class, 1, 2, 5, EnumCreatureType.CREATURE, BiomeDictionary.getBiomesForType(Type.DENSE));
	EntityRegistry.registerModEntity(EntityOpalShot.class, "OpalShot", ++EntityID, MainRegistry.instance, 80, 3, true);

	
	
	
}
	public static void registerModEntityWithEgg(Class parEntityClass, String parEntityName, 
		      int parEggColor, int parEggSpotsColor)
		{
		    EntityRegistry.registerModEntity(parEntityClass, parEntityName, ++EntityID, MainRegistry.instance, 80, 3, false);
		    EntityRegistry.registerEgg(parEntityClass, parEggColor, parEggSpotsColor);
		    
		}	


}
