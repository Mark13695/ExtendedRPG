package com.modMark.Mob;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelQuadruped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class ModelSalamander extends ModelBase{
	
	ModelRenderer head;
	ModelRenderer body;
	ModelRenderer leg1;
	ModelRenderer leg2;
	ModelRenderer leg3;
	ModelRenderer leg4;
    ModelRenderer Tail;
	protected float childYOffset = 8.0F;
    protected float childZOffset = 4.0F;
  
  public ModelSalamander()
  {
	  	this.textureWidth = 100;
	    this.textureHeight = 100;
	  
      this.head = new ModelRenderer(this, 0, 0);
      this.head.addBox(-4F, -4F, -8F, 6, 9, 9);
      this.head.setRotationPoint(1F, 30F, -16F);
      
      
	  
      this.body = new ModelRenderer(this, 30, 0);
      this.body.addBox(-5F, -10F, -4F, 12, 36, 15);
      this.body.setRotationPoint(-1F, 37F, -7F);
      
      
      this.leg1 = new ModelRenderer(this, 0, 18);
      this.leg1.addBox(-2F, 0F, -2F, 2, 9, 2);
      this.leg1.setRotationPoint(-4F, 39F, 12F);
     
     
      this.leg2 = new ModelRenderer(this, 8, 18);
      this.leg2.addBox(-2F, 0F, -2F, 2, 9, 2);
      this.leg2.setRotationPoint(5F, 39F, 12F);
      
      
      this.leg3 = new ModelRenderer(this, 0, 29);
      this.leg3.addBox(-2F, 0F, -2F, 2, 9, 2);
      this.leg3.setRotationPoint(-4F, 39F, -14F);
      
     
      this.leg4 = new ModelRenderer(this, 8, 29);
      this.leg4.addBox(-2F, 0F, -2F, 2, 9, 2);
      this.leg4.setRotationPoint(5F, 39F, -14F);
      
     
      this.Tail = new ModelRenderer(this, 0, 51);
      this.Tail.addBox(0F, 0F, 0F, 6, 6, 27);
      this.Tail.setRotationPoint(-3F, 28F, 17F);
    
     
  }
	  
	  public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale2)
	  {
	    
		  float scale = scale2 / 2;
		  
	    setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);
	    
	    if(this.isChild){
	    	
	 
	    	GlStateManager.pushMatrix();
	    	GlStateManager.translate(0.0F, this.childYOffset * scale, this.childZOffset * scale);
	    	this.head.render(scale);
			this.head.render(scale);
            GlStateManager.popMatrix();
            GlStateManager.pushMatrix();
            GlStateManager.scale(0.5F, 0.5F, 0.5F);
            GlStateManager.translate(0.0F, 45.0F * scale, -0.1F);
		    this.body.render(scale);
		    this.leg1.render(scale);
		    this.leg2.render(scale);
		    this.leg3.render(scale);
		    this.leg4.render(scale);
		    this.Tail.render(scale);
		    GlStateManager.popMatrix();
	    }
	    else{
	    
	    
	    this.head.render(scale);
	    this.body.render(scale);
	    this.leg1.render(scale);
	    this.leg2.render(scale);
	    this.leg3.render(scale);
	    this.leg4.render(scale);
	    this.Tail.render(scale);
	  }}
	  
	  
	  
	   /**
     * Sets the model's various rotation angles. For bipeds, par1 and par2 are used for animating the movement of arms
     * and legs, where par1 represents the time(so that arms and legs swing back and forth) and par2 represents how
     * "far" arms and legs can swing at most.
     */
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn)
    {
        this.head.rotateAngleX = headPitch * 0.017453292F;
        this.head.rotateAngleY = netHeadYaw * 0.017453292F;
        this.body.rotateAngleX = ((float)Math.PI / 2F);
        this.leg1.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        this.leg2.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.4F * limbSwingAmount;
        this.leg3.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.4F * limbSwingAmount;
        this.leg4.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
    }
}
