package com.modMark.Mob;

import com.modMark.Refer.ReferenceStrings;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

@SideOnly(Side.CLIENT)
public class RenderSalaBlue extends RenderLiving {
	
	public static final ResourceLocation Texture_SalaBlue = new ResourceLocation(ReferenceStrings.MODID + ":textures/entity/salablue.png");

	public RenderSalaBlue(RenderManager rendermanagerIn) {
		super(rendermanagerIn, new ModelSalamander(), 0.5f);
		
	}
	
protected ResourceLocation getEntityTexture1(EntitySalaBlue entity) {
		
		return Texture_SalaBlue;
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity entity) {
		
		return this.getEntityTexture1((EntitySalaBlue)entity);
	}

}
