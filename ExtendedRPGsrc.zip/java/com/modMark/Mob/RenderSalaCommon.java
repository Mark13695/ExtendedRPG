package com.modMark.Mob;

import com.modMark.Refer.ReferenceStrings;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

@SideOnly(Side.CLIENT)
public class RenderSalaCommon extends RenderLiving {
	
	public static final ResourceLocation Texture_SalaCommon = new ResourceLocation(ReferenceStrings.MODID + ":textures/entity/salacommon.png");

	public RenderSalaCommon(RenderManager rendermanagerIn) {
		super(rendermanagerIn, new ModelSalamander(), 0.5f);
		
	}
	
protected ResourceLocation getEntityTexture1(EntitySalaCommon entity) {
		
		return Texture_SalaCommon;
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity entity) {
		
		return this.getEntityTexture1((EntitySalaCommon)entity);
	}

}
