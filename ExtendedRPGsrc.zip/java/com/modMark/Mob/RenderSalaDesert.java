package com.modMark.Mob;

import com.modMark.Refer.ReferenceStrings;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

@SideOnly(Side.CLIENT)
public class RenderSalaDesert extends RenderLiving<EntitySalaDesert> {
	
	public static final ResourceLocation Texture_SalaDesert = new ResourceLocation(ReferenceStrings.MODID + ":textures/entity/saladesert.png");

	public RenderSalaDesert(RenderManager rendermanagerIn) {
		super(rendermanagerIn, new ModelSalamander(), 0.5f);
		
	}
	@Override
protected ResourceLocation getEntityTexture(EntitySalaDesert entity) {
	
		
		return Texture_SalaDesert; 
	}

	

}
