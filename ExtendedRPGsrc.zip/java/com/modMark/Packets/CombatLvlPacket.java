package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CombatLvlPacket implements IMessage{

	private String ClientPlayer;
	private String NamePlayer;
	
	public CombatLvlPacket() {}
	public CombatLvlPacket(EntityPlayer client, EntityPlayer name){
		
		this.ClientPlayer = client.getUniqueID().toString();
		this.NamePlayer = name.getUniqueID().toString();
		
		
		
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		
		
		this.ClientPlayer = ByteBufUtils.readUTF8String(buf);
		this.NamePlayer = ByteBufUtils.readUTF8String(buf);
	}

	@Override
	public void toBytes(ByteBuf buf) {
			ByteBufUtils.writeUTF8String(buf, this.ClientPlayer);
			ByteBufUtils.writeUTF8String(buf, this.NamePlayer);
	}


//-----------------------------------------------------------------------------------------------

public static class MarkHandler15 implements IMessageHandler<CombatLvlPacket, IMessage > {

	@Override
	public IMessage onMessage(final CombatLvlPacket message, MessageContext ctx) {
		IThreadListener ThreadListener = (WorldServer) ctx.getServerHandler().playerEntity.worldObj;
				ThreadListener.addScheduledTask(new Runnable() {
					@Override
	                public void run() {
						final EntityPlayer player = (EntityPlayer) FMLCommonHandler.instance().getMinecraftServerInstance().getEntityFromUuid(UUID.fromString(message.ClientPlayer));
						final EntityPlayer player2 = (EntityPlayer) FMLCommonHandler.instance().getMinecraftServerInstance().getEntityFromUuid(UUID.fromString(message.NamePlayer));
						
						MarkData p1 = player.getCapability(MainRegistry.ModMark136Data, null);
						MarkData p2 = player2.getCapability(MainRegistry.ModMark136Data, null);
						
						p1.CombatLevelToClient(p1.getCombatLvl(p1), p2.getCombatLvl(p2));
						
	                    
	                }
				});
		return null;
	}

}
}
