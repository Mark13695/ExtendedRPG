package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CombatLvlPacket3 implements IMessage{

	private int ClientLvl;
	private int ID;
	
	public CombatLvlPacket3() {}
	public CombatLvlPacket3(int client, EntityPlayer player){
		
		this.ClientLvl = client;
		this.ID = player.getEntityId();
		
		
		
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		this.ClientLvl = buf.readInt();
		this.ID = buf.readInt();
	}

	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(this.ClientLvl);
		buf.writeInt(this.ID);
	}


//-----------------------------------------------------------------------------------------------

public static class MarkHandler17 implements IMessageHandler<CombatLvlPacket3, IMessage > {

	@Override
	public IMessage onMessage(final CombatLvlPacket3 message, MessageContext ctx) {
		IThreadListener ThreadListener = Minecraft.getMinecraft();
				ThreadListener.addScheduledTask(new Runnable() {
					@Override
	                public void run() {
						final EntityPlayer player =  ((EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.ID));
						MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
						
						p.Combat = message.ClientLvl;

	                    
	                }
				});
		return null;
	}

}
}
