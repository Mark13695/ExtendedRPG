package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Combat.MobData;
import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CombatLvlPacket4 implements IMessage{

	private int CbLvl;
	private int ID;
	private int LivID;
	
	public CombatLvlPacket4() {}
	public CombatLvlPacket4(int cb, EntityLiving Liv, EntityPlayer player){
		
		this.CbLvl = cb;
		this.ID = player.getEntityId();
		this.LivID = Liv.getEntityId();
		
		
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		this.CbLvl = buf.readInt();
		this.ID = buf.readInt();
		this.LivID = buf.readInt();
	}

	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(this.CbLvl);
		buf.writeInt(this.ID);
		buf.writeInt(this.LivID);
	}


//-----------------------------------------------------------------------------------------------

public static class MarkHandler18 implements IMessageHandler<CombatLvlPacket4, IMessage > {

	@Override
	public IMessage onMessage(final CombatLvlPacket4 message, MessageContext ctx) {
		IThreadListener ThreadListener = Minecraft.getMinecraft();
				ThreadListener.addScheduledTask(new Runnable() {
					@Override
	                public void run() {
						final EntityPlayer player =  ((EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.ID));
						final EntityLiving living =  ((EntityLiving) Minecraft.getMinecraft().theWorld.getEntityByID(message.LivID));
						MobData p = living.getCapability(MainRegistry.ModMark136MobData, null);
						
						p.Cb = message.CbLvl;

	                    
	                }
				});
		return null;
	}

}
}
