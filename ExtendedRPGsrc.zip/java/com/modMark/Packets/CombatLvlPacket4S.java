package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Combat.MobData;
import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CombatLvlPacket4S implements IMessage{

	private String ID;
	private String LivID;
	
	public CombatLvlPacket4S() {}
	public CombatLvlPacket4S(EntityLiving Liv, EntityPlayer player){
		
		
		this.ID = player.getUniqueID().toString();
		this.LivID = Liv.getUniqueID().toString();
		
		
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		this.ID = ByteBufUtils.readUTF8String(buf);
		this.LivID = ByteBufUtils.readUTF8String(buf);
	}

	@Override
	public void toBytes(ByteBuf buf) {
		ByteBufUtils.writeUTF8String(buf, this.ID);
		ByteBufUtils.writeUTF8String(buf, this.LivID);
	}


//-----------------------------------------------------------------------------------------------

public static class MarkHandler19 implements IMessageHandler<CombatLvlPacket4S, IMessage > {

	@Override
	public IMessage onMessage(final CombatLvlPacket4S message, MessageContext ctx) {
		IThreadListener ThreadListener = (WorldServer) ctx.getServerHandler().playerEntity.worldObj;
				ThreadListener.addScheduledTask(new Runnable() {
					@Override
	                public void run() {
						MinecraftServer server = FMLCommonHandler.instance().getMinecraftServerInstance();
						final EntityPlayer player =  ((EntityPlayer) server.getEntityFromUuid(UUID.fromString(message.ID)));
						final EntityLiving living =  ((EntityLiving) server.getEntityFromUuid(UUID.fromString(message.LivID)));
						MobData p = living.getCapability(MainRegistry.ModMark136MobData, null);
						System.out.println("player: " + player + " Mob: " + living);
						p.SyncCb(player);

	                    
	                }
				});
		return null;
	}

}
}
