package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Combat.MobData;
import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CombatLvlPacketHP implements IMessage{

	private int PlayerID;
	private int HPLvl;
	private int ID;
	private int MaxHP;
	private boolean isSpawning;
	private boolean isLeveling;
	
	
	public CombatLvlPacketHP() {}
	public CombatLvlPacketHP(EntityPlayer player, int hp, Entity id, int mhp, boolean Spawn, boolean L){
		
		this.PlayerID = player.getEntityId();
		this.HPLvl = hp;
		this.ID = id.getEntityId();
		this.MaxHP = mhp;
		this.isSpawning = Spawn;
		this.isLeveling = L;
		
		
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		this.HPLvl = buf.readInt();
		this.ID = buf.readInt();
		this.PlayerID = buf.readInt();
		this.MaxHP = buf.readInt();
		this.isSpawning = buf.readBoolean();
		this.isLeveling = buf.readBoolean();
	}

	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(this.HPLvl);
		buf.writeInt(this.ID);
		buf.writeInt(this.PlayerID);
		buf.writeInt(this.MaxHP);
		buf.writeBoolean(this.isSpawning);
		buf.writeBoolean(this.isLeveling);
	}


//-----------------------------------------------------------------------------------------------

public static class MarkHandler20 implements IMessageHandler<CombatLvlPacketHP, IMessage > {

	@Override
	public IMessage onMessage(final CombatLvlPacketHP message, MessageContext ctx) {
		IThreadListener ThreadListener = Minecraft.getMinecraft();
				ThreadListener.addScheduledTask(new Runnable() {
					@Override
	                public void run() {
						World world = Minecraft.getMinecraft().theWorld;
						if(world != null){
						final EntityPlayer player =  ((EntityPlayer) world.getEntityByID(message.PlayerID));
						
						Entity entity =  ((Entity) Minecraft.getMinecraft().theWorld.getEntityByID(message.ID));
						if(entity instanceof EntityPlayer){
							MarkData p = entity.getCapability(MainRegistry.ModMark136Data, null);
							if(message.isLeveling || message.isSpawning){
							p.setHpFromLevel(message.isSpawning);
							}
							else{
								p.setHP(message.HPLvl);
							}
							
						}
						else{
							if(entity != null){
							MobData p = entity.getCapability(MainRegistry.ModMark136MobData, null);
						
							p.setHP(message.HPLvl);
							p.setMaxHP(message.MaxHP);
							}
							else{
								System.err.println("Entity = null!! id: " + message.ID);
							}
						}
	                    
	                }
						else{
							System.err.println("world is null!");
						}
					}
				});
		return null;
	}

}
}
