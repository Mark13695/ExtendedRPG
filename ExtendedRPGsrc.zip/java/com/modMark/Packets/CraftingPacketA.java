package com.modMark.Packets;

import com.modMark.Gui.GuiCraftingTable;
import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.IThreadListener;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CraftingPacketA implements IMessage {
	
	private int PlayerID;
	private int SkillID;
	private int XP;
	private boolean NeedsEnergy;
	
	public CraftingPacketA(){}
	public CraftingPacketA(int XPIn ,int Skill, boolean b, EntityPlayer player){
		
		this.SkillID = Skill;
		this.PlayerID = player.getEntityId();
		this.XP = XPIn;
		this.NeedsEnergy = b;
	}
	
	@Override
	public void fromBytes(ByteBuf buf) {
		
		this.SkillID = buf.readInt();
		this.PlayerID = buf.readInt();
		this.XP = buf.readInt();
		this.NeedsEnergy = buf.readBoolean();
	}
	
	@Override
	public void toBytes(ByteBuf buf) {
		
		buf.writeInt(this.SkillID);
		buf.writeInt(this.PlayerID);
		buf.writeInt(this.XP);
		buf.writeBoolean(this.NeedsEnergy);
	}
	
	//-----------------------------------------------------------------------------------------------

	public static class MarkHandler5 implements IMessageHandler<CraftingPacketA, IMessage > {

		@Override
		public IMessage onMessage(final CraftingPacketA message, MessageContext ctx) {
			IThreadListener ThreadListener = Minecraft.getMinecraft();
					ThreadListener.addScheduledTask(new Runnable() {
						@Override
		                public void run() {
							final EntityPlayer player = (EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.PlayerID);
							
							
							MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
							GuiCraftingTable.SkillID = message.SkillID;
							GuiCraftingTable.XP = message.XP;
							GuiCraftingTable.NeedsEnergy = message.NeedsEnergy;
							GuiCraftingTable.player = player;
						
							
							
							
		                    
		                }
					});
			return null;
		}

	}
	}

	

