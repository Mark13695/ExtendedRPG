package com.modMark.Packets;

import com.modMark.Item_Block.TileEntity.TECraftingTable;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IThreadListener;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CraftingPacketB implements IMessage{

	private boolean isActive;
	private int playerID;
	
	private int X;
	private int Y;
	private int Z;
	
	public CraftingPacketB(){}
	public CraftingPacketB(boolean active, EntityPlayer player, int x, int y, int z){
		
		this.playerID = player.getEntityId();
		this.isActive = active;
		this.X = x;
		this.Y = y;
		this.Z = z;
		
	}
	
	@Override
	public void fromBytes(ByteBuf buf) {
		this.playerID = buf.readInt();
		this.isActive = buf.readBoolean();	
		this.X = buf.readInt();
		this.Y = buf.readInt();
		this.Z = buf.readInt();
		
	}
	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(this.playerID);
		buf.writeBoolean(this.isActive);
		buf.writeInt(this.X);
		buf.writeInt(this.Y);
		buf.writeInt(this.Z);
	
	}
	
	//-----------------------------------------------------------------------------------------------

		public static class MarkHandler7 implements IMessageHandler<CraftingPacketB, IMessage > {

			@Override
			public IMessage onMessage(final CraftingPacketB message, MessageContext ctx) {
				IThreadListener ThreadListener = Minecraft.getMinecraft();
						ThreadListener.addScheduledTask(new Runnable() {
							@Override
			                public void run() {
								final EntityPlayer player = (EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.playerID);
								BlockPos TEpos = new BlockPos(message.X, message.Y, message.Z);
								World world = Minecraft.getMinecraft().theWorld;
								TileEntity tileentity = world.getTileEntity(TEpos);
								 if (tileentity instanceof TECraftingTable) {
								TECraftingTable TE = (TECraftingTable) tileentity;
								
								TE.setIsActive(message.isActive);
								
								
								 }
								
							}
			
			
						});
						return null;
			
			}
			
		}

}
