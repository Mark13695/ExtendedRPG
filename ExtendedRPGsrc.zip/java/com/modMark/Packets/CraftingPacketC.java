package com.modMark.Packets;

import com.modMark.Gui.GuiCraftingTable;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.IThreadListener;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CraftingPacketC implements IMessage {
	
	private int PlayerID;
	private int XP;
	private int TableValue;
	
	
	public CraftingPacketC(){}
	public CraftingPacketC(int XPIn, int TableVal, EntityPlayer player){
		
		this.PlayerID = player.getEntityId();
		this.XP = XPIn;
		this.TableValue = TableVal;
	}
	@Override
	public void fromBytes(ByteBuf buf) {
		this.PlayerID = buf.readInt();
		this.XP = buf.readInt();
		this.TableValue = buf.readInt();
	}
	@Override
	public void toBytes(ByteBuf buf) {	
		buf.writeInt(this.PlayerID);
		buf.writeInt(this.XP);
		buf.writeInt(this.TableValue);
	}
	//-----------------------------------------------------------------------------------------------

		public static class MarkHandler8 implements IMessageHandler<CraftingPacketC, IMessage > {

			@Override
			public IMessage onMessage(final CraftingPacketC message, MessageContext ctx) {
				IThreadListener ThreadListener = Minecraft.getMinecraft();
						ThreadListener.addScheduledTask(new Runnable() {
							@Override
			                public void run() {
								final EntityPlayer player = (EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.PlayerID);
								
								
									if(GuiCraftingTable.SkillID == message.TableValue){
										GuiCraftingTable.XP = message.XP;
									}		
							}
						}
						);
						return null;
			}
		}
}
