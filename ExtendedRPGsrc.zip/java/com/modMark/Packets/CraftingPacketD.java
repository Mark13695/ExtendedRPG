package com.modMark.Packets;

import com.modMark.Item_Block.TileEntity.TECraftingTable;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IThreadListener;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CraftingPacketD implements IMessage{

	
	private int playerID;
	private int CurrentCraft;
	private int CraftVal;
	
	private int X;
	private int Y;
	private int Z;
	
	public CraftingPacketD(){}
	public CraftingPacketD(int Cur, int CraftV, EntityPlayer player, int x, int y, int z){
		
		this.playerID = player.getEntityId();
		this.CurrentCraft = Cur;
		this.CraftVal = CraftV;
		
		this.X = x;
		this.Y = y;
		this.Z = z;
		
	}
	
	@Override
	public void fromBytes(ByteBuf buf) {
		this.playerID = buf.readInt();
		
		this.X = buf.readInt();
		this.Y = buf.readInt();
		this.Z = buf.readInt();
		this.CurrentCraft = buf.readInt();
		this.CraftVal = buf.readInt();
		
	}
	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(this.playerID);
		
		buf.writeInt(this.X);
		buf.writeInt(this.Y);
		buf.writeInt(this.Z);
		buf.writeInt(this.CurrentCraft);
		buf.writeInt(this.CraftVal);
	
	}
	
	//-----------------------------------------------------------------------------------------------

		public static class MarkHandler13 implements IMessageHandler<CraftingPacketD, IMessage > {

			@Override
			public IMessage onMessage(final CraftingPacketD message, MessageContext ctx) {
				IThreadListener ThreadListener = Minecraft.getMinecraft();
						ThreadListener.addScheduledTask(new Runnable() {
							@Override
			                public void run() {
								final EntityPlayer player = (EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.playerID);
								BlockPos TEpos = new BlockPos(message.X, message.Y, message.Z);
								World world = Minecraft.getMinecraft().theWorld;
								TileEntity tileentity = world.getTileEntity(TEpos);
								 if (tileentity instanceof TECraftingTable) {
								TECraftingTable TE = (TECraftingTable) tileentity;
								
								TE.setCraftStackValue(message.CraftVal);
								TE.setCurrentCrProg(message.CurrentCraft);
								TE.remIngrInv();
								
								 }
								
							}
			
			
						});
						return null;
			
			}
			
		}

}
