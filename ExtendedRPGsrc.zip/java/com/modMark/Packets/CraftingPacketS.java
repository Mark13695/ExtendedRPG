package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Item_Block.TileEntity.TECraftingTable;
import com.modMark.Item_Block.TileEntity.TETrap;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IThreadListener;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class CraftingPacketS implements IMessage {

	private ItemStack stack;
	private int CraftVar;
	private String PlayerID;
	private int TEposX;
	private int TEposY;
	private int TEposZ;
	private boolean active;
	private ItemStack ingredient1;
	private ItemStack ingredient2;
	private ItemStack ingredient3;
	private boolean remCrStck;
	private boolean addremIngr;
	
	
	public CraftingPacketS(){}
	public CraftingPacketS(ItemStack s, int CrVar, EntityPlayer Playerid, BlockPos pos, boolean act, ItemStack[] st, boolean b1, boolean b2){
		
		this.stack = s;
		this.CraftVar = CrVar;
		this.PlayerID = Playerid.getUniqueID().toString();
		this.TEposX = pos.getX();
		this.TEposY = pos.getY();
		this.TEposZ = pos.getZ();
		this.active = act;
		this.ingredient1 = st[0];
		this.ingredient2 = st[1];
		this.ingredient3 = st[2];
		this.remCrStck = b1;
		this.addremIngr = b2;
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		
		this.stack = ByteBufUtils.readItemStack(buf);
		this.CraftVar = buf.readInt();
		this.PlayerID = ByteBufUtils.readUTF8String(buf);
		this.TEposX = buf.readInt();
		this.TEposY = buf.readInt();
		this.TEposZ = buf.readInt();
		this.active = buf.readBoolean();
		this.ingredient1 = ByteBufUtils.readItemStack(buf);
		this.ingredient2 = ByteBufUtils.readItemStack(buf);
		this.ingredient3 = ByteBufUtils.readItemStack(buf);
		this.remCrStck = buf.readBoolean();
		this.addremIngr = buf.readBoolean();
		
		
	}
	@Override
	public void toBytes(ByteBuf buf) {
		
		ByteBufUtils.writeItemStack(buf, this.stack);
		buf.writeInt(this.CraftVar);
		ByteBufUtils.writeUTF8String(buf, this.PlayerID);
		buf.writeInt(this.TEposX);
		buf.writeInt(this.TEposY);
		buf.writeInt(this.TEposZ);
		buf.writeBoolean(this.active);
		ByteBufUtils.writeItemStack(buf, this.ingredient1);
		ByteBufUtils.writeItemStack(buf, this.ingredient2);
		ByteBufUtils.writeItemStack(buf, this.ingredient3);
		buf.writeBoolean(this.remCrStck);
		buf.writeBoolean(this.addremIngr);
	}
	
	//-----------------------------------------------------------------------------------------------

	public static class MarkHandler6 implements IMessageHandler<CraftingPacketS, IMessage > {
		
		@Override
		public IMessage onMessage(final CraftingPacketS message, MessageContext ctx) {
			IThreadListener ThreadListener = (WorldServer) ctx.getServerHandler().playerEntity.worldObj;
					ThreadListener.addScheduledTask(new Runnable() {
						@Override
		                public void run() {
							
							EntityPlayer player = (EntityPlayer) FMLCommonHandler.instance().getMinecraftServerInstance().getEntityFromUuid(UUID.fromString(message.PlayerID));
							BlockPos TEpos = new BlockPos(message.TEposX, message.TEposY, message.TEposZ);
							World world = ctx.getServerHandler().playerEntity.worldObj;
							TileEntity tileentity = world.getTileEntity(TEpos);
							 if (tileentity instanceof TECraftingTable) {
							TECraftingTable TE = (TECraftingTable) tileentity;
							
							TE.setCraftStackValue(message.CraftVar);
							if(message.remCrStck){
							TE.removeStackFromSlot(25);
							}
							else{
							TE.setInventorySlotContents(25, message.stack);
							}
							TE.setaddRemIng(message.addremIngr);
							TE.setIsActive(message.active);
							TE.setIngredientList(message.ingredient1, message.ingredient2, message.ingredient3);
							
							
							 }
							
						}
		
	});
					return null;
		}	
}
}

