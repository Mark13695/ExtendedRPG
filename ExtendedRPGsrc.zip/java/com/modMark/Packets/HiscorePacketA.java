package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class HiscorePacketA implements IMessage{

	private int SkillID;
	private String PlayerID;
	private String SendUUID;
	
	public HiscorePacketA() {}
	public HiscorePacketA(int skillID, EntityPlayer Player){
		
		this.SkillID = skillID;
		this.PlayerID = Player.getUniqueID().toString();
		
		
		
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		
		
		this.SkillID = buf.readInt();
		this.PlayerID = ByteBufUtils.readUTF8String(buf);
		
	}

	@Override
	public void toBytes(ByteBuf buf) {
		
			buf.writeInt(this.SkillID);
			ByteBufUtils.writeUTF8String(buf, this.PlayerID);
		
	}


//-----------------------------------------------------------------------------------------------

public static class MarkHandler2 implements IMessageHandler<HiscorePacketA, IMessage > {

	
	@Override
	public IMessage onMessage(final HiscorePacketA message, MessageContext ctx) {
		IThreadListener ThreadListener = (WorldServer) ctx.getServerHandler().playerEntity.worldObj;
				ThreadListener.addScheduledTask(new Runnable() {
					@Override
	                public void run() {
						
						
						
						EntityPlayer player = (EntityPlayer) FMLCommonHandler.instance().getMinecraftServerInstance().getEntityFromUuid(UUID.fromString(message.PlayerID));
						
						MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
			
						p.HSSync(message.SkillID, player);
						
				
						
						
	                    
	                }
				});
		return null;
	}

}
}
