package com.modMark.Packets;

import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Skill.MarkData;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class HiscorePacketB implements IMessage{

	private int playerR;
	private String[] PlayerID;
	private int[] PlayerXP;
	private int Length;
	private boolean isOnline;
	private boolean AreOff;
	
	public HiscorePacketB() {}
	public HiscorePacketB(String[] ID, int[] XP, Boolean online, boolean off, EntityPlayer player){

		this.playerR = player.getEntityId();
		this.PlayerXP = XP;
		this.Length = PlayerXP.length;
		this.isOnline = online;
		this.PlayerID = ID;
		this.AreOff = off;
		

		}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		
		this.playerR = buf.readInt();
		this.Length = buf.readInt();
		this.isOnline = buf.readBoolean();
		this.AreOff = buf.readBoolean();
		this.PlayerID = new String[Length];
		this.PlayerXP = new int[Length];
		
		for (int k = 0; k < this.PlayerID.length; k++){
			
			this.PlayerID[k] = ByteBufUtils.readUTF8String(buf);
			this.PlayerXP[k] = buf.readInt();
			
		}
		
		}

	@Override
	public void toBytes(ByteBuf buf) {
		
		if (this.PlayerID.length > 10000){
			throw new IndexOutOfBoundsException("more than 10000 players?");
		}
		buf.writeInt(this.playerR);
		buf.writeInt(this.Length);
		buf.writeBoolean(this.isOnline);
		buf.writeBoolean(this.AreOff);
		
		for (int j = 0; j < this.PlayerID.length; j++){
			
			ByteBufUtils.writeUTF8String(buf, this.PlayerID[j]);
			buf.writeInt(this.PlayerXP[j]);
			
			}
			
		}


//-----------------------------------------------------------------------------------------------

public static class MarkHandler3 implements IMessageHandler<HiscorePacketB, IMessage > {

	@Override
	public IMessage onMessage(final HiscorePacketB message, MessageContext ctx) {
		IThreadListener ThreadListener = Minecraft.getMinecraft();
				ThreadListener.addScheduledTask(new Runnable() {
					@Override
	                public void run() {
						final EntityPlayer player =  ((EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.playerR));
						EntityPlayer[] playerpre = new EntityPlayer[message.Length];
						String[] playerS = new String[message.Length];
						
						
						playerS = message.PlayerID;
						GuiHiscoreList.player = player;
						GuiHiscoreList.AreOff = message.AreOff;
						
						if (message.isOnline){
						GuiHiscoreList.XPTab = message.PlayerXP;
						GuiHiscoreList.PlayerTab = playerS;
						}
						else{
						GuiHiscoreList.XPTab2 = message.PlayerXP;
						GuiHiscoreList.PlayerTab2 = playerS;	
						}
	                    
	                }
				});
		return null;
	}

}
}
