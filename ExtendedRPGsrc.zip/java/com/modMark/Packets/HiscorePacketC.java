package com.modMark.Packets;

import java.util.List;

import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Skill.MarkData;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class HiscorePacketC implements IMessage{

	private int playerR;
	private String[] PlayerID;
	private long[] PlayerTotXP;
	private int[] PlayerTotal;
	private int Length;
	private Boolean isOnline;
	private Boolean AreOff;
	
	
	public HiscorePacketC() {}
	public HiscorePacketC(String[] ID, long[] XP, int[] Tot, boolean online, boolean off, EntityPlayer player){

		this.playerR = player.getEntityId();
		this.PlayerTotXP = XP;
		this.PlayerTotal = Tot;
		this.isOnline = online;
		this.AreOff = off;
		this.PlayerID = ID;
		this.Length = PlayerID.length;

		}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		
		this.playerR = buf.readInt();
		this.Length = buf.readInt();
		this.isOnline = buf.readBoolean();
		this.AreOff = buf.readBoolean();
		this.PlayerID = new String[Length];
		this.PlayerTotXP = new long[Length];
		this.PlayerTotal = new int[Length];
		
		for (int k = 0; k < this.Length; k++){
			
			this.PlayerID[k] = ByteBufUtils.readUTF8String(buf);;
			this.PlayerTotXP[k] = buf.readLong();
			this.PlayerTotal[k] = buf.readInt();
		}
		
		
		}

	@Override
	public void toBytes(ByteBuf buf) {
		
		buf.writeInt(this.playerR);
		buf.writeInt(this.Length);
		buf.writeBoolean(this.isOnline);
		buf.writeBoolean(this.AreOff);
		
		for (int j = 0; j < this.Length; j++){
			
			ByteBufUtils.writeUTF8String(buf, this.PlayerID[j]);
			buf.writeLong(this.PlayerTotXP[j]);
			buf.writeInt(this.PlayerTotal[j]);
			
			}
			
		}


//-----------------------------------------------------------------------------------------------

public static class MarkHandler4 implements IMessageHandler<HiscorePacketC, IMessage > {

	@Override
	public IMessage onMessage(final HiscorePacketC message, MessageContext ctx) {
		IThreadListener ThreadListener = Minecraft.getMinecraft();
				ThreadListener.addScheduledTask(new Runnable() {
					@Override
	                public void run() {
						final EntityPlayer player =  ((EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.playerR));
						EntityPlayer[] Playerpre = new EntityPlayer[message.Length];
						String[] playerS = new String[message.Length];
						

						
						
						playerS = message.PlayerID;
						GuiHiscoreList.AreOff = message.AreOff;
						GuiHiscoreList.player = player;
						
						if (message.isOnline){
						System.out.println("Online Players : " + playerS.length);
						GuiHiscoreList.TotXPTab = message.PlayerTotXP;
						GuiHiscoreList.PlayerTab = playerS;
						GuiHiscoreList.TotTab = message.PlayerTotal;
						}
						else{
						System.out.println("Offline Players : " + playerS.length);
						GuiHiscoreList.TotXPTab2 = message.PlayerTotXP;
						GuiHiscoreList.PlayerTab2 = playerS;
						GuiHiscoreList.TotTab2 = message.PlayerTotal;
							
						}
	                }
				});
		return null;
	}

}
}



