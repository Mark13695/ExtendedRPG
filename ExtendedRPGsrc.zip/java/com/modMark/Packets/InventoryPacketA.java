package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Gui.IGuiHandlerMark;
import com.modMark.Main.MainRegistry;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class InventoryPacketA implements IMessage {

	String PlayerID;
	
	public InventoryPacketA(){}
	public InventoryPacketA(EntityPlayer player){
		
		this.PlayerID = player.getUniqueID().toString();
		
	}
	@Override
	public void fromBytes(ByteBuf buf) {
		this.PlayerID = ByteBufUtils.readUTF8String(buf);
		
	}
	@Override
	public void toBytes(ByteBuf buf) {
		ByteBufUtils.writeUTF8String(buf, this.PlayerID);
		
	}
	//-----------------------------------------------------------------------------------------------

		public static class MarkHandler9 implements IMessageHandler<InventoryPacketA, IMessage > {
			
			@Override
			public IMessage onMessage(final InventoryPacketA message, MessageContext ctx) {
				IThreadListener ThreadListener = (WorldServer) ctx.getServerHandler().playerEntity.worldObj;
						ThreadListener.addScheduledTask(new Runnable() {
							@Override
			                public void run() {
					
								EntityPlayer player = (EntityPlayer) FMLCommonHandler.instance().getMinecraftServerInstance().getEntityFromUuid(UUID.fromString(message.PlayerID));
								player.openGui( MainRegistry.instance, IGuiHandlerMark.Inventory , player.worldObj , (int) player.posX , (int) player.posY , (int) player.posZ  );
								
								
							}
	
						}
						);
						return null;
			}
		}
	
	
	
}
