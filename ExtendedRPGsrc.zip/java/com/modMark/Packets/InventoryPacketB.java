package com.modMark.Packets;

import com.modMark.Crafting.MarkContainerInv;
import com.modMark.Item_Block.TileEntity.TECraftingTable;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IThreadListener;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class InventoryPacketB implements IMessage{

	private boolean isActive;
	private int playerID;
	
	
	public InventoryPacketB(){}
	public InventoryPacketB(EntityPlayer player){
		
		this.playerID = player.getEntityId();
		
		
	}
	
	@Override
	public void fromBytes(ByteBuf buf) {
		this.playerID = buf.readInt();
		this.isActive = buf.readBoolean();	
		
	}
	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(this.playerID);
		buf.writeBoolean(this.isActive);
		
	}
	
	//-----------------------------------------------------------------------------------------------

		public static class MarkHandler10 implements IMessageHandler<InventoryPacketB, IMessage > {

			@Override
			public IMessage onMessage(final InventoryPacketB message, MessageContext ctx) {
				IThreadListener ThreadListener = Minecraft.getMinecraft();
						ThreadListener.addScheduledTask(new Runnable() {
							@Override
			                public void run() {
								final EntityPlayer player = (EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.playerID);
								
								Container inv = player.openContainer;
								if(inv instanceof MarkContainerInv){
									 MarkContainerInv inventory = (MarkContainerInv) inv;
								
								 }
								
							}
			
			
						});
						return null;
			
			}
			
		}

}
