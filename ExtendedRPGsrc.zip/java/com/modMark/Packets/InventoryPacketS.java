package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Crafting.MarkContainerInv;
import com.modMark.Crafting.MarkInventory;
import com.modMark.Item_Block.TileEntity.TECraftingTable;
import com.modMark.Item_Block.TileEntity.TETrap;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IThreadListener;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class InventoryPacketS implements IMessage {

	private ItemStack stack;
	private int CraftVar;
	private String PlayerID;
	private ItemStack ingredient1;
	private ItemStack ingredient2;
	private ItemStack ingredient3;

	
	public InventoryPacketS(){}
	public InventoryPacketS(ItemStack s, int CrVar, EntityPlayer Playerid, ItemStack[] st){
		
		this.stack = s;
		this.CraftVar = CrVar;
		this.PlayerID = Playerid.getUniqueID().toString();
		this.ingredient1 = st[0];
		this.ingredient2 = st[1];
		this.ingredient3 = st[2];
		
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		
		this.stack = ByteBufUtils.readItemStack(buf);
		this.CraftVar = buf.readInt();
		this.PlayerID = ByteBufUtils.readUTF8String(buf);
		this.ingredient1 = ByteBufUtils.readItemStack(buf);
		this.ingredient2 = ByteBufUtils.readItemStack(buf);
		this.ingredient3 = ByteBufUtils.readItemStack(buf);
		
		
		
	}
	@Override
	public void toBytes(ByteBuf buf) {
		
		ByteBufUtils.writeItemStack(buf, this.stack);
		buf.writeInt(this.CraftVar);
		ByteBufUtils.writeUTF8String(buf, this.PlayerID);
		ByteBufUtils.writeItemStack(buf, this.ingredient1);
		ByteBufUtils.writeItemStack(buf, this.ingredient2);
		ByteBufUtils.writeItemStack(buf, this.ingredient3);
		
	}
	
	//-----------------------------------------------------------------------------------------------

	public static class MarkHandler11 implements IMessageHandler<InventoryPacketS, IMessage > {
		
		@Override
		public IMessage onMessage(final InventoryPacketS message, MessageContext ctx) {
			IThreadListener ThreadListener = (WorldServer) ctx.getServerHandler().playerEntity.worldObj;
					ThreadListener.addScheduledTask(new Runnable() {
						@Override
		                public void run() {
							
							EntityPlayer player = (EntityPlayer) FMLCommonHandler.instance().getMinecraftServerInstance().getEntityFromUuid(UUID.fromString(message.PlayerID));
						
							World world = ctx.getServerHandler().playerEntity.worldObj;
							
							Container inv = player.openContainer;
							if(inv instanceof MarkContainerInv){
								 MarkContainerInv inventory = (MarkContainerInv) inv;
							
							inventory.setCraftStackValue(message.CraftVar);
							inventory.Showcase.setInventorySlotContents(18, message.stack);
							inventory.setIngredientList(message.ingredient1, message.ingredient2, message.ingredient3);
							
							
							 }
						}
						
		
	});
					return null;
		}	
}
}

