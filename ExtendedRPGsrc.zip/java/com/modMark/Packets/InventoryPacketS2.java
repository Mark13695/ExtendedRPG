package com.modMark.Packets;

import java.util.UUID;

import com.modMark.Crafting.MarkContainerInv;
import com.modMark.Crafting.MarkInventory;
import com.modMark.Item_Block.TileEntity.TECraftingTable;
import com.modMark.Item_Block.TileEntity.TETrap;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IThreadListener;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class InventoryPacketS2 implements IMessage {

	
	private String PlayerID;
	

	
	public InventoryPacketS2(){}
	public InventoryPacketS2(EntityPlayer Playerid){
		
		this.PlayerID = Playerid.getUniqueID().toString();
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {

		this.PlayerID = ByteBufUtils.readUTF8String(buf);

	}
	@Override
	public void toBytes(ByteBuf buf) {
		
		ByteBufUtils.writeUTF8String(buf, this.PlayerID);
	
	}
	
	//-----------------------------------------------------------------------------------------------

	public static class MarkHandler12 implements IMessageHandler<InventoryPacketS2, IMessage > {
		
		@Override
		public IMessage onMessage(final InventoryPacketS2 message, MessageContext ctx) {
			IThreadListener ThreadListener = (WorldServer) ctx.getServerHandler().playerEntity.worldObj;
					ThreadListener.addScheduledTask(new Runnable() {
						@Override
		                public void run() {
							
							EntityPlayer player = (EntityPlayer) FMLCommonHandler.instance().getMinecraftServerInstance().getEntityFromUuid(UUID.fromString(message.PlayerID));
						
							World world = ctx.getServerHandler().playerEntity.worldObj;
							
							Container inv = player.openContainer;
							if(inv instanceof MarkContainerInv){
								 MarkContainerInv inventory = (MarkContainerInv) inv;
							
								 inventory.Craft();
							
							 }
						}
						
		
	});
					return null;
		}	
}
}

