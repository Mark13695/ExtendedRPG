package com.modMark.Packets;

import com.modMark.Combat.MarkFoodStats;
import com.modMark.Gui.GuiCraftingTable;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.IThreadListener;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketHUD implements IMessage {
	
	private int foodLevel;
	private int PlayerID;
	
	public PacketHUD(){}
	public PacketHUD(int Food, EntityPlayer player){
		
		this.foodLevel = Food;
		this.PlayerID = player.getEntityId();
		
	}
	

	@Override
	public void fromBytes(ByteBuf buf) {
		this.PlayerID = buf.readInt();
		this.foodLevel = buf.readInt();
	}

	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(this.PlayerID);
		buf.writeInt(this.foodLevel);
	}
	
	//-----------------------------------------------------------------------------------------------

		public static class MarkHandler14 implements IMessageHandler<PacketHUD, IMessage > {

			@Override
			public IMessage onMessage(final PacketHUD message, MessageContext ctx) {
				IThreadListener ThreadListener = Minecraft.getMinecraft();
						ThreadListener.addScheduledTask(new Runnable() {
							@Override
			                public void run() {
								final EntityPlayer player = (EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.PlayerID);
								
								if(player.getFoodStats() instanceof MarkFoodStats){
					 
									((MarkFoodStats)player.getFoodStats()).setFoodLevel2(message.foodLevel);
								}
						}});
				return null;
			}

		}

}
