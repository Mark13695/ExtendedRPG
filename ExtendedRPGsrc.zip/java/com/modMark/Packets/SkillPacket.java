package com.modMark.Packets;

import com.modMark.Gui.GuiHiscoreList;
import com.modMark.Gui.GuiStatlist;
import com.modMark.Main.MainRegistry;
import com.modMark.Skill.MarkData;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.IThreadListener;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class SkillPacket implements IMessage{

	private int ID;
	private int[] XP = new int[35];
	
	public SkillPacket() {}
	public SkillPacket(int[] s, EntityPlayer player){
		
		this.ID = player.getEntityId();
		this.XP = s;
		
		
		
		
	}
	
	
	@Override
	public void fromBytes(ByteBuf buf) {
		
		for (int k = 0; k < 35; k++){
			
			this.XP[k] = buf.readInt();
			
		}
		this.ID = buf.readInt();
		
	}

	@Override
	public void toBytes(ByteBuf buf) {
		
		for (int j = 0; j < 35; j++){
			
			buf.writeInt(this.XP[j]);
			}
			buf.writeInt(this.ID);
		
	}


//-----------------------------------------------------------------------------------------------

public static class MarkHandler implements IMessageHandler<SkillPacket, IMessage > {

	@Override
	public IMessage onMessage(final SkillPacket message, MessageContext ctx) {
		IThreadListener ThreadListener = Minecraft.getMinecraft();
				ThreadListener.addScheduledTask(new Runnable() {
					@Override
	                public void run() {
						final EntityPlayer player = (EntityPlayer) Minecraft.getMinecraft().theWorld.getEntityByID(message.ID);
						
						
						MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
						GuiStatlist.XP = message.XP;
						GuiHiscoreList.XP_OWN = message.XP;
						
						
						
	                    
	                }
				});
		return null;
	}

}
}
