package com.modMark.Proxy;

import com.modMark.Combat.EntityOpalShot;
import com.modMark.Combat.EventHandlerHUD;
import com.modMark.Combat.RenderOpalShot;
import com.modMark.Gui.GuiHUDBars;
import com.modMark.Item_Block.MarkModelRender;
import com.modMark.Main.MainRegistry;
import com.modMark.Main.MarkKeyBindings;
import com.modMark.Mob.EntitySalaBlue;
import com.modMark.Mob.EntitySalaCommon;
import com.modMark.Mob.EntitySalaDesert;
import com.modMark.Mob.EntitySalaGreen;
import com.modMark.Mob.EntitySalaRed;
import com.modMark.Mob.ModelSalamander;
import com.modMark.Mob.RenderSalaBlue;
import com.modMark.Mob.RenderSalaCommon;
import com.modMark.Mob.RenderSalaDesert;
import com.modMark.Mob.RenderSalaGreen;
import com.modMark.Mob.RenderSalaRed;

import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.renderer.entity.RenderCow;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ClientProxy extends CommonProxy {
	
	private static GuiHUDBars hud;
	
	@Override
    public void preInit(FMLPreInitializationEvent event) {
        super.preInit(event);
        MarkModelRender.INSTANCE.RegistryFluid();
        MinecraftForge.EVENT_BUS.register(new MarkKeyBindings());
        this.registerRenderers();
        MarkKeyBindings.init();
        
    }

    @Override
    public void init(FMLInitializationEvent event) {
        super.init(event);
        MarkModelRender.INSTANCE.init();
    }

    @Override
    public void postInit(FMLPostInitializationEvent event) {
        super.postInit(event);
        this.RegisterEventHUD();
    }
    public static void RegisterEventHUD(){
    	 hud = new GuiHUDBars(Minecraft.getMinecraft());
         MinecraftForge.EVENT_BUS.register(new EventHandlerHUD(hud, Minecraft.getMinecraft()));
    
    }
    
    public void registerRenderers(){
    	RenderingRegistry.registerEntityRenderingHandler(EntitySalaCommon.class, RenderSalaCommon::new);
    	RenderingRegistry.registerEntityRenderingHandler(EntitySalaDesert.class, RenderSalaDesert::new);
    	RenderingRegistry.registerEntityRenderingHandler(EntitySalaGreen.class, RenderSalaGreen::new);
    	RenderingRegistry.registerEntityRenderingHandler(EntitySalaRed.class, RenderSalaRed::new);
    	RenderingRegistry.registerEntityRenderingHandler(EntitySalaBlue.class, RenderSalaBlue::new);
    	RenderingRegistry.registerEntityRenderingHandler(EntityOpalShot.class, RenderOpalShot::new);
    	
    }
    
    
}
