package com.modMark.Refer;

public class ReferenceStrings {
	
	public static final String MODID = "mark13695";
	public static final String NAME = "Extended RPG";
	public static final String VERSION = "0.11.5";
	
	
	
	//important
	//gradlew.bat build
	
	//full important tutorials: http://www.minecraftforge.net/forum/index.php?topic=36887.0
}
