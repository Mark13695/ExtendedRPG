package com.modMark.Skill;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.modMark.Combat.MarkFoodStats;
import com.modMark.Combat.MobData;
import com.modMark.Crafting.MarkContainer;
import com.modMark.Crafting.MarkInventory;
import com.modMark.Gui.GuiHUDBars;
import com.modMark.Gui.GuiInventory2;
import com.modMark.Gui.IGuiHandlerMark;
import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.MarkItems;
import com.modMark.Item_Block.Block.BlockGemOres;
import com.modMark.Item_Block.Block.MarkCraftingTable;
import com.modMark.Item_Block.Block.MarkFullTrap;
import com.modMark.Item_Block.Block.MarkHerbCrops;
import com.modMark.Item_Block.Block.MarkOre;
import com.modMark.Item_Block.Block.MarkTrap;
import com.modMark.Item_Block.TileEntity.TETrap;
import com.modMark.Main.MainRegistry;
import com.modMark.Mob.EntitySalaBlue;
import com.modMark.Mob.EntitySalaCommon;
import com.modMark.Mob.EntitySalaDesert;
import com.modMark.Mob.EntitySalaGreen;
import com.modMark.Mob.EntitySalaRed;
import com.modMark.Packets.CraftingPacketA;
import com.modMark.Packets.InventoryPacketA;
import com.modMark.Packets.SkillPacket;
import com.modMark.Refer.ReferenceStrings;

import akka.actor.FSM.State;
import ibxm.Player;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.BlockNewLeaf;
import net.minecraft.block.BlockOldLeaf;
import net.minecraft.block.BlockPlanks;
import net.minecraft.block.BlockStone;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityMooshroom;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntityRabbit;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.FoodStats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.fixes.EntityHealth;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.EntityEvent.EntityConstructing;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.BreakSpeed;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteract;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.LeftClickBlock;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickBlock;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickItem;
import net.minecraftforge.event.terraingen.SaplingGrowTreeEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.event.world.BlockEvent.BreakEvent;
import net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemCraftedEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemSmeltedEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent;
import scala.reflect.internal.Trees.ThisSubstituter;



public class EventHandlerMark {
	
	public boolean CanUseTool = true;
	public boolean CanBreak = true;
	

	 @SubscribeEvent
	public void onAttachCapability(AttachCapabilitiesEvent.Entity event)
	    {
	        if(event.getEntity() instanceof EntityPlayer)
	        {
	            event.addCapability(new ResourceLocation(ReferenceStrings.MODID + ":ModMark136Data"), new MarkData((EntityPlayer) event.getEntity()));
	        }
	        else if(event.getEntity() instanceof EntityLiving){
	        	event.addCapability(new ResourceLocation(ReferenceStrings.MODID + ":ModMark136MobData"), new MobData((EntityLiving)event.getEntity()));
	        }
	    }
	
	@SubscribeEvent
	public void onEntityJoinWorld(EntityJoinWorldEvent event) {
		event.setCanceled(false);
		
		if (event.getEntity() instanceof EntityPlayer && event.getEntity() != null) {
			EntityPlayer player = (EntityPlayer) event.getEntity();
			MarkData pl = player.getCapability(MainRegistry.ModMark136Data, null);
			
			pl.RequestingSync();
			
			if(!(player.getFoodStats() instanceof MarkFoodStats)){
			ObfuscationReflectionHelper.setPrivateValue(EntityPlayer.class,	(EntityPlayer) player, new MarkFoodStats(),	"foodStats", "field_71100_bB");
			}
			
	        if(event.getEntity().getCapability(MainRegistry.ModMark136Data, null) != null){
	        	MarkData p = event.getEntity().getCapability(MainRegistry.ModMark136Data, null);
	        	if(p.XP != null){
				p.addXp(8, 0);
				p.syncSkill();
				p.setHpFromLevel(true);
	        	}
	        	else{
	        		System.out.println("XP array does'nt exist");
	        	}
				
			}
	       
	    } 
		else if(!event.getWorld().isRemote && event.getEntity() instanceof EntityLiving && event.getEntity() != null){
			
			EntityLiving Li = (EntityLiving)event.getEntity();
			
		        if(Li.getCapability(MainRegistry.ModMark136MobData, null) != null){
		        	MobData m = Li.getCapability(MainRegistry.ModMark136MobData, null);
		        	if(m.Cb == 0){
		        		if(Li instanceof EntityZombie || Li instanceof EntitySkeleton || Li instanceof EntitySpider){
		        			int a = 20;
		        			int bpre = (new Random()).nextInt(10000);
		        			int b = bpre == 0 ? (new Random()).nextInt(56) : (bpre < 10 ? (new Random()).nextInt(51) :
		        				(bpre < 100 ? (new Random()).nextInt(41) : (bpre < 1000 ? (new Random()).nextInt(31) : (new Random()).nextInt(21))));
		        			
		        		m.setCombat(a + b);
		        		
		        			
		        		}
		        		else if(Li instanceof EntityWolf){
		        			int a = 1;
		        			int bpre = (new Random()).nextInt(10000);
		        			int b = bpre == 0 ? (new Random()).nextInt(29) : (bpre < 10 ? (new Random()).nextInt(26) :
		        				(bpre < 100 ? (new Random()).nextInt(24) : (bpre < 1000 ? (new Random()).nextInt(19) : (new Random()).nextInt(14))));
		        			
		        		m.setCombat(a + b);
		        		
		        		}
		        		else if(Li instanceof EntityCreeper){
		        			event.setCanceled(true);
		        		}
		        		else{
		        		m.setCombat(1);
		        		
		        		}
		        	}
		        }
		        } 
		
		
	    
	}
	
	
	
	@SubscribeEvent
	public void onPlayerLogIn(PlayerLoggedInEvent event) {
		EntityPlayer player = (EntityPlayer) event.player;
		if(MarkData.OfflinePlayers.contains(player.getName())){
		int idx = MarkData.OfflinePlayers.indexOf(player.getName());
		MarkData.OfflinePlayers.remove(idx);
		MarkData.offlineXP.remove(idx);
		MarkData.offlineToT.remove(idx);
		System.out.println("Player removed from offline Register");
		}
		else{
			System.out.println("No Player Found in offline Register! new player?");
			
		}
	}
	@SubscribeEvent
	public void onPlayerLogout(PlayerLoggedOutEvent event) {
		EntityPlayer player = (EntityPlayer) event.player;
		MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
	
		MarkData.OfflinePlayers.add(player.getName());
		MarkData.offlineXP.add(p.getXp());
		MarkData.offlineToT.add(p.getTotalLvl(p));
		System.out.println("Player Added to offline Register");
	}
	
	
	@SubscribeEvent
	public void onPlayerCloned(PlayerEvent.Clone event) {
	    NBTTagCompound compound = new NBTTagCompound();
	    System.out.println("called!");
	    event.getOriginal().getCapability(MainRegistry.ModMark136Data, null).serializeNBT();
	    event.getEntityPlayer().getCapability(MainRegistry.ModMark136Data, null).deserializeNBT(compound);
	    event.getEntityPlayer().getCapability(MainRegistry.ModMark136Data, null).XP = event.getOriginal().getCapability(MainRegistry.ModMark136Data, null).XP;
	    event.getEntityPlayer().getCapability(MainRegistry.ModMark136Data, null).setHP(event.getEntityPlayer().getCapability(MainRegistry.ModMark136Data, null).getMaxHP());
	}
	
	@SubscribeEvent
	public void MinExcaWCFarm_Req(BreakSpeed event)
	{
		EntityPlayer p = event.getEntityPlayer();
		MarkData pl = p.getCapability(MainRegistry.ModMark136Data, null);
		MarkHashMaps.BlockHashMaps(pl);
		Block block = event.getState().getBlock();
		int lvl = MarkHashMaps.ToolBlockLevel.get(block) != null ? MarkHashMaps.ToolBlockLevel.get(block) : -1;
		
		if (p.getHeldItemMainhand() != null){
		Item HandItem = p.getHeldItemMainhand().getItem();
		
		
		int Shovel = MarkHashMaps.ShovelTool.get(HandItem) != null ? MarkHashMaps.ShovelTool.get(HandItem) : 0;
		int Axe = MarkHashMaps.AxeTool.get(HandItem) != null ? MarkHashMaps.AxeTool.get(HandItem) : 0;
		int Pickaxe = MarkHashMaps.PickaxeTool.get(HandItem) != null ? MarkHashMaps.PickaxeTool.get(HandItem) : 0;
		int Hoe = MarkHashMaps.HoeTool.get(HandItem) != null ? MarkHashMaps.HoeTool.get(HandItem) : 0;
		int Sword = MarkHashMaps.SwordTool.get(HandItem) != null ? MarkHashMaps.SwordTool.get(HandItem) : 0;
		
		
		int material = MarkHashMaps.SkillMaterial.get(event.getState().getMaterial()) != null ? MarkHashMaps.SkillMaterial.get(event.getState().getMaterial()) : 0;
	
		if (material == 7){
			event.setNewSpeed(Hoe <= lvl ? event.getOriginalSpeed() / 4 : event.getOriginalSpeed());
		}
		else if (material == 8){
			event.setNewSpeed(Pickaxe <= lvl ? event.getOriginalSpeed() / 4 : event.getOriginalSpeed());
		}
		else if (material == 10){
			event.setNewSpeed(Shovel <= lvl ? event.getOriginalSpeed() / 4 : event.getOriginalSpeed());
		}
		else if (material == 11){
			event.setNewSpeed(Axe <= lvl ? event.getOriginalSpeed() / 4 : event.getOriginalSpeed());
		}
		else{
			event.setNewSpeed(lvl != -1 ? event.getOriginalSpeed() / 4 : event.getOriginalSpeed());
		}
		}
		else{
			event.setNewSpeed(lvl != -1 ? event.getOriginalSpeed() / 4 : event.getOriginalSpeed());
		}
		if(!this.CanBreak || !this.CanUseTool){
			event.setCanceled(true);
		}
		else{
			event.setCanceled(false);;
		}
		
	}
			
	
	@SubscribeEvent
	public void ToolEvent(HarvestDropsEvent event)
	{
		if (event.getHarvester() != null){
		EntityPlayer p = event.getHarvester();
		MarkData pl = p.getCapability(MainRegistry.ModMark136Data, null);
		MarkHashMaps.BlockHashMaps(pl);
		
		Block block = event.getState().getBlock();
		
		if(block == Blocks.LEAVES || block == Blocks.LEAVES2){	
				event.getDrops().clear();
		}
		
		
		
		
		if(block == Blocks.IRON_ORE){
			
			event.getDrops().clear();
			event.getDrops().add(new ItemStack(MarkBlocks.OreIron.getDefaultState().withProperty(MarkOre.Natural, false).getBlock(), 1));
			
		}
		if(block == Blocks.GOLD_ORE){
			
				event.getDrops().clear();
				event.getDrops().add(new ItemStack(MarkBlocks.OreGold.getDefaultState().withProperty(MarkOre.Natural, false).getBlock(), 1));
				
			
		}
		int lvl = MarkHashMaps.ToolBlockLevel.get(block) != null ? MarkHashMaps.ToolBlockLevel.get(block) : -1;
		if(p.getHeldItemMainhand() != null){
		Item HandItem = p.getHeldItemMainhand().getItem();
		
		
		int Shovel = MarkHashMaps.ShovelTool.get(HandItem) != null ? MarkHashMaps.ShovelTool.get(HandItem) : 0;
		int Axe = MarkHashMaps.AxeTool.get(HandItem) != null ? MarkHashMaps.AxeTool.get(HandItem) : 0;
		int Pickaxe = MarkHashMaps.PickaxeTool.get(HandItem) != null ? MarkHashMaps.PickaxeTool.get(HandItem) : 0;
		int Hoe = MarkHashMaps.HoeTool.get(HandItem) != null ? MarkHashMaps.HoeTool.get(HandItem) : 0;
		int Sword = MarkHashMaps.SwordTool.get(HandItem) != null ? MarkHashMaps.SwordTool.get(HandItem) : 0;
		
		
		int material = MarkHashMaps.SkillMaterial.get(event.getState().getMaterial()) != null ? MarkHashMaps.SkillMaterial.get(event.getState().getMaterial()) : 0;
		
		if (material == 7){
			event.setDropChance(Hoe < lvl ? 0.0F : 1.0F);
		}
		else if (material == 8){
			event.setDropChance(Pickaxe < lvl ? 0.0F : 1.0F);
		}
		else if (material == 10){
			event.setDropChance(Shovel < lvl ? 0.0F : 1.0F);
		}
		else if (material == 11){
			event.setDropChance(Axe < lvl ? 0.0F : 1.0F);
		}
		else{
			event.setDropChance(lvl != -1 ? 0.0F : 1.0F);
		}
		}
		else{
			event.setDropChance(lvl != -1 ? 0.0F : 1.0F);
			
		}
		}
	}
	
	@SubscribeEvent
	public void MinExcaWC_XP(BreakEvent event){
		
		
		MarkData p = event.getPlayer().getCapability(MainRegistry.ModMark136Data, null);
		Material material = event.getState().getMaterial();
		Block block = event.getState().getBlock();
		MarkHashMaps.BlockHashMaps(p);
		Integer a = MarkHashMaps.SkillMaterial.get(material);
		Integer b = MarkHashMaps.TaskBlockXP2.get(event.getState().getBlock()) == null ? MarkHashMaps.TaskBlockXP.get(event.getState()) : MarkHashMaps.TaskBlockXP2.get(event.getState().getBlock());
		int SkillID;
		int gXp; 
		boolean isBlockOwner = true;
		
		if(a == null){
			SkillID = 8;
		}
		else{
			SkillID = a;
		}
		
		
		if(block instanceof MarkFullTrap || block instanceof MarkTrap){
			isBlockOwner = false;
			TileEntity tileentity = event.getWorld().getTileEntity(event.getPos());
			 if (tileentity instanceof TETrap) {
			TETrap TE = (TETrap) tileentity;
			if(TE.getPlayer() != null || event.getPlayer() != null){
			isBlockOwner = TE.getPlayer() == event.getPlayer().getUniqueID();
			}
		}
			
	}
		if(b != null){
			if(isBlockOwner){
				gXp = b;
			}
			else{
				gXp = b / 8;
			}
			
			p.addXp(SkillID, gXp);
		}
		
		
		if (block == Blocks.TALLGRASS){
			Random random = new Random();
			int Ra = random.nextInt(50000);
			
			World world = event.getWorld();
			double x = event.getPos().getX();
			double y = event.getPos().getY();
			double z = event.getPos().getZ();
			if(Ra == 0){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.NetheriteBar, 1)));
			}
			else if(Ra == 1 || Ra == 2){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.GemSiam, 1)));
			}
			else if(Ra == 3 || Ra == 4){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Leather60, 2)));
			}
			else if(Ra >= 5 && Ra <= 9){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.DIAMOND, 1)));
			}
			else if(Ra >= 10 && Ra <= 19){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.GemAmethyst, 1)));
			}
			else if(Ra >= 20 && Ra <= 29){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Leather40, 2)));
			}
			else if(Ra >= 30 && Ra <= 49){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.IRON_SWORD, 1)));
			}
			else if(Ra >= 50 && Ra <= 69){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.IRON_PICKAXE, 1)));
			}
			else if(Ra >= 70 && Ra <= 89){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.IRON_AXE, 1)));
			}
			else if(Ra >= 90 && Ra <= 109){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.IRON_SHOVEL, 1)));
			}
			else if(Ra >= 110 && Ra <= 129){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.GOLD_INGOT, 2)));
			}
			else if(Ra >= 130 && Ra <= 149){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.IRON_INGOT, 3)));
			}
			else if(Ra >= 150 && Ra <= 1149){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.AnethSeed, 1)));
			}
			else if(Ra >= 1150 && Ra <= 2149){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.RomarinSeed, 1)));
			}
			else if(Ra >= 2150 && Ra <= 2949){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.RaifortSeed, 1)));
			}
			else if(Ra >= 2950 && Ra <= 3649){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.CeleriSeed, 1)));
			}
			else if(Ra >= 3650 && Ra <= 4249){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.SarrietteSeed, 1)));
			}
			else if(Ra >= 4250 && Ra <= 4649){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.ArmoiseSeed, 1)));
			}
			else if(Ra >= 4650 && Ra <= 4849){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.CerfeuilSeed, 1)));
			}
			else if(Ra >= 4850 && Ra <= 4949){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.EstragonSeed, 1)));
			}
			else if(Ra >= 4950 && Ra <= 5199){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.OnionSeed, 1)));
			}
			else if(Ra >= 5200 && Ra <= 6199){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Herb, 1, 0)));
			}
			else if(Ra >= 6200 && Ra <= 7199){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Herb, 1, 2)));
			}
			else if(Ra >= 7200 && Ra <= 7999){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Herb, 1, 4)));
			}
			else if(Ra >= 8000 && Ra <= 8699){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Herb, 1, 6)));
			}
			else if(Ra >= 8700 && Ra <= 9299){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Herb, 1, 8)));
			}
			else if(Ra >= 9300 && Ra <= 9699){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Herb, 1, 10)));
			}
			else if(Ra >= 9700 && Ra <= 9899){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Herb, 1, 12)));
			}
			else if(Ra >= 9900 && Ra <= 9999){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.Herb, 1, 14)));
			}
			else if(Ra >= 10000 && Ra <= 11699){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.CommonCottonSeed, 1)));
			}
			else if(Ra >= 11700 && Ra <= 11999){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkItems.GreenCottonSeed, 1)));
			}
			else if(Ra >= 12000 && Ra <= 12999){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.STRING, 1)));
			}
			else if(Ra >= 13000 && Ra <= 13999){
				EntityRabbit rabbit = new EntityRabbit(world);
				rabbit.setPosition(x, y, z);
				event.getWorld().spawnEntityInWorld(rabbit);
			}
			}
		else if(block == Blocks.LEAVES || block == Blocks.LEAVES2){
			
			Random random = new Random();
		
		
		
		World world = event.getWorld();
		double x = event.getPos().getX();
		double y = event.getPos().getY();
		double z = event.getPos().getZ();
		
		if(event.getState() == Blocks.LEAVES.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.OAK)){
		if (random.nextInt(40) < 2){
			event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkBlocks.LogOak_Sapling, 1)));	
		}
		if (random.nextInt(200) == 0){
			event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.APPLE, 1)));	
			
		}
		}
		else if(event.getState() == Blocks.LEAVES.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.SPRUCE)){
		if (random.nextInt(40) < 2){
			event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkBlocks.LogSpruce_Sapling, 1)));	
		}
		}
		else if(event.getState() == Blocks.LEAVES.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.BIRCH)){
		if (random.nextInt(40) < 2){
			event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkBlocks.LogBirch_Sapling, 1)));	
		}
		}
		else if(event.getState() == Blocks.LEAVES.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.JUNGLE)){
			if (random.nextInt(40) == 0){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkBlocks.LogJungle_Sapling, 1)));	
			}
			}
		else if(event.getState() == Blocks.LEAVES2.getDefaultState().withProperty(BlockNewLeaf.VARIANT, BlockPlanks.EnumType.ACACIA)){
			if (random.nextInt(40) < 2){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkBlocks.LogAcacia_Sapling, 1)));	
			}
			}
		else if(event.getState() == Blocks.LEAVES2.getDefaultState().withProperty(BlockNewLeaf.VARIANT, BlockPlanks.EnumType.DARK_OAK)){
			if (random.nextInt(40) < 2){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(MarkBlocks.LogDarkOak_Sapling, 1)));	
			}
			if (random.nextInt(200) == 0){
				event.getWorld().spawnEntityInWorld(new EntityItem(world, x, y, z, new ItemStack(Items.APPLE, 1)));	
			}
			}
		}
		
		
			p.getXp();
			p.syncSkill();	
		

		}
	
	@SubscribeEvent
	public void PlayerInteractEvent(PlayerInteractEvent event){
		
		if(event.getFace() != null && event.getPos() != null){
		
			EntityPlayer player =  event.getEntityPlayer();
			MarkData p = event.getEntityPlayer().getCapability(MainRegistry.ModMark136Data, null);
			if(player instanceof EntityPlayerMP){
			if(event.getItemStack() != null){
			Item item = event.getItemStack().getItem();
			
		//Both Clicks:
			
		//Stone
			
		if(item == Items.STONE_PICKAXE){this.CanUseTool = p.requireLvl(8, 10, 1);}
		else if(item == Items.STONE_SHOVEL){this.CanUseTool = p.requireLvl(10, 10, 1); }
		else if(item == Items.STONE_AXE){this.CanUseTool = p.requireLvl(11, 10, 1); }
		//Iron
		else if(item == Items.IRON_PICKAXE){this.CanUseTool = p.requireLvl(8, 20, 1); }
		else if(item == Items.IRON_SHOVEL){this.CanUseTool = p.requireLvl(10, 20, 1); }
		else if(item == Items.IRON_AXE){this.CanUseTool = p.requireLvl(11, 20, 1); }
		//Gold
		else if(item == Items.GOLDEN_PICKAXE){this.CanUseTool = p.requireLvl(8, 30, 1); }
		else if(item == Items.GOLDEN_SHOVEL){this.CanUseTool = p.requireLvl(10, 30, 1); }
		else if(item == Items.GOLDEN_AXE){this.CanUseTool = p.requireLvl(11, 30, 1); }
		//Diamond
		else if(item == Items.DIAMOND_PICKAXE){this.CanUseTool = p.requireLvl(8, 40, 1); }
		else if(item == Items.DIAMOND_SHOVEL){this.CanUseTool = p.requireLvl(10, 40, 1); }
		else if(item == Items.DIAMOND_AXE){this.CanUseTool = p.requireLvl(11, 40, 1); }
		else{this.CanUseTool = true;}
		
			}else{this.CanUseTool = true;}
			}	
		}
		
			
			

		}	
	
	
	@SubscribeEvent
	public void PlayerInteractGathering(LeftClickBlock event){
		if(event.getFace() != null && event.getPos() != null){
		EntityPlayer player = event.getEntityPlayer();
		MarkData p = event.getEntityPlayer().getCapability(MainRegistry.ModMark136Data, null);
		if(player instanceof EntityPlayerMP){
			
			Block block = event.getWorld().getBlockState(event.getPos()).getBlock();
			
			
			
			
			Material material = event.getWorld().getBlockState(event.getPos()).getMaterial();

			MarkHashMaps.BlockHashMaps(p);
			
			Integer	a = MarkHashMaps.SkillMaterial.get(material);
			Integer b = MarkHashMaps.TaskBlockLevel.get(block);
			int SkillID;
			int ReqLvl; 
			boolean isBlockOwner = true;
			
			
			
			if(a == null){
				SkillID = 8;
			}
			else{
				SkillID = a;
			}
			if(b == null){
				ReqLvl = 0;
			}
			else{
				ReqLvl = b;
			}
			
			if(block instanceof MarkFullTrap || block instanceof MarkTrap){
				TileEntity tileentity = event.getWorld().getTileEntity(event.getPos());
				 if (tileentity instanceof TETrap) {
				TETrap TE = (TETrap) tileentity;
				if(TE.getPlayer() != null || !TE.getPlayer().toString().equals("null") || player != null){
				isBlockOwner = TE.getPlayer().equals(player.getUniqueID());
				System.out.println("" + TE.getPlayer().toString() + " / " + player.getUniqueID());
				}
			}
				
		}
			if(isBlockOwner){
			this.CanBreak = p.requireLvl(SkillID, ReqLvl, 0);
			}
			else{
				if (block instanceof MarkFullTrap || block instanceof MarkTrap){
				this.CanBreak = false;
				TextComponentString component = new TextComponentString(TextFormatting.RED + "This is not Your Trap!");
				player.addChatComponentMessage(component);
				}
				else{
					this.CanBreak = p.requireLvl(SkillID, ReqLvl, 0);
				}
			}
}}}
	
	@SubscribeEvent
	public void PlayerInteractRightClicks(RightClickBlock event){
		
		EntityPlayer player =  event.getEntityPlayer();
		MarkData p = event.getEntityPlayer().getCapability(MainRegistry.ModMark136Data, null);
		Block block = event.getWorld().getBlockState(event.getPos()).getBlock();
		
			
        	
        	
        	
        
		if(event.getItemStack() != null){
		ItemStack stack = event.getItemStack();
		Item item = event.getItemStack().getItem();
		
		Random ran = new Random();
		
		if(event.getPos() != null){
		
		
		
		if (p != null){
		if (item == Items.BOOK){
			if (block == MarkBlocks.Script01){	if(p.requireLvl(13, 1, 2) == true){
				p.addXp(13, 5); 
				stack.stackSize--;
				player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW1, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				if(R < 15){event.getWorld().setBlockState(event.getPos(), Blocks.STONE.getDefaultState());}}}
			
			else if (block == MarkBlocks.Script05){ if(p.requireLvl(13, 5, 2) == true){
				p.addXp(13, 8);
				stack.stackSize--;
				player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW5, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				if(R < 15){event.getWorld().setBlockState(event.getPos(), Blocks.STONE.getDefaultState());}}}
			
			else if (block == MarkBlocks.Script10){	if(p.requireLvl(13, 10, 2) == true){
				p.addXp(13, 12);
				stack.stackSize--;
				player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW10, 1));
				int R = ran.nextInt(100);
				System.out.println("Random Number: " + R);
				if(R < 16){event.getWorld().setBlockState(event.getPos(), Blocks.STONE.getDefaultState());}}}
			
			else if (block == MarkBlocks.Script15){ 	if(p.requireLvl(13, 15, 2) == true){
				p.addXp(13, 15);
				stack.stackSize--;
				player.inventory.addItemStackToInventory(new ItemStack(MarkItems.BookW15, 1));
				int R = ran.nextInt(100); 
				System.out.println("Random Number: " + R);
				if(R < 17){event.getWorld().setBlockState(event.getPos(), Blocks.STONE.getDefaultState());}}}
			
			p.syncSkill();
			
		}
		if (block == Blocks.FARMLAND || block == Blocks.DIRT || block == Blocks.GRASS){
		
		if (stack == new ItemStack(MarkBlocks.LogAcacia_Sapling, 1 )){event.setCanceled(!p.requireLvl(7, 20, 5));} 
		else if (stack == new ItemStack(MarkBlocks.LogDarkOak_Sapling, 1 )){event.setCanceled(!p.requireLvl(7, 20, 5));}}
		if (block == MarkBlocks.EnrichedGrass || block == Blocks.DIRT || block == Blocks.FARMLAND){
		if (item == Item.getItemFromBlock(MarkBlocks.LogYew_Sapling)){event.setCanceled(!p.requireLvl(7, 40, 5));}}  
		if (block == Blocks.SOUL_SAND || block == MarkBlocks.NetherSand){
		if (item == Item.getItemFromBlock(MarkBlocks.LogNetherBranch_Sapling)){event.setCanceled(!p.requireLvl(7, 60, 5));}	}
		if (block == MarkBlocks.CrystSand || block == MarkBlocks.Cyantinian){
		if (item == Item.getItemFromBlock(MarkBlocks.LogCrystWood_Sapling)){event.setCanceled(!p.requireLvl(7, 80, 5));}}
		
		if (block == Blocks.FARMLAND){
		if (item == MarkItems.RomarinSeed){event.setCanceled(!p.requireLvl(7, 5, 5));}
		else if (item == MarkItems.RaifortSeed){event.setCanceled(!p.requireLvl(7, 12, 5));}
		else if (item == MarkItems.CeleriSeed){event.setCanceled(!p.requireLvl(7, 19, 5));}
		else if (item == MarkItems.SarrietteSeed){event.setCanceled(!p.requireLvl(7, 26, 5));}
		else if (item == MarkItems.ArmoiseSeed){event.setCanceled(!p.requireLvl(7, 33, 5));}
		else if (item == MarkItems.CerfeuilSeed){event.setCanceled(!p.requireLvl(7, 40, 5));}
		else if (item == MarkItems.EstragonSeed){event.setCanceled(!p.requireLvl(7, 47, 5));}
		else if (item == MarkItems.NetherweedSeed){event.setCanceled(!p.requireLvl(7, 54, 5));}
		else if (item == MarkItems.FlameweedSeed){event.setCanceled(!p.requireLvl(7, 61, 5));}
		else if (item == MarkItems.BrutalRedSeed){event.setCanceled(!p.requireLvl(7, 68, 5));}
		else if (item == MarkItems.CrystweedSeed){event.setCanceled(!p.requireLvl(7, 75, 5));}
		else if (item == MarkItems.DarkCrystalSeed){event.setCanceled(!p.requireLvl(7, 82, 5));}
		else if (item == MarkItems.BrutalBlueSeed){event.setCanceled(!p.requireLvl(7, 89, 5));}
		else if (item == MarkItems.AnethSeed){event.setCanceled(!p.requireLvl(7, 1, 5));}
		else if (item == Items.WHEAT){event.setCanceled(!p.requireLvl(7, 1, 5));}
		else if (item == Items.CARROT){event.setCanceled(!p.requireLvl(7, 10, 5));}
		else if (item == Items.POTATO){event.setCanceled(!p.requireLvl(7, 20, 5));}
		else if (item == MarkItems.OnionSeed){event.setCanceled(!p.requireLvl(7, 40, 5));}
		else if (item == MarkItems.TomatoSeed){event.setCanceled(!p.requireLvl(7, 60, 5));}
		else if (item == MarkItems.BlueberrySeed){event.setCanceled(!p.requireLvl(7, 80, 5));}
		else if (item == MarkItems.CommonCottonSeed){event.setCanceled(!p.requireLvl(7, 20, 5));}
		else if (item == MarkItems.GreenCottonSeed){event.setCanceled(!p.requireLvl(7, 40, 5));}
		else if (item == MarkItems.RedCottonSeed){event.setCanceled(!p.requireLvl(7, 60, 5));}
		else if (item == MarkItems.BlueCottonSeed){event.setCanceled(!p.requireLvl(7, 80, 5));} }
		}else{System.out.println("Player is null!");}
		
		
	}else{}}}
	
	
	
	@SubscribeEvent
	public void FoodEvent(RightClickItem event){
		EntityPlayer player = event.getEntityPlayer();
		
		
		
		
	}
	
	@SubscribeEvent
	public void AnimalBreedingEvent(EntityInteract event){
		
		 
		 MarkData p = event.getEntityPlayer().getCapability(MainRegistry.ModMark136Data, null);
		if(event.getItemStack() != null & event.getTarget() != null & event.getEntityPlayer() != null){
			Item hand = event.getItemStack().getItem();
			boolean isMeat = hand == Items.PORKCHOP || hand == Items.COOKED_PORKCHOP || hand == Items.BEEF || hand == Items.COOKED_BEEF || hand == Items.CHICKEN || hand == Items.COOKED_CHICKEN || hand == Items.RABBIT || hand == Items.COOKED_RABBIT || hand == Items.MUTTON || hand == Items.COOKED_MUTTON || hand == Items.ROTTEN_FLESH;
			

			if(event.getTarget() instanceof EntityHorse){
				
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
				if(hand == Items.GOLDEN_APPLE || hand == Items.GOLDEN_CARROT){
					p.addXp(20 + (p.Level[18] * 3), 18);
				}}}
			else if(event.getTarget() instanceof EntitySheep || event.getTarget() instanceof EntityCow || event.getTarget() instanceof EntityMooshroom){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
					if(hand == Items.WHEAT){
						p.addXp(26, 18);
				}}}
			else if(event.getTarget() instanceof EntityPig){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
					if(hand == Items.CARROT || hand == Items.POTATO){
						p.addXp(26, 18);
				}}}
			else if(event.getTarget() instanceof EntityChicken){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
					if(hand == Items.WHEAT_SEEDS || hand == Items.MELON_SEEDS || hand == Items.PUMPKIN_SEEDS){
						p.addXp(26, 18);
				}}}
			else if(event.getTarget() instanceof EntityWolf){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack()) && ((EntityWolf) event.getTarget()).isTamed()){
					if(isMeat){
						p.addXp(26, 8);
				}}}
			else if(event.getTarget() instanceof EntityOcelot) {
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack()) && ((EntityOcelot) event.getTarget()).isTamed()){
					if(hand == Items.FISH){
						p.addXp(26, 18);
				}}}
			else if(event.getTarget() instanceof EntityRabbit){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
					if (hand == Item.getItemFromBlock(Blocks.YELLOW_FLOWER) || hand == Items.CARROT || hand == Items.GOLDEN_CARROT){
						p.addXp(26, 18);
				}}}
			else if(event.getTarget() instanceof EntitySalaCommon){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
					
					if (hand == Items.POTATO){
						if (p.requireLvl(26, 10, 0)){
						p.addXp(26, 27);
						
				}else
				{
					event.setCanceled(true);
					((EntityAnimal) event.getTarget()).resetInLove();
				}
					
					}}}
			else if(event.getTarget() instanceof EntitySalaDesert){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
					
					if (hand == Item.getItemFromBlock(Blocks.CACTUS)){
						if (p.requireLvl(26, 20, 0)){
						p.addXp(26, 40);
					}
						else{
							event.setCanceled(true);
							((EntityAnimal) event.getTarget()).resetInLove();
						}
					
					}}}
			else if(event.getTarget() instanceof EntitySalaGreen){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
					
					if (hand == MarkItems.Onion){
						if (p.requireLvl(26, 40, 0)){
						p.addXp(26, 65);
					}
						else{
						event.setCanceled(true);
						((EntityAnimal) event.getTarget()).resetInLove();
					}
					
					}}}
			else if(event.getTarget() instanceof EntitySalaRed){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
					
					if (hand == MarkItems.Tomato){
						if (p.requireLvl(26, 60, 0)){
						p.addXp(26, 85);
					}
						else{
						event.setCanceled(true);
						((EntityAnimal) event.getTarget()).resetInLove();
					}
					
					}}}
			else if(event.getTarget() instanceof EntitySalaBlue){
				if(!((EntityAgeable) event.getTarget()).isChild() && ((EntityAnimal) event.getTarget()).processInteract(event.getEntityPlayer(), event.getHand(), event.getItemStack())){
					
					if (hand == MarkItems.Blueberry){
						if (p.requireLvl(26, 80, 0)){
						p.addXp(26, 110);
					}
						else{
						event.setCanceled(true);
						((EntityAnimal) event.getTarget()).resetInLove();
					}
					
					}}}
			p.syncSkill();
			}
			
			
			
			
		}
	}
	
		 
	
	

