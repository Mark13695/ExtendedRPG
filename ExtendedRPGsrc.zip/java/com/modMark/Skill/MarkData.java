package com.modMark.Skill;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import com.modMark.Main.MainRegistry;
import com.modMark.Main.MarkAchievements;
import com.modMark.Packets.CombatLvlPacket2;
import com.modMark.Packets.CombatLvlPacket3;
import com.modMark.Packets.CombatLvlPacketHP;
import com.modMark.Packets.HiscorePacketB;
import com.modMark.Packets.HiscorePacketC;
import com.modMark.Packets.SkillPacket;

import net.minecraft.block.Block;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagIntArray;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class MarkData implements ICapabilityProvider, INBTSerializable<NBTTagCompound> {

	/**this field will be used in getXP()*/
public int MainLock = 1;
public boolean LeveledUp;

public static List <String> OfflinePlayers = new ArrayList<>();
public static List<int[]> offlineXP = new ArrayList<int[]>();
public static List<Integer> offlineToT = new ArrayList<>();




	
	
	
	
	
	
	/**The name of the Skill*/
	public String[] SkillName = new String[35]; //head
	/**this field are for calculating the skill levels ect*/
	public int[] Level = new int[35]; //head
	public int[] NextLevel = new int[35]; //head
	public int[] XpNeed = new int[35]; //head
	

	/**Total Level*/
	public int Total;
	public int prevCB;
	public int Combat = 1;
	public int Combat2 = 1;
	public int CurHP;
	public int MaxHP;
	
	
	
	
	
	public static int HSSkillID = 35;
	private long TotXp = 0;
	public EntityPlayer HSPlayerIn;
	
	public int[] XP = new int[35];
	private final EntityPlayer player;
	
	
	/** Ready! */
	public MarkData(EntityPlayer player){
		this.player = player;
		for (int i = 0; i < 35; i++){
			XP[i] = 0;		
	}
	}
	
	
	public static void register()
	{
		CapabilityManager.INSTANCE.register(MarkData.class, new MarkData.Storage(), new MarkData.Factory());
	
	}
	
	
		
	

	@Override
	public boolean hasCapability(Capability<?> capability, EnumFacing facing) {
		
		return MainRegistry.ModMark136Data != null && capability == MainRegistry.ModMark136Data;
	}

	@Override
	public <T> T getCapability(Capability<T> capability, EnumFacing facing) {
		
		if(MainRegistry.ModMark136Data == null){
			
		}
		if(capability != MainRegistry.ModMark136Data){
			
		}
		return MainRegistry.ModMark136Data != null && capability == MainRegistry.ModMark136Data ? (T)this : null;
	}
	
	
	
	public boolean isServerSide() {
	    return player instanceof EntityPlayerMP;
	}
	
	
	
	@Override
	public NBTTagCompound serializeNBT() {
		NBTTagCompound Array = new NBTTagCompound();
		
		Array.setIntArray("Skill136", this.getXp());
		
		
		return Array;
		
	}

	
	@Override
	public void deserializeNBT(NBTTagCompound compound) {
		
			this.setXP(compound.getIntArray("Skill136"));
				
			
	}
	
	public void setHpFromLevel(boolean isSpawning){
		
		int HP = (int)Math.floor(((this.Level[0] * this.Level[5]) / 10 + this.Level[0] * 7 + this.Level[5] *7 + 86) - ( 158 *((( this.Level[0] - 1)+(this.Level[5] - 1)) / 508)));
		this.MaxHP = HP;
		List <EntityPlayerMP> players =  FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().getPlayerList();
		if(isSpawning){
			this.CurHP = HP;
			if(!this.player.worldObj.isRemote){
			for (int i = 0; i < players.size();i++){
				MainRegistry.network.sendTo(new CombatLvlPacketHP(players.get(i),this.CurHP, this.player, this.MaxHP, true, false), players.get(i));
				}
			}
		}
		else{
			if(!this.player.worldObj.isRemote){
			for (int i = 0; i < players.size();i++){
				MainRegistry.network.sendTo(new CombatLvlPacketHP(players.get(i),this.CurHP, this.player, this.MaxHP, false, true), players.get(i));
				}
				}
		}
		
	}
	public void setHP(int hp){
		
		this.CurHP = hp;
		if(this.player.worldObj.isRemote){
			//this.player.onDeath(source);
		}
		List <EntityPlayerMP> players =  FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().getPlayerList();
		if(!this.player.worldObj.isRemote){
		for (int i = 0; i < players.size();i++){
		MainRegistry.network.sendTo(new CombatLvlPacketHP(players.get(i),this.CurHP, this.player, this.MaxHP, false, false), players.get(i));
		}
		}
	}
	public int getHP(){
		return this.CurHP;
	}
	public int getMaxHP(){
		return this.MaxHP;
	}

	public void setXP(int[] Xp){
			
		this.XP = Xp;
	}
	
	public int addXp(int SkillID, int amount){
		MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
		this.setSkillName();
		System.out.println("added " + amount + " XP to " + this.SkillName[SkillID]);
		this.Lvlcalc(p);
		
		//if true, you're level up!
		if((p.XP[SkillID] + amount) >= this.NextLevel[SkillID] && p.XP[SkillID] < this.NextLevel[SkillID] && !player.capabilities.isCreativeMode){
			TextComponentString component = new TextComponentString(TextFormatting.GREEN + "Congratulations! Your Level in " + this.SkillName[SkillID] + " is now " + (this.Level[SkillID]+ 1));
		player.addChatComponentMessage(component);
		p.setAchievement(SkillID);
		if(SkillID == 0 || SkillID == 5){
			this.LeveledUp = true;
		}
		}
		if(!player.capabilities.isCreativeMode){
			
		return this.XP[SkillID] += amount;
		}
		else{ return this.XP[SkillID];}
	}
	
	/**this is to check if the requirement level is high enough to do the action. 
		SkillID = the ID of the skill.	
		reqlvl = the requirement level to do the action.	
		method = the text that will apear*/
	public boolean requireLvl(int SkillID, int reqlvl, int method){
		
		MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
		
		
		
		p.getXp();
		this.setSkillName();
		p.Lvlcalc(p);
		
		
			if (method == 0){
				boolean candothis = p.Level[SkillID] >= reqlvl;
				if(candothis == false){
					if(player instanceof EntityPlayerMP){
					TextComponentString component = new TextComponentString(TextFormatting.RED + "You need " + reqlvl + " " + this.SkillName[SkillID] + " for this");
			player.addChatComponentMessage(component);
					}
				}
				
			return candothis;
			}
			
			if (method == 1){
				boolean candothis = p.Level[SkillID] >= reqlvl;
				
			if(candothis == false){
				if(player instanceof EntityPlayerMP){
				TextComponentString component = new TextComponentString(TextFormatting.RED + "You need a level of " + reqlvl + " " + this.SkillName[SkillID] + " to use this tool");
			player.addChatComponentMessage(component);
				}
			}
			
			return candothis;
			}
			
			if (method == 2){
				boolean candothis = p.Level[SkillID] >= reqlvl;
				if(candothis == false){
					if(player instanceof EntityPlayerMP){
					TextComponentString component = new TextComponentString(TextFormatting.RED + "You need a level of " + reqlvl + " " + this.SkillName[SkillID] + " to know What it is");
				player.addChatComponentMessage(component);
					}
				}
				return candothis;
				}

			if (method == 3){
				boolean candothis = p.Level[SkillID] >= reqlvl;
				if(candothis == false){
					if(player instanceof EntityPlayerMP){
					TextComponentString component = new TextComponentString(TextFormatting.RED + "You need a level of " + reqlvl + " " + this.SkillName[SkillID] + " to study this book");
				player.addChatComponentMessage(component);
				}}
				return candothis;
				}
			if (method == 4){
				boolean candothis = p.Level[SkillID] >= reqlvl;
				if(candothis == false){
					if(player instanceof EntityPlayerMP){
					TextComponentString component = new TextComponentString(TextFormatting.RED + "You need a level of " + reqlvl + " " + this.SkillName[SkillID] + " to clean this herb");
				player.addChatComponentMessage(component);
				}}
				return candothis;
			}
			
			
			if (method == 5){
				boolean candothis = p.Level[SkillID] >= reqlvl;
				if(candothis == false){
					if(player instanceof EntityPlayerMP){
					TextComponentString component = new TextComponentString(TextFormatting.RED + "You need a level of " + reqlvl + " " + this.SkillName[SkillID] + " to place this");
				player.addChatComponentMessage(component);
				}}
				return candothis;
				}
			if (method == 6){
				boolean candothis = p.Level[SkillID] >= reqlvl;
				if(candothis == false){
					if(player instanceof EntityPlayerMP){
					TextComponentString component = new TextComponentString(TextFormatting.RED + "You need a level of " + reqlvl + " " + this.SkillName[SkillID] + " for Catching this");
				player.addChatComponentMessage(component);
				}}
				return candothis;
				}
			if (method == 7){
				boolean candothis = p.Level[SkillID] >= reqlvl;
				if(candothis == false){
					if(player instanceof EntityPlayerMP){
					TextComponentString component = new TextComponentString(TextFormatting.RED + "You need a level of " + reqlvl + " " + this.SkillName[SkillID] + " to fish here");
				player.addChatComponentMessage(component);
				}}
				return candothis;
				}
			
			else{
				return false;
				
			}
				
			}
				
	public int[] getXp() {
	
		
		MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
	for (int i = 0;i < 35; i++){
			if ((p.XP[i]) > 120000 && this.MainLock == 1)				{p.XP[i] = 120000;}
		else if ((p.XP[i]) > 40000000 && this.MainLock == 2)				{p.XP[i] = 40000000;}
		else if ((p.XP[i]) > 2000000000 && this.MainLock == 3)			{p.XP[i] = 2000000000;}
		
		}
	
	
	return this.XP;
	
	}
	
	
	
	public void syncSkill() {
	    if (this.isServerSide() && this.player != null){
	    	
	        MainRegistry.network.sendTo(new SkillPacket(this.XP, this.player), (EntityPlayerMP) player);
	        
	    }
	    
	}
	
	
	public void HSSync(int SkillID, EntityPlayer playerIn){
		this.HSSkillID = SkillID;
		this.HSPlayerIn = playerIn;
		
		System.out.println("Sync Called from Player: " + playerIn.getName() + "ServerSide=" + Boolean.toString(!(HSPlayerIn instanceof EntityPlayerSP)));
		
		if (!(HSPlayerIn instanceof EntityPlayerSP) && this.HSPlayerIn != null){
			List <EntityPlayerMP> players =  FMLCommonHandler.instance().getMinecraftServerInstance().getPlayerList().getPlayerList();
			EntityPlayerMP[] HSPlayerp = new EntityPlayerMP[players.size()];
			HSPlayerp = players.toArray(HSPlayerp);
			String[] HSPlayer = new String[players.size()];
			String[] HSPlayer2 = new String[0];
			int[][] HSXP3 = new int[0][35];
			int[] HSXP2 = new int[0];
			long[] HSTotXP2 = new long[0];
			int[] HSTotLVL2 = new int[0];
			
			if(this.OfflinePlayers != null){
			HSPlayer2 = new String[OfflinePlayers.size()];
			HSPlayer2 = OfflinePlayers.toArray(HSPlayer2);
			HSXP3 = new int[offlineXP.size()][35];
			HSXP3 = offlineXP.toArray(HSXP3);
			HSXP2 = new int[OfflinePlayers.size()];
			if(SkillID < 35){
			for (int i = 0; i < OfflinePlayers.size(); i++){
			HSXP2[i] = HSXP3[i][SkillID];
			}
			}
			HSTotXP2 = new long[OfflinePlayers.size()];
			
			Integer[] HSTotLVL3 = new Integer[offlineToT.size()];
			HSTotLVL3 = offlineToT.toArray(HSTotLVL3);
			HSTotLVL2 = new int[offlineToT.size()];
			for (int i = 0; i < offlineToT.size(); i++){
				HSTotLVL2[i] = HSTotLVL3[i];
			}
		}
			
			for(int i = 0; i < players.size(); i++){
			HSPlayer[i] = HSPlayerp[i].getName();
			}
			
			
			int[] HSXP = new int[HSPlayer.length];
			long[] HSTotXP = new long[HSPlayer.length];
			int[] HSTotLVL = new int[HSPlayer.length];
			
			
			boolean Offliners = false;
			if (OfflinePlayers != null){
				for (int i = 0;i < OfflinePlayers.size(); i++){
					if (HSPlayer2 != null){
						if (HSPlayer2.length != 0){
						Offliners = true;
						}
						else{
						Offliners = false;
						}
					}
				}
			}
			else{
				Offliners = false;
			}
			
			
			if(HSSkillID < 35){
			for(int i = 0; i < HSPlayer.length; i++){
				MarkData OtherP = HSPlayerp[i].getCapability(MainRegistry.ModMark136Data, null); 
				HSXP[i] = OtherP.getXp()[HSSkillID];
				
				}
			MainRegistry.network.sendTo(new HiscorePacketB(HSPlayer, HSXP, true, Offliners, HSPlayerIn), (EntityPlayerMP) HSPlayerIn); 
			if (Offliners){
				System.out.println("Offline Players XP HS: " + HSPlayer2.length);
				MainRegistry.network.sendTo(new HiscorePacketB(HSPlayer2, HSXP2, false, Offliners, HSPlayerIn), (EntityPlayerMP) HSPlayerIn); 
			}
			else{
				System.out.println("No Offline Players XP HS");
			}
				
			}
			else {
				for (int i = 0; i < HSPlayer.length; i++){
					MarkData OtherP = HSPlayerp[i].getCapability(MainRegistry.ModMark136Data, null);
					HSTotXP[i] = 0;
					HSTotLVL[i] = 0;
					
					
					for (int i2 = 0; i2 < 35; i2++){
						HSTotXP[i] += OtherP.XP[i2];
						HSTotLVL[i] += OtherP.Level[i2];
					}
					}
				if(Offliners && HSTotXP2.length == OfflinePlayers.size()){
				for (int i = 0; i < OfflinePlayers.size(); i++){
					HSTotXP2[i] = 0;
					
					for (int i2 = 0; i2 < 35; i2++){
						HSTotXP2[i] += HSXP3[i][i2];
					}
				}
				}
				System.out.println(HSPlayer[0]);
				MainRegistry.network.sendTo(new HiscorePacketC(HSPlayer, HSTotXP, HSTotLVL, true, Offliners, HSPlayerIn), (EntityPlayerMP) HSPlayerIn);
				
				
				
				if (Offliners){
					System.out.println("Offline Players Total HS: " + HSPlayer2.length);
					MainRegistry.network.sendTo(new HiscorePacketC(HSPlayer2, HSTotXP2, HSTotLVL2, false, Offliners, HSPlayerIn), (EntityPlayerMP) HSPlayerIn);
				}
				else{
					System.out.println("No Offline Players Total HS");
				}
			}
			
			
		}
	}
	
	public void RequestingSync() {
	    if (this.isServerSide()){
	    	MainRegistry.network.sendTo(new SkillPacket(this.XP, this.player), (EntityPlayerMP) player);
	    }
	    else{
	    	MainRegistry.network.sendToServer(new SkillPacket());
	    }
	}
	/** IEEP... saves data if death or end */
	public void saveReviveRelevantNBTData(NBTTagCompound compound, boolean wasDeath) {
		
	        this.serializeNBT();
	}
	
	/**sets the name of the skill */
	public void setSkillName(){
		
		 this.SkillName[0] = "Constitution";
		 this.SkillName[1] = "Melee";
		 this.SkillName[2] = "Ranged";
		 this.SkillName[3] = "Magic";
		 this.SkillName[4] = "Defence";
		 this.SkillName[5] = "Endurance";
		 this.SkillName[6] = "Slayer";
		 this.SkillName[7] = "Farming";
		 this.SkillName[8] = "Mining";
		 this.SkillName[9] = "Hunter";
		 this.SkillName[10] = "Excavation";
		 this.SkillName[11] = "Woodcutting";
		 this.SkillName[12] = "Fishing";
		 this.SkillName[13] = "Archeology";
		 this.SkillName[14] = "Tailory";
		 this.SkillName[15] = "Smithing";
		 this.SkillName[16] = "Tanning";
		 this.SkillName[17] = "Jewelry";
		 this.SkillName[18] = "Fletching";
		 this.SkillName[19] = "Cooking";
		 this.SkillName[20] = "Herblore";
		 this.SkillName[21] = "Honour";
		 this.SkillName[22] = "Construction";
		 this.SkillName[23] = "Agility";
		 this.SkillName[24] = "Exploration";
		 this.SkillName[25] = "Pet Caring";
		 this.SkillName[26] = "Lifestock";
		 this.SkillName[27] = "Knowledge";
		 this.SkillName[28] = "Technology";
		 this.SkillName[29] = "Manufacturing";
		 this.SkillName[30] = "Chemistry";
		 this.SkillName[31] = "Specility";
		 this.SkillName[32] = "Mutating";
		 this.SkillName[33] = "Fisioning";
		 this.SkillName[34] = "Fusioning";
		  
		}

	//this methode is to calculate my XP to level(and this really works!!)
	 public void Lvlcalc(MarkData data) {
		
		MarkData p = data;
			
	for (int i = 0; i < 35;i++) {
		
		
		double[] Level1 = new double[35];
		double[] NextLevel0 = new double[35]; 
		double[] NextLevel1 = new double[35];
	 
			if (p.getXp()[i] == 2000000000)										{Level1[i] = 255;}
		else if (p.getXp()[i] >= 1720000000 && p.getXp()[i] <= 1999999999)	{Level1[i] = 254;}
		else if (p.getXp()[i] >= 1480000000 && p.getXp()[i] <= 1719999999)	{Level1[i] = 253;}
		else if (p.getXp()[i] >= 1280000000 && p.getXp()[i] <= 1479999999)	{Level1[i] = 252;}
		else if (p.getXp()[i] >= 1120000000 && p.getXp()[i] <= 1279999999)	{Level1[i] = 251;}
		else if (p.getXp()[i] >= 1000000000 && p.getXp()[i] <= 1119999999)	{Level1[i] = 250;}
		else if (p.getXp()[i] >= 936171373 && p.getXp()[i] <= 999999999)		{Level1[i] = 249;}
		else if (p.getXp()[i] >= 50242686 && p.getXp()[i] <= 936171372)		{Level1[i] = ((Math.log(p.getXp()[i] + 256)/Math.log(256))-1)*91+1;}
		else if (p.getXp()[i] >= 34799106 && p.getXp()[i] <= 50242685)		{Level1[i] = 200;}
		else if (p.getXp()[i] >= 149782 && p.getXp()[i] <= 34799105)			{Level1[i] = ((Math.log10(p.getXp()[i] + 687)/Math.log10(687))-1)*120+1;}
		else if (p.getXp()[i] >= 99539 && p.getXp()[i] <= 149781)				{Level1[i] = 99;}
		else if (p.getXp()[i] <= 99538)											{Level1[i] = ((Math.log10(p.getXp()[i] + 695)/Math.log10(695))-1)*129+1;}
		else 																		{Level1[i] = 0;}

	 
	 	p.Level[i] = (int) Math.floor(Level1[i]); /** floors this.Level down*/
		NextLevel0[i] = (int) (p.Level[i] + 1);  /** says Level + 1*/
		
		
		
		
			if (p.Level[i] < 99) 												{NextLevel1[i] = (Math.pow(695, (NextLevel0[i] - 1)/129 +1) - 695);}
		else if (p.Level[i] == 99)												{NextLevel1[i] = 701754;}
		else if (p.Level[i] >= 100 && this.Level[i] < 200) 						{NextLevel1[i] = (Math.pow(687, (NextLevel0[i] - 1)/120 +1) - 687);}
		else if (p.Level[i] == 200) 												{NextLevel1[i] = 100005814;}
		else if (p.Level[i] >= 201 && this.Level[i] < 249) 						{NextLevel1[i] = (Math.pow(256, (NextLevel0[i] - 1)/91 +1) - 256);}
		else if (p.Level[i] == 249) 												{NextLevel1[i] = 1000000000;}
		else if (p.Level[i] == 250) 												{NextLevel1[i] = 1120000000;}
		else if (p.Level[i] == 251) 												{NextLevel1[i] = 1280000000;}
		else if (p.Level[i] == 252) 												{NextLevel1[i] = 1480000000;}
		else if (p.Level[i] == 253) 												{NextLevel1[i] = 1720000000;}
		else if (p.Level[i] == 254) 												{NextLevel1[i] = 2000000000;}
		else 																		{NextLevel1[i] = 0;}
		
			p.NextLevel[i] = (int) Math.ceil(NextLevel1[i]);
			p.XpNeed[i] = (int) (p.NextLevel[i] - p.getXp()[i]);
		}
	
	}
	 
	 public void CombatLevelToClient(int Client, int Name){
		 MainRegistry.network.sendTo(new CombatLvlPacket2(Client, Name, HSPlayerIn), (EntityPlayerMP) this.player); 			
	 }
	 
	 
 public int[] getLevel(int[] xp, EntityPlayer player){
		 
		MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
		int[] XP2 = p.XP;
		
		double[] pLevel1 = new double[35];
		int[] pLevel = new int[35];
			for (int i = 0; i < 35;i++) {
				 
				 if (XP2[i] == 2000000000){pLevel1[i] = 255;}
					else if (XP2[i] >= 1720000000 && XP2[i] <= 1999999999){pLevel1[i] = 254;}
					else if (XP2[i] >= 1480000000 && XP2[i] <= 1719999999){pLevel1[i] = 253;}
					else if (XP2[i] >= 1280000000 && XP2[i] <= 1479999999){pLevel1[i] = 252;}
					else if (XP2[i] >= 1120000000 && XP2[i] <= 1279999999){pLevel1[i] = 251;}
					else if (XP2[i] >= 1000000000 && XP2[i] <= 1119999999){pLevel1[i] = 250;}
					else if (XP2[i] >= 936171373 && XP2[i] <= 999999999){pLevel1[i] = 249;}
					else if (XP2[i] >= 50242686 && XP2[i] <= 936171372){pLevel1[i] = ((Math.log(XP2[i] + 256)/Math.log(256))-1)*91+1;}
					else if (XP2[i] >= 34799106 && XP2[i] <= 50242685){pLevel1[i] = 200;}
					else if (XP2[i] >= 149782 && XP2[i] <= 34799105){pLevel1[i] = ((Math.log10(XP2[i] + 687)/Math.log10(687))-1)*120+1;}
					else if (XP2[i] >= 99539 && XP2[i] <= 149781){pLevel1[i] = 99;}
					else if (XP2[i] >= 0 && XP2[i] <= 99538){pLevel1[i] = ((Math.log10(XP2[i] + 695)/Math.log10(695))-1)*129+1;}
					else {pLevel1[i] = 1;}

				 pLevel[i] = (int) Math.floor(pLevel1[i]); /** floors level down*/
				 
					
					
				}
		 return pLevel;
		 
	 }
		 
	 /**to calculate the combat level 
	 * @return */
	 public int getCombatLvl(MarkData data){

	this.Lvlcalc(data);
		 
	double d1, d2, d3, d4, d5, d6, d7;

	int i1, i2, i3;
		
	if(this.Level[1] == 255 && this.Level[2] == 255 && this.Level[3] != 255 || this.Level[1] == 255 && this.Level[2] != 255 && this.Level[3] == 255 || this.Level[1] != 255 && this.Level[2] == 255 && this.Level[3] == 255 ){
		
		i1 = 2;
	}
	else if(this.Level[1] == 255 && this.Level[2] == 255 && this.Level[3] == 255){
		
		i1 = 3;
	}
	else{
		
		i1 = 1;
	}
		 
		 
		 
	if(this.Level[1] >= this.Level[2] && this.Level[1] >= this.Level[3]){
		d1 = this.Level[1];
	}
	else if(this.Level[2] >= this.Level[3]){
		d1 = this.Level[2];
	}
	else
	{
		d1 = this.Level[3];
	}
	
	if(d1 >= this.Level[4]){
		d2 = d1;
		d3 = this.Level[4];
	}
	else
	{
		d2 = this.Level[4];
		d3 = d1;
	}
	
	d4 =  (d2 + (d3 / 10)) / 280.5D * 209;
	i2 = (int) Math.floor(d4);
	
	if (this.Level[0] >= this.Level[5]){
		
		d5 = this.Level[0];
		d6 = this.Level[5];
	}
	else
	{
		d5 = this.Level[5];
		d6 = this.Level[0];
	}
	
	d7 = (d5 + (d6 * 3/2)) / 637.5D * 138;
	i3 = (int) Math.floor(d7);
	
	this.Combat = i1 + i2 + i3;
	if(this.Combat != this.prevCB){
		MainRegistry.network.sendTo(new CombatLvlPacket3(this.Combat, player), (EntityPlayerMP) player);
	}
	
	
	this.prevCB = this.Combat;
	return i1 + i2 + i3;
	 }
	 
	 /**to calculate the Total Level----------------------------------------------------------------------*/
	 public int getTotalLvl(MarkData data) {
		 
		 Lvlcalc(data);
		 this.Total = 0;
	for (int i = 0; i < 35; i++){
		Total += this.Level[i];
	}
		return this.Total;
	}	
	 
	 /**this is for the achievements */
	 public void setAchievement(int SkillID){
		MarkData p = player.getCapability(MainRegistry.ModMark136Data, null);
		
		 if(SkillID == 0){
			 if(p.Level[0] + 1 >= 2){
				 player.addStat(MarkAchievements.HP2, 1); 
					if(p.Level[0] + 1 >= 25){
						player.addStat(MarkAchievements.HP25, 1); 
						if(p.Level[0] + 1 >= 50){
							player.addStat(MarkAchievements.HP50, 1); 
							if(p.Level[0] + 1 >= 75){
								player.addStat(MarkAchievements.HP75, 1); 
								if(p.Level[0] + 1 >= 99){
									player.addStat(MarkAchievements.HP99, 1); 
									if(p.Level[0] + 1 >= 100){
										player.addStat(MarkAchievements.HP100, 1);
										if(p.Level[0] + 1 >= 125){
											player.addStat(MarkAchievements.HP125, 1); 
											if(p.Level[0] + 1 >= 150){
												player.addStat(MarkAchievements.HP150, 1);
												if(p.Level[0] + 1 >= 175){
													player.addStat(MarkAchievements.HP175, 1); 
													if(p.Level[0] + 1 >= 200){
														player.addStat(MarkAchievements.HP200, 1);
														if(p.Level[0] + 1 >= 201){
															player.addStat(MarkAchievements.HP201, 1);
															if(p.Level[0] + 1 >= 220){
																player.addStat(MarkAchievements.HP220, 1);
																if(p.Level[0] + 1 >= 240){
																	player.addStat(MarkAchievements.HP240, 1);
																	if(p.Level[0] + 1 >= 250){
																		player.addStat(MarkAchievements.HP250, 1);
																		if(p.Level[0] + 1 >= 255){
																			player.addStat(MarkAchievements.HPMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 1){
			 if(p.Level[1] + 1 >= 2){
				 player.addStat(MarkAchievements.ML2, 1); 
					if(p.Level[1] + 1 >= 25){
						player.addStat(MarkAchievements.ML25, 1); 
						if(p.Level[1] + 1 >= 50){
							player.addStat(MarkAchievements.ML50, 1); 
							if(p.Level[1] + 1 >= 75){
								player.addStat(MarkAchievements.ML75, 1); 
								if(p.Level[1] + 1 >= 99){
									player.addStat(MarkAchievements.ML99, 1); 
									if(p.Level[1] + 1 >= 100){
										player.addStat(MarkAchievements.ML100, 1);
										if(p.Level[1] + 1 >= 125){
											player.addStat(MarkAchievements.ML125, 1); 
											if(p.Level[1] + 1 >= 150){
												player.addStat(MarkAchievements.ML150, 1);
												if(p.Level[1] + 1 >= 175){
													player.addStat(MarkAchievements.ML175, 1); 
													if(p.Level[1] + 1 >= 200){
														player.addStat(MarkAchievements.ML200, 1);
														if(p.Level[1] + 1 >= 201){
															player.addStat(MarkAchievements.ML201, 1);
															if(p.Level[1] + 1 >= 220){
																player.addStat(MarkAchievements.ML220, 1);
																if(p.Level[1] + 1 >= 240){
																	player.addStat(MarkAchievements.ML240, 1);
																	if(p.Level[1] + 1 >= 250){
																		player.addStat(MarkAchievements.ML250, 1);
																		if(p.Level[1] + 1 >= 255){
																			player.addStat(MarkAchievements.MLMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 2){
			 if(p.Level[2] + 1 >= 2){
				 player.addStat(MarkAchievements.RN2, 1); 
					if(p.Level[2] + 1 >= 25){
						player.addStat(MarkAchievements.RN25, 1); 
						if(p.Level[2] + 1 >= 50){
							player.addStat(MarkAchievements.RN50, 1); 
							if(p.Level[2] + 1 >= 75){
								player.addStat(MarkAchievements.RN75, 1); 
								if(p.Level[2] + 1 >= 99){
									player.addStat(MarkAchievements.RN99, 1); 
									if(p.Level[2] + 1 >= 100){
										player.addStat(MarkAchievements.RN100, 1);
										if(p.Level[2] + 1 >= 125){
											player.addStat(MarkAchievements.RN125, 1); 
											if(p.Level[2] + 1 >= 150){
												player.addStat(MarkAchievements.RN150, 1);
												if(p.Level[2] + 1 >= 175){
													player.addStat(MarkAchievements.RN175, 1); 
													if(p.Level[2] + 1 >= 200){
														player.addStat(MarkAchievements.RN200, 1);
														if(p.Level[2] + 1 >= 201){
															player.addStat(MarkAchievements.RN201, 1);
															if(p.Level[2] + 1 >= 220){
																player.addStat(MarkAchievements.RN220, 1);
																if(p.Level[2] + 1 >= 240){
																	player.addStat(MarkAchievements.RN240, 1);
																	if(p.Level[2] + 1 >= 250){
																		player.addStat(MarkAchievements.RN250, 1);
																		if(p.Level[2] + 1 >= 255){
																			player.addStat(MarkAchievements.RNMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 3){
			 if(p.Level[3] + 1 >= 2){
				 player.addStat(MarkAchievements.MG2, 1); 
					if(p.Level[3] + 1 >= 25){
						player.addStat(MarkAchievements.MG25, 1); 
						if(p.Level[3] + 1 >= 50){
							player.addStat(MarkAchievements.MG50, 1); 
							if(p.Level[3] + 1 >= 75){
								player.addStat(MarkAchievements.MG75, 1); 
								if(p.Level[3] + 1 >= 99){
									player.addStat(MarkAchievements.MG99, 1); 
									if(p.Level[3] + 1 >= 100){
										player.addStat(MarkAchievements.MG100, 1);
										if(p.Level[3] + 1 >= 125){
											player.addStat(MarkAchievements.MG125, 1); 
											if(p.Level[3] + 1 >= 150){
												player.addStat(MarkAchievements.MG150, 1);
												if(p.Level[3] + 1 >= 175){
													player.addStat(MarkAchievements.MG175, 1); 
													if(p.Level[3] + 1 >= 200){
														player.addStat(MarkAchievements.MG200, 1);
														if(p.Level[3] + 1 >= 201){
															player.addStat(MarkAchievements.MG201, 1);
															if(p.Level[3] + 1 >= 220){
																player.addStat(MarkAchievements.MG220, 1);
																if(p.Level[3] + 1 >= 240){
																	player.addStat(MarkAchievements.MG240, 1);
																	if(p.Level[3] + 1 >= 250){
																		player.addStat(MarkAchievements.MG250, 1);
																		if(p.Level[3] + 1 >= 255){
																			player.addStat(MarkAchievements.MGMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 4){
			 if(p.Level[4] + 1 >= 2){
				 player.addStat(MarkAchievements.DF2, 1); 
					if(p.Level[4] + 1 >= 25){
						player.addStat(MarkAchievements.DF25, 1); 
						if(p.Level[4] + 1 >= 50){
							player.addStat(MarkAchievements.DF50, 1); 
							if(p.Level[4] + 1 >= 75){
								player.addStat(MarkAchievements.DF75, 1); 
								if(p.Level[4] + 1 >= 99){
									player.addStat(MarkAchievements.DF99, 1); 
									if(p.Level[4] + 1 >= 100){
										player.addStat(MarkAchievements.DF100, 1);
										if(p.Level[4] + 1 >= 125){
											player.addStat(MarkAchievements.DF125, 1); 
											if(p.Level[4] + 1 >= 150){
												player.addStat(MarkAchievements.DF150, 1);
												if(p.Level[4] + 1 >= 175){
													player.addStat(MarkAchievements.DF175, 1); 
													if(p.Level[4] + 1 >= 200){
														player.addStat(MarkAchievements.DF200, 1);
														if(p.Level[4] + 1 >= 201){
															player.addStat(MarkAchievements.DF201, 1);
															if(p.Level[4] + 1 >= 220){
																player.addStat(MarkAchievements.DF220, 1);
																if(p.Level[4] + 1 >= 240){
																	player.addStat(MarkAchievements.DF240, 1);
																	if(p.Level[4] + 1 >= 250){
																		player.addStat(MarkAchievements.DF250, 1);
																		if(p.Level[4] + 1 >= 255){
																			player.addStat(MarkAchievements.DFMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 5){
			 if(p.Level[5] + 1 >= 2){
				 player.addStat(MarkAchievements.EN2, 1); 
					if(p.Level[5] + 1 >= 25){
						player.addStat(MarkAchievements.EN25, 1); 
						if(p.Level[5] + 1 >= 50){
							player.addStat(MarkAchievements.EN50, 1); 
							if(p.Level[5] + 1 >= 75){
								player.addStat(MarkAchievements.EN75, 1); 
								if(p.Level[5] + 1 >= 99){
									player.addStat(MarkAchievements.EN99, 1); 
									if(p.Level[5] + 1 >= 100){
										player.addStat(MarkAchievements.EN100, 1);
										if(p.Level[5] + 1 >= 125){
											player.addStat(MarkAchievements.EN125, 1); 
											if(p.Level[5] + 1 >= 150){
												player.addStat(MarkAchievements.EN150, 1);
												if(p.Level[5] + 1 >= 175){
													player.addStat(MarkAchievements.EN175, 1); 
													if(p.Level[5] + 1 >= 200){
														player.addStat(MarkAchievements.EN200, 1);
														if(p.Level[5] + 1 >= 201){
															player.addStat(MarkAchievements.EN201, 1);
															if(p.Level[5] + 1 >= 220){
																player.addStat(MarkAchievements.EN220, 1);
																if(p.Level[5] + 1 >= 240){
																	player.addStat(MarkAchievements.EN240, 1);
																	if(p.Level[5] + 1 >= 250){
																		player.addStat(MarkAchievements.EN250, 1);
																		if(p.Level[5] + 1 >= 255){
																			player.addStat(MarkAchievements.ENMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 6){
			 if(p.Level[6] + 1 >= 2){
				 player.addStat(MarkAchievements.SL2, 1); 
					if(p.Level[6] + 1 >= 25){
						player.addStat(MarkAchievements.SL25, 1); 
						if(p.Level[6] + 1 >= 50){
							player.addStat(MarkAchievements.SL50, 1); 
							if(p.Level[6] + 1 >= 75){
								player.addStat(MarkAchievements.SL75, 1); 
								if(p.Level[6] + 1 >= 99){
									player.addStat(MarkAchievements.SL99, 1); 
									if(p.Level[6] + 1 >= 100){
										player.addStat(MarkAchievements.SL100, 1);
										if(p.Level[6] + 1 >= 125){
											player.addStat(MarkAchievements.SL125, 1); 
											if(p.Level[6] + 1 >= 150){
												player.addStat(MarkAchievements.SL150, 1);
												if(p.Level[6] + 1 >= 175){
													player.addStat(MarkAchievements.SL175, 1); 
													if(p.Level[6] + 1 >= 200){
														player.addStat(MarkAchievements.SL200, 1);
														if(p.Level[6] + 1 >= 201){
															player.addStat(MarkAchievements.SL201, 1);
															if(p.Level[6] + 1 >= 220){
																player.addStat(MarkAchievements.SL220, 1);
																if(p.Level[6] + 1 >= 240){
																	player.addStat(MarkAchievements.SL240, 1);
																	if(p.Level[6] + 1 >= 250){
																		player.addStat(MarkAchievements.SL250, 1);
																		if(p.Level[6] + 1 >= 255){
																			player.addStat(MarkAchievements.SLMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 7){
			 if(p.Level[7] + 1 >= 2){
				player.addStat(MarkAchievements.FA2, 1); 
				if(p.Level[7] + 1 >= 25){
					player.addStat(MarkAchievements.FA25, 1); 
					if(p.Level[7] + 1 >= 50){
						player.addStat(MarkAchievements.FA50, 1); 
						if(p.Level[7] + 1 >= 75){
							player.addStat(MarkAchievements.FA75, 1); 
							if(p.Level[7] + 1 >= 99){
								player.addStat(MarkAchievements.FA99, 1); 
								if(p.Level[7] + 1 >= 100){
									player.addStat(MarkAchievements.FA100, 1);
									if(p.Level[7] + 1 >= 125){
										player.addStat(MarkAchievements.FA125, 1); 
										if(p.Level[7] + 1 >= 150){
											player.addStat(MarkAchievements.FA150, 1);
											if(p.Level[7] + 1 >= 175){
												player.addStat(MarkAchievements.FA175, 1); 
												if(p.Level[7] + 1 >= 200){
													player.addStat(MarkAchievements.FA200, 1);
													if(p.Level[7] + 1 >= 201){
														player.addStat(MarkAchievements.FA201, 1);
														if(p.Level[7] + 1 >= 220){
															player.addStat(MarkAchievements.FA220, 1);
															if(p.Level[7] + 1 >= 240){
																player.addStat(MarkAchievements.FA240, 1);
																if(p.Level[7] + 1 >= 250){
																	player.addStat(MarkAchievements.FA250, 1);
																	if(p.Level[7] + 1 >= 255){
																		player.addStat(MarkAchievements.FAMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 8){
			 if(p.Level[8] + 1 >= 2){
				 player.addStat(MarkAchievements.MI2, 1); 
					if(p.Level[8] + 1 >= 25){
						player.addStat(MarkAchievements.MI25, 1); 
						if(p.Level[8] + 1 >= 50){
							player.addStat(MarkAchievements.MI50, 1); 
							if(p.Level[8] + 1 >= 75){
								player.addStat(MarkAchievements.MI75, 1); 
								if(p.Level[8] + 1 >= 99){
									player.addStat(MarkAchievements.MI99, 1); 
									if(p.Level[8] + 1 >= 100){
										player.addStat(MarkAchievements.MI100, 1);
										if(p.Level[8] + 1 >= 125){
											player.addStat(MarkAchievements.MI125, 1); 
											if(p.Level[8] + 1 >= 150){
												player.addStat(MarkAchievements.MI150, 1);
												if(p.Level[8] + 1 >= 175){
													player.addStat(MarkAchievements.MI175, 1); 
													if(p.Level[8] + 1 >= 200){
														player.addStat(MarkAchievements.MI200, 1);
														if(p.Level[8] + 1 >= 201){
															player.addStat(MarkAchievements.MI201, 1);
															if(p.Level[8] + 1 >= 220){
																player.addStat(MarkAchievements.MI220, 1);
																if(p.Level[8] + 1 >= 240){
																	player.addStat(MarkAchievements.MI240, 1);
																	if(p.Level[8] + 1 >= 250){
																		player.addStat(MarkAchievements.MI250, 1);
																		if(p.Level[8] + 1 >= 255){
																			player.addStat(MarkAchievements.MIMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 9){
			 if(p.Level[9] + 1 >= 2){
					 player.addStat(MarkAchievements.HU2, 1); 
						if(p.Level[9] + 1 >= 25){
							player.addStat(MarkAchievements.HU25, 1); 
							if(p.Level[9] + 1 >= 50){
								player.addStat(MarkAchievements.HU50, 1); 
								if(p.Level[9] + 1 >= 75){
									player.addStat(MarkAchievements.HU75, 1); 
									if(p.Level[9] + 1 >= 99){
										player.addStat(MarkAchievements.HU99, 1); 
										if(p.Level[9] + 1 >= 100){
											player.addStat(MarkAchievements.HU100, 1);
											if(p.Level[9] + 1 >= 125){
												player.addStat(MarkAchievements.HU125, 1); 
												if(p.Level[9] + 1 >= 150){
													player.addStat(MarkAchievements.HU150, 1);
													if(p.Level[9] + 1 >= 175){
														player.addStat(MarkAchievements.HU175, 1); 
														if(p.Level[9] + 1 >= 200){
															player.addStat(MarkAchievements.HU200, 1);
															if(p.Level[9] + 1 >= 201){
																player.addStat(MarkAchievements.HU201, 1);
																if(p.Level[9] + 1 >= 220){
																	player.addStat(MarkAchievements.HU220, 1);
																	if(p.Level[9] + 1 >= 240){
																		player.addStat(MarkAchievements.HU240, 1);
																		if(p.Level[9] + 1 >= 250){
																			player.addStat(MarkAchievements.HU250, 1);
																			if(p.Level[9] + 1 >= 255){
																				player.addStat(MarkAchievements.HUMAX, 1);
				}}}}}}}}}}}}}}}}
		 else if(SkillID == 10){
			 if(p.Level[10] + 1 >= 2){
				 player.addStat(MarkAchievements.EX2, 1); 
					if(p.Level[10] + 1 >= 25){
						player.addStat(MarkAchievements.EX25, 1); 
						if(p.Level[10] + 1 >= 50){
							player.addStat(MarkAchievements.EX50, 1); 
							if(p.Level[10] + 1 >= 75){
								player.addStat(MarkAchievements.EX75, 1); 
								if(p.Level[10] + 1 >= 99){
									player.addStat(MarkAchievements.EX99, 1); 
									if(p.Level[10] + 1 >= 100){
										player.addStat(MarkAchievements.EX100, 1);
										if(p.Level[10] + 1 >= 125){
											player.addStat(MarkAchievements.EX125, 1); 
											if(p.Level[10] + 1 >= 150){
												player.addStat(MarkAchievements.EX150, 1);
												if(p.Level[10] + 1 >= 175){
													player.addStat(MarkAchievements.EX175, 1); 
													if(p.Level[10] + 1 >= 200){
														player.addStat(MarkAchievements.EX200, 1);
														if(p.Level[10] + 1 >= 201){
															player.addStat(MarkAchievements.EX201, 1);
															if(p.Level[10] + 1 >= 220){
																player.addStat(MarkAchievements.EX220, 1);
																if(p.Level[10] + 1 >= 240){
																	player.addStat(MarkAchievements.EX240, 1);
																	if(p.Level[10] + 1 >= 250){
																		player.addStat(MarkAchievements.EX250, 1);
																		if(p.Level[10] + 1 >= 255){
																			player.addStat(MarkAchievements.EXMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 11){
			 if(p.Level[11] + 1 >= 2){
				 player.addStat(MarkAchievements.WC2, 1); 
					if(p.Level[11] + 1 >= 25){
						player.addStat(MarkAchievements.WC25, 1); 
						if(p.Level[11] + 1 >= 50){
							player.addStat(MarkAchievements.WC50, 1); 
							if(p.Level[11] + 1 >= 75){
								player.addStat(MarkAchievements.WC75, 1); 
								if(p.Level[11] + 1 >= 99){
									player.addStat(MarkAchievements.WC99, 1); 
									if(p.Level[11] + 1 >= 100){
										player.addStat(MarkAchievements.WC100, 1);
										if(p.Level[11] + 1 >= 125){
											player.addStat(MarkAchievements.WC125, 1); 
											if(p.Level[11] + 1 >= 150){
												player.addStat(MarkAchievements.WC150, 1);
												if(p.Level[11] + 1 >= 175){
													player.addStat(MarkAchievements.WC175, 1); 
													if(p.Level[11] + 1 >= 200){
														player.addStat(MarkAchievements.WC200, 1);
														if(p.Level[11] + 1 >= 201){
															player.addStat(MarkAchievements.WC201, 1);
															if(p.Level[11] + 1 >= 220){
																player.addStat(MarkAchievements.WC220, 1);
																if(p.Level[11] + 1 >= 240){
																	player.addStat(MarkAchievements.WC240, 1);
																	if(p.Level[11] + 1 >= 250){
																		player.addStat(MarkAchievements.WC250, 1);
																		if(p.Level[11] + 1 >= 255){
																			player.addStat(MarkAchievements.WCMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 12){
			 if(p.Level[12] + 1 >= 2){
				 player.addStat(MarkAchievements.FS2, 1); 
					if(p.Level[12] + 1 >= 25){
						player.addStat(MarkAchievements.FS25, 1); 
						if(p.Level[12] + 1 >= 50){
							player.addStat(MarkAchievements.FS50, 1); 
							if(p.Level[12] + 1 >= 75){
								player.addStat(MarkAchievements.FS75, 1); 
								if(p.Level[12] + 1 >= 99){
									player.addStat(MarkAchievements.FS99, 1); 
									if(p.Level[12] + 1 >= 100){
										player.addStat(MarkAchievements.FS100, 1);
										if(p.Level[12] + 1 >= 125){
											player.addStat(MarkAchievements.FS125, 1); 
											if(p.Level[12] + 1 >= 150){
												player.addStat(MarkAchievements.FS150, 1);
												if(p.Level[12] + 1 >= 175){
													player.addStat(MarkAchievements.FS175, 1); 
													if(p.Level[12] + 1 >= 200){
														player.addStat(MarkAchievements.FS200, 1);
														if(p.Level[12] + 1 >= 201){
															player.addStat(MarkAchievements.FS201, 1);
															if(p.Level[12] + 1 >= 220){
																player.addStat(MarkAchievements.FS220, 1);
																if(p.Level[12] + 1 >= 240){
																	player.addStat(MarkAchievements.FS240, 1);
																	if(p.Level[12] + 1 >= 250){
																		player.addStat(MarkAchievements.FS250, 1);
																		if(p.Level[12] + 1 >= 255){
																			player.addStat(MarkAchievements.FSMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 13){
			 if(p.Level[13] + 1 >= 2){
					 player.addStat(MarkAchievements.AR2, 1); 
						if(p.Level[13] + 1 >= 25){
							player.addStat(MarkAchievements.AR25, 1); 
							if(p.Level[13] + 1 >= 50){
								player.addStat(MarkAchievements.AR50, 1); 
								if(p.Level[13] + 1 >= 75){
									player.addStat(MarkAchievements.AR75, 1); 
									if(p.Level[13] + 1 >= 99){
										player.addStat(MarkAchievements.AR99, 1); 
										if(p.Level[13] + 1 >= 100){
											player.addStat(MarkAchievements.AR100, 1);
											if(p.Level[13] + 1 >= 125){
												player.addStat(MarkAchievements.AR125, 1); 
												if(p.Level[13] + 1 >= 150){
													player.addStat(MarkAchievements.AR150, 1);
													if(p.Level[13] + 1 >= 175){
														player.addStat(MarkAchievements.AR175, 1); 
														if(p.Level[13] + 1 >= 200){
															player.addStat(MarkAchievements.AR200, 1);
															if(p.Level[13] + 1 >= 201){
																player.addStat(MarkAchievements.AR201, 1);
																if(p.Level[13] + 1 >= 220){
																	player.addStat(MarkAchievements.AR220, 1);
																	if(p.Level[13] + 1 >= 240){
																		player.addStat(MarkAchievements.AR240, 1);
																		if(p.Level[13] + 1 >= 250){
																			player.addStat(MarkAchievements.AR250, 1);
																			if(p.Level[13] + 1 >= 255){
																				player.addStat(MarkAchievements.ARMAX, 1);
				}}}}}}}}}}}}}}}}
		 else if(SkillID == 14){
			 if(p.Level[14] + 1 >= 2){
				 player.addStat(MarkAchievements.TA2, 1); 
					if(p.Level[14] + 1 >= 25){
						player.addStat(MarkAchievements.TA25, 1); 
						if(p.Level[14] + 1 >= 50){
							player.addStat(MarkAchievements.TA50, 1); 
							if(p.Level[14] + 1 >= 75){
								player.addStat(MarkAchievements.TA75, 1); 
								if(p.Level[14] + 1 >= 99){
									player.addStat(MarkAchievements.TA99, 1); 
									if(p.Level[14] + 1 >= 100){
										player.addStat(MarkAchievements.TA100, 1);
										if(p.Level[14] + 1 >= 125){
											player.addStat(MarkAchievements.TA125, 1); 
											if(p.Level[14] + 1 >= 150){
												player.addStat(MarkAchievements.TA150, 1);
												if(p.Level[14] + 1 >= 175){
													player.addStat(MarkAchievements.TA175, 1); 
													if(p.Level[14] + 1 >= 200){
														player.addStat(MarkAchievements.TA200, 1);
														if(p.Level[14] + 1 >= 201){
															player.addStat(MarkAchievements.TA201, 1);
															if(p.Level[14] + 1 >= 220){
																player.addStat(MarkAchievements.TA220, 1);
																if(p.Level[14] + 1 >= 240){
																	player.addStat(MarkAchievements.TA240, 1);
																	if(p.Level[14] + 1 >= 250){
																		player.addStat(MarkAchievements.TA250, 1);
																		if(p.Level[14] + 1 >= 255){
																			player.addStat(MarkAchievements.TAMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 15){
			 if(p.Level[15] + 1 >= 2){
				 player.addStat(MarkAchievements.SM2, 1); 
					if(p.Level[15] + 1 >= 25){
						player.addStat(MarkAchievements.SM25, 1); 
						if(p.Level[15] + 1 >= 50){
							player.addStat(MarkAchievements.SM50, 1); 
							if(p.Level[15] + 1 >= 75){
								player.addStat(MarkAchievements.SM75, 1); 
								if(p.Level[15] + 1 >= 99){
									player.addStat(MarkAchievements.SM99, 1); 
									if(p.Level[15] + 1 >= 100){
										player.addStat(MarkAchievements.SM100, 1);
										if(p.Level[15] + 1 >= 125){
											player.addStat(MarkAchievements.SM125, 1); 
											if(p.Level[15] + 1 >= 150){
												player.addStat(MarkAchievements.SM150, 1);
												if(p.Level[15] + 1 >= 175){
													player.addStat(MarkAchievements.SM175, 1); 
													if(p.Level[15] + 1 >= 200){
														player.addStat(MarkAchievements.SM200, 1);
														if(p.Level[15] + 1 >= 201){
															player.addStat(MarkAchievements.SM201, 1);
															if(p.Level[15] + 1 >= 220){
																player.addStat(MarkAchievements.SM220, 1);
																if(p.Level[15] + 1 >= 240){
																	player.addStat(MarkAchievements.SM240, 1);
																	if(p.Level[15] + 1 >= 250){
																		player.addStat(MarkAchievements.SM250, 1);
																		if(p.Level[15] + 1 >= 255){
																			player.addStat(MarkAchievements.SMMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 16){
			 if(p.Level[16] + 1 >= 2){
				 player.addStat(MarkAchievements.TN2, 1); 
					if(p.Level[16] + 1 >= 25){
						player.addStat(MarkAchievements.TN25, 1); 
						if(p.Level[16] + 1 >= 50){
							player.addStat(MarkAchievements.TN50, 1); 
							if(p.Level[16] + 1 >= 75){
								player.addStat(MarkAchievements.TN75, 1); 
								if(p.Level[16] + 1 >= 99){
									player.addStat(MarkAchievements.TN99, 1); 
									if(p.Level[16] + 1 >= 100){
										player.addStat(MarkAchievements.TN100, 1);
										if(p.Level[16] + 1 >= 125){
											player.addStat(MarkAchievements.TN125, 1); 
											if(p.Level[16] + 1 >= 150){
												player.addStat(MarkAchievements.TN150, 1);
												if(p.Level[16] + 1 >= 175){
													player.addStat(MarkAchievements.TN175, 1); 
													if(p.Level[16] + 1 >= 200){
														player.addStat(MarkAchievements.TN200, 1);
														if(p.Level[16] + 1 >= 201){
															player.addStat(MarkAchievements.TN201, 1);
															if(p.Level[16] + 1 >= 220){
																player.addStat(MarkAchievements.TN220, 1);
																if(p.Level[16] + 1 >= 240){
																	player.addStat(MarkAchievements.TN240, 1);
																	if(p.Level[16] + 1 >= 250){
																		player.addStat(MarkAchievements.TN250, 1);
																		if(p.Level[16] + 1 >= 255){
																			player.addStat(MarkAchievements.TNMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 17){
			 if(p.Level[17] + 1 >= 2){
					 player.addStat(MarkAchievements.JE2, 1); 
						if(p.Level[17] + 1 >= 25){
							player.addStat(MarkAchievements.JE25, 1); 
							if(p.Level[17] + 1 >= 50){
								player.addStat(MarkAchievements.JE50, 1); 
								if(p.Level[17] + 1 >= 75){
									player.addStat(MarkAchievements.JE75, 1); 
									if(p.Level[17] + 1 >= 99){
										player.addStat(MarkAchievements.JE99, 1); 
										if(p.Level[17] + 1 >= 100){
											player.addStat(MarkAchievements.JE100, 1);
											if(p.Level[17] + 1 >= 125){
												player.addStat(MarkAchievements.JE125, 1); 
												if(p.Level[17] + 1 >= 150){
													player.addStat(MarkAchievements.JE150, 1);
													if(p.Level[17] + 1 >= 175){
														player.addStat(MarkAchievements.JE175, 1); 
														if(p.Level[17] + 1 >= 200){
															player.addStat(MarkAchievements.JE200, 1);
															if(p.Level[17] + 1 >= 201){
																player.addStat(MarkAchievements.JE201, 1);
																if(p.Level[17] + 1 >= 220){
																	player.addStat(MarkAchievements.JE220, 1);
																	if(p.Level[17] + 1 >= 240){
																		player.addStat(MarkAchievements.JE240, 1);
																		if(p.Level[17] + 1 >= 250){
																			player.addStat(MarkAchievements.JE250, 1);
																			if(p.Level[17] + 1 >= 255){
																				player.addStat(MarkAchievements.JEMAX, 1);
				}}}}}}}}}}}}}}}}
		 else if(SkillID == 18){
			 if(p.Level[18] + 1 >= 2){
				 player.addStat(MarkAchievements.FL2, 1); 
					if(p.Level[18] + 1 >= 25){
						player.addStat(MarkAchievements.FL25, 1); 
						if(p.Level[18] + 1 >= 50){
							player.addStat(MarkAchievements.FL50, 1); 
							if(p.Level[18] + 1 >= 75){
								player.addStat(MarkAchievements.FL75, 1); 
								if(p.Level[18] + 1 >= 99){
									player.addStat(MarkAchievements.FL99, 1); 
									if(p.Level[18] + 1 >= 100){
										player.addStat(MarkAchievements.FL100, 1);
										if(p.Level[18] + 1 >= 125){
											player.addStat(MarkAchievements.FL125, 1); 
											if(p.Level[18] + 1 >= 150){
												player.addStat(MarkAchievements.FL150, 1);
												if(p.Level[18] + 1 >= 175){
													player.addStat(MarkAchievements.FL175, 1); 
													if(p.Level[18] + 1 >= 200){
														player.addStat(MarkAchievements.FL200, 1);
														if(p.Level[18] + 1 >= 201){
															player.addStat(MarkAchievements.FL201, 1);
															if(p.Level[18] + 1 >= 220){
																player.addStat(MarkAchievements.FL220, 1);
																if(p.Level[18] + 1 >= 240){
																	player.addStat(MarkAchievements.FL240, 1);
																	if(p.Level[18] + 1 >= 250){
																		player.addStat(MarkAchievements.FL250, 1);
																		if(p.Level[18] + 1 >= 255){
																			player.addStat(MarkAchievements.FLMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 19){
			 if(p.Level[19] + 1 >= 2){
				 player.addStat(MarkAchievements.CO2, 1); 
					if(p.Level[19] + 1 >= 25){
						player.addStat(MarkAchievements.CO25, 1); 
						if(p.Level[19] + 1 >= 50){
							player.addStat(MarkAchievements.CO50, 1); 
							if(p.Level[19] + 1 >= 75){
								player.addStat(MarkAchievements.CO75, 1); 
								if(p.Level[19] + 1 >= 99){
									player.addStat(MarkAchievements.CO99, 1); 
									if(p.Level[19] + 1 >= 100){
										player.addStat(MarkAchievements.CO100, 1);
										if(p.Level[19] + 1 >= 125){
											player.addStat(MarkAchievements.CO125, 1); 
											if(p.Level[19] + 1 >= 150){
												player.addStat(MarkAchievements.CO150, 1);
												if(p.Level[19] + 1 >= 175){
													player.addStat(MarkAchievements.CO175, 1); 
													if(p.Level[19] + 1 >= 200){
														player.addStat(MarkAchievements.CO200, 1);
														if(p.Level[19] + 1 >= 201){
															player.addStat(MarkAchievements.CO201, 1);
															if(p.Level[19] + 1 >= 220){
																player.addStat(MarkAchievements.CO220, 1);
																if(p.Level[19] + 1 >= 240){
																	player.addStat(MarkAchievements.CO240, 1);
																	if(p.Level[19] + 1 >= 250){
																		player.addStat(MarkAchievements.CO250, 1);
																		if(p.Level[19] + 1 >= 255){
																			player.addStat(MarkAchievements.COMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 20){
			 if(p.Level[20] + 1 >= 2){
				 player.addStat(MarkAchievements.HE2, 1); 
					if(p.Level[20] + 1 >= 25){
						player.addStat(MarkAchievements.HE25, 1); 
						if(p.Level[20] + 1 >= 50){
							player.addStat(MarkAchievements.HE50, 1); 
							if(p.Level[20] + 1 >= 75){
								player.addStat(MarkAchievements.HE75, 1); 
								if(p.Level[20] + 1 >= 99){
									player.addStat(MarkAchievements.HE99, 1); 
									if(p.Level[20] + 1 >= 100){
										player.addStat(MarkAchievements.HE100, 1);
										if(p.Level[20] + 1 >= 125){
											player.addStat(MarkAchievements.HE125, 1); 
											if(p.Level[20] + 1 >= 150){
												player.addStat(MarkAchievements.HE150, 1);
												if(p.Level[20] + 1 >= 175){
													player.addStat(MarkAchievements.HE175, 1); 
													if(p.Level[20] + 1 >= 200){
														player.addStat(MarkAchievements.HE200, 1);
														if(p.Level[20] + 1 >= 201){
															player.addStat(MarkAchievements.HE201, 1);
															if(p.Level[20] + 1 >= 220){
																player.addStat(MarkAchievements.HE220, 1);
																if(p.Level[20] + 1 >= 240){
																	player.addStat(MarkAchievements.HE240, 1);
																	if(p.Level[20] + 1 >= 250){
																		player.addStat(MarkAchievements.HE250, 1);
																		if(p.Level[20] + 1 >= 255){
																			player.addStat(MarkAchievements.HEMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 21){
			 if(p.Level[21] + 1 >= 2){
				 player.addStat(MarkAchievements.HO2, 1); 
					if(p.Level[21] + 1 >= 25){
						player.addStat(MarkAchievements.HO25, 1); 
						if(p.Level[21] + 1 >= 50){
							player.addStat(MarkAchievements.HO50, 1); 
							if(p.Level[21] + 1 >= 75){
								player.addStat(MarkAchievements.HO75, 1); 
								if(p.Level[21] + 1 >= 99){
									player.addStat(MarkAchievements.HO99, 1); 
									if(p.Level[21] + 1 >= 100){
										player.addStat(MarkAchievements.HO100, 1);
										if(p.Level[21] + 1 >= 125){
											player.addStat(MarkAchievements.HO125, 1); 
											if(p.Level[21] + 1 >= 150){
												player.addStat(MarkAchievements.HO150, 1);
												if(p.Level[21] + 1 >= 175){
													player.addStat(MarkAchievements.HO175, 1); 
													if(p.Level[21] + 1 >= 200){
														player.addStat(MarkAchievements.HO200, 1);
														if(p.Level[21] + 1 >= 201){
															player.addStat(MarkAchievements.HO201, 1);
															if(p.Level[21] + 1 >= 220){
																player.addStat(MarkAchievements.HO220, 1);
																if(p.Level[21] + 1 >= 240){
																	player.addStat(MarkAchievements.HO240, 1);
																	if(p.Level[21] + 1 >= 250){
																		player.addStat(MarkAchievements.HO250, 1);
																		if(p.Level[21] + 1 >= 255){
																			player.addStat(MarkAchievements.HOMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 22){
			 if(p.Level[22] + 1 >= 2){
				 player.addStat(MarkAchievements.CN2, 1); 
					if(p.Level[22] + 1 >= 25){
						player.addStat(MarkAchievements.CN25, 1); 
						if(p.Level[22] + 1 >= 50){
							player.addStat(MarkAchievements.CN50, 1); 
							if(p.Level[22] + 1 >= 75){
								player.addStat(MarkAchievements.CN75, 1); 
								if(p.Level[22] + 1 >= 99){
									player.addStat(MarkAchievements.CN99, 1); 
									if(p.Level[22] + 1 >= 100){
										player.addStat(MarkAchievements.CN100, 1);
										if(p.Level[22] + 1 >= 125){
											player.addStat(MarkAchievements.CN125, 1); 
											if(p.Level[22] + 1 >= 150){
												player.addStat(MarkAchievements.CN150, 1);
												if(p.Level[22] + 1 >= 175){
													player.addStat(MarkAchievements.CN175, 1); 
													if(p.Level[22] + 1 >= 200){
														player.addStat(MarkAchievements.CN200, 1);
														if(p.Level[22] + 1 >= 201){
															player.addStat(MarkAchievements.CN201, 1);
															if(p.Level[22] + 1 >= 220){
																player.addStat(MarkAchievements.CN220, 1);
																if(p.Level[22] + 1 >= 240){
																	player.addStat(MarkAchievements.CN240, 1);
																	if(p.Level[22] + 1 >= 250){
																		player.addStat(MarkAchievements.CN250, 1);
																		if(p.Level[22] + 1 >= 255){
																			player.addStat(MarkAchievements.CNMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 23){
			 if(p.Level[23] + 1 >= 2){
				 player.addStat(MarkAchievements.AG2, 1); 
					if(p.Level[23] + 1 >= 25){
						player.addStat(MarkAchievements.AG25, 1); 
						if(p.Level[23] + 1 >= 50){
							player.addStat(MarkAchievements.AG50, 1); 
							if(p.Level[23] + 1 >= 75){
								player.addStat(MarkAchievements.AG75, 1); 
								if(p.Level[23] + 1 >= 99){
									player.addStat(MarkAchievements.AG99, 1); 
									if(p.Level[23] + 1 >= 100){
										player.addStat(MarkAchievements.AG100, 1);
										if(p.Level[23] + 1 >= 125){
											player.addStat(MarkAchievements.AG125, 1); 
											if(p.Level[23] + 1 >= 150){
												player.addStat(MarkAchievements.AG150, 1);
												if(p.Level[23] + 1 >= 175){
													player.addStat(MarkAchievements.AG175, 1); 
													if(p.Level[23] + 1 >= 200){
														player.addStat(MarkAchievements.AG200, 1);
														if(p.Level[23] + 1 >= 201){
															player.addStat(MarkAchievements.AG201, 1);
															if(p.Level[23] + 1 >= 220){
																player.addStat(MarkAchievements.AG220, 1);
																if(p.Level[23] + 1 >= 240){
																	player.addStat(MarkAchievements.AG240, 1);
																	if(p.Level[23] + 1 >= 250){
																		player.addStat(MarkAchievements.AG250, 1);
																		if(p.Level[23] + 1 >= 255){
																			player.addStat(MarkAchievements.AGMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 24){
			 if(p.Level[24] + 1 >= 2){
				 player.addStat(MarkAchievements.DN2, 1); 
					if(p.Level[24] + 1 >= 25){
						player.addStat(MarkAchievements.DN25, 1); 
						if(p.Level[24] + 1 >= 50){
							player.addStat(MarkAchievements.DN50, 1); 
							if(p.Level[24] + 1 >= 75){
								player.addStat(MarkAchievements.DN75, 1); 
								if(p.Level[24] + 1 >= 99){
									player.addStat(MarkAchievements.DN99, 1); 
									if(p.Level[24] + 1 >= 100){
										player.addStat(MarkAchievements.DN100, 1);
										if(p.Level[24] + 1 >= 125){
											player.addStat(MarkAchievements.DN125, 1); 
											if(p.Level[24] + 1 >= 150){
												player.addStat(MarkAchievements.DN150, 1);
												if(p.Level[24] + 1 >= 175){
													player.addStat(MarkAchievements.DN175, 1); 
													if(p.Level[24] + 1 >= 200){
														player.addStat(MarkAchievements.DN200, 1);
														if(p.Level[24] + 1 >= 201){
															player.addStat(MarkAchievements.DN201, 1);
															if(p.Level[24] + 1 >= 220){
																player.addStat(MarkAchievements.DN220, 1);
																if(p.Level[24] + 1 >= 240){
																	player.addStat(MarkAchievements.DN240, 1);
																	if(p.Level[24] + 1 >= 250){
																		player.addStat(MarkAchievements.DN250, 1);
																		if(p.Level[24] + 1 >= 255){
																			player.addStat(MarkAchievements.DNMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 25){
			 if(p.Level[25] + 1 >= 2){
				 player.addStat(MarkAchievements.PC2, 1); 
					if(p.Level[25] + 1 >= 25){
						player.addStat(MarkAchievements.PC25, 1); 
						if(p.Level[25] + 1 >= 50){
							player.addStat(MarkAchievements.PC50, 1); 
							if(p.Level[25] + 1 >= 75){
								player.addStat(MarkAchievements.PC75, 1); 
								if(p.Level[25] + 1 >= 99){
									player.addStat(MarkAchievements.PC99, 1); 
									if(p.Level[25] + 1 >= 100){
										player.addStat(MarkAchievements.PC100, 1);
										if(p.Level[25] + 1 >= 125){
											player.addStat(MarkAchievements.PC125, 1); 
											if(p.Level[25] + 1 >= 150){
												player.addStat(MarkAchievements.PC150, 1);
												if(p.Level[25] + 1 >= 175){
													player.addStat(MarkAchievements.PC175, 1); 
													if(p.Level[25] + 1 >= 200){
														player.addStat(MarkAchievements.PC200, 1);
														if(p.Level[25] + 1 >= 201){
															player.addStat(MarkAchievements.PC201, 1);
															if(p.Level[25] + 1 >= 220){
																player.addStat(MarkAchievements.PC220, 1);
																if(p.Level[25] + 1 >= 240){
																	player.addStat(MarkAchievements.PC240, 1);
																	if(p.Level[25] + 1 >= 250){
																		player.addStat(MarkAchievements.PC250, 1);
																		if(p.Level[25] + 1 >= 255){
																			player.addStat(MarkAchievements.PCMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 26){
			 if(p.Level[26] + 1 >= 2){
				 player.addStat(MarkAchievements.LS2, 1); 
					if(p.Level[26] + 1 >= 25){
						player.addStat(MarkAchievements.LS25, 1); 
						if(p.Level[26] + 1 >= 50){
							player.addStat(MarkAchievements.LS50, 1); 
							if(p.Level[26] + 1 >= 75){
								player.addStat(MarkAchievements.LS75, 1); 
								if(p.Level[26] + 1 >= 99){
									player.addStat(MarkAchievements.LS99, 1); 
									if(p.Level[26] + 1 >= 100){
										player.addStat(MarkAchievements.LS100, 1);
										if(p.Level[26] + 1 >= 125){
											player.addStat(MarkAchievements.LS125, 1); 
											if(p.Level[26] + 1 >= 150){
												player.addStat(MarkAchievements.LS150, 1);
												if(p.Level[26] + 1 >= 175){
													player.addStat(MarkAchievements.LS175, 1); 
													if(p.Level[26] + 1 >= 200){
														player.addStat(MarkAchievements.LS200, 1);
														if(p.Level[26] + 1 >= 201){
															player.addStat(MarkAchievements.LS201, 1);
															if(p.Level[26] + 1 >= 220){
																player.addStat(MarkAchievements.LS220, 1);
																if(p.Level[26] + 1 >= 240){
																	player.addStat(MarkAchievements.LS240, 1);
																	if(p.Level[26] + 1 >= 250){
																		player.addStat(MarkAchievements.LS250, 1);
																		if(p.Level[26] + 1 >= 255){
																			player.addStat(MarkAchievements.LSMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 27){
			 if(p.Level[27] + 1 >= 2){
				 player.addStat(MarkAchievements.KW2, 1); 
					if(p.Level[27] + 1 >= 25){
						player.addStat(MarkAchievements.KW25, 1); 
						if(p.Level[27] + 1 >= 50){
							player.addStat(MarkAchievements.KW50, 1); 
							if(p.Level[27] + 1 >= 75){
								player.addStat(MarkAchievements.KW75, 1); 
								if(p.Level[27] + 1 >= 99){
									player.addStat(MarkAchievements.KW99, 1); 
									if(p.Level[27] + 1 >= 100){
										player.addStat(MarkAchievements.KW100, 1);
										if(p.Level[27] + 1 >= 125){
											player.addStat(MarkAchievements.KW125, 1); 
											if(p.Level[27] + 1 >= 150){
												player.addStat(MarkAchievements.KW150, 1);
												if(p.Level[27] + 1 >= 175){
													player.addStat(MarkAchievements.KW175, 1); 
													if(p.Level[27] + 1 >= 200){
														player.addStat(MarkAchievements.KW200, 1);
														if(p.Level[27] + 1 >= 201){
															player.addStat(MarkAchievements.KW201, 1);
															if(p.Level[27] + 1 >= 220){
																player.addStat(MarkAchievements.KW220, 1);
																if(p.Level[27] + 1 >= 240){
																	player.addStat(MarkAchievements.KW240, 1);
																	if(p.Level[27] + 1 >= 250){
																		player.addStat(MarkAchievements.KW250, 1);
																		if(p.Level[27] + 1 >= 255){
																			player.addStat(MarkAchievements.KWMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 28){
			 if(p.Level[28] + 1 >= 2){
				 player.addStat(MarkAchievements.TC2, 1); 
					if(p.Level[28] + 1 >= 25){
						player.addStat(MarkAchievements.TC25, 1); 
						if(p.Level[28] + 1 >= 50){
							player.addStat(MarkAchievements.TC50, 1); 
							if(p.Level[28] + 1 >= 75){
								player.addStat(MarkAchievements.TC75, 1); 
								if(p.Level[28] + 1 >= 99){
									player.addStat(MarkAchievements.TC99, 1); 
									if(p.Level[28] + 1 >= 100){
										player.addStat(MarkAchievements.TC100, 1);
										if(p.Level[28] + 1 >= 125){
											player.addStat(MarkAchievements.TC125, 1); 
											if(p.Level[28] + 1 >= 150){
												player.addStat(MarkAchievements.TC150, 1);
												if(p.Level[28] + 1 >= 175){
													player.addStat(MarkAchievements.TC175, 1); 
													if(p.Level[28] + 1 >= 200){
														player.addStat(MarkAchievements.TC200, 1);
														if(p.Level[28] + 1 >= 201){
															player.addStat(MarkAchievements.TC201, 1);
															if(p.Level[28] + 1 >= 220){
																player.addStat(MarkAchievements.TC220, 1);
																if(p.Level[28] + 1 >= 240){
																	player.addStat(MarkAchievements.TC240, 1);
																	if(p.Level[28] + 1 >= 250){
																		player.addStat(MarkAchievements.TC250, 1);
																		if(p.Level[28] + 1 >= 255){
																			player.addStat(MarkAchievements.TCMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 29){
			 if(p.Level[29] + 1 >= 2){
				 player.addStat(MarkAchievements.EG2, 1); 
					if(p.Level[29] + 1 >= 25){
						player.addStat(MarkAchievements.EG25, 1); 
						if(p.Level[29] + 1 >= 50){
							player.addStat(MarkAchievements.EG50, 1); 
							if(p.Level[29] + 1 >= 75){
								player.addStat(MarkAchievements.EG75, 1); 
								if(p.Level[29] + 1 >= 99){
									player.addStat(MarkAchievements.EG99, 1); 
									if(p.Level[29] + 1 >= 100){
										player.addStat(MarkAchievements.EG100, 1);
										if(p.Level[29] + 1 >= 125){
											player.addStat(MarkAchievements.EG125, 1); 
											if(p.Level[29] + 1 >= 150){
												player.addStat(MarkAchievements.EG150, 1);
												if(p.Level[29] + 1 >= 175){
													player.addStat(MarkAchievements.EG175, 1); 
													if(p.Level[29] + 1 >= 200){
														player.addStat(MarkAchievements.EG200, 1);
														if(p.Level[29] + 1 >= 201){
															player.addStat(MarkAchievements.EG201, 1);
															if(p.Level[29] + 1 >= 220){
																player.addStat(MarkAchievements.EG220, 1);
																if(p.Level[29] + 1 >= 240){
																	player.addStat(MarkAchievements.EG240, 1);
																	if(p.Level[29] + 1 >= 250){
																		player.addStat(MarkAchievements.EG250, 1);
																		if(p.Level[29] + 1 >= 255){
																			player.addStat(MarkAchievements.EGMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 30){
			 if(p.Level[30] + 1 >= 2){
				 player.addStat(MarkAchievements.CH2, 1); 
					if(p.Level[30] + 1 >= 25){
						player.addStat(MarkAchievements.CH25, 1); 
						if(p.Level[30] + 1 >= 50){
							player.addStat(MarkAchievements.CH50, 1); 
							if(p.Level[30] + 1 >= 75){
								player.addStat(MarkAchievements.CH75, 1); 
								if(p.Level[30] + 1 >= 99){
									player.addStat(MarkAchievements.CH99, 1); 
									if(p.Level[30] + 1 >= 100){
										player.addStat(MarkAchievements.CH100, 1);
										if(p.Level[30] + 1 >= 125){
											player.addStat(MarkAchievements.CH125, 1); 
											if(p.Level[30] + 1 >= 150){
												player.addStat(MarkAchievements.CH150, 1);
												if(p.Level[30] + 1 >= 175){
													player.addStat(MarkAchievements.CH175, 1); 
													if(p.Level[30] + 1 >= 200){
														player.addStat(MarkAchievements.CH200, 1);
														if(p.Level[30] + 1 >= 201){
															player.addStat(MarkAchievements.CH201, 1);
															if(p.Level[30] + 1 >= 220){
																player.addStat(MarkAchievements.CH220, 1);
																if(p.Level[30] + 1 >= 240){
																	player.addStat(MarkAchievements.CH240, 1);
																	if(p.Level[30] + 1 >= 250){
																		player.addStat(MarkAchievements.CH250, 1);
																		if(p.Level[30] + 1 >= 255){
																			player.addStat(MarkAchievements.CHMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 31){
			 if(p.Level[31] + 1 >= 2){
				 player.addStat(MarkAchievements.SP2, 1); 
					if(p.Level[31] + 1 >= 25){
						player.addStat(MarkAchievements.SP25, 1); 
						if(p.Level[31] + 1 >= 50){
							player.addStat(MarkAchievements.SP50, 1); 
							if(p.Level[31] + 1 >= 75){
								player.addStat(MarkAchievements.SP75, 1); 
								if(p.Level[31] + 1 >= 99){
									player.addStat(MarkAchievements.SP99, 1); 
									if(p.Level[31] + 1 >= 100){
										player.addStat(MarkAchievements.SP100, 1);
										if(p.Level[31] + 1 >= 125){
											player.addStat(MarkAchievements.SP125, 1); 
											if(p.Level[31] + 1 >= 150){
												player.addStat(MarkAchievements.SP150, 1);
												if(p.Level[31] + 1 >= 175){
													player.addStat(MarkAchievements.SP175, 1); 
													if(p.Level[31] + 1 >= 200){
														player.addStat(MarkAchievements.SP200, 1);
														if(p.Level[31] + 1 >= 201){
															player.addStat(MarkAchievements.SP201, 1);
															if(p.Level[31] + 1 >= 220){
																player.addStat(MarkAchievements.SP220, 1);
																if(p.Level[31] + 1 >= 240){
																	player.addStat(MarkAchievements.SP240, 1);
																	if(p.Level[31] + 1 >= 250){
																		player.addStat(MarkAchievements.SP250, 1);
																		if(p.Level[31] + 1 >= 255){
																			player.addStat(MarkAchievements.SPMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 32){
			 if(p.Level[32] + 1 >= 2){
				 player.addStat(MarkAchievements.MU2, 1); 
					if(p.Level[32] + 1 >= 25){
						player.addStat(MarkAchievements.MU25, 1); 
						if(p.Level[32] + 1 >= 50){
							player.addStat(MarkAchievements.MU50, 1); 
							if(p.Level[32] + 1 >= 75){
								player.addStat(MarkAchievements.MU75, 1); 
								if(p.Level[32] + 1 >= 99){
									player.addStat(MarkAchievements.MU99, 1); 
									if(p.Level[32] + 1 >= 100){
										player.addStat(MarkAchievements.MU100, 1);
										if(p.Level[32] + 1 >= 125){
											player.addStat(MarkAchievements.MU125, 1); 
											if(p.Level[32] + 1 >= 150){
												player.addStat(MarkAchievements.MU150, 1);
												if(p.Level[32] + 1 >= 175){
													player.addStat(MarkAchievements.MU175, 1); 
													if(p.Level[32] + 1 >= 200){
														player.addStat(MarkAchievements.MU200, 1);
														if(p.Level[32] + 1 >= 201){
															player.addStat(MarkAchievements.MU201, 1);
															if(p.Level[32] + 1 >= 220){
																player.addStat(MarkAchievements.MU220, 1);
																if(p.Level[32] + 1 >= 240){
																	player.addStat(MarkAchievements.MU240, 1);
																	if(p.Level[32] + 1 >= 250){
																		player.addStat(MarkAchievements.MU250, 1);
																		if(p.Level[32] + 1 >= 255){
																			player.addStat(MarkAchievements.MUMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 33){
			 if(p.Level[33] + 1 >= 2){
				 player.addStat(MarkAchievements.FI2, 1); 
					if(p.Level[33] + 1 >= 25){
						player.addStat(MarkAchievements.FI25, 1); 
						if(p.Level[33] + 1 >= 50){
							player.addStat(MarkAchievements.FI50, 1); 
							if(p.Level[33] + 1 >= 75){
								player.addStat(MarkAchievements.FI75, 1); 
								if(p.Level[33] + 1 >= 99){
									player.addStat(MarkAchievements.FI99, 1); 
									if(p.Level[33] + 1 >= 100){
										player.addStat(MarkAchievements.FI100, 1);
										if(p.Level[33] + 1 >= 125){
											player.addStat(MarkAchievements.FI125, 1); 
											if(p.Level[33] + 1 >= 150){
												player.addStat(MarkAchievements.FI150, 1);
												if(p.Level[33] + 1 >= 175){
													player.addStat(MarkAchievements.FI175, 1); 
													if(p.Level[33] + 1 >= 200){
														player.addStat(MarkAchievements.FI200, 1);
														if(p.Level[33] + 1 >= 201){
															player.addStat(MarkAchievements.FI201, 1);
															if(p.Level[33] + 1 >= 220){
																player.addStat(MarkAchievements.FI220, 1);
																if(p.Level[33] + 1 >= 240){
																	player.addStat(MarkAchievements.FI240, 1);
																	if(p.Level[33] + 1 >= 250){
																		player.addStat(MarkAchievements.FI250, 1);
																		if(p.Level[33] + 1 >= 255){
																			player.addStat(MarkAchievements.FIMAX, 1);
			}}}}}}}}}}}}}}}}
		 else if(SkillID == 34){
			 if(p.Level[34] + 1 >= 2){
				 player.addStat(MarkAchievements.FU2, 1); 
					if(p.Level[34] + 1 >= 25){
						player.addStat(MarkAchievements.FU25, 1); 
						if(p.Level[34] + 1 >= 50){
							player.addStat(MarkAchievements.FU50, 1); 
							if(p.Level[34] + 1 >= 75){
								player.addStat(MarkAchievements.FU75, 1); 
								if(p.Level[34] + 1 >= 99){
									player.addStat(MarkAchievements.FU99, 1); 
									if(p.Level[34] + 1 >= 100){
										player.addStat(MarkAchievements.FU100, 1);
										if(p.Level[34] + 1 >= 125){
											player.addStat(MarkAchievements.FU125, 1); 
											if(p.Level[34] + 1 >= 150){
												player.addStat(MarkAchievements.FU150, 1);
												if(p.Level[34] + 1 >= 175){
													player.addStat(MarkAchievements.FU175, 1); 
													if(p.Level[34] + 1 >= 200){
														player.addStat(MarkAchievements.FU200, 1);
														if(p.Level[34] + 1 >= 201){
															player.addStat(MarkAchievements.FU201, 1);
															if(p.Level[34] + 1 >= 220){
																player.addStat(MarkAchievements.FU220, 1);
																if(p.Level[34] + 1 >= 240){
																	player.addStat(MarkAchievements.FU240, 1);
																	if(p.Level[34] + 1 >= 250){
																		player.addStat(MarkAchievements.FU250, 1);
																		if(p.Level[34] + 1 >= 255){
																			player.addStat(MarkAchievements.FUMAX, 1);
			}}}}}}}}}}}}}}}}
			 
			if(p.Total >= 200){
				player.addStat(MarkAchievements.Total200, 1);
				if(p.Total >= 500){
					player.addStat(MarkAchievements.Total500, 1);
					if(p.Total >= 1000){
						player.addStat(MarkAchievements.Total1000, 1);
						if(p.Total >= 1500){
							player.addStat(MarkAchievements.Total1500, 1);
							if(p.Total >= 2000){
								player.addStat(MarkAchievements.Total2000, 1);
								if(p.Total >= 2500){
									player.addStat(MarkAchievements.Total2500, 1);
									if(p.Total >= 3000){
										player.addStat(MarkAchievements.Total3000, 1);
										if(p.Total >= 3500){
											player.addStat(MarkAchievements.Total3500, 1);
											if(p.Total >= 4000){
												player.addStat(MarkAchievements.Total4000, 1);
												if(p.Total >= 4500){
													player.addStat(MarkAchievements.Total4500, 1);
													if(p.Total >= 5000){
														player.addStat(MarkAchievements.Total5000, 1);
														if(p.Total >= 5500){
															player.addStat(MarkAchievements.Total5500, 1);
															if(p.Total >= 6000){
																player.addStat(MarkAchievements.Total6000, 1);
																if(p.Total >= 6500){
																	player.addStat(MarkAchievements.Total6500, 1);
																	if(p.Total >= 7000){
																		player.addStat(MarkAchievements.Total7000, 1);
																		if(p.Total >= 7500){
																			player.addStat(MarkAchievements.Total7500, 1);
																			if(p.Total >= 8000){
																				player.addStat(MarkAchievements.Total8000, 1);
																				if(p.Total >= 8200){
																					player.addStat(MarkAchievements.Total8200, 1);
																					if(p.Total >= 8400){
																						player.addStat(MarkAchievements.Total8400, 1);
																						if(p.Total >= 8500){
																							player.addStat(MarkAchievements.Total8500, 1);
																							if(p.Total >= 8600){
																								player.addStat(MarkAchievements.Total8600, 1);
																								if(p.Total >= 8700){
																									player.addStat(MarkAchievements.Total8700, 1);
																									if(p.Total >= 8800){
																										player.addStat(MarkAchievements.Total8800, 1);
																										if(p.Total >= 8900){
																											player.addStat(MarkAchievements.Total8900, 1);
																											if(p.Total >= 8925){
																												player.addStat(MarkAchievements.GrandMaster, 1);
																												
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			 
		 }

	
		
	 
	 public static class Storage implements Capability.IStorage<MarkData>
	    {

	        @Override
	        public NBTBase writeNBT(Capability<MarkData> capability, MarkData instance, EnumFacing side)
	        {
	            return null;
	        }

	        @Override
	        public void readNBT(Capability<MarkData> capability, MarkData instance, EnumFacing side, NBTBase nbt)
	        {

	        }

	    }
	 
	 public static class Factory implements Callable<MarkData>
	    {
	        @Override
	        public MarkData call() throws Exception
	        {
	            return null;
	        }
	    }
}

