package com.modMark.Skill;

import java.util.HashMap;
import java.util.Map;

import com.modMark.Item_Block.MarkBlocks;
import com.modMark.Item_Block.Block.BlockGemOres;
import com.modMark.Item_Block.Block.MarkHerbCrops;
import com.modMark.Item_Block.Block.MarkOre;

import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class MarkHashMaps {
	/** wraps skill ID and Materal together*/
	public static Map<Material, Integer> SkillMaterial = new HashMap<Material, Integer>();
	/** this gives the Requirement Level*/
	public static Map<Block, Integer> TaskBlockLevel = new HashMap<Block, Integer>();
	/** this gives the Xp to be added*/
	public static Map<IBlockState, Integer> TaskBlockXP = new HashMap<IBlockState, Integer>();
	public static Map<Block, Integer> TaskBlockXP2 = new HashMap<Block, Integer>();
	
	public static Map<Item, Integer> TaskItem = new HashMap<Item, Integer>();
	
	public static Map<Block, Float> BlockHardness = new HashMap<Block, Float>();
	public static Map<Block, Float> BlockResistance = new HashMap<Block, Float>();
	public static Map<Block, Integer> ToolLvl = new HashMap<Block, Integer>();
	
	
	public static Map<Item, Integer> ShovelTool = new HashMap<Item, Integer>();
	public static Map<Item, Integer> AxeTool = new HashMap<Item, Integer>();
	public static Map<Item, Integer> PickaxeTool = new HashMap<Item, Integer>();
	public static Map<Item, Integer> HoeTool = new HashMap<Item, Integer>();
	public static Map<Item, Integer> SwordTool = new HashMap<Item, Integer>();
	public static Map<Block, Integer> ToolBlockLevel = new HashMap<Block, Integer>();

	public static void BlockHashMaps(MarkData p){
		
		SkillMaterial.put(Material.VINE, 7);
		SkillMaterial.put(Material.PLANTS, 7);
		SkillMaterial.put(Material.ROCK, 8);
		SkillMaterial.put(MarkBlocks.Trap, 9);
		SkillMaterial.put(Material.SAND, 10);
		SkillMaterial.put(Material.GROUND, 10);
		SkillMaterial.put(Material.GRASS, 10);
		SkillMaterial.put(Material.WOOD, 11);
		SkillMaterial.put(Material.CACTUS, 11);
		
		//Farming
		
		TaskBlockLevel.put(Blocks.CARROTS, 10);
		TaskBlockLevel.put(Blocks.POTATOES, 20);
		TaskBlockLevel.put(MarkBlocks.OnionCrop, 40);
		TaskBlockLevel.put(MarkBlocks.TomatoCrop, 60);
		TaskBlockLevel.put(MarkBlocks.BlueberryCrop, 80);
		TaskBlockLevel.put(MarkBlocks.CommonCottonCrop, 20);
		TaskBlockLevel.put(MarkBlocks.GreenCottonCrop, 40);
		TaskBlockLevel.put(MarkBlocks.RedCottonCrop, 60);
		TaskBlockLevel.put(MarkBlocks.BlueCottonCrop, 80);
		TaskBlockLevel.put(MarkBlocks.RomarinCrop, 5);
		TaskBlockLevel.put(MarkBlocks.RaifortCrop, 12);
		TaskBlockLevel.put(MarkBlocks.CeleriCrop, 19);
		TaskBlockLevel.put(MarkBlocks.SarrietteCrop, 26);
		TaskBlockLevel.put(MarkBlocks.ArmoiseCrop, 33);
		TaskBlockLevel.put(MarkBlocks.CerfeuilCrop, 40);
		TaskBlockLevel.put(MarkBlocks.EstragonCrop, 47);
		TaskBlockLevel.put(MarkBlocks.NetherweedCrop, 54);
		TaskBlockLevel.put(MarkBlocks.FlameweedCrop, 61);
		TaskBlockLevel.put(MarkBlocks.BrutalRedCrop, 68);
		TaskBlockLevel.put(MarkBlocks.CrystweedCrop, 75);
		TaskBlockLevel.put(MarkBlocks.DarkCrystalCrop, 82);
		TaskBlockLevel.put(MarkBlocks.BrutalBlueCrop, 89);
		TaskBlockLevel.put(MarkBlocks.TallGrass40, 40);
		TaskBlockLevel.put(MarkBlocks.TallGrass60, 60);
		TaskBlockLevel.put(MarkBlocks.TallGrass80, 80);
		
		
		TaskBlockLevel.put(Blocks.COAL_ORE, 5);
		TaskBlockLevel.put(Blocks.EMERALD_ORE, 10);
		TaskBlockLevel.put(Blocks.IRON_ORE, 20);
		TaskBlockLevel.put(Blocks.LAPIS_ORE, 25);
		TaskBlockLevel.put(Blocks.GOLD_ORE, 30);
		TaskBlockLevel.put(Blocks.DIAMOND_ORE, 40);
		TaskBlockLevel.put(MarkBlocks.DiamondBush, 40);
		TaskBlockLevel.put(Blocks.REDSTONE_ORE, 45);
		TaskBlockLevel.put(Blocks.LIT_REDSTONE_ORE, 45);
		TaskBlockLevel.put(Blocks.REDSTONE_BLOCK, 45);
		TaskBlockLevel.put(Blocks.OBSIDIAN, 45);
		TaskBlockLevel.put(Blocks.NETHERRACK, 50);
		TaskBlockLevel.put(Blocks.NETHER_BRICK, 50);
		TaskBlockLevel.put(Blocks.QUARTZ_ORE, 55);
		TaskBlockLevel.put(Blocks.QUARTZ_BLOCK, 55);
		TaskBlockLevel.put(MarkBlocks.OreNetherite, 60);
		TaskBlockLevel.put(MarkBlocks.CrystRack, 75);
		TaskBlockLevel.put(MarkBlocks.OreCrystlium, 80);
		
		TaskBlockLevel.put(MarkBlocks.GemOpalOre, 5);
		TaskBlockLevel.put(Blocks.GRAVEL, 5);
		TaskBlockLevel.put(MarkBlocks.GemSapphireOre, 10);
		TaskBlockLevel.put(Blocks.SAND, 10);
		TaskBlockLevel.put(MarkBlocks.GemOlivineOre, 15);
		TaskBlockLevel.put(MarkBlocks.GemHyacinthOre, 20);
		TaskBlockLevel.put(MarkBlocks.GemTopazOre, 25);
		
		TaskBlockLevel.put(Blocks.MYCELIUM, 30);
		TaskBlockLevel.put(MarkBlocks.EnrichedGrass, 35);
		TaskBlockLevel.put(MarkBlocks.GemAmethystOre, 40);
		TaskBlockLevel.put(MarkBlocks.AmethystBush, 40);
		TaskBlockLevel.put(MarkBlocks.NetherSand, 50);
		TaskBlockLevel.put(Blocks.SOUL_SAND, 55);
		TaskBlockLevel.put(MarkBlocks.GemSiamOre, 60);
		TaskBlockLevel.put(MarkBlocks.CrystSand, 75);
		TaskBlockLevel.put(MarkBlocks.GemAquamarineOre, 80);
		TaskBlockLevel.put(MarkBlocks.Cyantinian, 90);
		
		TaskBlockLevel.put(Blocks.CACTUS, 10);
		TaskBlockLevel.put(Blocks.LOG2, 20);
		TaskBlockLevel.put(MarkBlocks.LogYew, 40);
		TaskBlockLevel.put(MarkBlocks.LogYew_Planks, 40);
		TaskBlockLevel.put(MarkBlocks.LogNetherBranch, 60);
		TaskBlockLevel.put(MarkBlocks.LogNetherBranch_Planks, 60);
		TaskBlockLevel.put(MarkBlocks.LogCrystWood, 80);
		TaskBlockLevel.put(MarkBlocks.LogCrystWood_Planks, 80);
		
		TaskBlockLevel.put(MarkBlocks.MarkTrap10, 10);
		TaskBlockLevel.put(MarkBlocks.MarkTrap20, 20);
		TaskBlockLevel.put(MarkBlocks.MarkTrap40, 40);
		TaskBlockLevel.put(MarkBlocks.MarkTrap60, 60);
		TaskBlockLevel.put(MarkBlocks.MarkTrap80, 80);
		
		//XP
		
		
		TaskBlockXP.put(Blocks.WHEAT.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 10);
		TaskBlockXP.put(Blocks.CARROTS.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 15);
		TaskBlockXP.put(Blocks.POTATOES.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 20);
		TaskBlockXP.put(MarkBlocks.OnionCrop.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 35);
		TaskBlockXP.put(MarkBlocks.TomatoCrop.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 50);
		TaskBlockXP.put(MarkBlocks.BlueberryCrop.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 70);
		TaskBlockXP.put(MarkBlocks.CommonCottonCrop.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 20);
		TaskBlockXP.put(MarkBlocks.GreenCottonCrop.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 35);
		TaskBlockXP.put(MarkBlocks.RedCottonCrop.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 50);
		TaskBlockXP.put(MarkBlocks.BlueCottonCrop.getDefaultState().withProperty(BlockCrops.AGE, Integer.valueOf(7)), 70);
		TaskBlockXP.put(MarkBlocks.AnethCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 20);
		TaskBlockXP.put(MarkBlocks.RomarinCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 27);
		TaskBlockXP.put(MarkBlocks.RaifortCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 34);
		TaskBlockXP.put(MarkBlocks.CeleriCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 41);
		TaskBlockXP.put(MarkBlocks.SarrietteCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 48);
		TaskBlockXP.put(MarkBlocks.ArmoiseCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 55);
		TaskBlockXP.put(MarkBlocks.CerfeuilCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 65);
		TaskBlockXP.put(MarkBlocks.EstragonCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 80);
		TaskBlockXP.put(MarkBlocks.NetherweedCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 95);
		TaskBlockXP.put(MarkBlocks.FlameweedCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 110);
		TaskBlockXP.put(MarkBlocks.BrutalRedCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 130);
		TaskBlockXP.put(MarkBlocks.CrystweedCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 150);
		TaskBlockXP.put(MarkBlocks.DarkCrystalCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 175);
		TaskBlockXP.put(MarkBlocks.BrutalBlueCrop.getDefaultState().withProperty(MarkHerbCrops.AGE, Integer.valueOf(7)), 200);
		
		TaskBlockXP2.put(Blocks.STONE, 8);
		TaskBlockXP2.put(Blocks.COBBLESTONE, 8);
		TaskBlockXP2.put(Blocks.SANDSTONE, 10);
		TaskBlockXP2.put(Blocks.COAL_ORE, 15);
		TaskBlockXP2.put(Blocks.EMERALD_ORE, 20);
		TaskBlockXP2.put(Blocks.IRON_ORE, 25);
		TaskBlockXP2.put(MarkBlocks.OreIron, 9);
		TaskBlockXP2.put(Blocks.LAPIS_ORE, 30);
		TaskBlockXP2.put(Blocks.GOLD_ORE, 40);
		TaskBlockXP2.put(MarkBlocks.OreGold, 12);
		TaskBlockXP2.put(Blocks.DIAMOND_ORE, 50);
		TaskBlockXP2.put(MarkBlocks.DiamondBush, 50);
		TaskBlockXP2.put(Blocks.REDSTONE_ORE, 60);
		TaskBlockXP2.put(Blocks.LIT_REDSTONE_ORE, 60);
		TaskBlockXP2.put(Blocks.OBSIDIAN, 90);
		TaskBlockXP2.put(Blocks.NETHERRACK, 35);
		TaskBlockXP2.put(Blocks.NETHER_BRICK, 35);
		TaskBlockXP2.put(Blocks.QUARTZ_ORE, 70);
		TaskBlockXP2.put(Blocks.QUARTZ_BLOCK, 26);
		TaskBlockXP.put(MarkBlocks.OreNetherite.getDefaultState().withProperty(MarkOre.Natural, true), 80);
		TaskBlockXP.put(MarkBlocks.OreNetherite.getDefaultState().withProperty(MarkOre.Natural, false), 32);
		TaskBlockXP2.put(MarkBlocks.CrystRack, 45);
		TaskBlockXP.put(MarkBlocks.OreCrystlium.getDefaultState().withProperty(MarkOre.Natural, true), 90);
		TaskBlockXP.put(MarkBlocks.OreCrystlium.getDefaultState().withProperty(MarkOre.Natural, false), 40);
		
		TaskBlockXP2.put(Blocks.DIRT, 5);
		TaskBlockXP2.put(Blocks.GRASS, 5);
		TaskBlockXP.put(MarkBlocks.GemOpalOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 15);
		TaskBlockXP.put(MarkBlocks.GemOpalOre.getDefaultState().withProperty(BlockGemOres.Natural, false), 3);
		TaskBlockXP2.put(Blocks.GRAVEL, 7);
		TaskBlockXP.put(MarkBlocks.GemSapphireOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 20);
		TaskBlockXP.put(MarkBlocks.GemSapphireOre.getDefaultState().withProperty(BlockGemOres.Natural, false), 4);
		TaskBlockXP2.put(Blocks.SAND, 9);
		TaskBlockXP.put(MarkBlocks.GemOlivineOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 25);
		TaskBlockXP.put(MarkBlocks.GemOlivineOre.getDefaultState().withProperty(BlockGemOres.Natural, false), 5);
		TaskBlockXP.put(MarkBlocks.GemHyacinthOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 30);
		TaskBlockXP.put(MarkBlocks.GemHyacinthOre.getDefaultState().withProperty(BlockGemOres.Natural, false), 7);
		TaskBlockXP.put(MarkBlocks.GemTopazOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 35);
		TaskBlockXP.put(MarkBlocks.GemTopazOre.getDefaultState().withProperty(BlockGemOres.Natural, false), 10);
		TaskBlockXP2.put(Blocks.MYCELIUM, 28);
		TaskBlockXP2.put(MarkBlocks.EnrichedGrass, 30);
		TaskBlockXP.put(MarkBlocks.GemAmethystOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 50);
		TaskBlockXP.put(MarkBlocks.GemAmethystOre.getDefaultState().withProperty(BlockGemOres.Natural, false), 15);
		TaskBlockXP2.put(MarkBlocks.AmethystBush, 50);
		TaskBlockXP2.put(MarkBlocks.NetherSand, 35);
		TaskBlockXP2.put(Blocks.SOUL_SAND, 38);
		TaskBlockXP.put(MarkBlocks.GemSiamOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 80);
		TaskBlockXP.put(MarkBlocks.GemSiamOre.getDefaultState().withProperty(BlockGemOres.Natural, false), 25);
		TaskBlockXP2.put(MarkBlocks.CrystSand, 45);
		TaskBlockXP.put(MarkBlocks.GemAquamarineOre.getDefaultState().withProperty(BlockGemOres.Natural, true), 90);
		TaskBlockXP.put(MarkBlocks.GemAquamarineOre.getDefaultState().withProperty(BlockGemOres.Natural, false), 35);
		TaskBlockXP2.put(MarkBlocks.Cyantinian, 120);
		
		TaskBlockXP2.put(Blocks.LOG, 10);
		TaskBlockXP2.put(Blocks.PLANKS, 7);
		TaskBlockXP2.put(Blocks.CACTUS, 15);
		TaskBlockXP2.put(Blocks.LOG2, 20);
		TaskBlockXP2.put(MarkBlocks.LogYew, 30);
		TaskBlockXP2.put(MarkBlocks.LogNetherBranch, 45);
		TaskBlockXP2.put(MarkBlocks.LogCrystWood, 60);
		
		TaskBlockXP2.put(MarkBlocks.MarkTrap01, 25);
		TaskBlockXP2.put(MarkBlocks.MarkTrap10, 45);
		TaskBlockXP2.put(MarkBlocks.MarkTrap20, 85);
		TaskBlockXP2.put(MarkBlocks.MarkTrap40, 125);
		TaskBlockXP2.put(MarkBlocks.MarkTrap60, 160);
		TaskBlockXP2.put(MarkBlocks.MarkTrap80, 200);
		

		ToolBlockLevel.put(MarkBlocks.GemOpalOre, 0);
		ToolBlockLevel.put(MarkBlocks.GemSapphireOre, 0);
		ToolBlockLevel.put(MarkBlocks.GemOlivineOre, 1);
		ToolBlockLevel.put(MarkBlocks.GemHyacinthOre, 1);
		ToolBlockLevel.put(MarkBlocks.GemTopazOre, 1);
		ToolBlockLevel.put(MarkBlocks.GemAmethystOre, 2);
		ToolBlockLevel.put(MarkBlocks.GemSiamOre, 3);
		ToolBlockLevel.put(MarkBlocks.GemAquamarineOre, 3); //will be lvl 4 in the future
		
		ToolBlockLevel.put(MarkBlocks.OreIron, 1);
		ToolBlockLevel.put(MarkBlocks.OreGold, 2);
		ToolBlockLevel.put(MarkBlocks.OreNetherite, 3);
		ToolBlockLevel.put(MarkBlocks.OreCrystlium, 3); //will be lvl 4 in the future
		
		
		ToolBlockLevel.put(MarkBlocks.EnrichedGrass, 2);
		
		ToolBlockLevel.put(MarkBlocks.NetherSand, 2);
		ToolBlockLevel.put(MarkBlocks.CrystSand, 3);
		ToolBlockLevel.put(MarkBlocks.Cyantinian, 3); // will be lvl 5 in the future
		
		ToolBlockLevel.put(MarkBlocks.LogYew, 2);
		ToolBlockLevel.put(MarkBlocks.LogYew_Planks, 2);
		ToolBlockLevel.put(MarkBlocks.LogNetherBranch, 3);
		ToolBlockLevel.put(MarkBlocks.LogNetherBranch_Planks, 3);
		ToolBlockLevel.put(MarkBlocks.LogCrystWood, 3); //will be lvl 4 in the future
		ToolBlockLevel.put(MarkBlocks.LogCrystWood_Planks, 3); //will be lvl 4 in the future
		
		
		ShovelTool.put(Items.WOODEN_SHOVEL, 0);
		ShovelTool.put(Items.GOLDEN_SHOVEL, 0);
		ShovelTool.put(Items.STONE_SHOVEL, 1);
		ShovelTool.put(Items.IRON_SHOVEL, 2);
		ShovelTool.put(Items.DIAMOND_SHOVEL, 3);
		
		AxeTool.put(Items.WOODEN_AXE, 0);
		AxeTool.put(Items.GOLDEN_AXE, 0);
		AxeTool.put(Items.STONE_AXE, 1);
		AxeTool.put(Items.IRON_AXE, 2);
		AxeTool.put(Items.DIAMOND_AXE, 3);
		
		PickaxeTool.put(Items.WOODEN_PICKAXE, 0);
		PickaxeTool.put(Items.GOLDEN_PICKAXE, 0);
		PickaxeTool.put(Items.STONE_PICKAXE, 1);
		PickaxeTool.put(Items.IRON_PICKAXE, 2);
		PickaxeTool.put(Items.DIAMOND_PICKAXE, 3);
		
		HoeTool.put(Items.WOODEN_HOE, 0);
		HoeTool.put(Items.GOLDEN_HOE, 0);
		HoeTool.put(Items.STONE_HOE, 1);
		HoeTool.put(Items.IRON_HOE, 2);
		HoeTool.put(Items.DIAMOND_HOE, 3);
		
		SwordTool.put(Items.WOODEN_SWORD, 0);
		SwordTool.put(Items.GOLDEN_SWORD, 0);
		SwordTool.put(Items.STONE_SWORD, 1);
		SwordTool.put(Items.IRON_SWORD, 2);
		SwordTool.put(Items.DIAMOND_SWORD, 3);
		
	}
	
	public void RunnableItemList(MarkData p){
		
	}
	
	public static void ToolLevel(){
		
		
		
		
		
	}
	
	
}
